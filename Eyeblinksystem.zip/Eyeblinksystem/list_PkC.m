% Make the final package of all trace-only recording sessions grouped by modulation type after making
% all data of each session into a package with pckg_all function. --Zhong

listing = dir('pack_*');

list_PC=struct('cell_ID',[],'file_name',[],'cell_num',[],'CR_fac_sps',[],'CR_sup_sps',[],'UR_fac_sps',[],'UR_sup_sps',[],'mod_info_sps',[],'all_info_sps',[],...
    'CR_fac_cps',[],'CR_sup_cps',[],'UR_fac_cps',[],'UR_sup_cps',[],'mod_info_cps',[],'all_info_cps',[]);

cell_ID=1;
% first loop for each recording session
for i=1:size(listing,1)
    load(listing(i).name);
%   second loop for each cell
    for j=1:size(package.mod_tp_sps,2)
       list_PC(cell_ID).cell_ID=cell_ID;
       list_PC(cell_ID).file_name=listing(i).name; 
       list_PC(cell_ID).cell_num=package.mod_tp_sps(j).cell_ch; 
       list_PC(cell_ID).CR_fac_sps=package.mod_tp_sps(j).CR_trial.CR_fac; 
       list_PC(cell_ID).CR_sup_sps=package.mod_tp_sps(j).CR_trial.CR_sup; 
       list_PC(cell_ID).UR_fac_sps=package.mod_tp_sps(j).CR_trial.UR_fac; 
       list_PC(cell_ID).UR_sup_sps=package.mod_tp_sps(j).CR_trial.UR_sup;
       list_PC(cell_ID).mod_info_sps=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
           list_PC(cell_ID).mod_info_sps.CRf=package.mod_tp_sps(j).CR_trial.CR_fac_info;
           list_PC(cell_ID).mod_info_sps.CRs=package.mod_tp_sps(j).CR_trial.CR_sup_info;
           list_PC(cell_ID).mod_info_sps.URf=package.mod_tp_sps(j).CR_trial.UR_fac_info;
           list_PC(cell_ID).mod_info_sps.URs=package.mod_tp_sps(j).CR_trial.UR_sup_info;
       list_PC(cell_ID).all_info_sps=struct('sss_all',[],'ttt',[]);
           list_PC(cell_ID).all_info_sps.sss_all=struct('blk',[],'behavior',[],'psth',[]);
               list_PC(cell_ID).all_info_sps.sss_all.blk=package.blk_avg;
               list_PC(cell_ID).all_info_sps.sss_all.behavior=package.behavior_table;
               list_PC(cell_ID).all_info_sps.sss_all.psth=package.psth_sps(j);
           list_PC(cell_ID).all_info_sps.ttt=package.ttt_sps(j);
       
       for k=1:size(package.mod_tp_cps,2)
           if package.mod_tp_cps(k).cell_ch==package.mod_tp_sps(j).cell_ch
               list_PC(cell_ID).CR_fac_cps=package.mod_tp_cps(k).CR_trial.CR_fac; 
               list_PC(cell_ID).CR_sup_cps=package.mod_tp_cps(k).CR_trial.CR_sup; 
               list_PC(cell_ID).UR_fac_cps=package.mod_tp_cps(k).CR_trial.UR_fac; 
               list_PC(cell_ID).UR_sup_cps=package.mod_tp_cps(k).CR_trial.UR_sup;
               list_PC(cell_ID).mod_info_cps=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
                   list_PC(cell_ID).mod_info_cps.CRf=package.mod_tp_cps(k).CR_trial.CR_fac_info;
                   list_PC(cell_ID).mod_info_cps.CRs=package.mod_tp_cps(k).CR_trial.CR_sup_info;
                   list_PC(cell_ID).mod_info_cps.URf=package.mod_tp_cps(k).CR_trial.UR_fac_info;
                   list_PC(cell_ID).mod_info_cps.URs=package.mod_tp_cps(k).CR_trial.UR_sup_info;
               list_PC(cell_ID).all_info_cps=struct('sss_all',[],'ttt',[]);
                   list_PC(cell_ID).all_info_cps.sss_all=struct('blk',[],'behavior',[],'psth',[]);
                       list_PC(cell_ID).all_info_cps.sss_all.blk=package.blk_avg;
                       list_PC(cell_ID).all_info_cps.sss_all.behavior=package.behavior_table;
                       list_PC(cell_ID).all_info_cps.sss_all.psth=package.psth_cps(k);
                   list_PC(cell_ID).all_info_cps.ttt=package.ttt_cps(k);               
           end
       end
           
           
       cell_ID=cell_ID+1;

       

    end
end