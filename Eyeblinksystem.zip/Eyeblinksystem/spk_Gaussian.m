%To make each of single spike in each single trial as an Gaussian
%distribution to smooth the curve. The data resorce is tas which contains 
% the JRClust sorting results. The final_window = window_here*2+1. The
%larger the sigma is the more compacted of each Gaussian curve.  --Zhong


function spk_Gau=spk_Gaussian(tas,t_pre,t_post,window,sigma)

if isempty(tas)
   spk_Gau=[];
   return
end

spk_Gau_all(size(tas,2))=struct('cell',[],'spk_Gau_cell',[]);

% First loop for each cell
for i=1:size(tas,2)
    spk_Gau_cell(size(tas(i).tss,2))=struct('trial',[],'spk_Gau_trial',[]);
    
%     Second loop for each trial in this neuron
    for j=1:size(tas(i).tss,2)
        spk_Gau_trial=zeros((t_pre+t_post)*20+1,3);
        spk_Gau_trial(:,1)=(-t_pre:0.05:t_post);
        
%         Third loop for each single spike and to produce Gaussian curve
        for k=1:length(tas(i).tss(j).t)          
            t_spk=tas(i).tss(j).t(k)*1000;
            if t_spk+window > -t_pre && t_spk+window <= t_post
                x=(t_spk-window):0.05:(t_spk+window);
                y=gaussmf(x,[sigma t_spk])/(sigma*sqrt(2*pi));

    %           Add the Gaussian value back to each time point in three
    %           situations
                if t_spk-window < -t_pre
                    [~,idx]=min(abs(spk_Gau_trial(:,1)-t_spk));
                    t=idx;
                    spk_Gau_trial(t,3)=k;
                    [~,idx]=min(abs(x+t_pre));
                    tt=idx;
    %                 tt=find(x==-t_pre,1,'first');
                    for m=tt:(length(x)-tt+1)
                        spk_Gau_trial(m-tt+1,2)=spk_Gau_trial(m-tt+1,2)+y(m);
                    end

                elseif t_spk+window > t_post
                    [~,idx]=min(abs(spk_Gau_trial(:,1)-t_spk+window));
                    t=idx;
    %                 t=find(spk_Gau_trial(:,1)==t_spk-window,1,'first');
                    spk_Gau_trial(t+window/0.05,3)=k;
                    [~,idx]=min(abs(x-t_post));
                    tt=idx;
    %                 tt=find(x==t_post,1,'first');
                    for m=1:tt
                        spk_Gau_trial(t+m-1,2)=spk_Gau_trial(t+m-1,2)+y(m);
                    end

                elseif t_spk-window >= -t_pre && t_spk+window <= t_post
                    [~,idx]=min(abs(spk_Gau_trial(:,1)-t_spk+window));
                    t=idx;
    %                 t=find(spk_Gau_trial(:,1)==t_spk-window,1,'first');
                    spk_Gau_trial(t+window/0.05,3)=k;
                    for m=1:length(x)
                        spk_Gau_trial(t+m-1,2)=spk_Gau_trial(t+m-1,2)+y(m);
                    end
                end
            end
        end
        spk_Gau_cell(j).trial=j;
        spk_Gau_cell(j).spk_Gau_trial=spk_Gau_trial;
    end
    spk_Gau_all(i).cell=i;
    spk_Gau_all(i).spk_Gau_cell=spk_Gau_cell;
end
    spk_Gau=spk_Gau_all;
end