function velo_trial=velocity_cal(velo_raw,t_pre,t_post,t_psth,trg,bin,step,r)

t_pre=t_pre/1000;
t_post=t_post/1000;
t_psth=t_psth/1000;
bin=bin/1000;
step=step/1000;
r=r/100;

velo_trial=struct('nr',[],'t_trg',[],'info',[],'raw',[],'avg_velo',[],'peak_velo',[]);

for k=1:size(trg,2)    
    if ~isempty(trg(k).nr)
    %     velo_trial(k).trial=trg(k).nr;
        velo_trial(k).nr=trg(k).nr;
        velo_trial(k).t_trg=trg(k).t;
    %     t_0=find(t_sys==trg(k).t,1,'first');
        info=zeros((t_pre+t_psth-bin)/step+1,2);
        velo_raw_trial=velo_raw([velo_raw.t]> trg(k).t-t_pre & [velo_raw.t]<= trg(k).t+t_psth);
        for i=1:(t_pre+t_psth-bin)/step+1
            info(i,1)=-t_pre+bin/2+(i-1)*step;
            t_find_1=trg(k).t-t_pre+(i-1)*step;
            t_find_2=trg(k).t-t_pre+bin+(i-1)*step;
%             t_range=[velo_raw_trial([velo_raw.t]> t_find_1 & [velo_raw.t]<= t_find_2).dir];
            if ~isempty(velo_raw_trial)
                t_1=find([velo_raw_trial.t] > t_find_1,1,'first');
                t_2=find([velo_raw_trial.t] <= t_find_2,1,'last');
                if t_2>=t_1
                   info(i,2)=sum([velo_raw_trial(t_1:t_2).dir])*2*pi*r/(1024*bin);      
                else
                   info(i,2)=0;
                end
            end
%             if ~isempty(t_range)
%                info(i,2)=sum(t_range)*2*pi*r/(1024*bin);  
%             else
%                info(i,2)=0; 
%             end
            
        end
        velo_trial(k).info=info;
        velo_trial(k).raw=velo_raw_trial;
        velo_trial(k).avg_velo=mean(info(1:((t_post+t_pre-bin)/step+1),2));
        velo_trial(k).peak_velo=max(info(1:((t_post+t_pre-bin)/step+1),2));
    end     
end

end