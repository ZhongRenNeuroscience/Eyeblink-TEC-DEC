% The function is for producing the overall behavior form (including the ranks of each trial in certain parameter) in one session as
% well as calculate the average values of various parameters in different
% types of trials.  
% Run in eyeblink system, need blk file with all behavior info. --Zhong

function [behavior,trial_num,early]=behavior_analysis(blk,cs_lc,t_pre,t_post,t_probe)

behavior=zeros(size(blk,2),23);
t_pre=t_pre/1000;
t_post=t_post/1000;
t_probe=t_probe/1000;
ur_amp_norm=mean([blk.ur_amp]);
early=0;


for k=1:size(blk,2)
    
    behavior(k,1)=k;
    cslc=cs_lc(k,1);
   
    if isempty(blk(k).cr_on)
        behavior(k,2)=0;
%         behavior(k,4:15)=0;
    
    elseif isempty(blk(k).cr_pk)
        behavior(k,2)=0;
    elseif isempty(blk(k).cr_amp)
        behavior(k,2)=0;
    else
        cr_onset=blk(k).cr_on-cslc;
        if  cr_onset<=0.050
            behavior(k,2)=2;
        else
            behavior(k,2)=1;
            behavior(k,4)=cr_onset;
            if cr_onset<=0.25
                early=early+1;
            end
            cr_pktime=blk(k).cr_pk-cslc;
            behavior(k,6)=cr_pktime;
            pk_latency=cr_pktime-cr_onset;
            behavior(k,8)=pk_latency;
            cr_amp=blk(k).cr_amp/ur_amp_norm;
            behavior(k,10)=cr_amp;
            cr_slope=cr_amp/pk_latency;
            behavior(k,12)=cr_slope;
            num_cr_on=find(blk(k).t==blk(k).cr_on);
            [max_diff,max_t]=behavior_differential(blk,k,t_pre,t_post,1);
            behavior(k,14)=max_diff;
            behavior(k,15)=max_t;
            cr_end=cslc+t_post;
            num_cr_end=find(blk(k).t==cr_end);
            if cr_amp<=0.05
               behavior(k,2)=0;
               behavior(k,4)=0;
               behavior(k,6)=0; 
               behavior(k,8)=0;
               behavior(k,10)=0;
               behavior(k,12)=0;
               behavior(k,14)=0;
               behavior(k,15)=0;               
            end
%             cr_area=(sum(blk(k).tr((num_cr_on):(num_cr_end)))-(blk(k).tr(num_cr_on)+blk(k).tr(num_cr_end))/2)/(ur_amp_norm*20000); %#ok<FNDSB>
%             behavior(k,18)=cr_area;
%             cr_duration=cr_area/cr_amp;
%             behavior(k,20)=cr_duration;
        end
    end
    
    if isempty(blk(k).ur_pk & blk(k).ur_amp)
        behavior(k,3)=0;
        if behavior(k,2)==1
        [max_diff,max_t]=behavior_differential(blk,k,t_pre,t_probe,1);
        behavior(k,14)=max_diff;
        behavior(k,15)=max_t;
        cr_end=cslc+t_probe;
        num_cr_end=find(blk(k).t==cr_end);
        cr_area=(sum(blk(k).tr((num_cr_on):(num_cr_end)))-(blk(k).tr(num_cr_on)+blk(k).tr(num_cr_end))/2)/(ur_amp_norm*20000); %#ok<FNDSB>
%         behavior(k,18)=cr_area;
%         cr_duration=cr_area/cr_amp;
%         behavior(k,20)=cr_duration;
        end

    elseif isempty(blk(k).ur_pk | blk(k).ur_amp)
        behavior(k,3)=2;
        behavior(k,22)=0;
        behavior(k,23)=0;
    else
        behavior(k,3)=1;
        behavior(k,22)=blk(k).ur_pk-cslc;
        behavior(k,23)=blk(k).ur_amp/ur_amp_norm;
    end
    
    if size(blk(k).tr,1)>31000
       behavior(k,2)=3;
       behavior(k,3)=3;
    end
    
end

 trial_num=k;

 [~,p] = sort(behavior(:,4),'descend');
   r = 1:length(behavior(:,4));
   r(p) = r;
   behavior(:,5)=r';
   
    [~,p] = sort(behavior(:,6),'descend');
   r = 1:length(behavior(:,6));
   r(p) = r;
   behavior(:,7)=r';
   
    [~,p] = sort(behavior(:,8),'descend');
   r = 1:length(behavior(:,8));
   r(p) = r;
   behavior(:,9)=r';
   
    [~,p] = sort(behavior(:,10),'descend');
   r = 1:length(behavior(:,10));
   r(p) = r;
   behavior(:,11)=r';
   
    [~,p] = sort(behavior(:,12),'descend');
   r = 1:length(behavior(:,12));
   r(p) = r;
   behavior(:,13)=r';
   
    [~,p] = sort(behavior(:,14),'descend');
   r = 1:length(behavior(:,14));
   r(p) = r;
   behavior(:,16)=r';
   
   [~,p] = sort(behavior(:,15),'descend');
   r = 1:length(behavior(:,15));
   r(p) = r;
   behavior(:,17)=r';  
   
    [~,p] = sort(behavior(:,18),'descend');
   r = 1:length(behavior(:,18));
   r(p) = r;
   behavior(:,19)=r';
   
    [~,p] = sort(behavior(:,20),'descend');
   r = 1:length(behavior(:,20));
   r(p) = r;
   behavior(:,21)=r';

   behavior(k+1,:)=sum(behavior,1);
   behavior(k+2,:)=sum(behavior~=0,1)-1;
   
%    probe_trial=find(behavior(:,3)==0);
%    for n=1:length(probe_trial)
%        
%    end
   for m=1:23
       behavior(k+3,m)=behavior(k+1,m)/behavior(k+2,m);
   end
   
   behavior(k+4,:)=sum(behavior(behavior(behavior(:,3)==0),:),1);
   behavior(k+5,:)=behavior(k+4,:)/behavior(k+4,2);
   
   behavior(k+3,2)=NaN;
   behavior(k+5,2)=NaN;
   
   behavior(k+6,:)=behavior(k+1,:)-behavior(k+4,:);
   behavior(k+7,:)=behavior(k+6,:)/(behavior(k+1,2)-behavior(k+4,2));
   
   column_names={'trial_num','CR_trial','normal_trial','CR_onset','CRonset_rank','CR_peaktime','CR_pkt_rank','peak_latency','pk_lat_rank','CR_amp','CRamp_rank',...
   'CR_slpoe','CRslp_rank','CR_differential','CR_diff_time','CR_diff_rank','CR_diff_time_rank','CR_area','CRarea_rank','CR_duration','CRdur_rank','UR_peaktime','UR_amp'};
   behavior=array2table(behavior,'VariableNames',column_names);
   
end