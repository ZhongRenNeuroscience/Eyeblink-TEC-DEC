% To calculate the instantaneous eyeblink velocity basing on the
% subtracting value before and after the window.
% Run as a function within behavior analysis. --Zhong

function [max_diff,max_t]=behavior_differential(blk,trial_num,t_pre,t_post,window)

t_pre=t_pre*1000;
t_post=t_post*1000;
differential=zeros(t_post/window,2);



for i=1:t_post/window
    differential(i,1)=i;
    j=(t_pre+i)*20;
    differential(i,2)=(blk(trial_num).tr(j)-blk(trial_num).tr(j-window*20+1))/(window*20);
end
    max_diff=max(differential(:,2));
    max_t_idx=find(differential(:,2)==max_diff,1);
    max_t=differential(max_t_idx,1);

end

