% To test the overall modulation type of one neuron in one recording
% session seperated by CR trial, non-CR trial and probe trial. 
% Input parameters are baseline time span, modulation detection
% time span, psth input of one session, SD standard above or under the
% baseline as facilitation or suppression, and mininum time span for a
% modulation event, respectively. After each modulation type detection, a
% merge procedure will be performed to test whether two modulations could
% be viewed as one.  --Zhong

function modulation=modulation_type(t_baseline,t_test,psth,SD_time,min_mod_t)

[~,t_idx]=min(abs(psth(1).Gau_psth_shft(:,1)+t_baseline));
modulation(size(psth,2))=struct('num_fac',[],'num_sup',[],'fac_merge',[],'sup_merge',[],'fac_info',[],'sup_info',[],'fac_mginfo',[],'sup_mginfo',[],...
    'ur_fac',[],'ur_fpkt',[],'ur_sup',[],'ur_spkt',[],'bsl_frq',[],'test_frq',[],'SD',[]);

% first for loop - each cell
for k=1:size(psth,2)
    mean_baseline=mean(psth(k).Gau_psth_shft(t_idx:(t_idx+t_baseline-1),2));
    mean_test=mean(psth(k).Gau_psth_shft((t_idx+t_baseline):(t_idx+t_baseline+t_test),2));
    SD_baseline=std(psth(k).Gau_psth_shft(t_idx:(t_idx+t_baseline-1),2));
    thrshld_up=mean_baseline+SD_time*SD_baseline;
    thrshld_down=mean_baseline-SD_time*SD_baseline;
    
%   facilitation detection
    modulation(k).fac_info=struct('onset_time',[],'end_time',[],'peak_time',[],'peak_value',[],'duration',[],'merge_to_next',[]);
    fac_dtn=psth(k).Gau_psth_shft(((t_idx+t_baseline):(t_idx+t_baseline+t_test)),2)> thrshld_up;
    [fac_region, fac_num_region]=bwlabel(fac_dtn);
    fac_size = regionprops(fac_region,'Area');
    num_fac=0;
    if fac_num_region>0
        for m=1: fac_num_region
            if fac_size(m).Area >= min_mod_t
             num_fac=num_fac+1;
             t_fac_onset=find(fac_region==m,1,'first')-1;
             t_fac_end=find(fac_region==m,1,'last')-1;
             modulation(k).fac_info(num_fac).onset_time=t_fac_onset;
             modulation(k).fac_info(num_fac).end_time=t_fac_end;
             modulation(k).fac_info(num_fac).duration=t_fac_end-t_fac_onset;
             [pk_value,t_peak]=max(psth(k).Gau_psth_shft(((t_idx+t_baseline+t_fac_onset+1):(t_idx+t_baseline+t_fac_end+1)),2));
             modulation(k).fac_info(num_fac).peak_time=t_fac_onset+t_peak-1;
             modulation(k).fac_info(num_fac).peak_value=pk_value;
            end
        end
    end
    modulation(k).num_fac=num_fac;
    
%   merge facilitation that should be connected, it depends on whether it
%   is the last event
    if num_fac > 0
        fac_merge=num_fac;
        for i=1:num_fac
            if num_fac-i>0
               t_last_end=modulation(k).fac_info(i).end_time;
               t_next_on=modulation(k).fac_info(i+1).onset_time;
               inter_fac_btm=min(psth(k).Gau_psth_shft(((t_idx+t_baseline+t_last_end+1):(t_idx+t_baseline+t_next_on+1)),2));
               if inter_fac_btm >= mean_baseline
                  fac_merge=fac_merge-1;
                  modulation(k).fac_info(i).merge_to_next=1;
               else
                  modulation(k).fac_info(i).merge_to_next=0;
               end
            else    
               t_last_end=modulation(k).fac_info(i).end_time;
               t_next_on=t_test;
               inter_fac_btm=min(psth(k).Gau_psth_shft(((t_idx+t_baseline+t_last_end+1):(t_idx+t_baseline+t_next_on+1)),2));
               if inter_fac_btm >= mean_baseline
                  modulation(k).fac_info(i).merge_to_next=1;
               else
                  modulation(k).fac_info(i).merge_to_next=0;
               end
            end
        end
        modulation(k).fac_merge=fac_merge;
    else
        modulation(k).fac_merge=0;
    end
% merge the facilitation info   
   modulation(k).fac_mginfo=struct('t_onset',[],'t_peak',[],'t_end',[],'dur',[],'peak',[]);
   yes=1;
   for x=1:modulation(k).num_fac
       if x==1 
          modulation(k).fac_mginfo(yes).peak=modulation(k).fac_info(x).peak_value;
          modulation(k).fac_mginfo(yes).t_peak=modulation(k).fac_info(x).peak_time;
          modulation(k).fac_mginfo(yes).t_onset=modulation(k).fac_info(x).onset_time;
       elseif x>1 && modulation(k).fac_info(x-1).merge_to_next==0
          modulation(k).fac_mginfo(yes).peak=modulation(k).fac_info(x).peak_value;
          modulation(k).fac_mginfo(yes).t_peak=modulation(k).fac_info(x).peak_time;
          modulation(k).fac_mginfo(yes).t_onset=modulation(k).fac_info(x).onset_time; 
       end
%        if modulation(k).fac_info(x).merge_to_next==1
%           if x<modulation(k).num_fac && modulation(k).fac_mginfo(yes).peak < modulation(k).fac_info(x+1).peak_value
%           modulation(k).fac_mginfo(yes).peak=modulation(k).fac_info(x+1).peak_value;
%           modulation(k).fac_mginfo(yes).t_peak=modulation(k).fac_info(x+1).peak_time;
%           end
%           if x==modulation(k).num_fac
%           modulation(k).fac_mginfo(yes).t_end=t_test;   
%           else
%           modulation(k).fac_mginfo(yes).t_end=modulation(k).fac_info(x+1).end_time;    
%           end
%        else
%           modulation(k).fac_mginfo(yes).t_end=modulation(k).fac_info(x).end_time;
%           yes=yes+1;
%        end
   end
   for y=1:modulation(k).fac_merge
       modulation(k).fac_mginfo(y).dur=modulation(k).fac_mginfo(y).t_end-modulation(k).fac_mginfo(y).t_onset;
   end
    
    
%   suppression detection
    modulation(k).sup_info=struct('onset_time',[],'end_time',[],'btm_time',[],'btm_value',[],'duration',[]);
    sup_dtn=psth(k).Gau_psth_shft(((t_idx+t_baseline):(t_idx+t_baseline+t_test)),2)< thrshld_down;
    [sup_region, sup_num_region]=bwlabel(sup_dtn);
    sup_size = regionprops(sup_region,'Area');
    num_sup=0;
    if sup_num_region>0
        for n=1: sup_num_region
            if sup_size(n).Area >= min_mod_t
             num_sup=num_sup+1;
             t_sup_onset=find(sup_region==n,1,'first')-1;
             t_sup_end=find(sup_region==n,1,'last')-1;
             modulation(k).sup_info(num_sup).onset_time=t_sup_onset;
             modulation(k).sup_info(num_sup).end_time=t_sup_end;
             modulation(k).sup_info(num_sup).duration=t_sup_end-t_sup_onset;
             [btm_value,t_btm]=min(psth(k).Gau_psth_shft(((t_idx+t_baseline+t_sup_onset+1):(t_idx+t_baseline+t_sup_end+1)),2));
             modulation(k).sup_info(num_sup).btm_time=t_sup_onset+t_btm-1;
             modulation(k).sup_info(num_sup).btm_value=btm_value;
            end
        end
    end
    modulation(k).num_sup=num_sup;
    
%   merge supression that should be connected
    if  num_sup >0
        sup_merge=num_sup;
        for j=1:num_sup
            if num_sup-j>0
               t_last_end=modulation(k).sup_info(j).end_time;
               t_next_on=modulation(k).sup_info(j+1).onset_time;
               inter_sup_pk=max(psth(k).Gau_psth_shft(((t_idx+t_baseline+t_last_end+1):(t_idx+t_baseline+t_next_on+1)),2));
               if inter_sup_pk <= mean_baseline
                  sup_merge=sup_merge-1;
                  modulation(k).sup_info(j).merge_to_next=1;
               else
                  modulation(k).sup_info(j).merge_to_next=0;
               end
            else    
               t_last_end=modulation(k).sup_info(j).end_time;
               t_next_on=t_test;
               inter_sup_pk=max(psth(k).Gau_psth_shft(((t_idx+t_baseline+t_last_end+1):(t_idx+t_baseline+t_next_on+1)),2));
               if inter_sup_pk >= mean_baseline
                  modulation(k).sup_info(j).merge_to_next=1;
               else
                  modulation(k).sup_info(j).merge_to_next=0;
               end
            end
        end
        modulation(k).sup_merge=sup_merge;
    else
        modulation(k).sup_merge=0;
    end
% merge the suppression info    
   modulation(k).sup_mginfo=struct('t_onset',[],'t_peak',[],'t_end',[],'dur',[],'peak',[]);
   yes=1;
   for x=1:modulation(k).num_sup
       if x==1 
          modulation(k).sup_mginfo(yes).peak=modulation(k).sup_info(x).btm_value;
          modulation(k).sup_mginfo(yes).t_peak=modulation(k).sup_info(x).btm_time;
          modulation(k).sup_mginfo(yes).t_onset=modulation(k).sup_info(x).onset_time;
       elseif x>1 && modulation(k).sup_info(x-1).merge_to_next==0
          modulation(k).sup_mginfo(yes).peak=modulation(k).sup_info(x).btm_value;
          modulation(k).sup_mginfo(yes).t_peak=modulation(k).sup_info(x).btm_time;
          modulation(k).sup_mginfo(yes).t_onset=modulation(k).sup_info(x).onset_time; 
       end
       if modulation(k).sup_info(x).merge_to_next==1
          if modulation(k).sup_mginfo(yes).peak > modulation(k).sup_info(x).btm_value
          modulation(k).sup_mginfo(yes).peak=modulation(k).sup_info(x).btm_value;
          modulation(k).sup_mginfo(yes).t_peak=modulation(k).sup_info(x).btm_time;
          end
          if x==modulation(k).num_sup
          modulation(k).sup_mginfo(yes).t_end=t_test;   
          else
          modulation(k).sup_mginfo(yes).t_end=modulation(k).sup_info(x+1).end_time;    
          end
       else
          modulation(k).sup_mginfo(yes).t_end=modulation(k).sup_info(x).end_time;
          yes=yes+1;
       end
   end
   for y=1:modulation(k).sup_merge
       modulation(k).sup_mginfo(y).dur=modulation(k).sup_mginfo(y).t_end-modulation(k).sup_mginfo(y).t_onset;
   end
    
%   ur modulation type detection 
%     ur_thrshld=10; %set detection standard with frequency change
    ur_max=max(psth(k).Gau_psth_shft((t_idx+t_baseline+t_test):(t_idx+t_baseline+t_test+100),2));
    ur_min=min(psth(k).Gau_psth_shft((t_idx+t_baseline+t_test):(t_idx+t_baseline+t_test+100),2));
    if ur_max >= thrshld_up
        modulation(k).ur_fac=ur_max;
        ur_maxt=find(psth(k).Gau_psth_shft((t_idx+t_baseline+t_test):(t_idx+t_baseline+t_test+100),2)==ur_max,1);
        modulation(k).ur_fpkt=psth(k).Gau_psth_shft(ur_maxt+t_idx+t_baseline+t_test-1,1);
    else
        modulation(k).ur_fac=0;
        modulation(k).ur_fpkt=0;
    end
    if ur_min <= thrshld_down
        modulation(k).ur_sup=ur_min;
        ur_mint=find(psth(k).Gau_psth_shft((t_idx+t_baseline+t_test):(t_idx+t_baseline+t_test+100),2)==ur_min,1);
        modulation(k).ur_spkt=psth(k).Gau_psth_shft(ur_mint+t_idx+t_baseline+t_test-1,1);
    else
        modulation(k).ur_sup=0;
        modulation(k).ur_spkt=0;
    end
    modulation(k).bsl_frq=mean_baseline;
    modulation(k).test_frq=mean_test;
    modulation(k).SD=SD_baseline;
end

end