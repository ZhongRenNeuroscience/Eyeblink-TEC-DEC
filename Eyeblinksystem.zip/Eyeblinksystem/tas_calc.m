% Produce the spike event data of each trial from raw spk file which can 
% be grouped by CR, non-CR and probe triasls with locs. --Zhong

function tas = tas_calc(cell_spk,stm_lc,t_pre,t_post)
if isempty(stm_lc(1).nr)
    tas=[];
else
    t_pre = t_pre / 1000;
    t_post = t_post / 1000;

  % Creating trigger aligned spikes (TAS) as a struct   
    tas(size(cell_spk,2) - 1) = struct('cell',[],'tss',[],'ch',[]);
    for i = 2:size(cell_spk,2)    % Escaping Cell_No.0 (background), index starts from 2
      % Extracting data for each cell as trigger separated spikes (TSS)
        tss(size(stm_lc,2)) = struct('trial',[],'t',[]);
        for j = 1:size(stm_lc,2)
            idx = ([cell_spk(i).t] > stm_lc(j).t - t_pre) & ([cell_spk(i).t] <= stm_lc(j).t + t_post);
            fire = cell_spk(i).t(idx);
            fire = fire - stm_lc(j).t;
          % Arranging data
            tss(j).trial = stm_lc(j).nr;
            tss(j).t = round(fire,5);
        end
      % Arranging data
        tas(i-1).cell = i - 1;
        tas(i-1).tss = tss;
        tas(i-1).ch=cell_spk(i).ch;
    end
end
end