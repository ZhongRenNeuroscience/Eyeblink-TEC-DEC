% Based on the sorting database of one single unit, plot the spike events
% of each trial to check the sorting quality and modulation detection
% confidence from whole package database mod_list. After that the raster 
% will be plotted in another figure. Change the mod_ID and non according to
% the candidate neuron. --Zhong 

figure;
mod_ID=139;
type='non';

for i=1:size(list_mod.(type)(mod_ID).all_info.ttt.CR_trial,2)
    subplot(10,6,i)
    hold on
    y=zeros(size(list_mod.(type)(mod_ID).all_info.ttt.CR_trial(i).spk_time,1),1);
    plot (list_mod.(type)(mod_ID).all_info.ttt.CR_trial(i).spk_time*1000,y,'k.')
    hold on
    for j=1:size(list_mod.(type)(mod_ID).all_info.ttt.CR_trial(i).spk_time,1)
        t=list_mod.(type)(mod_ID).all_info.ttt.CR_trial(i).spk_time(j)*1000;
        line([t t],[-1, 1],'Color','black','LineStyle','-','LineWidth',1.0);
        hold on
    end
    line([0 0],[-1, 1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[-1, 1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[-1, 1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    xlim([-250 750]);
end

figure;
    for m=1:size(list_mod.(type)(mod_ID).all_info.ttt.CR_trial,2)
        hold on
        Y=ones(size(list_mod.(type)(mod_ID).all_info.ttt.CR_trial(m).spk_time,1),1)*m;
        plot(list_mod.(type)(mod_ID).all_info.ttt.CR_trial(m).spk_time*1000,Y,'k.')
    end
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');