clear;

% Input parameters
  csv_name = 'DCN7_201031_090222.csv';
  t_pre = 550;
  t_post = 500;
  t_probe=t_post+250;  %(t_probe=t_post+250 just for whole probe trial trace)
  dur = 1000;
  t_psth = 1050;
%   bin_psth = 150;
%   bin_corr = 250;
%   psth_window = 50;
  

% Import Intan header and path
  read_Intan_RHD2000_file;
  cd(path);
% Import Intan time vectors
  t = import_intan_time;
  t = fix_intan_time(t);
% Import Intan ADC channels vector
  adc = import_intan_adc([]);
  din = import_intan_din([]);
% Import CSV file from JRCLUST
  spk = import_jrc_csv(csv_name);
%   ctp = import_ctp_csv('cell_tp.csv');
% Detection CS/US edge
  cs_lc = find_trg_pks([adc(1).v],3,t,dur);
  us_lc = find_trg_pks([adc(2).v],3,t,dur);
%   us_lc(10:10:end,:) = [];
% Filter eyeblink trace
%   v = idv_filter([adc(4).v],1,200,0,0,0,0);
  v = [adc(3).v];
% Detect CR/UR in eyeblink trace
  blk = blk_detn(v,t,cs_lc,us_lc,t_pre,t_post,t_probe,dur);
  [behavior,trial_num,early]=behavior_analysis(blk,cs_lc,t_pre,t_post,t_probe);
%   blk_plot(t,blk);
% Calculte PSTH
%   Clocs = locs_vfy(1,cs_lc,{blk.cr_on});
  [Clocs,NO_locs,PRB_locs]=trial_tp(behavior,cs_lc);

% Calculate the raw displacement on the treadmill
  velo_raw=velocity_raw(din,t,1,2);
  velo_C=velocity_cal(velo_raw,t_pre,t_post,t_psth,Clocs,50,10,8);
  velo_N=velocity_cal(velo_raw,t_pre,t_post,t_psth,NO_locs,50,10,8);
  velo_P=velocity_cal(velo_raw,t_pre,t_post,t_psth,PRB_locs,50,10,8);
  
  CL_locs=struct('nr',[],'t',[],'velo_info',[],'avg_velo',[],'peak_velo',[],'velo_raw',[]);
  CH_locs=struct('nr',[],'t',[],'velo_info',[],'avg_velo',[],'peak_velo',[],'velo_raw',[]);
  CL_idx=0;
  CH_idx=0;
  
  [~,index] = sortrows([velo_C.avg_velo].');
  velo_C = velo_C(index);
  clear index;
  velo_C_20f=velo_C(20).avg_velo;
  velo_C_20l=velo_C(size(velo_C,2)-19).avg_velo;
  if velo_C_20f<=0.001
     for k=1:size(velo_C,2)
         if velo_C(k).avg_velo >=0.001 || velo_C(k).peak_velo >=0.05
            CH_idx=CH_idx+1;
            CH_locs(CH_idx).nr=velo_C(k).nr;
            CH_locs(CH_idx).t=velo_C(k).t_trg;
            CH_locs(CH_idx).velo_info=velo_C(k).info;     
            CH_locs(CH_idx).avg_velo=velo_C(k).avg_velo;
            CH_locs(CH_idx).peak_velo=velo_C(k).peak_velo;
            CH_locs(CH_idx).velo_raw=velo_C(k).raw;
         else
            CL_idx=CL_idx+1;
            CL_locs(CL_idx).nr=velo_C(k).nr;
            CL_locs(CL_idx).t=velo_C(k).t_trg;
            CL_locs(CL_idx).velo_info=velo_C(k).info;   
            CL_locs(CL_idx).avg_velo=velo_C(k).avg_velo;
            CL_locs(CL_idx).peak_velo=velo_C(k).peak_velo; 
            CL_locs(CL_idx).velo_raw=velo_C(k).raw;
         end
     end
  else
     for k=1:size(velo_C,2)
         if k>20
            CH_idx=CH_idx+1;
            CH_locs(CH_idx).nr=velo_C(k).nr;
            CH_locs(CH_idx).t=velo_C(k).t_trg;
            CH_locs(CH_idx).velo_info=velo_C(k).info;  
            CH_locs(CH_idx).avg_velo=velo_C(k).avg_velo;
            CH_locs(CH_idx).peak_velo=velo_C(k).peak_velo;
            CH_locs(CH_idx).velo_raw=velo_C(k).raw;
         elseif k<=20
            CL_idx=CL_idx+1;
            CL_locs(CL_idx).nr=velo_C(k).nr;
            CL_locs(CL_idx).t=velo_C(k).t_trg;
            CL_locs(CL_idx).velo_info=velo_C(k).info; 
            CL_locs(CL_idx).avg_velo=velo_C(k).avg_velo;
            CL_locs(CL_idx).peak_velo=velo_C(k).peak_velo;  
            CL_locs(CL_idx).velo_raw=velo_C(k).raw;
         end
     end    
  end
  
  for k=1:size(NO_locs,2)
      NO_locs(k).velo_info=velo_N(k).info;   
      NO_locs(k).avg_velo=velo_N(k).avg_velo;
      NO_locs(k).peak_velo=velo_N(k).peak_velo;  
  end
  
  [~,index] = sortrows([CL_locs.nr].');
  CL_locs = CL_locs(index);
  clear index;
  [~,index] = sortrows([CH_locs.nr].');
  CH_locs = CH_locs(index);
  clear index;
  [~,index] = sortrows([velo_C.nr].');
  velo_C = velo_C(index);
  clear index;
  
  Ctas=tas_calc(spk,Clocs,t_pre,t_psth);
  CLtas=tas_calc(spk,CL_locs,t_pre,t_psth);
  CHtas=tas_calc(spk,CH_locs,t_pre,t_psth);
% Atas=tas_calc(spk,All_locs,t_pre,t_post);
  Ntas=tas_calc(spk,NO_locs,t_pre,t_psth);
  Ptas=tas_calc(spk,PRB_locs,t_pre,t_psth);


%   [Cpsth,Ctas] = psth_calc(spk,Clocs,psth_window,1,t_pre,t_psth);
%   All_locs=locs_vfy(0,cs_lc,{blk.cr_on});
% % Cell modulation detection
%   mod_tp = cell_mod_detn(Cpsth,[-500 0],[0 500],[0 500]);
%   blk_spk = blk_spk_calc(spk,blk,Clocs,t_pre,t_post,bin_corr);
% Trial by trial behavior analysis
  
% Saving
%   blk_pack = dat_out_blk('aaa',500,ctp,blk,Cpsth,mod_tp,blk_spk);

% Shift window PSTH plot
% psth_plot(Cpsth,size(Cpsth,2),size(Clocs,2),'hist',Ctas,blk,Clocs)

% Gaussian spike smoothing filter and PSTH plot
spk_CR_Gau=spk_Gaussian(Ctas,t_pre,t_psth,10,3);  %for whole session PSTH using CR trials
psth_CR_Gau=Gau_psth_cal(spk_CR_Gau,t_pre,t_psth,0);  % last input is for sliding window
mod_CR=modulation_type(t_pre-50,t_post,psth_CR_Gau,3,10);
ttt_CR_Gau=ifr_Gau_trial(spk_CR_Gau,10,1); % shift_window size + bin size
Gau_psth_plot(psth_CR_Gau,Ctas,blk,Clocs,t_post,0,csv_name);
cd(path);

spk_CL_Gau=spk_Gaussian(CLtas,t_pre,t_psth,10,3);  %for whole session PSTH using CR trials
psth_CL_Gau=Gau_psth_cal(spk_CL_Gau,t_pre,t_psth,0);  % last input is for sliding window
mod_CL=modulation_type(t_pre-50,t_post,psth_CL_Gau,3,10);
ttt_CL_Gau=ifr_Gau_trial(spk_CL_Gau,10,1); % shift_window size + bin size

spk_CH_Gau=spk_Gaussian(CHtas,t_pre,t_psth,10,3);  %for whole session PSTH using CR trials
psth_CH_Gau=Gau_psth_cal(spk_CH_Gau,t_pre,t_psth,0);  % last input is for sliding window
mod_CH=modulation_type(t_pre-50,t_post,psth_CH_Gau,3,10);
ttt_CH_Gau=ifr_Gau_trial(spk_CH_Gau,10,1); % shift_window size + bin size

spk_NO_Gau=spk_Gaussian(Ntas,t_pre,t_psth,10,3);
psth_NO_Gau=Gau_psth_cal(spk_NO_Gau,t_pre,t_psth,0);
mod_NO=modulation_type(t_pre-50,t_post,psth_NO_Gau,3,10);
ttt_NO_Gau=ifr_Gau_trial(spk_NO_Gau,10,1); % shift_window size + bin size

Gau_psth_plot_loco(psth_CL_Gau,psth_CH_Gau,psth_NO_Gau,CLtas,CHtas,Ntas,blk,CL_locs,CH_locs,NO_locs,t_post,0,csv_name)


% spk_NO_Gau=[];
% psth_NO_Gau=[];
% mod_NO=[];
% ttt_NO_Gau=[]; % shift_window size + bin size

spk_PRB_Gau=spk_Gaussian(Ptas,t_pre,t_psth,10,3);
psth_PRB_Gau=Gau_psth_cal(spk_PRB_Gau,t_pre,t_psth,0);
mod_PRB=modulation_type(t_pre-50,t_post,psth_PRB_Gau,3,10);
ttt_PRB_Gau=ifr_Gau_trial(spk_PRB_Gau,10,1); % shift_window size + bin size
% spk_Gau_ifr=spk_Gaussian(Atas,t_pre,t_psth,10,3);   %for single trial instantaneous firing rate using all trials
% Gau_psth_ifr=Gau_psth_all(spk_Gau_ifr,t_pre,t_psth,0); % last parameter: window size

% Behavior drift plot
% blk_drift_plot(blk,Clocs);

% load 'blk.mat';
% load 'cs_lc.mat';
% load 't_post.mat';
% load 'Clocs.mat';

% [behavior,trial_num,early]=behavior_analysis(blk,cs_lc,t_pre,t_post,t_probe);
% [correlation,p_cor,drift_slope]=blk_drift_plot(blk,Clocs,t_post);
% [conversion_test_10]=conversion_test(behavior,10);
% [conversion_test_20]=conversion_test(behavior,20);
% [conversion_test_30]=conversion_test(behavior,30);
% behavior_output=behavior_output(behavior,trial_num,correlation,p_cor,drift_slope,early,conversion_test_10,conversion_test_20,conversion_test_30);
% save_behavior(blk,behavior,cs_lc,Clocs);
% 
% package=package(blk,behavior,ifr_Gau_trial);

package=pckg_all_loco(t_pre,dur,Clocs,NO_locs,PRB_locs,CH_locs,CL_locs,blk,behavior,psth_CR_Gau,psth_NO_Gau,psth_PRB_Gau,psth_CH_Gau,psth_CL_Gau,...
    mod_CR,mod_NO,mod_PRB,mod_CH,mod_CL,ttt_CR_Gau,ttt_NO_Gau,ttt_PRB_Gau,ttt_CH_Gau,ttt_CL_Gau,Ctas,Ntas,Ptas,CHtas,CLtas,velo_C,velo_N,velo_P,csv_name);
cd(path);
close all;
