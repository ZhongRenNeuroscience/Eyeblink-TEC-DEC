slope_cal_range=[0.1 0.9];
date='230522';

listing = dir([date '*']);

for n=1:length(listing)
    load(listing(n).name);
    if contains(listing(n).name,'delay_pair')
        behavior_form=behavior_form;
        t_post=250;
    elseif contains(listing(n).name,'trace500_pair')
        behavior_form=behavior_form;
        t_post=750;    
    else
        behavior_form=behavior_form_prb;
        t_post=750;  
    end
    
    for j=1:size(behavior_form,2)-1
        if behavior_form(j).CR_pkt-behavior_form(j).CR_on>0
           amp_idx_1=behavior_form(j).CR_amp*slope_cal_range(1)/100;
           amp_idx_2=behavior_form(j).CR_amp*slope_cal_range(2)/100;
           [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(behavior_form(j).blk_trace(:,1),behavior_form(j).blk_trace(:,2),[0 t_post],[amp_idx_1 amp_idx_1],1);
           [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(behavior_form(j).blk_trace(:,1),behavior_form(j).blk_trace(:,2),[0 t_post],[amp_idx_2 amp_idx_2],1);
           if length(inter_t_1)>1
               [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-behavior_form(j).CR_on));
               inter_amp_1=inter_amp_1(inter_t_1_idx);
           end
           if isempty(inter_t_1)
               inter_t_1=NaN;
               inter_amp_1=NaN;
           end
           if length(inter_t_2)>1
               inter_t_2=inter_t_2(1);
               inter_amp_2=inter_amp_2(1);
           end 
           if isempty(inter_t_2)
               inter_t_2=NaN;
               inter_amp_2=NaN;
           end
           behavior_form(j).CR_slope=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
        else
           behavior_form(j).CR_slope=NaN;
        end             
    end
    behavior_form(size(behavior_form,2)).CR_slope=nanmean([behavior_form(1:size(behavior_form,2)-1).CR_slope]);

    save(listing(n).name,'behavior_form');
end