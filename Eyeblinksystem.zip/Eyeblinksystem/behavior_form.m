function behavior_form=behavior_form(trial_num,behavior,blk,t_post)

velocity_curve_bin=10;
CR_onset_v_thrd=0.002;
CR_onset_amp_thrd=0.05;
slope_cal_range=[0.1 0.9];

behavior_form=struct('trial_num',[],'CR_on',[],'CR_on_v',[],'CR_on_amp',[],'CR_pkt',[],'CR_latency',[],'CR_amp',[],'CR_slope',[],'CR_velocity',[],'CR_t_pk_v',[],...
    'CR_rate',[],'blk_trace',[],'velocity_trace',[]);
j=0;
m=0;
UR_mean=mean([blk.ur_amp]);

for i=1:trial_num
    if behavior{i,{'normal_trial'}}==1
       m=m+1; 
    end
    
    if behavior{i,{'CR_trial'}}==1 && behavior{i,{'normal_trial'}}==1
       j=j+1;
       behavior_form(j).trial_num=behavior{i,{'trial_num'}};
       behavior_form(j).CR_on=behavior{i,{'CR_onset'}}*1000;
       behavior_form(j).CR_pkt=behavior{i,{'CR_peaktime'}}*1000;
       behavior_form(j).CR_latency=behavior{i,{'peak_latency'}}*1000;
       
       CR_amp=behavior{i,{'CR_amp'}}*100;
       if CR_amp > 100
       behavior_form(j).CR_amp=100;
       else
       behavior_form(j).CR_amp=CR_amp;
       end
       
       blk_smooth=zeros(1550,2);
       blk_smooth(:,1)=-550:1:999;
       for k=1:1550
           blk_smooth(k,2)=mean(blk(i).tr((20*k-19):20*k,1))/UR_mean;
       end
       behavior_form(j).blk_trace=blk_smooth;
       
       if behavior_form(j).CR_pkt-behavior_form(j).CR_on>0
           amp_idx_1=behavior_form(j).CR_amp*slope_cal_range(1)/100;
           amp_idx_2=behavior_form(j).CR_amp*slope_cal_range(2)/100;
           [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(behavior_form(j).blk_trace(:,1),behavior_form(j).blk_trace(:,2),[0 t_post],[amp_idx_1 amp_idx_1],1);
           [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(behavior_form(j).blk_trace(:,1),behavior_form(j).blk_trace(:,2),[0 t_post],[amp_idx_2 amp_idx_2],1);
           if length(inter_t_1)>1
               [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-behavior_form(j).CR_on));
               inter_amp_1=inter_amp_1(inter_t_1_idx);
           end
           if isempty(inter_t_1)
               inter_t_1=NaN;
               inter_amp_1=NaN;
           end
           if length(inter_t_2)>1
               inter_t_2=inter_t_2(1);
               inter_amp_2=inter_amp_2(1);
           end 
           if isempty(inter_t_2)
               inter_t_2=NaN;
               inter_amp_2=NaN;
           end
           behavior_form(j).CR_slope=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
        else
           behavior_form(j).CR_slope=NaN;
        end  
       
       velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
       for k=1:1550/velocity_curve_bin
           k_1=(k-1)*velocity_curve_bin+1;
           k_2=k*velocity_curve_bin;
           velocity_curve_trial(k,1)=blk_smooth(k_1,1)+velocity_curve_bin/2;
           velocity_curve_trial(k,2)=(blk_smooth(k_2,2)-blk_smooth(k_1,2))/velocity_curve_bin;          
       end       
       behavior_form(j).velocity_trace=velocity_curve_trial;
       if j==1
           t_idx=find(velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<t_post);
       end
       [behavior_form(j).CR_velocity,idx_t_max_velocity]=max(velocity_curve_trial(t_idx,2));
       behavior_form(j).CR_t_pk_v=velocity_curve_trial(t_idx(1)+idx_t_max_velocity-1,1);       
        t_50=find(velocity_curve_trial(:,1)<=50,1,'last');
        t_end=find(velocity_curve_trial(:,1)<=t_post,1,'last');
        t_onset_v=find(velocity_curve_trial(t_50+1:t_end,2)>=CR_onset_v_thrd,1,'first');
        if ~isempty(t_onset_v)
            behavior_form(j).CR_on_v=velocity_curve_trial(t_50+t_onset_v,1);    
        else
            behavior_form(j).CR_on_v=NaN;
        end

        t_50=find(blk_smooth(:,1)<=50,1,'last');
        t_end=find(blk_smooth(:,1)<=t_post,1,'last');
        t_onset_amp=find(blk_smooth(t_50+1:t_end,2)>=CR_onset_amp_thrd,1,'first');
        if ~isempty(t_onset_amp)
            behavior_form(j).CR_on_amp=blk_smooth(t_50+t_onset_amp,1);    
        else
            behavior_form(j).CR_on_amp=NaN;
        end    
        
        
    end
end


behavior_form(j+1).trial_num='mean';
behavior_form(j+1).CR_on=nanmean([behavior_form(1:j).CR_on]);
behavior_form(j+1).CR_on_v=nanmean([behavior_form(1:j).CR_on_v]);
behavior_form(j+1).CR_on_amp=nanmean([behavior_form(1:j).CR_on_amp]);
behavior_form(j+1).CR_pkt=nanmean([behavior_form(1:j).CR_pkt]);
behavior_form(j+1).CR_latency=nanmean([behavior_form(1:j).CR_latency]);
behavior_form(j+1).CR_amp=nanmean([behavior_form(1:j).CR_amp]);
behavior_form(j+1).CR_slope=nanmean([behavior_form(1:j).CR_slope]);
behavior_form(j+1).CR_velocity=nanmean([behavior_form(1:j).CR_velocity]);
behavior_form(j+1).CR_t_pk_v=nanmean([behavior_form(1:j).CR_t_pk_v]);
behavior_form(j+1).CR_rate=j/m*100;

behavior_form_all=zeros(1550,j);
for i=1:j
    behavior_form_all(:,i)=behavior_form(i).blk_trace(:,2);    
end
blk_trace_all=zeros(1550,2);
blk_trace_all(:,1)=-550:1:999;
blk_trace_all(:,2)=mean(behavior_form_all,2);
behavior_form(j+1).blk_trace=blk_trace_all;

velocity_form_all=zeros(1550/velocity_curve_bin,j);
for i=1:j
    velocity_form_all(:,i)=behavior_form(i).velocity_trace(:,2);    
end
velocity_trace_all=zeros(1550/velocity_curve_bin,2);
velocity_trace_all(:,1)=behavior_form(1).velocity_trace(:,1);
velocity_trace_all(:,2)=mean(velocity_form_all,2);
behavior_form(j+1).velocity_trace=velocity_trace_all;
end