% Plot the PSTH with behavior curves and raster of single units in one
% session after spk_Gaussian and Gau_psth_cal, also with tas which
% contains spike event info after JRClust sorting and locs with CS onset
% time point. win_sz is just for figure name, no real function to the code.
% --Zhong


function Gau_psth_plot_CNP(Gau_psth_CR,Gau_psth_NO,Gau_psth_PRB,CRtas,NOtas,PRBtas,blk,CR_locs,NO_locs,PRB_locs,t_post,csv_name)

outpath='D:\Mimo\mPFC_trace\CNP_PSTH\';
cell_number=size(Gau_psth_CR,2);
UR_mean=mean([blk.ur_amp]);
t_norm=(blk(CR_locs(2).nr).t-CR_locs(2).t)*1000;    

CR_number=size(CR_locs,2);
blk_data_CR=zeros(size(blk(2).tr,1),size(CR_locs,2));
for n=1:size(CR_locs,2)
    trial_num=CR_locs(n).nr;
    blk_data_CR(:,n)=blk(trial_num).tr/UR_mean;
end
mean_blk_CR=mean(blk_data_CR,2);

if ~isempty(NO_locs(1).nr)
    NO_number=size(NO_locs,2);
    blk_data_NO=zeros(size(blk(2).tr,1),size(NO_locs,2));
    for n=1:size(NO_locs,2)
        trial_num=NO_locs(n).nr;
        blk_data_NO(:,n)=blk(trial_num).tr/UR_mean;
    end
    mean_blk_NO=mean(blk_data_NO,2);
end

if ~isempty(PRB_locs(1).nr)
    PRB_number=size(PRB_locs,2);
    blk_data_PRB=zeros(size(blk(2).tr,1),size(PRB_locs,2));
    for n=1:size(PRB_locs,2)
        trial_num=PRB_locs(n).nr;
        blk_data_PRB(:,n)=blk(trial_num).tr/UR_mean;
    end
    mean_blk_PRB=mean(blk_data_PRB,2);
end
    
ymax=max(max(blk_data_CR))+0.1;
ymin=min(min(blk_data_CR))-0.1;
    
for k=1:cell_number
    cell_nr=k;
    if t_post==250
    fig_name = strcat('No.',num2str(cell_nr,'%03d'),'_delay');
    elseif t_post==500
    fig_name = strcat('No.',num2str(cell_nr,'%03d'),'_trace');
    end
    figure('Name',fig_name,'NumberTitle','off','units','normalized','outerposition',[0 0 1 1])
    
    %   plot behavior data     
    subplot(3,3,1)
    hold on
    for i=1:size(blk_data_CR,2)
        plot(t_norm,blk_data_CR(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    plot(t_norm,mean_blk_CR,'Color',[0 0 0],'LineWidth',2)
    hold on
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace');
    title('Normal CR trials');
    
    subplot(3,3,4)
    hold on
    for m=1:CR_number
        hold on
        Y=ones(length(CRtas(cell_nr).tss(m).t),1)*m;
        plot(CRtas(cell_nr).tss(m).t*1000,Y,'k.')
    end
    hold on
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');
    
    subplot(3,3,7)
    hold on
    h = histogram(Gau_psth_CR(k).Gau_psth_shft(:,1));
        h.BinEdges = (min(Gau_psth_CR(k).Gau_psth_shft(:,1))):(max(Gau_psth_CR(k).Gau_psth_shft(:,1)) + 1);
        h.NumBins = size(Gau_psth_CR(k).Gau_psth_shft,1);
        h.BinCounts = Gau_psth_CR(k).Gau_psth_shft(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    % Draw 0 point reference line
    yh = max(Gau_psth_CR(k).Gau_psth_shft(:,2)) * 1.01;
    hold on
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    hold on    
    
%   plot behavior data     
    subplot(3,3,2)
    hold on
    if ~isempty(NO_locs(1).nr)
        for i=1:size(blk_data_NO,2)
            plot(t_norm,blk_data_NO(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
            hold on
        end
        plot(t_norm,mean_blk_NO,'Color',[0 0 0],'LineWidth',2)
        hold on
    end
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')  
    title('Normal non CR trials');
    
    %   plot raster data
    subplot(3,3,5)
    hold on
    if ~isempty(NO_locs(1).nr)
        for m=1:NO_number
            hold on
            Y=ones(length(NOtas(cell_nr).tss(m).t),1)*m;
            plot(NOtas(cell_nr).tss(m).t*1000,Y,'k.')
        end
        hold on
    end
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');

    % plot PSTH  
    subplot(3,3,8)
    hold on
    if ~isempty(NO_locs(1).nr)
        h = histogram(Gau_psth_NO(k).Gau_psth_shft(:,1));
            h.BinEdges = (min(Gau_psth_NO(k).Gau_psth_shft(:,1))):(max(Gau_psth_NO(k).Gau_psth_shft(:,1)) + 1);
            h.NumBins = size(Gau_psth_NO(k).Gau_psth_shft,1);
            h.BinCounts = Gau_psth_NO(k).Gau_psth_shft(:,2)';
            h.EdgeColor = [0 0 0];
            h.EdgeAlpha = 0.50;
            h.FaceColor = [0 0.4470 0.7410];
            h.FaceAlpha = 0.75;

        % Draw 0 point reference line
        yh = max(Gau_psth_NO(k).Gau_psth_shft(:,2)) * 1.01;
        hold on
    end
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    hold on      
    
    subplot(3,3,3)
    hold on
    if ~isempty(PRB_locs(1).nr)
        for i=1:size(blk_data_PRB,2)
            plot(t_norm,blk_data_PRB(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
            hold on
        end
        plot(t_norm,mean_blk_PRB,'Color',[0 0 0],'LineWidth',2)
        hold on
    end
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')
    title('Probe CR trials');
    
    subplot(3,3,6)
    hold on
    if ~isempty(PRB_locs(1).nr)
        for m=1:PRB_number
            hold on
            Y=ones(length(PRBtas(cell_nr).tss(m).t),1)*m;
            plot(PRBtas(cell_nr).tss(m).t*1000,Y,'k.')
        end
        hold on
    end
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');  
    
    subplot(3,3,9)
    hold on
    if ~isempty(PRB_locs(1).nr)
        h = histogram(Gau_psth_PRB(k).Gau_psth_shft(:,1));
            h.BinEdges = (min(Gau_psth_PRB(k).Gau_psth_shft(:,1))):(max(Gau_psth_PRB(k).Gau_psth_shft(:,1)) + 1);
            h.NumBins = size(Gau_psth_PRB(k).Gau_psth_shft,1);
            h.BinCounts = Gau_psth_PRB(k).Gau_psth_shft(:,2)';
            h.EdgeColor = [0 0 0];
            h.EdgeAlpha = 0.50;
            h.FaceColor = [0 0.4470 0.7410];
            h.FaceAlpha = 0.75;

        % Draw 0 point reference line
        yh = max(Gau_psth_PRB(k).Gau_psth_shft(:,2)) * 1.01;
        hold on
    end
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    hold on
    cd(outpath);
    saveas(gcf,[csv_name '_' fig_name '.tiff']);
end
close all
end