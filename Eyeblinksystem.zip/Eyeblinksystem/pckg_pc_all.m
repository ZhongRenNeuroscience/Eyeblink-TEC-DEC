% Make all usable info of one recording session into a package.
% Level 1: mod_tp: contains both the CR and UR modulation type info based on whole session psth divided by CR/nonCR/probe trial types.
%          blk_avg: average eyelid trace among 3 types of trials in one session.
%          psth: contains the average ephys info of one session under 3 types of trials
%          ttt: contains both the behavior and instantaneous firing rate (ifr) info of each single trial sorted by 3 types.
%          behavior_table: the behavior analysis result of each single trial.
% Level 2: All the trials are divided here by the trial type, CR or not, probe or not.
% Level 3: mod_type: the number of CR/UR facilitation/suppression and their detail info based on whole session psth.
%          blk_avg: time point + eyelid trace data.
%          psth: average baseline frequency + raw psth only with Gaussian filter with highest time resolusion + smoothed psth after sliding window and bin size.
%          ttt: trial number + cs trigger time point + 
%               blink trace (realtime line; normalized time line; raw eyelid trace; eyelid trace with mean_ur_amplitue normalization) +
%               blink info (the info of this trial extracted from behavior analysis data) +
%               spike time (the spike time point in this trial extracted from spike sorting csv file) +
%               ifr_org_Gau(the ifr data only after the Gaussian conversion) +
%               ifr_smooth (the Gaussian filtered ifr data with sliding window and bin size smoothing)
% (Zhong 31-03-19)

function package=pckg_pc_all(t_pre,dur,Clocs,NO_locs,PRB_locs,blk,behavior,...
        psth_CR_Gau,psth_cps_CR_Gau,psth_NO_Gau,psth_cps_NO_Gau,psth_PRB_Gau,psth_cps_PRB_Gau,...
        mod_CR,mod_cps_CR,mod_NO,mod_cps_NO,mod_PRB,mod_cps_PRB,...
        ttt_CR_Gau,ttt_cps_CR_Gau,ttt_NO_Gau,ttt_cps_NO_Gau,ttt_PRB_Gau,ttt_cps_PRB_Gau,...
        Ctas,Ctas_cps,Ntas,Ntas_cps,Ptas,Ptas_cps,csv_name)

outpath='D:\Zhong\Trace-trained-mice\T_D_data_output\Newdata\';

package=struct('mod_tp_sps',[],'mod_tp_cps',[],'blk_avg',[],'psth_sps',[],'ttt_sps',[],'psth_cps',[],'ttt_cps',[],'behavior_table',[]);

package.mod_tp_sps=struct('cell_ch',[],'CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.mod_tp_cps=struct('cell_ch',[],'CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.blk_avg=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.psth_sps=struct('cell_ch',[],'CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.psth_cps=struct('cell_ch',[],'CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.ttt_sps=struct('cell_ch',[],'CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.ttt_cps=struct('cell_ch',[],'CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
package.behavior_table=behavior;

blk_t=(t_pre+dur)*20;
UR_mean=mean([blk.ur_amp]);

for i=1:size(mod_CR,2)
% CR_trial
  % modulation type
    package.mod_tp_sps(i).cell_ch=i;
    package.mod_tp_sps(i).CR_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp_sps(i).CR_trial.CR_fac=mod_CR(i).fac_merge;
    package.mod_tp_sps(i).CR_trial.CR_sup=mod_CR(i).sup_merge;
    if mod_CR(i).ur_fac==0
       package.mod_tp_sps(i).CR_trial.UR_fac=0;
    else 
       package.mod_tp_sps(i).CR_trial.UR_fac=1; 
    end
    if mod_CR(i).ur_sup==0
       package.mod_tp_sps(i).CR_trial.UR_sup=0;
    else 
       package.mod_tp_sps(i).CR_trial.UR_sup=1; 
    end
    if package.mod_tp_sps(i).CR_trial.CR_fac==0
       package.mod_tp_sps(i).CR_trial.CR_fac_info=[];
    else
       package.mod_tp_sps(i).CR_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_sps(i).CR_trial.CR_fac
           package.mod_tp_sps(i).CR_trial.CR_fac_info(j).t_onset=mod_CR(i).fac_mginfo(j).t_onset;
           package.mod_tp_sps(i).CR_trial.CR_fac_info(j).t_end=mod_CR(i).fac_mginfo(j).t_end;
           package.mod_tp_sps(i).CR_trial.CR_fac_info(j).dur=mod_CR(i).fac_mginfo(j).dur;
           package.mod_tp_sps(i).CR_trial.CR_fac_info(j).t_peak=mod_CR(i).fac_mginfo(j).t_peak;
           package.mod_tp_sps(i).CR_trial.CR_fac_info(j).peak=mod_CR(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp_sps(i).CR_trial.CR_sup==0
       package.mod_tp_sps(i).CR_trial.CR_sup_info=[];
    else
       package.mod_tp_sps(i).CR_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_sps(i).CR_trial.CR_sup
           package.mod_tp_sps(i).CR_trial.CR_sup_info(j).t_onset=mod_CR(i).sup_mginfo(j).t_onset;
           package.mod_tp_sps(i).CR_trial.CR_sup_info(j).t_end=mod_CR(i).sup_mginfo(j).t_end;
           package.mod_tp_sps(i).CR_trial.CR_sup_info(j).dur=mod_CR(i).sup_mginfo(j).dur;
           package.mod_tp_sps(i).CR_trial.CR_sup_info(j).t_peak=mod_CR(i).sup_mginfo(j).t_peak;
           package.mod_tp_sps(i).CR_trial.CR_sup_info(j).peak=mod_CR(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp_sps(i).CR_trial.UR_fac==0
       package.mod_tp_sps(i).CR_trial.UR_fac_info=[];
    else 
       package.mod_tp_sps(i).CR_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_sps(i).CR_trial.UR_fac_info.t_peak=mod_CR(i).ur_fpkt;
       package.mod_tp_sps(i).CR_trial.UR_fac_info.peak=mod_CR(i).ur_fac;
    end    
    if package.mod_tp_sps(i).CR_trial.UR_sup==0
       package.mod_tp_sps(i).CR_trial.UR_sup_info=[];
    else 
       package.mod_tp_sps(i).CR_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_sps(i).CR_trial.UR_sup_info.t_peak=mod_CR(i).ur_spkt;
       package.mod_tp_sps(i).CR_trial.UR_sup_info.peak=mod_CR(i).ur_sup;
    end
  % psth info
    package.psth_sps(i).cell_ch=i;
    package.psth_sps(i).CR_trial=struct('bsl_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth_sps(i).CR_trial.bsl_frq=mod_CR(i).bsl_frq;
    package.psth_sps(i).CR_trial.psth_raw=psth_CR_Gau(i).Gau_psth_org;
    package.psth_sps(i).CR_trial.psth_smooth=psth_CR_Gau(i).Gau_psth_shft;
  % ttt info 
    package.ttt_sps(i).cell_ch=i;
    package.ttt_sps(i).CR_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    CR_blk_data=zeros(blk_t,size(Clocs,2));
    for k=1:size(Clocs,2)
        package.ttt_sps(i).CR_trial(k).trial_num=Clocs(k).nr;
        package.ttt_sps(i).CR_trial(k).cs_lc=Clocs(k).t;
        package.ttt_sps(i).CR_trial(k).blk_trace(:,1)=blk(Clocs(k).nr).t;
        package.ttt_sps(i).CR_trial(k).blk_trace(:,2)=blk(Clocs(k).nr).t-Clocs(k).t;
        package.ttt_sps(i).CR_trial(k).blk_trace(:,3)=blk(Clocs(k).nr).tr;
        package.ttt_sps(i).CR_trial(k).blk_trace(:,4)=blk(Clocs(k).nr).tr/UR_mean;
        CR_blk_data(:,k)=blk(Clocs(k).nr).tr/UR_mean;
        package.ttt_sps(i).CR_trial(k).blk_info=blk_trial_info(behavior,Clocs(k).nr);
        package.ttt_sps(i).CR_trial(k).spk_time=Ctas(i).tss(k).t;
        package.ttt_sps(i).CR_trial(k).ifr_org_Gau=ttt_CR_Gau(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt_sps(i).CR_trial(k).ifr_smooth=ttt_CR_Gau(i).ifr_Gau_cell(k).ifr_Gau_bin;
    end
    package.blk_avg.CR_trial(:,1)=(blk(Clocs(1).nr).t-Clocs(1).t)*1000;  
    package.blk_avg.CR_trial(:,2)=mean(CR_blk_data,2);
    
% nonCR_trial
  % modulation type
    package.mod_tp_sps(i).nonCR_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp_sps(i).nonCR_trial.CR_fac=mod_NO(i).fac_merge;
    package.mod_tp_sps(i).nonCR_trial.CR_sup=mod_NO(i).sup_merge;
    if mod_NO(i).ur_fac==0
       package.mod_tp_sps(i).nonCR_trial.UR_fac=0;
    else 
       package.mod_tp_sps(i).nonCR_trial.UR_fac=1; 
    end
    if mod_NO(i).ur_sup==0
       package.mod_tp_sps(i).nonCR_trial.UR_sup=0;
    else 
       package.mod_tp_sps(i).nonCR_trial.UR_sup=1; 
    end
    if package.mod_tp_sps(i).nonCR_trial.CR_fac==0
       package.mod_tp_sps(i).nonCR_trial.CR_fac_info=[];
    else
       package.mod_tp_sps(i).nonCR_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_sps(i).nonCR_trial.CR_fac
           package.mod_tp_sps(i).nonCR_trial.CR_fac_info(j).t_onset=mod_NO(i).fac_mginfo(j).t_onset;
           package.mod_tp_sps(i).nonCR_trial.CR_fac_info(j).t_end=mod_NO(i).fac_mginfo(j).t_end;
           package.mod_tp_sps(i).nonCR_trial.CR_fac_info(j).dur=mod_NO(i).fac_mginfo(j).dur;
           package.mod_tp_sps(i).nonCR_trial.CR_fac_info(j).t_peak=mod_NO(i).fac_mginfo(j).t_peak;
           package.mod_tp_sps(i).nonCR_trial.CR_fac_info(j).peak=mod_NO(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp_sps(i).nonCR_trial.CR_sup==0
       package.mod_tp_sps(i).nonCR_trial.CR_sup_info=[];
    else
       package.mod_tp_sps(i).nonCR_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_sps(i).nonCR_trial.CR_sup
           package.mod_tp_sps(i).nonCR_trial.CR_sup_info(j).t_onset=mod_NO(i).sup_mginfo(j).t_onset;
           package.mod_tp_sps(i).nonCR_trial.CR_sup_info(j).t_end=mod_NO(i).sup_mginfo(j).t_end;
           package.mod_tp_sps(i).nonCR_trial.CR_sup_info(j).dur=mod_NO(i).sup_mginfo(j).dur;
           package.mod_tp_sps(i).nonCR_trial.CR_sup_info(j).t_peak=mod_NO(i).sup_mginfo(j).t_peak;
           package.mod_tp_sps(i).nonCR_trial.CR_sup_info(j).peak=mod_NO(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp_sps(i).nonCR_trial.UR_fac==0
       package.mod_tp_sps(i).nonCR_trial.UR_fac_info=[];
    else 
       package.mod_tp_sps(i).nonCR_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_sps(i).nonCR_trial.UR_fac_info.t_peak=mod_NO(i).ur_fpkt;
       package.mod_tp_sps(i).nonCR_trial.UR_fac_info.peak=mod_NO(i).ur_fac;
    end    
    if package.mod_tp_sps(i).nonCR_trial.UR_sup==0
       package.mod_tp_sps(i).nonCR_trial.UR_sup_info=[];
    else 
       package.mod_tp_sps(i).nonCR_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_sps(i).nonCR_trial.UR_sup_info.t_peak=mod_NO(i).ur_spkt;
       package.mod_tp_sps(i).nonCR_trial.UR_sup_info.peak=mod_NO(i).ur_sup;
    end
  % psth info
    package.psth_sps(i).nonCR_trial=struct('bsl_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth_sps(i).nonCR_trial.bsl_frq=mod_CR(i).bsl_frq;
    package.psth_sps(i).nonCR_trial.psth_raw=psth_NO_Gau(i).Gau_psth_org;
    package.psth_sps(i).nonCR_trial.psth_smooth=psth_NO_Gau(i).Gau_psth_shft;
  % ttt info
    package.ttt_sps(i).nonCR_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    nonCR_blk_data=zeros(blk_t,size(NO_locs,2));
    for k=1:size(NO_locs,2)
        package.ttt_sps(i).nonCR_trial(k).trial_num=NO_locs(k).nr;
        package.ttt_sps(i).nonCR_trial(k).cs_lc=NO_locs(k).t;
        package.ttt_sps(i).nonCR_trial(k).blk_trace(:,1)=blk(NO_locs(k).nr).t;
        package.ttt_sps(i).nonCR_trial(k).blk_trace(:,2)=blk(NO_locs(k).nr).t-NO_locs(k).t;
        package.ttt_sps(i).nonCR_trial(k).blk_trace(:,3)=blk(NO_locs(k).nr).tr;
        package.ttt_sps(i).nonCR_trial(k).blk_trace(:,4)=blk(NO_locs(k).nr).tr/UR_mean;
        nonCR_blk_data(:,k)=blk(NO_locs(k).nr).tr/UR_mean;
        package.ttt_sps(i).nonCR_trial(k).blk_info=blk_trial_info(behavior,NO_locs(k).nr);
        package.ttt_sps(i).nonCR_trial(k).spk_time=Ntas(i).tss(k).t;
        package.ttt_sps(i).nonCR_trial(k).ifr_org_Gau=ttt_NO_Gau(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt_sps(i).nonCR_trial(k).ifr_smooth=ttt_NO_Gau(i).ifr_Gau_cell(k).ifr_Gau_bin;
    end
        package.blk_avg.nonCR_trial(:,1)=(blk(NO_locs(1).nr).t-NO_locs(1).t)*1000;  
        package.blk_avg.nonCR_trial(:,2)=mean(nonCR_blk_data,2);
    
% Probe_trial
  % modulation type
    package.mod_tp_sps(i).probe_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp_sps(i).probe_trial.CR_fac=mod_PRB(i).fac_merge;
    package.mod_tp_sps(i).probe_trial.CR_sup=mod_PRB(i).sup_merge;
    if mod_PRB(i).ur_fac==0
       package.mod_tp_sps(i).probe_trial.UR_fac=0;
    else 
       package.mod_tp_sps(i).probe_trial.UR_fac=1; 
    end
    if mod_PRB(i).ur_sup==0
       package.mod_tp_sps(i).probe_trial.UR_sup=0;
    else 
       package.mod_tp_sps(i).probe_trial.UR_sup=1; 
    end
    if package.mod_tp_sps(i).probe_trial.CR_fac==0
       package.mod_tp_sps(i).probe_trial.CR_fac_info=[];
    else
       package.mod_tp_sps(i).probe_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_sps(i).probe_trial.CR_fac
           package.mod_tp_sps(i).probe_trial.CR_fac_info(j).t_onset=mod_PRB(i).fac_mginfo(j).t_onset;
           package.mod_tp_sps(i).probe_trial.CR_fac_info(j).t_end=mod_PRB(i).fac_mginfo(j).t_end;
           package.mod_tp_sps(i).probe_trial.CR_fac_info(j).dur=mod_PRB(i).fac_mginfo(j).dur;
           package.mod_tp_sps(i).probe_trial.CR_fac_info(j).t_peak=mod_PRB(i).fac_mginfo(j).t_peak;
           package.mod_tp_sps(i).probe_trial.CR_fac_info(j).peak=mod_PRB(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp_sps(i).probe_trial.CR_sup==0
       package.mod_tp_sps(i).probe_trial.CR_sup_info=[];
    else
       package.mod_tp_sps(i).probe_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_sps(i).probe_trial.CR_sup
           package.mod_tp_sps(i).probe_trial.CR_sup_info(j).t_onset=mod_PRB(i).sup_mginfo(j).t_onset;
           package.mod_tp_sps(i).probe_trial.CR_sup_info(j).t_end=mod_PRB(i).sup_mginfo(j).t_end;
           package.mod_tp_sps(i).probe_trial.CR_sup_info(j).dur=mod_PRB(i).sup_mginfo(j).dur;
           package.mod_tp_sps(i).probe_trial.CR_sup_info(j).t_peak=mod_PRB(i).sup_mginfo(j).t_peak;
           package.mod_tp_sps(i).probe_trial.CR_sup_info(j).peak=mod_PRB(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp_sps(i).probe_trial.UR_fac==0
       package.mod_tp_sps(i).probe_trial.UR_fac_info=[];
    else 
       package.mod_tp_sps(i).probe_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_sps(i).probe_trial.UR_fac_info.t_peak=mod_PRB(i).ur_fpkt;
       package.mod_tp_sps(i).probe_trial.UR_fac_info.peak=mod_PRB(i).ur_fac;
    end    
    if package.mod_tp_sps(i).probe_trial.UR_sup==0
       package.mod_tp_sps(i).probe_trial.UR_sup_info=[];
    else 
       package.mod_tp_sps(i).probe_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_sps(i).probe_trial.UR_sup_info.t_peak=mod_PRB(i).ur_spkt;
       package.mod_tp_sps(i).probe_trial.UR_sup_info.peak=mod_PRB(i).ur_sup;
    end
  % psth info
    package.psth_sps(i).probe_trial=struct('bsl_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth_sps(i).probe_trial.bsl_frq=mod_PRB(i).bsl_frq;
    package.psth_sps(i).probe_trial.psth_raw=psth_PRB_Gau(i).Gau_psth_org;
    package.psth_sps(i).probe_trial.psth_smooth=psth_PRB_Gau(i).Gau_psth_shft;
  % ttt info
    package.ttt_sps(i).probe_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    probe_blk_data=zeros(blk_t,size(PRB_locs,2));
    for k=1:size(PRB_locs,2)
        package.ttt_sps(i).probe_trial(k).trial_num=PRB_locs(k).nr;
        package.ttt_sps(i).probe_trial(k).cs_lc=PRB_locs(k).t;
        package.ttt_sps(i).probe_trial(k).blk_trace(:,1)=blk(PRB_locs(k).nr).t;
        package.ttt_sps(i).probe_trial(k).blk_trace(:,2)=blk(PRB_locs(k).nr).t-PRB_locs(k).t;
        package.ttt_sps(i).probe_trial(k).blk_trace(:,3)=blk(PRB_locs(k).nr).tr;
        package.ttt_sps(i).probe_trial(k).blk_trace(:,4)=blk(PRB_locs(k).nr).tr/UR_mean;
        probe_blk_data(:,k)=blk(PRB_locs(k).nr).tr/UR_mean;
        package.ttt_sps(i).probe_trial(k).blk_info=blk_trial_info(behavior,PRB_locs(k).nr);
        package.ttt_sps(i).probe_trial(k).spk_time=Ptas(i).tss(k).t;
        package.ttt_sps(i).probe_trial(k).ifr_org_Gau=ttt_PRB_Gau(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt_sps(i).probe_trial(k).ifr_smooth=ttt_PRB_Gau(i).ifr_Gau_cell(k).ifr_Gau_bin;
    end
        package.blk_avg.probe_trial(:,1)=(blk(PRB_locs(1).nr).t-PRB_locs(1).t)*1000;  
        package.blk_avg.probe_trial(:,2)=mean(probe_blk_data,2);
end
        
% cps analysis
for m=1:size(mod_cps_CR,2)

  % CR_trial
  % modulation type
    package.mod_tp_cps(m).cell_ch=Ctas_cps(m).ch;
    package.mod_tp_cps(m).CR_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp_cps(m).CR_trial.CR_fac=mod_cps_CR(m).fac_merge;
    package.mod_tp_cps(m).CR_trial.CR_sup=mod_cps_CR(m).sup_merge;
    if mod_cps_CR(m).ur_fac==0
       package.mod_tp_cps(m).CR_trial.UR_fac=0;
    else 
       package.mod_tp_cps(m).CR_trial.UR_fac=1; 
    end
    if mod_cps_CR(m).ur_sup==0
       package.mod_tp_cps(m).CR_trial.UR_sup=0;
    else 
       package.mod_tp_cps(m).CR_trial.UR_sup=1; 
    end
    if package.mod_tp_cps(m).CR_trial.CR_fac==0
       package.mod_tp_cps(m).CR_trial.CR_fac_info=[];
    else
       package.mod_tp_cps(m).CR_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_cps(m).CR_trial.CR_fac
           package.mod_tp_cps(m).CR_trial.CR_fac_info(j).t_onset=mod_cps_CR(m).fac_mginfo(j).t_onset;
           package.mod_tp_cps(m).CR_trial.CR_fac_info(j).t_end=mod_cps_CR(m).fac_mginfo(j).t_end;
           package.mod_tp_cps(m).CR_trial.CR_fac_info(j).dur=mod_cps_CR(m).fac_mginfo(j).dur;
           package.mod_tp_cps(m).CR_trial.CR_fac_info(j).t_peak=mod_cps_CR(m).fac_mginfo(j).t_peak;
           package.mod_tp_cps(m).CR_trial.CR_fac_info(j).peak=mod_cps_CR(m).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp_cps(m).CR_trial.CR_sup==0
       package.mod_tp_cps(m).CR_trial.CR_sup_info=[];
    else
       package.mod_tp_cps(m).CR_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_cps(m).CR_trial.CR_sup
           package.mod_tp_cps(m).CR_trial.CR_sup_info(j).t_onset=mod_cps_CR(m).sup_mginfo(j).t_onset;
           package.mod_tp_cps(m).CR_trial.CR_sup_info(j).t_end=mod_cps_CR(m).sup_mginfo(j).t_end;
           package.mod_tp_cps(m).CR_trial.CR_sup_info(j).dur=mod_cps_CR(m).sup_mginfo(j).dur;
           package.mod_tp_cps(m).CR_trial.CR_sup_info(j).t_peak=mod_cps_CR(m).sup_mginfo(j).t_peak;
           package.mod_tp_cps(m).CR_trial.CR_sup_info(j).peak=mod_cps_CR(m).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp_cps(m).CR_trial.UR_fac==0
       package.mod_tp_cps(m).CR_trial.UR_fac_info=[];
    else 
       package.mod_tp_cps(m).CR_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_cps(m).CR_trial.UR_fac_info.t_peak=mod_cps_CR(m).ur_fpkt;
       package.mod_tp_cps(m).CR_trial.UR_fac_info.peak=mod_cps_CR(m).ur_fac;
    end    
    if package.mod_tp_cps(m).CR_trial.UR_sup==0
       package.mod_tp_cps(m).CR_trial.UR_sup_info=[];
    else 
       package.mod_tp_cps(m).CR_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_cps(m).CR_trial.UR_sup_info.t_peak=mod_cps_CR(m).ur_spkt;
       package.mod_tp_cps(m).CR_trial.UR_sup_info.peak=mod_cps_CR(m).ur_sup;
    end
  % psth info
    package.psth_cps(m).cell_ch=Ctas_cps(m).ch;
    package.psth_cps(m).CR_trial=struct('bsl_frq',[],'test_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth_cps(m).CR_trial.bsl_frq=mod_cps_CR(m).bsl_frq;
    package.psth_cps(m).CR_trial.test_frq=mod_cps_CR(m).test_frq;
    package.psth_cps(m).CR_trial.psth_raw=psth_cps_CR_Gau(m).Gau_psth_org;
    package.psth_cps(m).CR_trial.psth_smooth=psth_cps_CR_Gau(m).Gau_psth_shft;
  % ttt info 
    package.ttt_cps(m).cell_ch=Ctas_cps(m).ch;
    package.ttt_cps(m).CR_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    CR_blk_data=zeros(blk_t,size(Clocs,2));
    for k=1:size(Clocs,2)
        package.ttt_cps(m).CR_trial(k).trial_num=Clocs(k).nr;
        package.ttt_cps(m).CR_trial(k).cs_lc=Clocs(k).t;
        package.ttt_cps(m).CR_trial(k).blk_trace(:,1)=blk(Clocs(k).nr).t;
        package.ttt_cps(m).CR_trial(k).blk_trace(:,2)=blk(Clocs(k).nr).t-Clocs(k).t;
        package.ttt_cps(m).CR_trial(k).blk_trace(:,3)=blk(Clocs(k).nr).tr;
        package.ttt_cps(m).CR_trial(k).blk_trace(:,4)=blk(Clocs(k).nr).tr/UR_mean;
        CR_blk_data(:,k)=blk(Clocs(k).nr).tr/UR_mean;
        package.ttt_cps(m).CR_trial(k).blk_info=blk_trial_info(behavior,Clocs(k).nr);
        package.ttt_cps(m).CR_trial(k).spk_time=Ctas_cps(m).tss(k).t;
        package.ttt_cps(m).CR_trial(k).ifr_org_Gau=ttt_cps_CR_Gau(m).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt_cps(m).CR_trial(k).ifr_smooth=ttt_cps_CR_Gau(m).ifr_Gau_cell(k).ifr_Gau_bin;
    end

    % nonCR_trial
  % modulation type
    package.mod_tp_cps(m).nonCR_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp_cps(m).nonCR_trial.CR_fac=mod_cps_NO(m).fac_merge;
    package.mod_tp_cps(m).nonCR_trial.CR_sup=mod_cps_NO(m).sup_merge;
    if mod_cps_NO(m).ur_fac==0
       package.mod_tp_cps(m).nonCR_trial.UR_fac=0;
    else 
       package.mod_tp_cps(m).nonCR_trial.UR_fac=1; 
    end
    if mod_cps_NO(m).ur_sup==0
       package.mod_tp_cps(m).nonCR_trial.UR_sup=0;
    else 
       package.mod_tp_cps(m).nonCR_trial.UR_sup=1; 
    end
    if package.mod_tp_cps(m).nonCR_trial.CR_fac==0
       package.mod_tp_cps(m).nonCR_trial.CR_fac_info=[];
    else
       package.mod_tp_cps(m).nonCR_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_cps(m).nonCR_trial.CR_fac
           package.mod_tp_cps(m).nonCR_trial.CR_fac_info(j).t_onset=mod_cps_NO(m).fac_mginfo(j).t_onset;
           package.mod_tp_cps(m).nonCR_trial.CR_fac_info(j).t_end=mod_cps_NO(m).fac_mginfo(j).t_end;
           package.mod_tp_cps(m).nonCR_trial.CR_fac_info(j).dur=mod_cps_NO(m).fac_mginfo(j).dur;
           package.mod_tp_cps(m).nonCR_trial.CR_fac_info(j).t_peak=mod_cps_NO(m).fac_mginfo(j).t_peak;
           package.mod_tp_cps(m).nonCR_trial.CR_fac_info(j).peak=mod_cps_NO(m).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp_cps(m).nonCR_trial.CR_sup==0
       package.mod_tp_cps(m).nonCR_trial.CR_sup_info=[];
    else
       package.mod_tp_cps(m).nonCR_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_cps(m).nonCR_trial.CR_sup
           package.mod_tp_cps(m).nonCR_trial.CR_sup_info(j).t_onset=mod_cps_NO(m).sup_mginfo(j).t_onset;
           package.mod_tp_cps(m).nonCR_trial.CR_sup_info(j).t_end=mod_cps_NO(m).sup_mginfo(j).t_end;
           package.mod_tp_cps(m).nonCR_trial.CR_sup_info(j).dur=mod_cps_NO(m).sup_mginfo(j).dur;
           package.mod_tp_cps(m).nonCR_trial.CR_sup_info(j).t_peak=mod_cps_NO(m).sup_mginfo(j).t_peak;
           package.mod_tp_cps(m).nonCR_trial.CR_sup_info(j).peak=mod_cps_NO(m).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp_cps(m).nonCR_trial.UR_fac==0
       package.mod_tp_cps(m).nonCR_trial.UR_fac_info=[];
    else 
       package.mod_tp_cps(m).nonCR_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_cps(m).nonCR_trial.UR_fac_info.t_peak=mod_cps_NO(m).ur_fpkt;
       package.mod_tp_cps(m).nonCR_trial.UR_fac_info.peak=mod_cps_NO(m).ur_fac;
    end    
    if package.mod_tp_cps(m).nonCR_trial.UR_sup==0
       package.mod_tp_cps(m).nonCR_trial.UR_sup_info=[];
    else 
       package.mod_tp_cps(m).nonCR_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_cps(m).nonCR_trial.UR_sup_info.t_peak=mod_cps_NO(m).ur_spkt;
       package.mod_tp_cps(m).nonCR_trial.UR_sup_info.peak=mod_cps_NO(m).ur_sup;
    end
  % psth info
    package.psth_cps(m).nonCR_trial=struct('bsl_frq',[],'test_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth_cps(m).nonCR_trial.bsl_frq=mod_cps_CR(m).bsl_frq;
    package.psth_cps(m).nonCR_trial.test_frq=mod_cps_CR(m).test_frq;
    package.psth_cps(m).nonCR_trial.psth_raw=psth_cps_NO_Gau(m).Gau_psth_org;
    package.psth_cps(m).nonCR_trial.psth_smooth=psth_cps_NO_Gau(m).Gau_psth_shft;
  % ttt info
    package.ttt_cps(m).nonCR_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    nonCR_blk_data=zeros(blk_t,size(NO_locs,2));
    for k=1:size(NO_locs,2)
        package.ttt_cps(m).nonCR_trial(k).trial_num=NO_locs(k).nr;
        package.ttt_cps(m).nonCR_trial(k).cs_lc=NO_locs(k).t;
        package.ttt_cps(m).nonCR_trial(k).blk_trace(:,1)=blk(NO_locs(k).nr).t;
        package.ttt_cps(m).nonCR_trial(k).blk_trace(:,2)=blk(NO_locs(k).nr).t-NO_locs(k).t;
        package.ttt_cps(m).nonCR_trial(k).blk_trace(:,3)=blk(NO_locs(k).nr).tr;
        package.ttt_cps(m).nonCR_trial(k).blk_trace(:,4)=blk(NO_locs(k).nr).tr/UR_mean;
        nonCR_blk_data(:,k)=blk(NO_locs(k).nr).tr/UR_mean;
        package.ttt_cps(m).nonCR_trial(k).blk_info=blk_trial_info(behavior,NO_locs(k).nr);
        package.ttt_cps(m).nonCR_trial(k).spk_time=Ntas_cps(m).tss(k).t;
        package.ttt_cps(m).nonCR_trial(k).ifr_org_Gau=ttt_cps_NO_Gau(m).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt_cps(m).nonCR_trial(k).ifr_smooth=ttt_cps_NO_Gau(m).ifr_Gau_cell(k).ifr_Gau_bin;
    end
        package.blk_avg.nonCR_trial(:,1)=(blk(NO_locs(1).nr).t-NO_locs(1).t)*1000;  
        package.blk_avg.nonCR_trial(:,2)=mean(nonCR_blk_data,2);

        % Probe_trial
    % modulation type
    package.mod_tp_cps(m).probe_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp_cps(m).probe_trial.CR_fac=mod_cps_PRB(m).fac_merge;
    package.mod_tp_cps(m).probe_trial.CR_sup=mod_cps_PRB(m).sup_merge;
    if mod_cps_PRB(m).ur_fac==0
       package.mod_tp_cps(m).probe_trial.UR_fac=0;
    else 
       package.mod_tp_cps(m).probe_trial.UR_fac=1; 
    end
    if mod_cps_PRB(m).ur_sup==0
       package.mod_tp_cps(m).probe_trial.UR_sup=0;
    else 
       package.mod_tp_cps(m).probe_trial.UR_sup=1; 
    end
    if package.mod_tp_cps(m).probe_trial.CR_fac==0
       package.mod_tp_cps(m).probe_trial.CR_fac_info=[];
    else
       package.mod_tp_cps(m).probe_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_cps(m).probe_trial.CR_fac
           package.mod_tp_cps(m).probe_trial.CR_fac_info(j).t_onset=mod_cps_PRB(m).fac_mginfo(j).t_onset;
           package.mod_tp_cps(m).probe_trial.CR_fac_info(j).t_end=mod_cps_PRB(m).fac_mginfo(j).t_end;
           package.mod_tp_cps(m).probe_trial.CR_fac_info(j).dur=mod_cps_PRB(m).fac_mginfo(j).dur;
           package.mod_tp_cps(m).probe_trial.CR_fac_info(j).t_peak=mod_cps_PRB(m).fac_mginfo(j).t_peak;
           package.mod_tp_cps(m).probe_trial.CR_fac_info(j).peak=mod_cps_PRB(m).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp_cps(m).probe_trial.CR_sup==0
       package.mod_tp_cps(m).probe_trial.CR_sup_info=[];
    else
       package.mod_tp_cps(m).probe_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp_cps(m).probe_trial.CR_sup
           package.mod_tp_cps(m).probe_trial.CR_sup_info(j).t_onset=mod_cps_PRB(m).sup_mginfo(j).t_onset;
           package.mod_tp_cps(m).probe_trial.CR_sup_info(j).t_end=mod_cps_PRB(m).sup_mginfo(j).t_end;
           package.mod_tp_cps(m).probe_trial.CR_sup_info(j).dur=mod_cps_PRB(m).sup_mginfo(j).dur;
           package.mod_tp_cps(m).probe_trial.CR_sup_info(j).t_peak=mod_cps_PRB(m).sup_mginfo(j).t_peak;
           package.mod_tp_cps(m).probe_trial.CR_sup_info(j).peak=mod_cps_PRB(m).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp_cps(m).probe_trial.UR_fac==0
       package.mod_tp_cps(m).probe_trial.UR_fac_info=[];
    else 
       package.mod_tp_cps(m).probe_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_cps(m).probe_trial.UR_fac_info.t_peak=mod_cps_PRB(m).ur_fpkt;
       package.mod_tp_cps(m).probe_trial.UR_fac_info.peak=mod_cps_PRB(m).ur_fac;
    end    
    if package.mod_tp_cps(m).probe_trial.UR_sup==0
       package.mod_tp_cps(m).probe_trial.UR_sup_info=[];
    else 
       package.mod_tp_cps(m).probe_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp_cps(m).probe_trial.UR_sup_info.t_peak=mod_cps_PRB(m).ur_spkt;
       package.mod_tp_cps(m).probe_trial.UR_sup_info.peak=mod_cps_PRB(m).ur_sup;
    end
  % psth info
    package.psth_cps(m).probe_trial=struct('bsl_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth_cps(m).probe_trial.bsl_frq=mod_cps_PRB(m).bsl_frq;
    package.psth_cps(m).probe_trial.psth_raw=psth_cps_PRB_Gau(m).Gau_psth_org;
    package.psth_cps(m).probe_trial.psth_smooth=psth_cps_PRB_Gau(m).Gau_psth_shft;
  % ttt info
    package.ttt_cps(m).probe_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    probe_blk_data=zeros(blk_t,size(PRB_locs,2));
    for k=1:size(PRB_locs,2)
        package.ttt_cps(m).probe_trial(k).trial_num=PRB_locs(k).nr;
        package.ttt_cps(m).probe_trial(k).cs_lc=PRB_locs(k).t;
        package.ttt_cps(m).probe_trial(k).blk_trace(:,1)=blk(PRB_locs(k).nr).t;
        package.ttt_cps(m).probe_trial(k).blk_trace(:,2)=blk(PRB_locs(k).nr).t-PRB_locs(k).t;
        package.ttt_cps(m).probe_trial(k).blk_trace(:,3)=blk(PRB_locs(k).nr).tr;
        package.ttt_cps(m).probe_trial(k).blk_trace(:,4)=blk(PRB_locs(k).nr).tr/UR_mean;
        probe_blk_data(:,k)=blk(PRB_locs(k).nr).tr/UR_mean;
        package.ttt_cps(m).probe_trial(k).blk_info=blk_trial_info(behavior,PRB_locs(k).nr);
        package.ttt_cps(m).probe_trial(k).spk_time=Ptas_cps(m).tss(k).t;
        package.ttt_cps(m).probe_trial(k).ifr_org_Gau=ttt_cps_PRB_Gau(m).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt_cps(m).probe_trial(k).ifr_smooth=ttt_cps_PRB_Gau(m).ifr_Gau_cell(k).ifr_Gau_bin;
    end
    package.blk_avg.probe_trial(:,1)=(blk(PRB_locs(1).nr).t-PRB_locs(1).t)*1000;  
    package.blk_avg.probe_trial(:,2)=mean(probe_blk_data,2); 

end


cd(outpath);
save(['pack_' csv_name '.mat'],'package');
end