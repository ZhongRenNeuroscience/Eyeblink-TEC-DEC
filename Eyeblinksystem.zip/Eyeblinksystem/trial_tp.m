% Group the trial type (CR, non-CR, and probe) with their trigger time 
% points based on the behavior form from behavior_analysis. --Zhong

function [Clocs,NO_locs,PRB_locs]=trial_tp(behavior,cs_lc)

Clocs=struct('nr',[],'t',[]);
% All_locs=struct('nr',[],'t',[]);
NO_locs=struct('nr',[],'t',[]);
PRB_locs=struct('nr',[],'t',[]);
CR=1;
NO=1;
PRB=1;

for i=1:size(cs_lc,1)
%     All_locs(i).nr=i;
%     All_locs(i).t=cs_lc(i,1);
    if behavior{i,2}==1 && behavior{i,3}==1
        Clocs(CR).nr=i;
        Clocs(CR).t=round(cs_lc(i,1),5);
        CR=CR+1;
    elseif behavior{i,2}==0 && behavior{i,3}==1
        NO_locs(NO).nr=i;
        NO_locs(NO).t=round(cs_lc(i,1),5);
        NO=NO+1;
    elseif behavior{i,3}==0 && behavior{i,2}==1
        PRB_locs(PRB).nr=i;
        PRB_locs(PRB).t=round(cs_lc(i,1),5);
        PRB=PRB+1;
    end
end
end

