% clear;

% Input parameters
  csv_name = 'DCN10_180620_115900_ks4_test.csv';
  t_pre = 550;
  t_post = 500;
  t_probe=t_post+250;  %(t_probe=t_post+250 just for whole probe trial trace)
  dur = 1000;
  t_psth = 1050;
%   bin_psth = 150;
%   bin_corr = 250;
%   psth_window = 50;
  

% Import Intan header and path
  read_Intan_RHD2000_file;
%   cd(path);
% Import Intan time vectors
  t = import_intan_time;
  t = fix_intan_time(t);
% Import Intan ADC channels vector
  adc = import_intan_adc([]);
%   din = import_intan_din([]);
% Import CSV file from JRCLUST
%   spk = import_jrc_csv(csv_name);
  csv_name=extractBefore(csv_name,'.csv');
%   ctp = import_ctp_csv('cell_tp.csv');
% Detection CS/US edge
  cs_lc = find_trg_pks([adc(1).v],3,t,dur);
  us_lc = find_trg_pks([adc(2).v],3,t,dur);
%   us_lc(10:10:end,:) = [];
% Filter eyeblink trace
%   v = idv_filter([adc(4).v],1,200,0,0,0,0);
  v = [adc(3).v];
% Detect CR/UR in eyeblink trace
  blk = blk_detn(v,t,cs_lc,us_lc,t_pre,t_post,t_probe,dur);
  [behavior,trial_num,early]=behavior_analysis(blk,cs_lc,t_pre,t_post,t_probe);
%   blk_plot(t,blk);
% Calculte PSTH
%   Clocs = locs_vfy(1,cs_lc,{blk.cr_on});
  [Clocs,NO_locs,PRB_locs]=trial_tp(behavior,cs_lc);
  
  Ctas=tas_calc(spk,Clocs,t_pre,t_psth);
% Atas=tas_calc(spk,All_locs,t_pre,t_post);
%   Ntas=tas_calc(spk,NO_locs,t_pre,t_psth);
%   Ptas=tas_calc(spk,PRB_locs,t_pre,t_psth);

% Calculate the raw displacement on the treadmill
%   velo_C=velocity_raw(din,t,1,2,Clocs);
%   velo_N=velocity_raw(din,t,1,2,NO_locs);
%   velo_P=velocity_raw(din,t,1,2,PRB_locs);

%   [Cpsth,Ctas] = psth_calc(spk,Clocs,psth_window,1,t_pre,t_psth);
%   All_locs=locs_vfy(0,cs_lc,{blk.cr_on});
% % Cell modulation detection
%   mod_tp = cell_mod_detn(Cpsth,[-500 0],[0 500],[0 500]);
%   blk_spk = blk_spk_calc(spk,blk,Clocs,t_pre,t_post,bin_corr);
% Trial by trial behavior analysis
  
% Saving
%   blk_pack = dat_out_blk('aaa',500,ctp,blk,Cpsth,mod_tp,blk_spk);

% Shift window PSTH plot
% psth_plot(Cpsth,size(Cpsth,2),size(Clocs,2),'hist',Ctas,blk,Clocs)

% Gaussian spike smoothing filter and PSTH plot
spk_CR_Gau=spk_Gaussian(Ctas,t_pre,t_psth,20,6);  %for whole session PSTH using CR trials
psth_CR_Gau=Gau_psth_cal(spk_CR_Gau,t_pre,t_psth,0);  % last input is for sliding window
mod_CR=modulation_type(t_pre-50,t_post,psth_CR_Gau,3,10);
ttt_CR_Gau=ifr_Gau_trial(spk_CR_Gau,10,1); % shift_window size + bin size
Gau_psth_plot(psth_CR_Gau,Ctas,blk,Clocs,t_post,'CR',csv_name);
% if ~isempty(NO_locs(1).nr)
%     spk_NO_Gau=spk_Gaussian(Ntas,t_pre,t_psth,20,6);
%     psth_NO_Gau=Gau_psth_cal(spk_NO_Gau,t_pre,t_psth,0);
%     mod_NO=modulation_type(t_pre-50,t_post,psth_NO_Gau,3,10);
%     ttt_NO_Gau=ifr_Gau_trial(spk_NO_Gau,10,1); % shift_window size + bin size
% else
%     spk_NO_Gau=[];
%     psth_NO_Gau=[];
%     mod_NO=[];
%     ttt_NO_Gau=[]; 
% end
% % Gau_psth_plot(psth_NO_Gau,Ntas,blk,NO_locs,t_post,0,'NON');
% 
% if ~isempty(PRB_locs(1).nr)
%     spk_PRB_Gau=spk_Gaussian(Ptas,t_pre,t_psth,20,6);
%     psth_PRB_Gau=Gau_psth_cal(spk_PRB_Gau,t_pre,t_psth,0);
%     mod_PRB=modulation_type(t_pre-50,t_post,psth_PRB_Gau,3,10);
%     ttt_PRB_Gau=ifr_Gau_trial(spk_PRB_Gau,10,1); % shift_window size + bin size
% else
%     spk_PRB_Gau=[];
%     psth_PRB_Gau=[];
%     mod_PRB=[];
%     ttt_PRB_Gau=[]; 
% end
    
% spk_Gau_ifr=spk_Gaussian(Atas,t_pre,t_psth,10,3);   %for single trial instantaneous firing rate using all trials
% Gau_psth_ifr=Gau_psth_all(spk_Gau_ifr,t_pre,t_psth,0); % last parameter: window size

% Gau_psth_plot_CNP(psth_CR_Gau,psth_NO_Gau,psth_PRB_Gau,Ctas,Ntas,Ptas,blk,Clocs,NO_locs,PRB_locs,t_post,csv_name)

% Behavior drift plot
% blk_drift_plot(blk,Clocs);

% load 'blk.mat';
% load 'cs_lc.mat';
% load 't_post.mat';
% load 'Clocs.mat';

% [behavior,trial_num,early]=behavior_analysis(blk,cs_lc,t_pre,t_post,t_probe);
% [correlation,p_cor,drift_slope]=blk_drift_plot(blk,Clocs,t_post);
% [conversion_test_10]=conversion_test(behavior,10);
% [conversion_test_20]=conversion_test(behavior,20);
% [conversion_test_30]=conversion_test(behavior,30);
% behavior_output=behavior_output(behavior,trial_num,correlation,p_cor,drift_slope,early,conversion_test_10,conversion_test_20,conversion_test_30);
% save_behavior(blk,behavior,cs_lc,Clocs);
% 
% package=package(blk,behavior,ifr_Gau_trial);

% package=pckg_all(t_pre,t_post,dur,Clocs,NO_locs,PRB_locs,blk,behavior,psth_CR_Gau,psth_NO_Gau,psth_PRB_Gau,mod_CR,mod_NO,mod_PRB,ttt_CR_Gau,ttt_NO_Gau,ttt_PRB_Gau,Ctas,Ntas,Ptas,csv_name,spk);
% cd(path);

