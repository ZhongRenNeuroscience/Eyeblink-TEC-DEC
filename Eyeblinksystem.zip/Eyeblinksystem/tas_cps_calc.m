function tss_cps = tas_cps_calc(t_CpX,stm_lc,t_pre,t_post)
    t_pre = t_pre / 1000;
    t_post = t_post / 1000;

  % Creating trigger aligned spikes (TAS) as a struct   
      % Extracting data for each cell as trigger separated spikes (TSS)
        tss_cps(size(stm_lc,2)) = struct('trial',[],'t',[]);
        for j = 1:size(stm_lc,2)
            idx = (t_CpX > stm_lc(j).t - t_pre) & (t_CpX <= stm_lc(j).t + t_post);
            fire = t_CpX(idx);
            fire = fire - stm_lc(j).t;
          % Arranging data
            tss_cps(j).trial = stm_lc(j).nr;
            tss_cps(j).t = round(fire,5);
        end

end