% Make all usable info of one recording session into a package.
% Level 1: mod_tp: contains both the CR and UR modulation type info based on whole session psth divided by CR/nonCR/probe trial types.
%          blk_avg: average eyelid trace among 3 types of trials in one session.
%          psth: contains the average ephys info of one session under 3 types of trials
%          ttt: contains both the behavior and instantaneous firing rate (ifr) info of each single trial sorted by 3 types.
%          behavior_table: the behavior analysis result of each single trial.
% Level 2: All the trials are divided here by the trial type, CR or not, probe or not.
% Level 3: mod_type: the number of CR/UR facilitation/suppression and their detail info based on whole session psth.
%          blk_avg: time point + eyelid trace data.
%          psth: average baseline frequency + raw psth only with Gaussian filter with highest time resolusion + smoothed psth after sliding window and bin size.
%          ttt: trial number + cs trigger time point + 
%               blink trace (realtime line; normalized time line; raw eyelid trace; eyelid trace with mean_ur_amplitue normalization) +
%               blink info (the info of this trial extracted from behavior analysis data) +
%               spike time (the spike time point in this trial extracted from spike sorting csv file) +
%               ifr_org_Gau(the ifr data only after the Gaussian conversion) +
%               ifr_smooth (the Gaussian filtered ifr data with sliding window and bin size smoothing)
% (Zhong 31-03-19)

function package=pckg_all_loco(t_pre,dur,Clocs,Nlocs,Plocs,CHlocs,CLlocs,blk,behavior,Cpsth,Npsth,Ppsth,CHpsth,CLpsth,...
    Cmod,Nmod,Pmod,CHmod,CLmod,Cttt,Nttt,Pttt,CHttt,CLttt,Ctas,Ntas,Ptas,CHtas,CLtas,velo_C,velo_N,velo_P,csv_name)

outpath='D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Trace-trained-mice\DCN_mat_output\loco_data\package\';

package=struct('mod_tp',[],'blk_avg',[],'psth',[],'ttt',[],'behavior_table',[]);

package.mod_tp=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[],'CH_trial',[],'CL_trial',[]);
package.blk_avg=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[],'CH_trial',[],'CL_trial',[]);
package.psth=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[],'CH_trial',[],'CL_trial',[]);
package.ttt=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[],'CH_trial',[],'CL_trial',[]);
package.behavior_table=behavior;

blk_t=(t_pre+dur)*20;

UR_mean=mean([blk.ur_amp]);

for i=1:size(Cmod,2)
% CR_trial
  % modulation type
    package.mod_tp(i).CR_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp(i).CR_trial.CR_fac=Cmod(i).fac_merge;
    package.mod_tp(i).CR_trial.CR_sup=Cmod(i).sup_merge;
    if Cmod(i).ur_fac==0
       package.mod_tp(i).CR_trial.UR_fac=0;
    else 
       package.mod_tp(i).CR_trial.UR_fac=1; 
    end
    if Cmod(i).ur_sup==0
       package.mod_tp(i).CR_trial.UR_sup=0;
    else 
       package.mod_tp(i).CR_trial.UR_sup=1; 
    end
    if package.mod_tp(i).CR_trial.CR_fac==0
       package.mod_tp(i).CR_trial.CR_fac_info=[];
    else
       package.mod_tp(i).CR_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).CR_trial.CR_fac
           package.mod_tp(i).CR_trial.CR_fac_info(j).t_onset=Cmod(i).fac_mginfo(j).t_onset;
           package.mod_tp(i).CR_trial.CR_fac_info(j).t_end=Cmod(i).fac_mginfo(j).t_end;
           package.mod_tp(i).CR_trial.CR_fac_info(j).dur=Cmod(i).fac_mginfo(j).dur;
           package.mod_tp(i).CR_trial.CR_fac_info(j).t_peak=Cmod(i).fac_mginfo(j).t_peak;
           package.mod_tp(i).CR_trial.CR_fac_info(j).peak=Cmod(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).CR_trial.CR_sup==0
       package.mod_tp(i).CR_trial.CR_sup_info=[];
    else
       package.mod_tp(i).CR_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).CR_trial.CR_sup
           package.mod_tp(i).CR_trial.CR_sup_info(j).t_onset=Cmod(i).sup_mginfo(j).t_onset;
           package.mod_tp(i).CR_trial.CR_sup_info(j).t_end=Cmod(i).sup_mginfo(j).t_end;
           package.mod_tp(i).CR_trial.CR_sup_info(j).dur=Cmod(i).sup_mginfo(j).dur;
           package.mod_tp(i).CR_trial.CR_sup_info(j).t_peak=Cmod(i).sup_mginfo(j).t_peak;
           package.mod_tp(i).CR_trial.CR_sup_info(j).peak=Cmod(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).CR_trial.UR_fac==0
       package.mod_tp(i).CR_trial.UR_fac_info=[];
    else 
       package.mod_tp(i).CR_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).CR_trial.UR_fac_info.t_peak=Cmod(i).ur_fpkt;
       package.mod_tp(i).CR_trial.UR_fac_info.peak=Cmod(i).ur_fac;
    end    
    if package.mod_tp(i).CR_trial.UR_sup==0
       package.mod_tp(i).CR_trial.UR_sup_info=[];
    else 
       package.mod_tp(i).CR_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).CR_trial.UR_sup_info.t_peak=Cmod(i).ur_spkt;
       package.mod_tp(i).CR_trial.UR_sup_info.peak=Cmod(i).ur_sup;
    end
  % psth info
    package.psth(i).CR_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth(i).CR_trial.avg_frq=Cmod(i).bsl_frq;
    package.psth(i).CR_trial.psth_raw=Cpsth(i).Gau_psth_org;
    package.psth(i).CR_trial.psth_smooth=Cpsth(i).Gau_psth_shft;
  % ttt info 
    package.ttt(i).CR_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[],'avg_velo',[],'peak_velo',[],'velo_info',[],'velo_raw',[]);
    CR_blk_data=zeros(blk_t,size(Clocs,2));
    for k=1:size(Clocs,2)
        package.ttt(i).CR_trial(k).trial_num=Clocs(k).nr;
        package.ttt(i).CR_trial(k).cs_lc=Clocs(k).t;
        package.ttt(i).CR_trial(k).blk_trace(:,1)=blk(Clocs(k).nr).t;
        package.ttt(i).CR_trial(k).blk_trace(:,2)=blk(Clocs(k).nr).t-Clocs(k).t;
        package.ttt(i).CR_trial(k).blk_trace(:,3)=blk(Clocs(k).nr).tr;
        package.ttt(i).CR_trial(k).blk_trace(:,4)=blk(Clocs(k).nr).tr/UR_mean;
        CR_blk_data(:,k)=blk(Clocs(k).nr).tr/UR_mean;
        package.ttt(i).CR_trial(k).blk_info=blk_trial_info(behavior,Clocs(k).nr);
        package.ttt(i).CR_trial(k).spk_time=Ctas(i).tss(k).t;
        package.ttt(i).CR_trial(k).ifr_org_Gau=Cttt(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt(i).CR_trial(k).ifr_smooth=Cttt(i).ifr_Gau_cell(k).ifr_Gau_bin;
        package.ttt(i).CR_trial(k).avg_velo=velo_C(k).avg_velo;
        package.ttt(i).CR_trial(k).peak_velo=velo_C(k).peak_velo;
        package.ttt(i).CR_trial(k).velo_info=velo_C(k).info;
        package.ttt(i).CR_trial(k).velo_raw=velo_C(k).raw;
    end
    package.blk_avg.CR_trial(:,1)=(blk(Clocs(1).nr).t-Clocs(1).t)*1000;  
    package.blk_avg.CR_trial(:,2)=mean(CR_blk_data,2);
    
% nonCR_trial
  % modulation type
    package.mod_tp(i).nonCR_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp(i).nonCR_trial.CR_fac=Nmod(i).fac_merge;
    package.mod_tp(i).nonCR_trial.CR_sup=Nmod(i).sup_merge;
    if Nmod(i).ur_fac==0
       package.mod_tp(i).nonCR_trial.UR_fac=0;
    else 
       package.mod_tp(i).nonCR_trial.UR_fac=1; 
    end
    if Nmod(i).ur_sup==0
       package.mod_tp(i).nonCR_trial.UR_sup=0;
    else 
       package.mod_tp(i).nonCR_trial.UR_sup=1; 
    end
    if package.mod_tp(i).nonCR_trial.CR_fac==0
       package.mod_tp(i).nonCR_trial.CR_fac_info=[];
    else
       package.mod_tp(i).nonCR_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).nonCR_trial.CR_fac
           package.mod_tp(i).nonCR_trial.CR_fac_info(j).t_onset=Nmod(i).fac_mginfo(j).t_onset;
           package.mod_tp(i).nonCR_trial.CR_fac_info(j).t_end=Nmod(i).fac_mginfo(j).t_end;
           package.mod_tp(i).nonCR_trial.CR_fac_info(j).dur=Nmod(i).fac_mginfo(j).dur;
           package.mod_tp(i).nonCR_trial.CR_fac_info(j).t_peak=Nmod(i).fac_mginfo(j).t_peak;
           package.mod_tp(i).nonCR_trial.CR_fac_info(j).peak=Nmod(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).nonCR_trial.CR_sup==0
       package.mod_tp(i).nonCR_trial.CR_sup_info=[];
    else
       package.mod_tp(i).nonCR_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).nonCR_trial.CR_sup
           package.mod_tp(i).nonCR_trial.CR_sup_info(j).t_onset=Nmod(i).sup_mginfo(j).t_onset;
           package.mod_tp(i).nonCR_trial.CR_sup_info(j).t_end=Nmod(i).sup_mginfo(j).t_end;
           package.mod_tp(i).nonCR_trial.CR_sup_info(j).dur=Nmod(i).sup_mginfo(j).dur;
           package.mod_tp(i).nonCR_trial.CR_sup_info(j).t_peak=Nmod(i).sup_mginfo(j).t_peak;
           package.mod_tp(i).nonCR_trial.CR_sup_info(j).peak=Nmod(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).nonCR_trial.UR_fac==0
       package.mod_tp(i).nonCR_trial.UR_fac_info=[];
    else 
       package.mod_tp(i).nonCR_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).nonCR_trial.UR_fac_info.t_peak=Nmod(i).ur_fpkt;
       package.mod_tp(i).nonCR_trial.UR_fac_info.peak=Nmod(i).ur_fac;
    end    
    if package.mod_tp(i).nonCR_trial.UR_sup==0
       package.mod_tp(i).nonCR_trial.UR_sup_info=[];
    else 
       package.mod_tp(i).nonCR_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).nonCR_trial.UR_sup_info.t_peak=Nmod(i).ur_spkt;
       package.mod_tp(i).nonCR_trial.UR_sup_info.peak=Nmod(i).ur_sup;
    end
  % psth info
    package.psth(i).nonCR_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth(i).nonCR_trial.avg_frq=Nmod(i).bsl_frq;
    package.psth(i).nonCR_trial.psth_raw=Npsth(i).Gau_psth_org;
    package.psth(i).nonCR_trial.psth_smooth=Npsth(i).Gau_psth_shft;
  % ttt info
    package.ttt(i).nonCR_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[],'avg_velo',[],'peak_velo',[],'velo_info',[],'velo_raw',[]);
    nonCR_blk_data=zeros(blk_t,size(Nlocs,2));
    for k=1:size(Nlocs,2)
        package.ttt(i).nonCR_trial(k).trial_num=Nlocs(k).nr;
        package.ttt(i).nonCR_trial(k).cs_lc=Nlocs(k).t;
        package.ttt(i).nonCR_trial(k).blk_trace(:,1)=blk(Nlocs(k).nr).t;
        package.ttt(i).nonCR_trial(k).blk_trace(:,2)=blk(Nlocs(k).nr).t-Nlocs(k).t;
        package.ttt(i).nonCR_trial(k).blk_trace(:,3)=blk(Nlocs(k).nr).tr;
        package.ttt(i).nonCR_trial(k).blk_trace(:,4)=blk(Nlocs(k).nr).tr/UR_mean;
        nonCR_blk_data(:,k)=blk(Nlocs(k).nr).tr/UR_mean;
        package.ttt(i).nonCR_trial(k).blk_info=blk_trial_info(behavior,Nlocs(k).nr);
        package.ttt(i).nonCR_trial(k).spk_time=Ntas(i).tss(k).t;
        package.ttt(i).nonCR_trial(k).ifr_org_Gau=Nttt(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt(i).nonCR_trial(k).ifr_smooth=Nttt(i).ifr_Gau_cell(k).ifr_Gau_bin;
        package.ttt(i).nonCR_trial(k).avg_velo=velo_N(k).avg_velo;
        package.ttt(i).nonCR_trial(k).peak_velo=velo_N(k).peak_velo;
        package.ttt(i).nonCR_trial(k).velo_info=velo_N(k).info;
        package.ttt(i).nonCR_trial(k).velo_raw=velo_N(k).raw;
    end
        package.blk_avg.nonCR_trial(:,1)=(blk(Nlocs(1).nr).t-Nlocs(1).t)*1000;  
        package.blk_avg.nonCR_trial(:,2)=mean(nonCR_blk_data,2);
    
% Probe_trial
  % modulation type
    package.mod_tp(i).probe_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp(i).probe_trial.CR_fac=Pmod(i).fac_merge;
    package.mod_tp(i).probe_trial.CR_sup=Pmod(i).sup_merge;
    if Pmod(i).ur_fac==0
       package.mod_tp(i).probe_trial.UR_fac=0;
    else 
       package.mod_tp(i).probe_trial.UR_fac=1; 
    end
    if Pmod(i).ur_sup==0
       package.mod_tp(i).probe_trial.UR_sup=0;
    else 
       package.mod_tp(i).probe_trial.UR_sup=1; 
    end
    if package.mod_tp(i).probe_trial.CR_fac==0
       package.mod_tp(i).probe_trial.CR_fac_info=[];
    else
       package.mod_tp(i).probe_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).probe_trial.CR_fac
           package.mod_tp(i).probe_trial.CR_fac_info(j).t_onset=Pmod(i).fac_mginfo(j).t_onset;
           package.mod_tp(i).probe_trial.CR_fac_info(j).t_end=Pmod(i).fac_mginfo(j).t_end;
           package.mod_tp(i).probe_trial.CR_fac_info(j).dur=Pmod(i).fac_mginfo(j).dur;
           package.mod_tp(i).probe_trial.CR_fac_info(j).t_peak=Pmod(i).fac_mginfo(j).t_peak;
           package.mod_tp(i).probe_trial.CR_fac_info(j).peak=Pmod(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).probe_trial.CR_sup==0
       package.mod_tp(i).probe_trial.CR_sup_info=[];
    else
       package.mod_tp(i).probe_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).probe_trial.CR_sup
           package.mod_tp(i).probe_trial.CR_sup_info(j).t_onset=Pmod(i).sup_mginfo(j).t_onset;
           package.mod_tp(i).probe_trial.CR_sup_info(j).t_end=Pmod(i).sup_mginfo(j).t_end;
           package.mod_tp(i).probe_trial.CR_sup_info(j).dur=Pmod(i).sup_mginfo(j).dur;
           package.mod_tp(i).probe_trial.CR_sup_info(j).t_peak=Pmod(i).sup_mginfo(j).t_peak;
           package.mod_tp(i).probe_trial.CR_sup_info(j).peak=Pmod(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).probe_trial.UR_fac==0
       package.mod_tp(i).probe_trial.UR_fac_info=[];
    else 
       package.mod_tp(i).probe_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).probe_trial.UR_fac_info.t_peak=Pmod(i).ur_fpkt;
       package.mod_tp(i).probe_trial.UR_fac_info.peak=Pmod(i).ur_fac;
    end    
    if package.mod_tp(i).probe_trial.UR_sup==0
       package.mod_tp(i).probe_trial.UR_sup_info=[];
    else 
       package.mod_tp(i).probe_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).probe_trial.UR_sup_info.t_peak=Pmod(i).ur_spkt;
       package.mod_tp(i).probe_trial.UR_sup_info.peak=Pmod(i).ur_sup;
    end
  % psth info
    package.psth(i).probe_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth(i).probe_trial.avg_frq=Pmod(i).bsl_frq;
    package.psth(i).probe_trial.psth_raw=Ppsth(i).Gau_psth_org;
    package.psth(i).probe_trial.psth_smooth=Ppsth(i).Gau_psth_shft;
  % ttt info
    package.ttt(i).probe_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[],'avg_velo',[],'peak_velo',[],'velo_info',[],'velo_raw',[]);
    probe_blk_data=zeros(blk_t,size(Clocs,2));
    for k=1:size(Plocs,2)
        package.ttt(i).probe_trial(k).trial_num=Plocs(k).nr;
        package.ttt(i).probe_trial(k).cs_lc=Plocs(k).t;
        package.ttt(i).probe_trial(k).blk_trace(:,1)=blk(Plocs(k).nr).t;
        package.ttt(i).probe_trial(k).blk_trace(:,2)=blk(Plocs(k).nr).t-Plocs(k).t;
        package.ttt(i).probe_trial(k).blk_trace(:,3)=blk(Plocs(k).nr).tr;
        package.ttt(i).probe_trial(k).blk_trace(:,4)=blk(Plocs(k).nr).tr/UR_mean;
        probe_blk_data(:,k)=blk(Plocs(k).nr).tr/UR_mean;
        package.ttt(i).probe_trial(k).blk_info=blk_trial_info(behavior,Plocs(k).nr);
        package.ttt(i).probe_trial(k).spk_time=Ptas(i).tss(k).t;
        package.ttt(i).probe_trial(k).ifr_org_Gau=Pttt(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt(i).probe_trial(k).ifr_smooth=Pttt(i).ifr_Gau_cell(k).ifr_Gau_bin;
        package.ttt(i).probe_trial(k).avg_velo=velo_P(k).avg_velo;
        package.ttt(i).probe_trial(k).peak_velo=velo_P(k).peak_velo;
        package.ttt(i).probe_trial(k).velo_info=velo_P(k).info;
        package.ttt(i).probe_trial(k).velo_raw=velo_P(k).raw;
    end
        package.blk_avg.probe_trial(:,1)=(blk(Plocs(1).nr).t-Plocs(1).t)*1000;  
        package.blk_avg.probe_trial(:,2)=mean(probe_blk_data,2);
        
  % CH_trial
  % modulation type
    package.mod_tp(i).CH_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp(i).CH_trial.CR_fac=CHmod(i).fac_merge;
    package.mod_tp(i).CH_trial.CR_sup=CHmod(i).sup_merge;
    if CHmod(i).ur_fac==0
       package.mod_tp(i).CH_trial.UR_fac=0;
    else 
       package.mod_tp(i).CH_trial.UR_fac=1; 
    end
    if CHmod(i).ur_sup==0
       package.mod_tp(i).CH_trial.UR_sup=0;
    else 
       package.mod_tp(i).CH_trial.UR_sup=1; 
    end
    if package.mod_tp(i).CH_trial.CR_fac==0
       package.mod_tp(i).CH_trial.CR_fac_info=[];
    else
       package.mod_tp(i).CH_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).CH_trial.CR_fac
           package.mod_tp(i).CH_trial.CR_fac_info(j).t_onset=CHmod(i).fac_mginfo(j).t_onset;
           package.mod_tp(i).CH_trial.CR_fac_info(j).t_end=CHmod(i).fac_mginfo(j).t_end;
           package.mod_tp(i).CH_trial.CR_fac_info(j).dur=CHmod(i).fac_mginfo(j).dur;
           package.mod_tp(i).CH_trial.CR_fac_info(j).t_peak=CHmod(i).fac_mginfo(j).t_peak;
           package.mod_tp(i).CH_trial.CR_fac_info(j).peak=CHmod(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).CH_trial.CR_sup==0
       package.mod_tp(i).CH_trial.CR_sup_info=[];
    else
       package.mod_tp(i).CH_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).CH_trial.CR_sup
           package.mod_tp(i).CH_trial.CR_sup_info(j).t_onset=CHmod(i).sup_mginfo(j).t_onset;
           package.mod_tp(i).CH_trial.CR_sup_info(j).t_end=CHmod(i).sup_mginfo(j).t_end;
           package.mod_tp(i).CH_trial.CR_sup_info(j).dur=CHmod(i).sup_mginfo(j).dur;
           package.mod_tp(i).CH_trial.CR_sup_info(j).t_peak=CHmod(i).sup_mginfo(j).t_peak;
           package.mod_tp(i).CH_trial.CR_sup_info(j).peak=CHmod(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).CH_trial.UR_fac==0
       package.mod_tp(i).CH_trial.UR_fac_info=[];
    else 
       package.mod_tp(i).CH_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).CH_trial.UR_fac_info.t_peak=CHmod(i).ur_fpkt;
       package.mod_tp(i).CH_trial.UR_fac_info.peak=CHmod(i).ur_fac;
    end    
    if package.mod_tp(i).CH_trial.UR_sup==0
       package.mod_tp(i).CH_trial.UR_sup_info=[];
    else 
       package.mod_tp(i).CH_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).CH_trial.UR_sup_info.t_peak=CHmod(i).ur_spkt;
       package.mod_tp(i).CH_trial.UR_sup_info.peak=CHmod(i).ur_sup;
    end
  % psth info
    package.psth(i).CH_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth(i).CH_trial.avg_frq=CHmod(i).bsl_frq;
    package.psth(i).CH_trial.psth_raw=CHpsth(i).Gau_psth_org;
    package.psth(i).CH_trial.psth_smooth=CHpsth(i).Gau_psth_shft;
  % ttt info 
    package.ttt(i).CH_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[],'avg_velo',[],'peak_velo',[],'velo_info',[],'velo_raw',[]);
    CH_blk_data=zeros(blk_t,size(CHlocs,2));
    for k=1:size(CHlocs,2)
        package.ttt(i).CH_trial(k).trial_num=CHlocs(k).nr;
        package.ttt(i).CH_trial(k).cs_lc=CHlocs(k).t;
        package.ttt(i).CH_trial(k).blk_trace(:,1)=blk(CHlocs(k).nr).t;
        package.ttt(i).CH_trial(k).blk_trace(:,2)=blk(CHlocs(k).nr).t-CHlocs(k).t;
        package.ttt(i).CH_trial(k).blk_trace(:,3)=blk(CHlocs(k).nr).tr;
        package.ttt(i).CH_trial(k).blk_trace(:,4)=blk(CHlocs(k).nr).tr/UR_mean;
        CH_blk_data(:,k)=blk(CHlocs(k).nr).tr/UR_mean;
        package.ttt(i).CH_trial(k).blk_info=blk_trial_info(behavior,CHlocs(k).nr);
        package.ttt(i).CH_trial(k).spk_time=CHtas(i).tss(k).t;
        package.ttt(i).CH_trial(k).ifr_org_Gau=CHttt(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt(i).CH_trial(k).ifr_smooth=CHttt(i).ifr_Gau_cell(k).ifr_Gau_bin;
        package.ttt(i).CH_trial(k).avg_velo=CHlocs(k).avg_velo;
        package.ttt(i).CH_trial(k).peak_velo=CHlocs(k).peak_velo;
        package.ttt(i).CH_trial(k).velo_info=CHlocs(k).velo_info;  
        package.ttt(i).CH_trial(k).velo_raw=CHlocs(k).velo_raw;  
    end
    package.blk_avg.CH_trial(:,1)=(blk(CHlocs(1).nr).t-CHlocs(1).t)*1000;  
    package.blk_avg.CH_trial(:,2)=mean(CH_blk_data,2);
    
  % CL_trial
  % modulation type
    package.mod_tp(i).CL_trial=struct('CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'CR_fac_info',[],'CR_sup_info',[],'UR_fac_info',[],'UR_sup_info',[]);
    package.mod_tp(i).CL_trial.CR_fac=CLmod(i).fac_merge;
    package.mod_tp(i).CL_trial.CR_sup=CLmod(i).sup_merge;
    if CLmod(i).ur_fac==0
       package.mod_tp(i).CL_trial.UR_fac=0;
    else 
       package.mod_tp(i).CL_trial.UR_fac=1; 
    end
    if CLmod(i).ur_sup==0
       package.mod_tp(i).CL_trial.UR_sup=0;
    else 
       package.mod_tp(i).CL_trial.UR_sup=1; 
    end
    if package.mod_tp(i).CL_trial.CR_fac==0
       package.mod_tp(i).CL_trial.CR_fac_info=[];
    else
       package.mod_tp(i).CL_trial.CR_fac_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).CL_trial.CR_fac
           package.mod_tp(i).CL_trial.CR_fac_info(j).t_onset=CLmod(i).fac_mginfo(j).t_onset;
           package.mod_tp(i).CL_trial.CR_fac_info(j).t_end=CLmod(i).fac_mginfo(j).t_end;
           package.mod_tp(i).CL_trial.CR_fac_info(j).dur=CLmod(i).fac_mginfo(j).dur;
           package.mod_tp(i).CL_trial.CR_fac_info(j).t_peak=CLmod(i).fac_mginfo(j).t_peak;
           package.mod_tp(i).CL_trial.CR_fac_info(j).peak=CLmod(i).fac_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).CL_trial.CR_sup==0
       package.mod_tp(i).CL_trial.CR_sup_info=[];
    else
       package.mod_tp(i).CL_trial.CR_sup_info=struct('t_onset',[],'t_end',[],'dur',[],'t_peak',[],'peak',[]);
       for j=1:package.mod_tp(i).CL_trial.CR_sup
           package.mod_tp(i).CL_trial.CR_sup_info(j).t_onset=CLmod(i).sup_mginfo(j).t_onset;
           package.mod_tp(i).CL_trial.CR_sup_info(j).t_end=CLmod(i).sup_mginfo(j).t_end;
           package.mod_tp(i).CL_trial.CR_sup_info(j).dur=CLmod(i).sup_mginfo(j).dur;
           package.mod_tp(i).CL_trial.CR_sup_info(j).t_peak=CLmod(i).sup_mginfo(j).t_peak;
           package.mod_tp(i).CL_trial.CR_sup_info(j).peak=CLmod(i).sup_mginfo(j).peak;
       end
    end
    if package.mod_tp(i).CL_trial.UR_fac==0
       package.mod_tp(i).CL_trial.UR_fac_info=[];
    else 
       package.mod_tp(i).CL_trial.UR_fac_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).CL_trial.UR_fac_info.t_peak=CLmod(i).ur_fpkt;
       package.mod_tp(i).CL_trial.UR_fac_info.peak=CLmod(i).ur_fac;
    end    
    if package.mod_tp(i).CL_trial.UR_sup==0
       package.mod_tp(i).CL_trial.UR_sup_info=[];
    else 
       package.mod_tp(i).CL_trial.UR_sup_info=struct('t_peak',[],'peak',[]);
       package.mod_tp(i).CL_trial.UR_sup_info.t_peak=CLmod(i).ur_spkt;
       package.mod_tp(i).CL_trial.UR_sup_info.peak=CLmod(i).ur_sup;
    end
  % psth info
    package.psth(i).CL_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    package.psth(i).CL_trial.avg_frq=CLmod(i).bsl_frq;
    package.psth(i).CL_trial.psth_raw=CLpsth(i).Gau_psth_org;
    package.psth(i).CL_trial.psth_smooth=CLpsth(i).Gau_psth_shft;
  % ttt info 
    package.ttt(i).CL_trial=struct('trial_num',[],'cs_lc',[],'blk_trace',[],'blk_info',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[],'avg_velo',[],'peak_velo',[],'velo_info',[],'velo_raw',[]);
    CL_blk_data=zeros(blk_t,size(CLlocs,2));
    for k=1:size(CLlocs,2)
        package.ttt(i).CL_trial(k).trial_num=CLlocs(k).nr;
        package.ttt(i).CL_trial(k).cs_lc=CLlocs(k).t;
        package.ttt(i).CL_trial(k).blk_trace(:,1)=blk(CLlocs(k).nr).t;
        package.ttt(i).CL_trial(k).blk_trace(:,2)=blk(CLlocs(k).nr).t-CLlocs(k).t;
        package.ttt(i).CL_trial(k).blk_trace(:,3)=blk(CLlocs(k).nr).tr;
        package.ttt(i).CL_trial(k).blk_trace(:,4)=blk(CLlocs(k).nr).tr/UR_mean;
        CL_blk_data(:,k)=blk(CLlocs(k).nr).tr/UR_mean;
        package.ttt(i).CL_trial(k).blk_info=blk_trial_info(behavior,CLlocs(k).nr);
        package.ttt(i).CL_trial(k).spk_time=CLtas(i).tss(k).t;
        package.ttt(i).CL_trial(k).ifr_org_Gau=CLttt(i).ifr_Gau_cell(k).ifr_Gau_org;
        package.ttt(i).CL_trial(k).ifr_smooth=CLttt(i).ifr_Gau_cell(k).ifr_Gau_bin;
        package.ttt(i).CL_trial(k).avg_velo=CLlocs(k).avg_velo;
        package.ttt(i).CL_trial(k).peak_velo=CLlocs(k).peak_velo;
        package.ttt(i).CL_trial(k).velo_info=CLlocs(k).velo_info;  
        package.ttt(i).CL_trial(k).velo_raw=CLlocs(k).velo_raw;  
    end
    package.blk_avg.CL_trial(:,1)=(blk(CLlocs(1).nr).t-CLlocs(1).t)*1000;  
    package.blk_avg.CL_trial(:,2)=mean(CL_blk_data,2);
end
cd(outpath);
save(['pack_' csv_name '.mat'],'package');
end