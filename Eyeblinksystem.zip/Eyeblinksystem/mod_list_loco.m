% Make the final package of all trace-only recording sessions grouped by modulation type after making
% all data of each session into a package with pckg_all function. --Zhong

listing = dir('pack_*');

list_mod=struct('cell_ID',[],'file_name',[],'cell_num',[],'channel_info',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[]);
cell_ID=1;

% first loop for each recording session
for i=1:size(listing,1)
    load(listing(i).name);
%   second loop for each cell
    for j=1:size(package.mod_tp,2)
%       for CR facilitation neuron

           list_mod(cell_ID).cell_ID=cell_ID;
           list_mod(cell_ID).file_name=listing(i).name; 
           list_mod(cell_ID).cell_num=j; 
           list_mod(cell_ID).channel_info=package.channel_info(j).ch; 
%            list_mod(cell_ID).CR_fac=package.mod_tp(j).CR_trial.CR_fac; 
%            list_mod(cell_ID).CR_sup=package.mod_tp(j).CR_trial.CR_sup; 
%            list_mod(cell_ID).UR_fac=package.mod_tp(j).CR_trial.UR_fac; 
%            list_mod(cell_ID).UR_sup=package.mod_tp(j).CR_trial.UR_sup;
%            list_mod(cell_ID).mod_info=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);%,'CHf',[],'CHs',[],'CLf',[],'CLs',[]);
%                list_mod(cell_ID).mod_info.CRf=package.mod_tp(j).CR_trial.CR_fac_info;
%                list_mod(cell_ID).mod_info.CRs=package.mod_tp(j).CR_trial.CR_sup_info;
%                list_mod(cell_ID).mod_info.URf=package.mod_tp(j).CR_trial.UR_fac_info;
%                list_mod(cell_ID).mod_info.URs=package.mod_tp(j).CR_trial.UR_sup_info;
% %                list_mod(cell_ID).mod_info.CHf=package.mod_tp(j).CH_trial.CR_fac_info;
% %                list_mod(cell_ID).mod_info.CHs=package.mod_tp(j).CH_trial.CR_sup_info;
% %                list_mod(cell_ID).mod_info.CLf=package.mod_tp(j).CL_trial.CR_fac_info;
% %                list_mod(cell_ID).mod_info.CLs=package.mod_tp(j).CL_trial.CR_sup_info;
%            list_mod(cell_ID).all_info=struct('sss_all',[],'ttt',[]);
%                list_mod(cell_ID).all_info.sss_all=struct('blk',[],'behavior',[],'psth',[]);
%                    list_mod(cell_ID).all_info.sss_all.blk=package.blk_avg;
%                    list_mod(cell_ID).all_info.sss_all.behavior=package.behavior_table;
%                    list_mod(cell_ID).all_info.sss_all.psth=package.psth(j);
%                list_mod(cell_ID).all_info.ttt=package.ttt(j);
%                
%                list_mod(cell_ID).all_info.ttt.CR_trial = rmfield(list_mod(cell_ID).all_info.ttt.CR_trial,'ifr_org_Gau'); 
%             if ~isempty(list_mod(cell_ID).all_info.ttt.nonCR_trial)
%                 list_mod(cell_ID).all_info.ttt.nonCR_trial = rmfield(list_mod(cell_ID).all_info.ttt.nonCR_trial,'ifr_org_Gau');   
%             end
%             if ~isempty(list_mod(cell_ID).all_info.ttt.probe_trial)
%                 list_mod(cell_ID).all_info.ttt.probe_trial = rmfield(list_mod(cell_ID).all_info.ttt.probe_trial,'ifr_org_Gau');   
%             end
%             if isfield(list_mod(cell_ID).all_info.ttt,'CH_trial')
%                 list_mod(cell_ID).all_info.ttt = rmfield(list_mod(cell_ID).all_info.ttt,'CH_trial');   
%             end            
%             if isfield(list_mod(cell_ID).all_info.ttt,'CL_trial')
%                 list_mod(cell_ID).all_info.ttt = rmfield(list_mod(cell_ID).all_info.ttt,'CL_trial');   
%             end 
        cell_ID=cell_ID+1;
    end
end