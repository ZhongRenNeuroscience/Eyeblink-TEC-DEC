% Plot the PSTH with behavior curves and raster of single units in one
% session after spk_Gaussian and Gau_psth_cal, also with tas which
% contains spike event info after JRClust sorting and locs with CS onset
% time point. win_sz is just for figure name, no real function to the code.
% --Zhong


function Gau_psth_plot_loco(Gau_psth_CL,Gau_psth_CH,Gau_psth_NO,CLtas,CHtas,NOtas,blk,CL_locs,CH_locs,NO_locs,t_post,tp,csv_name)

outpath='D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Trace-trained-mice\DCN_mat_output\loco_data\loco_figure\';

cell_number=size(Gau_psth_CL,2);
CL_number=size(CL_locs,2);
CH_number=size(CH_locs,2);
NO_number=size(NO_locs,2);
UR_mean=mean([blk.ur_amp]);
blk_data_CL=zeros(size(blk(2).tr,1),size(CL_locs,2));
blk_data_CH=zeros(size(blk(2).tr,1),size(CH_locs,2));
blk_data_NO=zeros(size(blk(2).tr,1),size(NO_locs,2));
t_norm=(blk(CL_locs(2).nr).t-CL_locs(2).t)*1000;    

for n=1:size(CL_locs,2)
    trial_num=CL_locs(n).nr;
    blk_data_CL(:,n)=blk(trial_num).tr/UR_mean;
end
for n=1:size(CH_locs,2)
    trial_num=CH_locs(n).nr;
    blk_data_CH(:,n)=blk(trial_num).tr/UR_mean;
end
for n=1:size(NO_locs,2)
    trial_num=NO_locs(n).nr;
    blk_data_NO(:,n)=blk(trial_num).tr/UR_mean;
end

mean_blk_CL=mean(blk_data_CL,2);
mean_blk_CH=mean(blk_data_CH,2);
mean_blk_NO=mean(blk_data_NO,2);

ymax=max([max(max(blk_data_CL)) max(max(blk_data_NO)) max(max(blk_data_NO))])+0.1;
ymin=min([min(min(blk_data_CL)) min(min(blk_data_NO)) min(min(blk_data_NO))])-0.1;
    
for k=1:cell_number
    cell_nr=k;
    if tp==0
    fig_name = strcat('Gau_PSTH Cell loco No.',num2str(cell_nr,'%03d'));
    elseif tp==1
    fig_name = strcat('Gau_PSTH Cell loco No.',num2str(cell_nr,'%03d'),'-cps');
    end
    figure('Name',fig_name,'NumberTitle','off','units','normalized','outerposition',[0 0 1 1])
    
    % plot velocity data
    subplot(4,3,1)
    hold on
    CH_loco_form=zeros(size(CH_locs,2),size(CH_locs(1).velo_info,1));
    for i=1:size(CH_locs,2)
        CH_loco_form(i,:)=smooth(CH_locs(i).velo_info(:,2));
        plot(CH_locs(i).velo_info(:,1)*1000,CH_loco_form(i,:),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    ymin_loco=min(min(CH_loco_form,[],1))-0.01;
    ymax_loco=max(max(CH_loco_form,[],1))+0.01;
    plot(CH_locs(1).velo_info(:,1)*1000,mean(CH_loco_form,1),'Color',[0 0 0],'LineWidth',2)
    if t_post==500
    line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    xticks(-250:250:1000);
    ylim([ymin_loco, ymax_loco]);
    xlabel('time(ms)');
    ylabel('Speed (m/s)') 
    title('Locomotion CR trials');
    
    subplot(4,3,2)
    hold on
    CL_loco_form=zeros(size(CL_locs,2),size(CL_locs(1).velo_info,1));
    for i=1:size(CL_locs,2)
        CL_loco_form(i,:)=smooth(CL_locs(i).velo_info(:,2));
        plot(CL_locs(i).velo_info(:,1)*1000,CL_loco_form(i,:),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end    
    plot(CL_locs(1).velo_info(:,1)*1000,mean(CL_loco_form,1),'Color',[0 0 0],'LineWidth',2)
    if t_post==500
    line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    xticks(-250:250:1000);
    ylim([ymin_loco, ymax_loco]);
    xlabel('time(ms)');
    ylabel('Speed (m/s)')    
    title('No/Low locomotion CR trials');

    subplot(4,3,3)
    hold on
    NO_loco_form=zeros(size(NO_locs,2),size(NO_locs(1).velo_info,1));
    for i=1:size(NO_locs,2)
        NO_loco_form(i,:)=smooth(NO_locs(i).velo_info(:,2));
        plot(NO_locs(i).velo_info(:,1)*1000,NO_loco_form(i,:),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end    
    plot(NO_locs(1).velo_info(:,1)*1000,mean(NO_loco_form,1),'Color',[0 0 0],'LineWidth',2)
    if t_post==500
    line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    xticks(-250:250:1000);
    ylim([ymin_loco, ymax_loco]);
    xlabel('time(ms)');
    ylabel('Speed (m/s)')  
    title('Non-CR trials');
    
    %   plot behavior data
    subplot(4,3,4)
    hold on
    for i=1:size(blk_data_CH,2)
        plot(t_norm,blk_data_CH(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    plot(t_norm,mean_blk_CH,'Color',[0 0 0],'LineWidth',2)
    hold on
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')    
    
    subplot(4,3,5)
    hold on
    for i=1:size(blk_data_CL,2)
        plot(t_norm,blk_data_CL(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    plot(t_norm,mean_blk_CL,'Color',[0 0 0],'LineWidth',2)
    hold on
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')

    subplot(4,3,6)
    hold on
    for i=1:size(blk_data_NO,2)
        plot(t_norm,blk_data_NO(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    plot(t_norm,mean_blk_NO,'Color',[0 0 0],'LineWidth',2)
    hold on
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')
    
    %   plot raster data
    subplot(4,3,7)
    hold on
    for m=1:CH_number
        hold on
        Y=ones(length(CHtas(cell_nr).tss(m).t),1)*m;
        plot(CHtas(cell_nr).tss(m).t*1000,Y,'k.')
    end
    hold on
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');
    
    subplot(4,3,8)
    hold on
    for m=1:CL_number
        hold on
        Y=ones(length(CLtas(cell_nr).tss(m).t),1)*m;
        plot(CLtas(cell_nr).tss(m).t*1000,Y,'k.')
    end
    hold on
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');
    
    subplot(4,3,9)
    hold on
    for m=1:NO_number
        hold on
        Y=ones(length(NOtas(cell_nr).tss(m).t),1)*m;
        plot(NOtas(cell_nr).tss(m).t*1000,Y,'k.')
    end
    hold on
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');


    % plot PSTH  
    subplot(4,3,10)
    hold on
    h = histogram(Gau_psth_CH(k).Gau_psth_shft(:,1));
        h.BinEdges = (min(Gau_psth_CH(k).Gau_psth_shft(:,1))):(max(Gau_psth_CH(k).Gau_psth_shft(:,1)) + 1);
        h.NumBins = size(Gau_psth_CH(k).Gau_psth_shft,1);
        h.BinCounts = Gau_psth_CH(k).Gau_psth_shft(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    % Draw 0 point reference line
    yh = max(Gau_psth_CH(k).Gau_psth_shft(:,2)) * 1.01;
    hold on
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    saveas(gcf,[fig_name '.jpg']);
    hold on    
    
    subplot(4,3,11)
    hold on
    h = histogram(Gau_psth_CL(k).Gau_psth_shft(:,1));
        h.BinEdges = (min(Gau_psth_CL(k).Gau_psth_shft(:,1))):(max(Gau_psth_CL(k).Gau_psth_shft(:,1)) + 1);
        h.NumBins = size(Gau_psth_CL(k).Gau_psth_shft,1);
        h.BinCounts = Gau_psth_CL(k).Gau_psth_shft(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    % Draw 0 point reference line
    yh = max(Gau_psth_CL(k).Gau_psth_shft(:,2)) * 1.01;
    hold on
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    saveas(gcf,[fig_name '.jpg']);
    hold on
    
    subplot(4,3,12)
    hold on
    h = histogram(Gau_psth_NO(k).Gau_psth_shft(:,1));
        h.BinEdges = (min(Gau_psth_NO(k).Gau_psth_shft(:,1))):(max(Gau_psth_NO(k).Gau_psth_shft(:,1)) + 1);
        h.NumBins = size(Gau_psth_NO(k).Gau_psth_shft,1);
        h.BinCounts = Gau_psth_NO(k).Gau_psth_shft(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    % Draw 0 point reference line
    yh = max(Gau_psth_NO(k).Gau_psth_shft(:,2)) * 1.01;
    hold on
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    saveas(gcf,[fig_name '.jpg']);
    hold on
    cd(outpath);
    saveas(gcf,[csv_name fig_name '.jpg']);
end
% close all
end