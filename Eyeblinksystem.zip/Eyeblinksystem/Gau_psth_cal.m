% Calculate the PSTH value in one session by accumulating the Gaussian-filtered
% single trial data from spk_Gaussian in eyeblink system.  --Zhong


function Gau_psth_all=Gau_psth_cal(spk_Gau,t_pre,t_post,window)

if isempty(spk_Gau)
    Gau_psth_all=[];
    return
end

Gau_psth_all(size(spk_Gau,2))=struct('cell',[],'Gau_psth_org',[],'Gau_psth_avg',[],'Gau_psth_shft',[]);

% First loop for each cell and get original data from spk_Gaussian
for i=1:size(spk_Gau,2)
    Gau_psth_org=zeros(size(spk_Gau(i).spk_Gau_cell(1).spk_Gau_trial,1),2);
    Gau_psth_org(:,1)=spk_Gau(i).spk_Gau_cell(1).spk_Gau_trial(:,1);
    
%     Get the spike data from all the trials and accumulate by each time
%     point
    for j=1:size(spk_Gau(i).spk_Gau_cell,2)
        Gau_psth_org(:,2)=Gau_psth_org(:,2)+spk_Gau(i).spk_Gau_cell(j).spk_Gau_trial(:,2);
    end
%     Correct the data to Hz considering the trial number and temporal
%     resolusion
    Gau_psth_org(:,2)=Gau_psth_org(:,2)/(j*0.00005*20);
   
    Gau_psth_avg=zeros((t_pre+t_post),2);
    Gau_psth_avg(:,1)=-t_pre:1:(t_post-1);
    
%     Average the data into 1ms
    for k=1:(t_pre+t_post)
        Gau_psth_avg(k,2)=mean(Gau_psth_org(((20*(k-1)+1):(20*(k-1)+20)),2));
    end
    
%     Use the shift window to retro-back the Gaussian window
    Gau_psth_shft=zeros((t_pre+t_post-2*window),2);
    Gau_psth_shft(:,1)=(-t_pre+window):1:(t_post-window-1);
    
    for m=1:(t_pre+t_post-2*window)
        Gau_psth_shft(m,2)=mean(Gau_psth_avg((m:(m+2*window)),2));
    end
    
    Gau_psth_all(i).cell=i;
    Gau_psth_all(i).Gau_psth_org=Gau_psth_org;
    Gau_psth_all(i).Gau_psth_avg=Gau_psth_avg;
    Gau_psth_all(i).Gau_psth_shft=Gau_psth_shft;
    
%     figure;
%     
%     plot (Gau_psth_all(i).Gau_psth_avg(:,1),Gau_psth_all(i).Gau_psth_avg(:,2))
%     plot (Gau_psth_all(i).Gau_psth_shft(:,1),Gau_psth_all(i).Gau_psth_shft(:,2))
end

end