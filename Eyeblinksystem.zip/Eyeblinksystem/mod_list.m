% Make the final package of all trace-only recording sessions grouped by modulation type after making
% all data of each session into a package with pckg_all function. --Zhong

listing = dir('pack_*');

list_mod=struct('fac',[],'sup',[],'non',[]);
list_mod.fac=struct('fac_ID',[],'cell_ID',[],'file_name',[],'cell_num',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[]);
list_mod.sup=struct('sup_ID',[],'cell_ID',[],'file_name',[],'cell_num',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[]);
list_mod.non=struct('non_ID',[],'cell_ID',[],'file_name',[],'cell_num',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[]);
fac_ID=1;
sup_ID=1;
non_ID=1;
cell_ID=1;

% first loop for each recording session
for i=1:size(listing,1)
    load(listing(i).name);
%   second loop for each cell
    for j=1:size(package.mod_tp,2)
%       for CR facilitation neuron
        if package.mod_tp(j).CR_trial.CR_fac > 0
           list_mod.fac(fac_ID).fac_ID=fac_ID;
           list_mod.fac(fac_ID).cell_ID=cell_ID;
           list_mod.fac(fac_ID).file_name=listing(i).name; 
           list_mod.fac(fac_ID).cell_num=j; 
           list_mod.fac(fac_ID).CR_fac=package.mod_tp(j).CR_trial.CR_fac; 
           list_mod.fac(fac_ID).CR_sup=package.mod_tp(j).CR_trial.CR_sup; 
           list_mod.fac(fac_ID).UR_fac=package.mod_tp(j).CR_trial.UR_fac; 
           list_mod.fac(fac_ID).UR_sup=package.mod_tp(j).CR_trial.UR_sup;
           list_mod.fac(fac_ID).mod_info=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
               list_mod.fac(fac_ID).mod_info.CRf=package.mod_tp(j).CR_trial.CR_fac_info;
               list_mod.fac(fac_ID).mod_info.CRs=package.mod_tp(j).CR_trial.CR_sup_info;
               list_mod.fac(fac_ID).mod_info.URf=package.mod_tp(j).CR_trial.UR_fac_info;
               list_mod.fac(fac_ID).mod_info.URs=package.mod_tp(j).CR_trial.UR_sup_info;
           list_mod.fac(fac_ID).all_info=struct('sss_all',[],'ttt',[]);
               list_mod.fac(fac_ID).all_info.sss_all=struct('blk',[],'behavior',[],'psth',[]);
                   list_mod.fac(fac_ID).all_info.sss_all.blk=package.blk_avg;
                   list_mod.fac(fac_ID).all_info.sss_all.behavior=package.behavior_table;
                   list_mod.fac(fac_ID).all_info.sss_all.psth=package.psth(j);
               list_mod.fac(fac_ID).all_info.ttt=package.ttt(j);
           fac_ID=fac_ID+1;
        end
%       for CR supression neuron
        if package.mod_tp(j).CR_trial.CR_sup > 0
           list_mod.sup(sup_ID).sup_ID=sup_ID;
           list_mod.sup(sup_ID).cell_ID=cell_ID;
           list_mod.sup(sup_ID).file_name=listing(i).name; 
           list_mod.sup(sup_ID).cell_num=j; 
           list_mod.sup(sup_ID).CR_fac=package.mod_tp(j).CR_trial.CR_fac; 
           list_mod.sup(sup_ID).CR_sup=package.mod_tp(j).CR_trial.CR_sup; 
           list_mod.sup(sup_ID).UR_fac=package.mod_tp(j).CR_trial.UR_fac; 
           list_mod.sup(sup_ID).UR_sup=package.mod_tp(j).CR_trial.UR_sup;
           list_mod.sup(sup_ID).mod_info=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
               list_mod.sup(sup_ID).mod_info.CRf=package.mod_tp(j).CR_trial.CR_fac_info;
               list_mod.sup(sup_ID).mod_info.CRs=package.mod_tp(j).CR_trial.CR_sup_info;
               list_mod.sup(sup_ID).mod_info.URf=package.mod_tp(j).CR_trial.UR_fac_info;
               list_mod.sup(sup_ID).mod_info.URs=package.mod_tp(j).CR_trial.UR_sup_info;
           list_mod.sup(sup_ID).all_info=struct('sss_all',[],'ttt',[]);
               list_mod.sup(sup_ID).all_info.sss_all=struct('blk',[],'behavior',[],'psth',[]);
                   list_mod.sup(sup_ID).all_info.sss_all.blk=package.blk_avg;
                   list_mod.sup(sup_ID).all_info.sss_all.behavior=package.behavior_table;
                   list_mod.sup(sup_ID).all_info.sss_all.psth=package.psth(j);
               list_mod.sup(sup_ID).all_info.ttt=package.ttt(j);
           sup_ID=sup_ID+1;
        end
%       for non-modulation neuron
        if package.mod_tp(j).CR_trial.CR_fac == 0 && package.mod_tp(j).CR_trial.CR_sup == 0
           list_mod.non(non_ID).non_ID=non_ID;
           list_mod.non(non_ID).cell_ID=cell_ID;
           list_mod.non(non_ID).file_name=listing(i).name; 
           list_mod.non(non_ID).cell_num=j; 
           list_mod.non(non_ID).CR_fac=package.mod_tp(j).CR_trial.CR_fac; 
           list_mod.non(non_ID).CR_sup=package.mod_tp(j).CR_trial.CR_sup; 
           list_mod.non(non_ID).UR_fac=package.mod_tp(j).CR_trial.UR_fac; 
           list_mod.non(non_ID).UR_sup=package.mod_tp(j).CR_trial.UR_sup;
           list_mod.non(non_ID).mod_info=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
               list_mod.non(non_ID).mod_info.CRf=package.mod_tp(j).CR_trial.CR_fac_info;
               list_mod.non(non_ID).mod_info.CRs=package.mod_tp(j).CR_trial.CR_sup_info;
               list_mod.non(non_ID).mod_info.URf=package.mod_tp(j).CR_trial.UR_fac_info;
               list_mod.non(non_ID).mod_info.URs=package.mod_tp(j).CR_trial.UR_sup_info;
           list_mod.non(non_ID).all_info=struct('sss_all',[],'ttt',[]);
               list_mod.non(non_ID).all_info.sss_all=struct('blk',[],'behavior',[],'psth',[]);
                   list_mod.non(non_ID).all_info.sss_all.blk=package.blk_avg;
                   list_mod.non(non_ID).all_info.sss_all.behavior=package.behavior_table;
                   list_mod.non(non_ID).all_info.sss_all.psth=package.psth(j);
               list_mod.non(non_ID).all_info.ttt=package.ttt(j);
           non_ID=non_ID+1;
        end
        cell_ID=cell_ID+1;
    end
end