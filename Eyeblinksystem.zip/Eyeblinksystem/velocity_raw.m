function velo_raw=velocity_raw(din_info,t_sys,ch_A_ID,ch_B_ID)

velo_raw=struct('t',[],'channel',[],'dir',[]);
dir_idx=zeros(2,1);

for i=1:length(t_sys)
    if din_info(ch_A_ID).v(i,1)+din_info(ch_A_ID).v(i+2,1)==1
       if din_info(ch_A_ID).v(i,1)<din_info(ch_A_ID).v(i+2,1)
          dir_idx(1,1)=1;
       elseif din_info(ch_A_ID).v(i,1)>din_info(ch_A_ID).v(i+2,1)
          dir_idx(1,1)=3; 
       end
       A_1=i;
       break
    end    
end
for i=1:length(t_sys)
    if din_info(ch_B_ID).v(i,1)+din_info(ch_B_ID).v(i+2,1)==1
       if din_info(ch_B_ID).v(i,1)<din_info(ch_B_ID).v(i+2,1)
          dir_idx(2,1)=2;
       elseif din_info(ch_B_ID).v(i,1)>din_info(ch_B_ID).v(i+2,1)
          dir_idx(2,1)=4; 
       end
       B_1=i;
       break
    end    
end
if dir_idx(1,1)*dir_idx(2,1)>0
   if dir_idx(2,1)-dir_idx(1,1)==1 || dir_idx(2,1)-dir_idx(1,1)==-3
      dir=1;
   elseif dir_idx(2,1)-dir_idx(1,1)==-1 || dir_idx(2,1)-dir_idx(1,1)==3
      dir=-1;
   end
else
   dir=0; 
end
if A_1<B_1
   first=1;
elseif A_1>B_1
   first=-1; 
end
dir_idx=dir*first;

idx_ch=0;
for i=1:length(t_sys)-2
    if din_info(ch_A_ID).v(i,1)+din_info(ch_A_ID).v(i+2,1)==1
       if idx_ch>0 && velo_raw(idx_ch).channel==1
          dir_idx=-dir_idx; 
       end
       idx_ch=idx_ch+1; 
       if din_info(ch_A_ID).v(i,1)>din_info(ch_A_ID).v(i+2,1)
          velo_raw(idx_ch).t=round(t_sys(i,1),5);
          velo_raw(idx_ch).channel=1;
          velo_raw(idx_ch).dir=dir_idx;
       elseif din_info(ch_A_ID).v(i,1)<din_info(ch_A_ID).v(i+2,1)
          velo_raw(idx_ch).t=round(t_sys(i,1),5)+0.0001;
          velo_raw(idx_ch).channel=1;
          velo_raw(idx_ch).dir=dir_idx;
       end   
    end
    if din_info(ch_B_ID).v(i,1)+din_info(ch_B_ID).v(i+2,1)==1
       if idx_ch>0 && velo_raw(idx_ch).channel==2
          dir_idx=-dir_idx; 
       end
       idx_ch=idx_ch+1;
       if din_info(ch_B_ID).v(i,1)>din_info(ch_B_ID).v(i+2,1)
          velo_raw(idx_ch).t=round(t_sys(i,1),5);
          velo_raw(idx_ch).channel=2;
          velo_raw(idx_ch).dir=dir_idx;
       elseif din_info(ch_B_ID).v(i,1)<din_info(ch_B_ID).v(i+2,1)
          velo_raw(idx_ch).t=round(t_sys(i,1),5)+0.0001;
          velo_raw(idx_ch).channel=2;
          velo_raw(idx_ch).dir=dir_idx;
       end  
    end          
end


end
