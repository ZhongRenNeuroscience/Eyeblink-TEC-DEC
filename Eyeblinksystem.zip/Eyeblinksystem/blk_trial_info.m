% Make a package of all behavior and ephys data based on single trial
% perspective.
% Run as a function of pckg_all to summarize all behavior data with
% behavior form produced by behavior_analysis function.  --Zhong

function package=blk_trial_info(behavior,m)

    package=struct('CR_onset',[],'CRonset_rank',[],'CR_peaktime',[],'CR_pkt_rank',[],'peak_latency',[],'pk_lat_rank',[],'CR_amp',[],'CRamp_rank',[],...
   'CR_slpoe',[],'CRslp_rank',[],'CR_differential',[],'CR_diff_time',[],'CR_diff_rank',[],'CR_diff_time_rank',[],'CR_area',[],'CRarea_rank',[],'CR_duration',[],...
   'CRdur_rank',[],'UR_peaktime',[],'UR_amp',[]);
    package.CR_onset=behavior{m,4};
    package.CRonset_rank=behavior{m,5};
    package.CR_peaktime=behavior{m,6};
    package.CR_pkt_rank=behavior{m,7};
    package.peak_latency=behavior{m,8};
    package.pk_lat_rank=behavior{m,9};
    package.CR_amp=behavior{m,10};
    package.CRamp_rank=behavior{m,11};
    package.CR_slpoe=behavior{m,12};
    package.CRslp_rank=behavior{m,13};
    package.CR_differential=behavior{m,14};
    package.CR_diff_time=behavior{m,15};
    package.CR_diff_rank=behavior{m,16};
    package.CR_diff_time_rank=behavior{m,17};
    package.CR_area=behavior{m,18};
    package.CRarea_rank=behavior{m,19};
    package.CR_duration=behavior{m,20};
    package.CRdur_rank=behavior{m,21};
    package.UR_peaktime=behavior{m,22};
    package.UR_amp=behavior{m,23};

end