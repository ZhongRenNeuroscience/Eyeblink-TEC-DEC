clear;

% Input parameters
  t_pre = 550;
  day='230522';
  
%   t_post = 250;
%   t_probe=500;  %(t_probe=t_post+250 just for whole probe trial trace)
%   dur = 1000;
%   session='delay';
  
  t_post = 750;
  t_probe=750;  %(t_probe=t_post+250 just for whole probe trial trace)
  dur = 1000;
  session='trace500';
 

% Import Intan header and path
  read_Intan_RHD2000_file;
  cd(path);
% Import Intan time vectors
  t = import_intan_time;
  t = fix_intan_time(t);
% Import Intan ADC channels vector
  adc = import_intan_adc([]);

%   ctp = import_ctp_csv('cell_tp.csv');
% Detection CS/US edge
  cs_lc = find_trg_pks([adc(1).v],3,t,dur);
  us_lc = find_trg_pks([adc(2).v],3,t,dur);
% Filter eyeblink trace
%   v = idv_filter([adc(4).v],1,200,0,0,0,0);
  v = [adc(3).v];
% Detect CR/UR in eyeblink trace
  blk = blk_detn(v,t,cs_lc,us_lc,t_pre,t_post,t_probe,dur);
  [behavior,trial_num,early]=behavior_analysis(blk,cs_lc,t_pre,t_post,t_probe);

  
 mydir  = pwd;
 idcs   = strfind(mydir,'\');
 newdir = mydir(1:idcs(end)-1);
 cd(newdir)

  if contains(session,'delay')
      behavior_form=behavior_form(trial_num,behavior,blk,t_post);
      save([day '_' session '_pair'],'behavior_form');      
  elseif contains(session,'trace500')
      behavior_form=behavior_form(trial_num,behavior,blk,t_post);
      save([day '_' session '_pair'],'behavior_form');        
  end
  behavior_form_prb=behavior_form_prb(trial_num,behavior,blk,t_probe);
  save([day '_' session '_probe'],'behavior_form_prb');

