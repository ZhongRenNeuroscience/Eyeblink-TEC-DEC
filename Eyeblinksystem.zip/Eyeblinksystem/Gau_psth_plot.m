% Plot the PSTH with behavior curves and raster of single units in one
% session after spk_Gaussian and Gau_psth_cal, also with tas which
% contains spike event info after JRClust sorting and locs with CS onset
% time point. win_sz is just for figure name, no real function to the code.
% --Zhong


function Gau_psth_plot(Gau_psth_all,Ctas,blk,Clocs,t_post,trial_tp,csv_name)

outpath='D:\Mimo\mPFC_trace\normal_PSTH\';

cell_number=size(Gau_psth_all,2);
CR_number=size(Clocs,2);
UR_mean=mean([blk.ur_amp]);
blk_data=zeros(size(blk(2).tr,1),size(Clocs,2));
t_norm=(blk(Clocs(1).nr).t-Clocs(1).t)*1000;    

for n=1:size(Clocs,2)
    trial_num=Clocs(n).nr;
%     t_trialon=Clocs(n).t;
%     t_norm=(blk(trial_num).t-t_trialon)*1000;
%         blk(trial_num).tr;
    blk_data(:,n)=blk(trial_num).tr/UR_mean;
end

mean_blk=mean(blk_data,2);
% std_blk=std(blk_data,0,2);
% std_up=mean_blk+std_blk;
% std_down=mean_blk-std_blk;
ymax=max(max(blk_data))+0.1;
ymin=min(min(blk_data))-0.1;
    
for k=1:cell_number
    cell_nr=k;
    if t_post==250
    fig_name = strcat('No.',num2str(cell_nr,'%03d'),trial_tp,'_delay');
    elseif t_post==500
    fig_name = strcat('No.',num2str(cell_nr,'%03d'),trial_tp,'_trace');
    end
    figure('Name',fig_name,'NumberTitle','off','units','normalized','outerposition',[0 0 1 1])

    %   plot behavior data
    subplot(3,1,1)
    hold on
    for i=1:size(blk_data,2)
        plot(t_norm,blk_data(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    plot(t_norm,mean_blk,'Color',[0 0 0],'LineWidth',2)
    hold on
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')

    %   plot raster data
    subplot(3,1,2)
    hold on

    for m=1:CR_number
        hold on
        Y=ones(length(Ctas(cell_nr).tss(m).t),1)*m;
        plot(Ctas(cell_nr).tss(m).t*1000,Y,'k.')
    end
    hold on
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');


    % plot PSTH    
    subplot(3,1,3)
    hold on
    h = histogram(Gau_psth_all(k).Gau_psth_shft(:,1));
        h.BinEdges = (min(Gau_psth_all(k).Gau_psth_shft(:,1))):(max(Gau_psth_all(k).Gau_psth_shft(:,1)) + 1);
        h.NumBins = size(Gau_psth_all(k).Gau_psth_shft,1);
        h.BinCounts = Gau_psth_all(k).Gau_psth_shft(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    % Draw 0 point reference line
    yh = max(Gau_psth_all(k).Gau_psth_shft(:,2)) * 1.01;
    hold on
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
%     saveas(gcf,[fig_name '.tiff']);
%     hold on
%     cd(outpath);
%     saveas(gcf,[csv_name '_' fig_name '.tiff']);
end
% close all
end