% Plot all trace-only recorded neurons as a whole list of their PSTH
% grouped by modulation type after the whole package is produced by
% list_mod.  -Zhong


% plot all facilitation neurons
figure;
for k=1:size(list_mod.fac,2)
    subplot(8,6,k)
    plot(list_mod.fac(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,1),list_mod.fac(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))
    hold on
    ymax=max(list_mod.fac(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*1.05;
    ymin=min(list_mod.fac(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*0.95;
    xlim([-250 750]);
    ylim([ymin ymax]);
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    title(['Fac-',num2str(list_mod.fac(k).cell_ID),' ',num2str(list_mod.fac(k).CR_fac),'-',num2str(list_mod.fac(k).CR_sup),'-',num2str(list_mod.fac(k).UR_fac),...
        '-',num2str(list_mod.fac(k).UR_sup)])
end

% plot all suppression neurons
figure;
for k=1:size(list_mod.sup,2)
    subplot(4,5,k)
    plot(list_mod.sup(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,1),list_mod.sup(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))
    hold on
    ymax=max(list_mod.sup(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*1.05;
    ymin=min(list_mod.sup(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*0.95;
    xlim([-250 750]);
    ylim([ymin ymax]);
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    title(['Sup-',num2str(list_mod.sup(k).cell_ID),' ',num2str(list_mod.sup(k).CR_fac),'-',num2str(list_mod.sup(k).CR_sup),'-',num2str(list_mod.sup(k).UR_fac),...
        '-',num2str(list_mod.sup(k).UR_sup)])
end

% plot all non-modulation neurons
figure;
for k=1:49
    subplot(7,7,k)
    plot(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,1),list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))
    hold on
    ymax=max(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*1.05;
    ymin=min(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*0.95;
    xlim([-250 750]);
    ylim([ymin ymax]);
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    title(['Non-',num2str(list_mod.non(k).cell_ID),' ',num2str(list_mod.non(k).CR_fac),'-',num2str(list_mod.non(k).CR_sup),'-',num2str(list_mod.non(k).UR_fac),...
        '-',num2str(list_mod.non(k).UR_sup)])
end

figure;
for k=50:98
    subplot(7,7,k-49)
    plot(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,1),list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))
    hold on
    ymax=max(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*1.05;
    ymin=min(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*0.95;
    xlim([-250 750]);
    ylim([ymin ymax]);
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    title(['Non-',num2str(list_mod.non(k).cell_ID),' ',num2str(list_mod.non(k).CR_fac),'-',num2str(list_mod.non(k).CR_sup),'-',num2str(list_mod.non(k).UR_fac),...
        '-',num2str(list_mod.non(k).UR_sup)])
end

figure;
for k=99:size(list_mod.non,2)
    subplot(7,7,k-98)
    plot(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,1),list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))
    hold on
    ymax=max(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*1.05;
    ymin=min(list_mod.non(k).all_info.sss_all.psth.CR_trial.psth_smooth(:,2))*0.95;
    xlim([-250 750]);
    ylim([ymin ymax]);
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    title(['Non-',num2str(list_mod.non(k).cell_ID),' ',num2str(list_mod.non(k).CR_fac),'-',num2str(list_mod.non(k).CR_sup),'-',num2str(list_mod.non(k).UR_fac),...
        '-',num2str(list_mod.non(k).UR_sup)])
end