% To calculate the single trial instantaneous firing rate with a similar pattern to
% Gau_psth_all which requires spk_Gaussian step before as input. window is for sliding window and bin_sz is for bin_size. --Zhong

function ifr_Gau_trial=ifr_Gau_trial(spk_Gau,window,bin_sz)

ifr_Gau_trial(size(spk_Gau,2))=struct('cell',[],'ifr_Gau_cell',[]); 

% first loop for each cell
for i=1:size(spk_Gau,2)
    ifr_Gau_cell(size(spk_Gau(i).spk_Gau_cell,2))=struct('trial',[],'ifr_Gau_org',[],'ifr_Gau_avg',[],'ifr_Gau_shft',[],'ifr_Gau_bin',[]);
 
%   second loop for each trial
    for j=1:size(spk_Gau(i).spk_Gau_cell,2)
        ifr_Gau_org=spk_Gau(i).spk_Gau_cell(j).spk_Gau_trial;
        t_max=max(spk_Gau(i).spk_Gau_cell(j).spk_Gau_trial(:,1));
        t_min=min(spk_Gau(i).spk_Gau_cell(j).spk_Gau_trial(:,1));
        ifr_Gau_avg=zeros(t_max-t_min,2);
        ifr_Gau_avg(:,1)=t_min:1:t_max-1;
        
%       third loop for each time point
%       avg to transform into 1ms
        for k=1:size(ifr_Gau_avg,1)
            ifr_Gau_avg(k,2)=mean(ifr_Gau_org((20*(k-1)+1):(20*(k-1)+20),2));
        end
        
%       shft to make sliding window        
        ifr_Gau_shft=zeros(t_max-t_min-2*window,5);
        ifr_Gau_shft(:,1)=(t_min+window):1:(t_max-window-1);
        
        for m=1:size(ifr_Gau_shft,1)
            ifr_Gau_shft(m,2)=mean(ifr_Gau_avg((m:(m+2*window)),2));
        end
        ifr_Gau_shft(:,3)=ifr_Gau_shft(:,2)/(0.00005*20);
        bsln_actvt=mean(ifr_Gau_shft(ifr_Gau_shft(:,1)<0,3));
        ifr_Gau_shft(:,4)=ifr_Gau_shft(:,3)/bsln_actvt;
        ifr_Gau_shft(:,5)=ifr_Gau_shft(:,3)-bsln_actvt;
        
%       bin to make a larger bin size
        ifr_Gau_bin=zeros((t_max-t_min-2*window)/bin_sz,2);
        ifr_Gau_bin(:,1)=t_min+window:bin_sz:t_max-window-1;
        
        for n=1:size(ifr_Gau_bin,1)
           ifr_Gau_bin(n,2)=mean(ifr_Gau_shft((bin_sz*(n-1)+1):(bin_sz*(n-1)+bin_sz),3)); 
        end
        ifr_Gau_bin(:,3)=ifr_Gau_bin(:,2)/bsln_actvt;
        ifr_Gau_bin(:,4)=ifr_Gau_bin(:,2)-bsln_actvt;
        
        ifr_Gau_cell(j).trial=j;
        ifr_Gau_cell(j).ifr_Gau_org=ifr_Gau_org;
        ifr_Gau_cell(j).ifr_Gau_avg=ifr_Gau_avg;
        ifr_Gau_cell(j).ifr_Gau_shft=ifr_Gau_shft;
        ifr_Gau_cell(j).ifr_Gau_bin=ifr_Gau_bin;
    end
    ifr_Gau_trial(i).cell=i;
    ifr_Gau_trial(i).ifr_Gau_cell=ifr_Gau_cell;
end

end