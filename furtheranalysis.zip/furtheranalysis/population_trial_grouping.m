list=trace_list_sim;
group_bin=20;
group_step=10;
t_pre=-250;
thrd_start=120;
thrd_end=500;
t_dur=750;
min_trial_num=10;
all_info_1='all_info';
align_info_1='align_info';
align_info_2='align_info';
mod_tp='CR_sup';
mod_idx=-1;
item='CR_onset';
ht_mp_bin=20;
ht_mp_step=5;
per_t_tg=0.4;
path='D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Wrapup_2\Figure 3\CR onset ordered PSTH\trace raw\Sup cells';
save_file_name='-T.pdf';
cd(path)

map=[0,0,0
0,0,0.025
0,0,0.05
0,0,0.075
0,0,0.1
0,0,0.125
0,0,0.15
0,0,0.175
0,0,0.2
0,0,0.225
0,0,0.25
0,0,0.275
0,0,0.3
0,0,0.325
0,0,0.35
0,0,0.375
0,0,0.4
0,0,0.425
0,0,0.45
0,0,0.475
0,0,0.5
0,0,0.525
0,0,0.55
0,0,0.575
0,0,0.6
0,0,0.625
0,0,0.65
0,0,0.675
0,0,0.7
0,0,0.725
0,0,0.75
0,0,0.775
0,0,0.8
0,0,0.825
0,0,0.85
0,0,0.875
0,0,0.9
0,0,0.925
0,0,0.95
0,0,0.975
0,0,1
0.025,0.025,1
0.05,0.05,1
0.075,0.075,1
0.1,0.1,1
0.125,0.125,1
0.15,0.15,1
0.175,0.175,1
0.2,0.2,1
0.225,0.225,1
0.25,0.25,1
0.275,0.275,1
0.3,0.3,1
0.325,0.325,1
0.35,0.35,1
0.375,0.375,1
0.4,0.4,1
0.425,0.425,1
0.45,0.45,1
0.475,0.475,1
0.5,0.5,1
0.525,0.525,1
0.55,0.55,1
0.575,0.575,1
0.6,0.6,1
0.625,0.625,1
0.65,0.65,1
0.675,0.675,1
0.7,0.7,1
0.725,0.725,1
0.75,0.75,1
0.775,0.775,1
0.8,0.8,1
0.825,0.825,1
0.85,0.85,1
0.875,0.875,1
0.9,0.9,1 
0.925,0.925,1
0.95,0.95,1
0.975,0.975,1
1,1,1];

[d,id]=findgroups({list.mouse_ID});
mouse_trial_list=struct('mouse_ID',[],'group_trial_list',[],'plot_mouse',[],'plot_rg_1',[],'plot_rg_2',[],'cell_num',[]);

for m=1:max(d)
    mouse_trial_list(m).mouse_ID=id{m};
    cell_num=0;
    for i=1:size(list,2)
        if ~isempty(list(i).(align_info_1).(mod_tp)) && contains(list(i).mouse_ID,id{m}) && ~isempty(list(i).(align_info_2).(mod_tp))
            cell_num=cell_num+1;    
        end
    end
    mouse_trial_list(m).cell_num=cell_num;
    
    empty=0;
    group_trial_list=struct('thrd_1',[],'thrd_2',[],'trial_list',[],'raw_ifr_list',[],'ifr_plot',[],'trial_size',[]);
    for n=1:(thrd_end-thrd_start-group_bin)/group_step+1
        thrd_1=(thrd_start+(n-1)*group_step)/1000;
        thrd_2=(thrd_start+(n-1)*group_step+group_bin)/1000;
        trial_list=struct('cell_ID',[],'trial_num',[],item,[],'ifr',[]);

        tr_idx=0;
        for i=1:size(list,2)
            if ~isempty(list(i).(align_info_1).(mod_tp)) && contains(list(i).mouse_ID,id{m}) && ~isempty(list(i).(align_info_2).(mod_tp))
                cell_num=cell_num+1;
                for j=1:size(list(i).(all_info_1).ttt.CR_trial,2)    
                    if list(i).(all_info_1).ttt.CR_trial(j).blk_info_new.(item)>=thrd_1 && list(i).(all_info_1).ttt.CR_trial(j).blk_info_new.(item)<thrd_2
                       tr_idx=tr_idx+1;        
                       trial_list(tr_idx).cell_ID=i;
                       trial_list(tr_idx).trial_num=list(i).(all_info_1).ttt.CR_trial(j).trial_num;
                       trial_list(tr_idx).(item)=list(i).(all_info_1).ttt.CR_trial(j).blk_info_new.(item)*1000;
                       t_idx_1=find(list(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,1)==t_pre);
                       t_idx_2=find(list(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,1)==t_dur);
                       t_idx_0=find(list(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,1)==0);
                       t_idx_post=find(list(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,1)==thrd_end);                   
                       trial_list(tr_idx).ifr=zeros(t_dur-t_pre,2);
                       trial_list(tr_idx).ifr(:,1)=list(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(t_idx_1:t_idx_2-1,1);
                       trial_list(tr_idx).ifr(:,2)=(list(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(t_idx_1:t_idx_2-1,3)*100-100)*mod_idx; 
                       if abs(mean(trial_list(tr_idx).ifr(:,2)))>1000
                          trial_list(tr_idx).ifr(:,2)=NaN;                          
                       end
                    end
                end
            end
        end   
        group_trial_list(n).thrd_1=thrd_1*1000;
        group_trial_list(n).thrd_2=thrd_2*1000;
        group_trial_list(n).trial_list=trial_list;       
        
        if ~isempty(trial_list(1).cell_ID)
            raw_ifr_list=zeros(t_dur-t_pre,size(trial_list,2));
            for k=1:size(trial_list,2)
                raw_ifr_list(:,k)=trial_list(k).ifr(:,2);        
            end

            raw_ifr_list=raw_ifr_list(:,all(~isnan(raw_ifr_list)));
            raw_ifr_list=raw_ifr_list(:,all(~isinf(raw_ifr_list)));

            ifr_plot=zeros(t_dur-t_pre,2);
            ifr_plot(:,1)=trial_list(1).ifr(:,1); 
            ifr_plot(:,2)=nanmean(raw_ifr_list,2); 
            group_trial_list(n).raw_ifr_list=raw_ifr_list;
            group_trial_list(n).ifr_plot=ifr_plot;   
            group_trial_list(n).trial_size=size(trial_list,2);
        else
            group_trial_list(n).raw_ifr_list=[];
            group_trial_list(n).ifr_plot=[];   
            group_trial_list(n).trial_size=0;
        end
    end
    mouse_trial_list(m).plot_rg_1=find([group_trial_list.trial_size]>=min_trial_num,1,'first');
    mouse_trial_list(m).plot_rg_2=find([group_trial_list.trial_size]>=min_trial_num,1,'last');
    if ~isempty(mouse_trial_list(m).plot_rg_1)
       if mouse_trial_list(m).plot_rg_2-mouse_trial_list(m).plot_rg_1+1>=((thrd_end-thrd_start-group_bin)/group_step+1)*per_t_tg
          for rg_idx=mouse_trial_list(m).plot_rg_1:mouse_trial_list(m).plot_rg_2
              if group_trial_list(rg_idx).trial_size<2
                 mouse_trial_list(m).plot_mouse=0;
                 break
              else
                 mouse_trial_list(m).plot_mouse=1;
              end             
          end 
       else
          mouse_trial_list(m).plot_mouse=0; 
       end
    else
        mouse_trial_list(m).plot_mouse=0;
    end
    
    mouse_trial_list(m).group_trial_list=group_trial_list;
end


%%
for m=1:size(mouse_trial_list,2)
    if mouse_trial_list(m).plot_mouse==1
        ht_mp_plot=zeros(mouse_trial_list(m).plot_rg_2-mouse_trial_list(m).plot_rg_1+1,(t_dur-t_pre-ht_mp_bin)/ht_mp_step);
        for n=mouse_trial_list(m).plot_rg_1:mouse_trial_list(m).plot_rg_2
            smth_curve=smooth_curve(mouse_trial_list(m).group_trial_list(n).ifr_plot(:,1),mouse_trial_list(m).group_trial_list(n).ifr_plot(:,2),ht_mp_bin,ht_mp_step);    
            ht_mp_plot(mouse_trial_list(m).plot_rg_2-n+1,:)=smth_curve(:,2)';
        end
        
        ht_mp_max=max(ht_mp_plot,[],2);
        ht_mp_max_range=ceil(median(ht_mp_max)*0.75/10)*10;

        % ht_mp_smth=smooth2a(ht_mp_plot,13,196);
        figure;
        subplot(2,2,1)
        h=heatmap(ht_mp_plot,'GridVisible','off','Colormap',map);
        h.ColorLimits = [0 ht_mp_max_range];
   
        subplot(2,2,2)
        for n=mouse_trial_list(m).plot_rg_1:mouse_trial_list(m).plot_rg_2
%             t_slot=mouse_trial_list(m).plot_rg_1+n-mouse_trial_list(m).plot_rg_1+1;
%             t_slot=mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1+n-1)+group_bin/2;
            plot(mouse_trial_list(m).group_trial_list(n).thrd_1+group_bin/2,n-mouse_trial_list(m).plot_rg_1+1,'*','Color',[1 0.5 1])
            hold on            
        end
        xlim([t_pre t_dur]);
        xticks(t_pre:250:t_dur);
        ylim([0 n-mouse_trial_list(m).plot_rg_1+2]);
        
        subplot(2,2,[3 4])
        bar_x=mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1).thrd_1+group_bin/2:group_step:mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_2).thrd_1+group_bin/2;
        bar_y=[mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1:mouse_trial_list(m).plot_rg_2).trial_size];
        bar(bar_x,bar_y,1);
%         h1=histogram([mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1:mouse_trial_list(m).plot_rg_2).trial_size]);
%         h1.BinWidth=group_step;
%         h1.BinLimits=[mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1).thrd_1 mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_2).thrd_2];
%         h1.FaceColor=[1 0.5 1];
%         h1.Normalization='count';
%         hold on
        xlim([mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1).thrd_1 mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_2).thrd_2]);
%         ylim([0 1]);
        xticks(mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1).thrd_1:group_step:mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_2).thrd_2);
        ylabel('Trial number');
        title([mouse_trial_list(m).mouse_ID ' - ' num2str(mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_1).thrd_1) 'ms - ' num2str(mouse_trial_list(m).group_trial_list(mouse_trial_list(m).plot_rg_2).thrd_2) 'ms ' num2str(mouse_trial_list(m).cell_num) ' cells']);
        
        saveas(gcf,[mouse_trial_list(m).mouse_ID save_file_name]);
    end
end



function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end



