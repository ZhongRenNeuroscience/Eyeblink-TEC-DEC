file=DT_mPFC_ready;
% mod_list=PFC_mod_list;
all_info='all_info_D';
align_info='align_info_D';
trial_type='CR_trial_D';
non_info='non_info_D';
CR_mod_info='CR_trial_D';
nonCR_mod_info='nonCR_trial_D';
all_info_2='all_info_T';
align_info_2='align_info_T';
trial_type_2='CR_trial_T';
non_info_2='non_info_T';
CR_mod_info_2='CR_trial_T';
nonCR_mod_info_2='nonCR_trial_T';
% bar_order={'Trace bsl','Delay bsl','Trace CR epoch','Delay CR epoch'};
% bar_order={'Delay bsl','Trace bsl','Delay CR epoch','Trace CR epoch'};
% cd 'D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Trace-trained-mice\T_D_data_output\htmp'
figure_name='mPFC_DT';
cell=230;
mod_type='CR_fac';
t_post=250;
t_post_2=500;
t_pre=-250;
dur=1250;
bin_htmp=50;
step_htmp=10;
trial_max=50;
sort_method='trial_num';
mix_plot=1;

ht_range_low=0;
ht_range_high=900;
color=parula;
type_idx=1;
ex_bsl_thrd_h=300;
ex_bsl_thrd_l=0;

ex_trial_1=[];
ex_trial_2=[];
ex_trial_3=[];
ex_trial_4=[];


% heat_map_list=struct('cell_ID',[],'file_name',[],'cell_num',[],'channel_info',[],'CR_trial_T',[],'nonCR_trial_T',[],'probe_trial_T',[]);
heat_map_list=struct('cell_ID',[],'file_name',[],'cell_num',[],'channel_info',[],'CR_trial_T',[],'nonCR_trial_T',[],'probe_trial_T',[],...
    'CR_trial_D',[],'nonCR_trial_D',[],'probe_trial_D',[]);

pos_bhv_1=[0.095 0.05 0.35 0.18];
pos_bhv_2=[0.095 0.77 0.35 0.18];
pos_htmp_1=[0.13 0.32 0.395 0.373];
pos_bhv_3=[0.575 0.05 0.35 0.18];
pos_bhv_4=[0.575 0.77 0.35 0.18];
pos_htmp_2=[0.575 0.285 0.35 0.42];
% pos_bar_1=[0.05 0.282 0.02 0.423];
% pos_psth_1=[0.78 0.37 0.17 0.22];
% pos_psth_2=[0.78 0.08 0.17 0.22];
% pos_bar_2=[0.41 0.26 0.02 0.456];
% pos_frq=[0.78 0.7 0.17 0.2];

% pos_bhv_1=[0.095 0.7 0.247 0.2];
% pos_htmp_1=[0.12 0.1 0.26 0.5];
% pos_bhv_3=[0.445 0.7 0.247 0.2];
% pos_htmp_2=[0.47 0.1 0.26 0.5];
% pos_bar_1=[0.06 0.051 0.02 0.566];
% % pos_psth_1=[0.78 0.37 0.17 0.22];
% % pos_psth_2=[0.78 0.08 0.17 0.22];
% % pos_bar_2=[0.41 0.051 0.02 0.566];
% % pos_frq=[0.78 0.7 0.17 0.2];

% bar_color_1=[0.4 0 0.8];
% bar_color_3=[0.9 0.8 1];
% bar_color_2=[1 0.5 0];
% bar_color_4=[1 0.9 0.8];

bar_color_2=[0.4 0 0.8];
bar_color_4=[0.9 0.8 1];
bar_color_1=[1 0.5 0];
bar_color_3=[1 0.9 0.8];

cold_map=[0,0,0
0,0,0.025
0,0,0.05
0,0,0.075
0,0,0.1
0,0,0.125
0,0,0.15
0,0,0.175
0,0,0.2
0,0,0.225
0,0,0.25
0,0,0.275
0,0,0.3
0,0,0.325
0,0,0.35
0,0,0.375
0,0,0.4
0,0,0.425
0,0,0.45
0,0,0.475
0,0,0.5
0,0,0.525
0,0,0.55
0,0,0.575
0,0,0.6
0,0,0.625
0,0,0.65
0,0,0.675
0,0,0.7
0,0,0.725
0,0,0.75
0,0,0.775
0,0,0.8
0,0,0.825
0,0,0.85
0,0,0.875
0,0,0.9
0,0,0.925
0,0,0.95
0,0,0.975
0,0,1
0.025,0.025,1
0.05,0.05,1
0.075,0.075,1
0.1,0.1,1
0.125,0.125,1
0.15,0.15,1
0.175,0.175,1
0.2,0.2,1
0.225,0.225,1
0.25,0.25,1
0.275,0.275,1
0.3,0.3,1
0.325,0.325,1
0.35,0.35,1
0.375,0.375,1
0.4,0.4,1
0.425,0.425,1
0.45,0.45,1
0.475,0.475,1
0.5,0.5,1
0.525,0.525,1
0.55,0.55,1
0.575,0.575,1
0.6,0.6,1
0.625,0.625,1
0.65,0.65,1
0.675,0.675,1
0.7,0.7,1
0.725,0.725,1
0.75,0.75,1
0.775,0.775,1
0.8,0.8,1
0.825,0.825,1
0.85,0.85,1
0.875,0.875,1
0.9,0.9,1 
0.925,0.925,1
0.95,0.95,1
0.975,0.975,1
1,1,1];

for i=cell:cell
    cell_ID=i;   
    heat_map_list(i).cell_ID=file(i).cell_ID;
    heat_map_list(i).file_name=file(i).file_name;
    heat_map_list(i).cell_num=file(i).cell_num;
%     heat_map_list(i).channel_info=file(i).channel_info_D;
    CR_trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
        'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
    for j=1:size(file(cell_ID).(all_info).ttt.CR_trial,2)
        CR_trial_info(j).field=j;
        CR_trial_info(j).trial_num=file(cell_ID).(all_info).ttt.CR_trial(j).trial_num;
        exclude_idx=find(ex_trial_1==j);
        CR_trial_info(j).CR_onset=file(cell_ID).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
        CR_trial_info(j).spk=file(cell_ID).(all_info).ttt.CR_trial(j).spk_time;
        CR_trial_info(j).blk_smth=file(cell_ID).(all_info).ttt.CR_trial(j).blk_smth;
        CR_trial_info(j).ifr_smth=file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth;
        CR_trial_info(j).bsl_frq=length(find([file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]>=t_pre/1000 & [file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]<0))/-t_pre*1000;
        if ~any(CR_trial_info(j).spk>0 & CR_trial_info(j).spk<t_post/1000) 
           CR_trial_info(j).field=[];  
        end
        if CR_trial_info(j).bsl_frq>ex_bsl_thrd_h || CR_trial_info(j).bsl_frq<ex_bsl_thrd_l
           CR_trial_info(j).field=[];            
        end
        if CR_trial_info(j).CR_onset>0.22 && mod(CR_trial_info(j).trial_num,2)>0
           CR_trial_info(j).field=[];            
        end
        CR_trial_info(j).CR_frq=length(find([file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]>=0 & [file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]<t_post/1000))/t_post*1000;
        t_ifr_start=find(file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth(:,1)==t_pre);
        ifr_plot=smooth_curve(file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
        CR_trial_info(j).ifr_plot=ifr_plot;
%         [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
%         CR_trial_info(j).mod_amp=mod_amp;
%         CR_trial_info(j).mod_pkt=mod_pkt*(2*step-1)/2;
    end 
  
    CR_trial_info=CR_trial_info(~cellfun(@isempty,{CR_trial_info.field}));
    [~,index] = sortrows([CR_trial_info.(sort_method)].'); 
    CR_trial_info = CR_trial_info(index);
    heat_map_list(i).CR_trial_T=CR_trial_info;
    plot_trials_CR=1:size(CR_trial_info,2);
    if size(CR_trial_info,2)>=trial_max
       plot_trials_CR=randperm(size(CR_trial_info,2),trial_max);
       plot_trials_CR=sort(plot_trials_CR);
    end
    
    nonCR_trial_info=struct('field',[],'trial_num',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
        'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
    for j=1:size(file(cell_ID).(all_info).ttt.nonCR_trial,2)
        nonCR_trial_info(j).field=j;
        nonCR_trial_info(j).trial_num=file(cell_ID).(all_info).ttt.nonCR_trial(j).trial_num;
        nonCR_trial_info(j).spk=file(cell_ID).(all_info).ttt.nonCR_trial(j).spk_time;
        nonCR_trial_info(j).blk_smth=file(cell_ID).(all_info).ttt.nonCR_trial(j).blk_smth;
        nonCR_trial_info(j).ifr_smth=file(cell_ID).(all_info).ttt.nonCR_trial(j).ifr_smooth;
        nonCR_trial_info(j).bsl_frq=length(find([file(cell_ID).(all_info).ttt.nonCR_trial(j).spk_time]>=t_pre/1000 & [file(cell_ID).(all_info).ttt.nonCR_trial(j).spk_time]<0))/-t_pre*1000;
        nonCR_trial_info(j).CR_frq=length(find([file(cell_ID).(all_info).ttt.nonCR_trial(j).spk_time]>=0 & [file(cell_ID).(all_info).ttt.nonCR_trial(j).spk_time]<t_post/1000))/t_post*1000;
        t_ifr_start=find(file(cell_ID).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1)==t_pre);
        ifr_plot=smooth_curve(file(cell_ID).(all_info).ttt.nonCR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info).ttt.nonCR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
        nonCR_trial_info(j).ifr_plot=ifr_plot;
%         [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
%         nonCR_trial_info(j).mod_amp=mod_amp;
%         nonCR_trial_info(j).mod_pkt=mod_pkt*(2*step-1)/2;
    end 
    [~,index] = sortrows([nonCR_trial_info.(sort_method)].'); 
    nonCR_trial_info = nonCR_trial_info(index);
    heat_map_list(i).nonCR_trial_T=nonCR_trial_info;
    plot_trials_nonCR=1:size(nonCR_trial_info,2);
    if size(nonCR_trial_info,2)>=trial_max
       plot_trials_nonCR=randperm(size(nonCR_trial_info,2),trial_max);
       plot_trials_nonCR=sort(plot_trials_nonCR);
    end

    probe_trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
        'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
    for j=1:size(file(cell_ID).(all_info).ttt.probe_trial,2)
        probe_trial_info(j).field=j;
        probe_trial_info(j).trial_num=file(cell_ID).(all_info).ttt.probe_trial(j).trial_num;
        probe_trial_info(j).CR_onset=file(cell_ID).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset;
        probe_trial_info(j).spk=file(cell_ID).(all_info).ttt.probe_trial(j).spk_time;
        probe_trial_info(j).blk_smth=file(cell_ID).(all_info).ttt.probe_trial(j).blk_smth;
        probe_trial_info(j).ifr_smth=file(cell_ID).(all_info).ttt.probe_trial(j).ifr_smooth;
        probe_trial_info(j).bsl_frq=length(find([file(cell_ID).(all_info).ttt.probe_trial(j).spk_time]>=t_pre/1000 & [file(cell_ID).(all_info).ttt.probe_trial(j).spk_time]<0))/-t_pre*1000;
        if ~any(probe_trial_info(j).spk>0 & probe_trial_info(j).spk<t_post/1000) 
           probe_trial_info(j).field=[];  
        end
        if probe_trial_info(j).bsl_frq>ex_bsl_thrd_h
           probe_trial_info(j).field=[];            
        end
        if (probe_trial_info(j).CR_onset>t_post/1000*0.95) %| probe_trial_info(j).CR_onset<0.18
           probe_trial_info(j).field=[];            
        end
        probe_trial_info(j).CR_frq=length(find([file(cell_ID).(all_info).ttt.probe_trial(j).spk_time]>=0 & [file(cell_ID).(all_info).ttt.probe_trial(j).spk_time]<t_post/1000))/t_post*1000;
        t_ifr_start=find(file(cell_ID).(all_info).ttt.probe_trial(j).ifr_smooth(:,1)==t_pre);
        ifr_plot=smooth_curve(file(cell_ID).(all_info).ttt.probe_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info).ttt.probe_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
        probe_trial_info(j).ifr_plot=ifr_plot;
%         [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
%         probe_trial_info(j).mod_amp=mod_amp;
%         probe_trial_info(j).mod_pkt=mod_pkt*(2*step-1)/2;
    end 
    probe_trial_info([probe_trial_info.CR_onset]==0)=[];
    probe_trial_info=probe_trial_info(~cellfun(@isempty,{probe_trial_info.CR_onset}));
    probe_trial_info=probe_trial_info(~cellfun(@isempty,{probe_trial_info.field}));
%     [~,index] = sortrows([probe_trial_info.(sort_method)].'); 
%     probe_trial_info = probe_trial_info(index);
%     heat_map_list(i).probe_trial_T=probe_trial_info;
%     plot_trials_probe=1:size(probe_trial_info,2);
%     if size(probe_trial_info,2)>=trial_max
%        plot_trials_probe=randperm(size(probe_trial_info,2),trial_max);
%        plot_trials_probe=sort(plot_trials_probe);
%     end

    if mix_plot==1
        CR_trial_info=cat(2,CR_trial_info,probe_trial_info); 
        [~,index] = sortrows([CR_trial_info.(sort_method)].'); 
        CR_trial_info = CR_trial_info(index);
        heat_map_list(i).CR_trial_T=CR_trial_info;
        plot_trials_CR=1:size(CR_trial_info,2);
        if size(CR_trial_info,2)>=trial_max
           plot_trials_CR=randperm(size(CR_trial_info,2),trial_max);
           plot_trials_CR=sort(plot_trials_CR);
        end
    end

    
    if ~isempty(all_info_2)
        CR_trial_info_2=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
            'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
        for j=1:size(file(cell_ID).(all_info_2).ttt.CR_trial,2)
            CR_trial_info_2(j).field=j;
            CR_trial_info_2(j).trial_num=file(cell_ID).(all_info_2).ttt.CR_trial(j).trial_num;
            CR_trial_info_2(j).CR_onset=file(cell_ID).(all_info_2).ttt.CR_trial(j).blk_info_new.CR_onset;
            CR_trial_info_2(j).spk=file(cell_ID).(all_info_2).ttt.CR_trial(j).spk_time;
            CR_trial_info_2(j).blk_smth=file(cell_ID).(all_info_2).ttt.CR_trial(j).blk_smth;
            CR_trial_info_2(j).ifr_smth=file(cell_ID).(all_info_2).ttt.CR_trial(j).ifr_smooth;
            CR_trial_info_2(j).bsl_frq=length(find([file(cell_ID).(all_info_2).ttt.CR_trial(j).spk_time]>=t_pre/1000 & [file(cell_ID).(all_info_2).ttt.CR_trial(j).spk_time]<0))/-t_pre*1000;
            if CR_trial_info_2(j).bsl_frq>ex_bsl_thrd_h || CR_trial_info_2(j).bsl_frq<ex_bsl_thrd_l
               CR_trial_info_2(j).field=[];            
            end   
            if CR_trial_info_2(j).CR_onset<0.18 && mod(CR_trial_info_2(j).trial_num,3)>0
               CR_trial_info_2(j).field=[];            
            end 
            CR_trial_info_2(j).CR_frq=length(find([file(cell_ID).(all_info_2).ttt.CR_trial(j).spk_time]>=0 & [file(cell_ID).(all_info_2).ttt.CR_trial(j).spk_time]<t_post_2/1000))/t_post_2*1000;
            t_ifr_start=find(file(cell_ID).(all_info_2).ttt.CR_trial(j).ifr_smooth(:,1)==t_pre);
            ifr_plot=smooth_curve(file(cell_ID).(all_info_2).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info_2).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
            CR_trial_info_2(j).ifr_plot=ifr_plot;
    %         [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
    %         CR_trial_info_2(j).mod_amp=mod_amp;
    %         CR_trial_info_2(j).mod_pkt=mod_pkt*(2*step-1)/2;
        end 
       CR_trial_info_2=CR_trial_info_2(~cellfun(@isempty,{CR_trial_info_2.field}));
       [~,index] = sortrows([CR_trial_info_2.(sort_method)].'); 
       CR_trial_info_2 = CR_trial_info_2(index);
       heat_map_list(i).CR_trial_D=CR_trial_info_2;
       plot_trials_CR_2=1:size(CR_trial_info_2,2);
       if size(CR_trial_info_2,2)>=trial_max
          plot_trials_CR_2=randperm(size(CR_trial_info_2,2),trial_max);
          plot_trials_CR_2=sort(plot_trials_CR_2);
       end
        
        nonCR_trial_info_2=struct('field',[],'trial_num',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
            'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
        for j=1:size(file(cell_ID).(all_info_2).ttt.nonCR_trial,2)
            nonCR_trial_info_2(j).field=j;
            nonCR_trial_info_2(j).trial_num=file(cell_ID).(all_info_2).ttt.nonCR_trial(j).trial_num;            
            nonCR_trial_info_2(j).spk=file(cell_ID).(all_info_2).ttt.nonCR_trial(j).spk_time;
            nonCR_trial_info_2(j).blk_smth=file(cell_ID).(all_info_2).ttt.nonCR_trial(j).blk_smth;
            nonCR_trial_info_2(j).ifr_smth=file(cell_ID).(all_info_2).ttt.nonCR_trial(j).ifr_smooth;
            nonCR_trial_info_2(j).bsl_frq=length(find([file(cell_ID).(all_info_2).ttt.nonCR_trial(j).spk_time]>=t_pre/1000 & [file(cell_ID).(all_info_2).ttt.nonCR_trial(j).spk_time]<0))/-t_pre*1000;
            nonCR_trial_info_2(j).CR_frq=length(find([file(cell_ID).(all_info_2).ttt.nonCR_trial(j).spk_time]>=0 & [file(cell_ID).(all_info_2).ttt.nonCR_trial(j).spk_time]<t_post_2/1000))/t_post_2*1000;
            t_ifr_start=find(file(cell_ID).(all_info_2).ttt.nonCR_trial(j).ifr_smooth(:,1)==t_pre);
            ifr_plot=smooth_curve(file(cell_ID).(all_info_2).ttt.nonCR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info_2).ttt.nonCR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
            nonCR_trial_info_2(j).ifr_plot=ifr_plot;
    %         [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
    %         nonCR_trial_info_2(j).mod_amp=mod_amp;
    %         nonCR_trial_info_2(j).mod_pkt=mod_pkt*(2*step-1)/2;
        end 
        [~,index] = sortrows([nonCR_trial_info_2.(sort_method)].'); 
        nonCR_trial_info_2 = nonCR_trial_info_2(index);
        heat_map_list(i).nonCR_trial_D=nonCR_trial_info_2;
        plot_trials_nonCR_2=1:size(nonCR_trial_info_2,2);
        if size(nonCR_trial_info_2,2)>=trial_max
           plot_trials_nonCR_2=randperm(size(nonCR_trial_info_2,2),trial_max);
           plot_trials_nonCR_2=sort(plot_trials_nonCR_2);
        end
        
        probe_trial_info_2=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
            'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
        for j=1:size(file(cell_ID).(all_info_2).ttt.probe_trial,2)
            probe_trial_info_2(j).field=j;
            probe_trial_info_2(j).trial_num=file(cell_ID).(all_info_2).ttt.probe_trial(j).trial_num;
            probe_trial_info_2(j).CR_onset=file(cell_ID).(all_info_2).ttt.probe_trial(j).blk_info_new.CR_onset;
            probe_trial_info_2(j).spk=file(cell_ID).(all_info_2).ttt.probe_trial(j).spk_time;
            probe_trial_info_2(j).blk_smth=file(cell_ID).(all_info_2).ttt.probe_trial(j).blk_smth;
            if probe_trial_info_2(j).bsl_frq>ex_bsl_thrd_h
               probe_trial_info_2(j).field=[];            
            end
            if probe_trial_info_2(j).CR_onset>t_post/1000*0.95 
               probe_trial_info_2(j).field=[];            
            end
            probe_trial_info_2(j).ifr_smth=file(cell_ID).(all_info_2).ttt.probe_trial(j).ifr_smooth;
            probe_trial_info_2(j).bsl_frq=length(find([file(cell_ID).(all_info_2).ttt.probe_trial(j).spk_time]>=t_pre/1000 & [file(cell_ID).(all_info_2).ttt.probe_trial(j).spk_time]<0))/-t_pre*1000;
            probe_trial_info_2(j).CR_frq=length(find([file(cell_ID).(all_info_2).ttt.probe_trial(j).spk_time]>=0 & [file(cell_ID).(all_info_2).ttt.probe_trial(j).spk_time]<t_post_2/1000))/t_post_2*1000;
            t_ifr_start=find(file(cell_ID).(all_info_2).ttt.probe_trial(j).ifr_smooth(:,1)==t_pre);
            ifr_plot=smooth_curve(file(cell_ID).(all_info_2).ttt.probe_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info_2).ttt.probe_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
            probe_trial_info_2(j).ifr_plot=ifr_plot;
    %         [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
    %         probe_trial_info_2(j).mod_amp=mod_amp;
    %         probe_trial_info_2(j).mod_pkt=mod_pkt*(2*step-1)/2;
        end 
        probe_trial_info_2([probe_trial_info_2.CR_onset]==0)=[];
        probe_trial_info_2=probe_trial_info_2(~cellfun(@isempty,{probe_trial_info_2.CR_onset}));
        probe_trial_info_2=probe_trial_info_2(~cellfun(@isempty,{probe_trial_info_2.field}));
        [~,index] = sortrows([probe_trial_info_2.(sort_method)].'); 
        probe_trial_info_2 = probe_trial_info_2(index);
        heat_map_list(i).probe_trial_D=probe_trial_info_2;
        plot_trials_probe_2=1:size(probe_trial_info_2,2);
        if size(probe_trial_info_2,2)>=trial_max
           plot_trials_probe_2=randperm(size(probe_trial_info_2,2),trial_max);
           plot_trials_probe_2=sort(plot_trials_probe_2);
        end

%         if mix_plot==1
%            CR_trial_info_2=cat(2,CR_trial_info_2,probe_trial_info_2); 
%            [~,index] = sortrows([CR_trial_info_2.(sort_method)].'); 
%            CR_trial_info_2 = CR_trial_info_2(index);
%            heat_map_list(i).CR_trial_D=CR_trial_info_2;
%            plot_trials_CR_2=1:size(CR_trial_info_2,2);
%            if size(CR_trial_info_2,2)>=trial_max
%               plot_trials_CR_2=randperm(size(CR_trial_info_2,2),trial_max);
%               plot_trials_CR_2=sort(plot_trials_CR_2);
%            end
%         end
    end       


    figure('units','normalized','outerposition',[0.1 0 0.4 1]);
    
    
    subplot('Position',pos_bhv_1)  
%     plot(file(cell_ID).(align_info).psth_ex(:,1),smooth(file(cell_ID).(align_info).psth_ex(:,2),25)/file(cell_ID).(align_info).bsl_frq_ex*100,'Color',bar_color_1,'LineWidth',2.0)
    plot(file(cell_ID).(align_info).psth_ex(:,1),smooth(file(cell_ID).(align_info).psth_ex(:,2),25),'Color',bar_color_1,'LineWidth',2.0)
    hold on
    if isempty(all_info_2)
        ymin_CR=floor(min(file(cell_ID).(align_info).psth_ex(t_ifr_start:t_ifr_start+dur-1,2)/file(cell_ID).(align_info).bsl_frq_ex*100)*0.9/10)*10;   
        ymax_CR=ceil(max(file(cell_ID).(align_info).psth_ex(t_ifr_start:t_ifr_start+dur-1,2)/file(cell_ID).(align_info).bsl_frq_ex*100)*1.05/10)*10; 
    else   
        ymin_CR=floor(min(min(file(cell_ID).(align_info).psth_ex(t_ifr_start:t_ifr_start+dur-1,2)/file(cell_ID).(align_info).bsl_frq_ex*100),min(file(cell_ID).(align_info_2).psth_ex(t_ifr_start:t_ifr_start+dur-1,2)/file(cell_ID).(align_info_2).bsl_frq_ex*100))*0.9/10)*10;   
        ymax_CR=ceil(max(max(file(cell_ID).(align_info).psth_ex(t_ifr_start:t_ifr_start+dur-1,2)/file(cell_ID).(align_info).bsl_frq_ex*100),max(file(cell_ID).(align_info_2).psth_ex(t_ifr_start:t_ifr_start+dur-1,2)/file(cell_ID).(align_info_2).bsl_frq_ex*100))*1.05/10)*10; 
    end
    ymin_CR=0;
    ymax_CR=120;
%        ymin_nonCR=floor(min(file(cell_ID).(non_info).psth(51:1550,2))*0.9);   
%        ymax_nonCR=ceil(max(file(cell_ID).(non_info).psth(51:1550,2))*1.05); 
%        ymax=max([ymax_CR ymax_nonCR]);
%        ymin=min([ymin_CR ymin_nonCR]);
    ylim([ymin_CR ymax_CR]); 
    line([0 0],[0,ymax_CR],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    line([250 250],[0,ymax_CR],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    line([500 500],[0,ymax_CR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
    hold on
%     text(mod_list(cell_ID).(align_info).(mod_type).t_onset,ymax_CR*0.8,'*','HorizontalAlignment','center');
    xlim([t_pre t_pre+dur]);
    xticks(-500:250:1000);
    xlabel('Time(ms)');
    ylabel('Relative firing rate (%)');
    title('CR trials');
    if ~isempty(all_info_2)
       subplot('Position',pos_bhv_2)  
%        plot(file(cell_ID).(all_info_2).sss_all.psth.nonCR_trial.psth_smooth(:,1),smooth(file(cell_ID).(all_info_2).sss_all.psth.nonCR_trial.psth_smooth(:,2),25)/file(cell_ID).(align_info_2).bsl_frq_ex*100,'Color',bar_color_3,'LineWidth',2.0)
       plot(file(cell_ID).(all_info_2).sss_all.psth.nonCR_trial.psth_smooth(:,1),smooth(file(cell_ID).(all_info_2).sss_all.psth.nonCR_trial.psth_smooth(:,2),25),'Color',bar_color_3,'LineWidth',2.0)
       hold on   
       plot(file(cell_ID).(align_info_2).psth_ex(:,1),smooth(file(cell_ID).(align_info_2).psth_ex(:,2),25)/file(cell_ID).(align_info_2).bsl_frq_ex*100,'Color',bar_color_3,'LineWidth',2.0)
       hold on      
       ymin_CR=floor(min(file(cell_ID).(align_info_2).psth_ex(51:1550,2))*0.9);   
       ymax_CR=ceil(max(file(cell_ID).(align_info_2).psth_ex(51:1550,2))*1.05); 
       ymin_nonCR=floor(min(min(file(cell_ID).(non_info).psth(51:1550,2)),min(file(cell_ID).(non_info_2).psth(51:1550,2)))*0.9);   
       ymax_nonCR=ceil(max(max(file(cell_ID).(non_info).psth(51:1550,2)),max(file(cell_ID).(non_info_2).psth(51:1550,2)))*1.05); 
       if abs(ymin_CR-ymin_nonCR)<20 && abs(ymax_CR-ymax_nonCR)<20
          ymax_CR=max([ymax_CR ymax_nonCR]);
          ymin_CR=min([ymin_CR ymin_nonCR]);       
       end
       line([0 0],[0,ymax_CR],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
       line([250 250],[0,ymax_CR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
       line([500 500],[0,ymax_CR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
       if ymin_CR==ymax_CR
          ylim([ymin_CR ymax_CR+1]); 
       else
          ylim([ymin_CR ymax_CR]);  
       end
           hold on
       xlim([t_pre t_pre+dur]);
%        text(mod_list(cell_ID).(align_info_2).(mod_type).t_onset,ymax_CR*0.8,'*','HorizontalAlignment','center');
       xticks(-500:250:1000);
       xlabel('Time(ms)');
       ylabel('Relative firing rate (%)');
       title('CR trials');
    end



    subplot('Position',pos_htmp_1)
    ifr_list_1=zeros(length(plot_trials_CR),(dur-bin_htmp)/step_htmp+1);
    CRonset_list_1=zeros(length(plot_trials_CR),1);
    for m=1:length(plot_trials_CR) 
        ifr_list_1(length(plot_trials_CR)-m+1,:)=CR_trial_info(plot_trials_CR(1,m)).ifr_plot(:,2)'/file(cell_ID).(align_info).bsl_frq_ex*100;
        CRonset_list_1(m,1)=CR_trial_info(plot_trials_CR(1,m)).CR_onset;
    end

    if ~isempty(all_info_2)
        ifr_list_3=zeros(length(plot_trials_nonCR_2),(dur-bin_htmp)/step_htmp+1);
        CRonset_list_3=zeros(length(plot_trials_nonCR_2),1);
        for m=1:length(plot_trials_nonCR_2) 
            ifr_list_3(length(plot_trials_nonCR_2)-m+1,:)=nonCR_trial_info_2(plot_trials_nonCR_2(1,m)).ifr_plot(:,2)'/file(cell_ID).(align_info_2).bsl_frq_ex*100;
            CRonset_list_3(m,1)=0;
        end           
    end
    if isempty(all_info_2)
       ifr_list_final=zeros(length(plot_trials_CR),(dur-bin_htmp)/step_htmp+1);
       ifr_list_final(1:length(plot_trials_CR),:)=ifr_list_1;
       CRonset_list_final=zeros(length(plot_trials_CR),1);
       CRonset_list_final(1:length(plot_trials_CR),1)=CRonset_list_1;   
    else
       ifr_list_final=zeros(length(plot_trials_CR)+length(plot_trials_nonCR_2),(dur-bin_htmp)/step_htmp+1);
       ifr_list_final(1:length(plot_trials_nonCR_2),:)=ifr_list_3;
       ifr_list_final(length(plot_trials_nonCR_2)+1:end,:)=ifr_list_1;     
       CRonset_list_final=zeros(length(plot_trials_CR)+length(plot_trials_nonCR_2),1);
       CRonset_list_final(1:length(plot_trials_CR),1)=CRonset_list_1;   
       CRonset_list_final(length(plot_trials_CR)+1:end,1)=CRonset_list_3;    
    end
    h=heatmap((ifr_list_final-100)*type_idx,'GridVisible','off','Colormap',color);
    range_mean=(mean(mean(ifr_list_final,1)))-100;
%     ht_range_low=floor(range_mean*type_idx/10)*10;
%     ht_range_high=ceil(range_mean*type_idx/10)*10+40;
    h.ColorLimits = [ht_range_low ht_range_high];

    subplot('Position',pos_bar_1)

    rectangle('Position',[0,0,5,length(plot_trials_CR)],'FaceColor',bar_color_1,'EdgeColor','none');
    hold on
    if ~isempty(all_info_2)
       rectangle('Position',[0,length(plot_trials_CR),5,length(plot_trials_nonCR_2)],'FaceColor',bar_color_3,'EdgeColor','none');
       hold on 
       axis([0 5 0 length(plot_trials_CR)+length(plot_trials_nonCR_2)]);
       hold on
       axis off 
    else
       axis([0 5 0 length(plot_trials_CR)]);
       hold on
       axis off    
    end
                    
   subplot('Position',pos_htmp_2)
   for m=1:length(CRonset_list_final)
       plot(CRonset_list_final(m,1)*1000,m,'m*')
       hold on             
   end 
    line([0 0],[0 m+1],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    line([250 250],[0 m+1],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    line([500 500],[0 m+1],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
    xlim([t_pre t_pre+dur]);
    xticks(-500:250:1000);
    ylim([0 m+1]);
    xlabel('Time(ms)');
    ylabel('Trials');    
   
   
    subplot('Position',pos_bhv_3)

    behavior_mean=zeros((1550-25)/5+1,size(CR_trial_info,2));
    for m=1:size(CR_trial_info,2)
        blk_curve=smooth_curve(CR_trial_info(m).blk_smth(:,1),CR_trial_info(m).blk_smth(:,2)*100,25,5);
        behavior_mean(:,m)=blk_curve(:,2);  
    end
%     for m=1:length(plot_trials_CR)
%         plot(blk_curve(:,1),behavior_mean(:,plot_trials_CR(1,m)),'Color',[0.9 0.9 0.9],'LineWidth',0.25)
%         hold on
%     end
    behavior_mean_plot=zeros(size(blk_curve,1),5);
    behavior_mean_plot(:,1)=blk_curve(:,1);
    behavior_mean_plot(:,2)=mean(behavior_mean,2);
    behavior_mean_plot(:,3)=std(behavior_mean,1,2);
    for m=1:size(blk_curve,1)
        behavior_mean_plot(m,4)=behavior_mean_plot(m,2)+behavior_mean_plot(m,3);
        behavior_mean_plot(m,5)=behavior_mean_plot(m,2)-behavior_mean_plot(m,3);       
    end
    ymax=max(max(behavior_mean))+0.1;
    ymin=min(min(behavior_mean))-0.1;
    %     line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    % rectangle('Position',[0,ymin*0.95,250,ymax-ymin],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')
    line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',2.0);
    line([t_post t_post],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
    plot(behavior_mean_plot(:,1),behavior_mean_plot(:,2),'Color',[0 0 0],'LineWidth',2)
    hold on
    plot(behavior_mean_plot(:,1),behavior_mean_plot(:,4),'Color',[0.8 0.8 0.8],'LineWidth',1)
    hold on
    plot(behavior_mean_plot(:,1),behavior_mean_plot(:,5),'Color',[0.8 0.8 0.8],'LineWidth',1)
    hold on
    if isempty(all_info_2)
       title('CR trials')         
    end
    line([0 0],[-10,110],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    line([250 250],[-10,110],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    line([500 500],[-10,110],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
    xlim([t_pre t_pre+dur]);
    xticks(-500:250:1000);
    yticks(0:100:100);
    ylim([-10,110]);
    xlabel('Time(ms)');
    ylabel('Normalized eyelid trace') 

    if ~isempty(all_info_2)
        subplot('Position',pos_bhv_4)

        behavior_mean=zeros((1550-25)/5+1,size(nonCR_trial_info_2,2));
        for m=1:size(nonCR_trial_info_2,2)
            blk_curve=smooth_curve(nonCR_trial_info_2(m).blk_smth(:,1),nonCR_trial_info_2(m).blk_smth(:,2)*100,25,5);
            behavior_mean(:,m)=blk_curve(:,2);  
        end
%         for m=1:length(plot_trials_CR_2)
%             plot(blk_curve(:,1),behavior_mean(:,plot_trials_CR_2(1,m)),'Color',[0.9 0.9 0.9],'LineWidth',0.25)
%             hold on
%         end
        behavior_mean_plot=zeros(size(blk_curve,1),5);
        behavior_mean_plot(:,1)=blk_curve(:,1);
        behavior_mean_plot(:,2)=mean(behavior_mean,2);
        behavior_mean_plot(:,3)=std(behavior_mean,1,2);
        for m=1:size(blk_curve,1)
            behavior_mean_plot(m,4)=behavior_mean_plot(m,2)+behavior_mean_plot(m,3);
            behavior_mean_plot(m,5)=behavior_mean_plot(m,2)-behavior_mean_plot(m,3);       
        end        
        ymax=max(max(behavior_mean))+0.1;
        ymin=min(min(behavior_mean))-0.1;
        %     line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
        % rectangle('Position',[0,ymin*0.95,250,ymax-ymin],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')
        line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',2.0);
        line([t_post_2 t_post_2],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
        plot(behavior_mean_plot(:,1),behavior_mean_plot(:,2),'Color',[0 0 0],'LineWidth',2)
        hold on
        plot(behavior_mean_plot(:,1),behavior_mean_plot(:,4),'Color',[0.8 0.8 0.8],'LineWidth',1)
        hold on
        plot(behavior_mean_plot(:,1),behavior_mean_plot(:,5),'Color',[0.8 0.8 0.8],'LineWidth',1)        
        hold on
        title('CR trials');
        line([0 0],[-10,110],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
        line([250 250],[-10,110],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
        line([500 500],[-10,110],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
        xlim([t_pre t_pre+dur]);
        xticks(-500:250:1000);
        yticks(0:100:100);
        ylim([-10,110]);
        xlabel('Time(ms)');
        ylabel('Normalized eyelid trace')        
    end

% 
%     subplot('Position',pos_htmp_2)
%     ifr_list_1=zeros(length(plot_trials_nonCR),(dur-bin_htmp)/step_htmp+1);
%     for m=1:length(plot_trials_nonCR) 
%         ifr_list_1(length(plot_trials_nonCR)-m+1,:)=nonCR_trial_info(plot_trials_nonCR(1,m)).ifr_plot(:,2)';
%     end
%     if ~isempty(all_info_2)
%         ifr_list_3=zeros(length(plot_trials_nonCR_2),(dur-bin_htmp)/step_htmp+1);
%         for m=1:length(plot_trials_nonCR_2) 
%             ifr_list_3(length(plot_trials_nonCR_2)-m+1,:)=nonCR_trial_info_2(plot_trials_nonCR_2(1,m)).ifr_plot(:,2)';
%         end          
%     end
%     if isempty(all_info_2)
%        ifr_list_final=ifr_list_1;
%     else
%        ifr_list_final=zeros(length(plot_trials_nonCR)+length(plot_trials_nonCR_2),(dur-bin_htmp)/step_htmp+1);
%        ifr_list_final(1:length(plot_trials_nonCR_2),:)=ifr_list_3;  
%        ifr_list_final(length(plot_trials_nonCR_2)+1:end,:)=ifr_list_1;    
%     end
%     h=heatmap(ifr_list_final,'GridVisible','off','Colormap',parula);
% %     range_mean=mean(mean(ifr_list_final,1));
% %     ht_range_low=floor(range_mean*0.9);
% %     ht_range_high=ceil(range_mean*1.5);
%     h.ColorLimits = [ht_range_low ht_range_high];

%     subplot('Position',pos_bar_2)
% 
%     rectangle('Position',[0,0,5,length(plot_trials_nonCR)],'FaceColor',bar_color_1,'EdgeColor','none');
%     hold on
%     if ~isempty(all_info_2)
%        rectangle('Position',[0,length(plot_trials_nonCR),5,length(plot_trials_nonCR_2)],'FaceColor',bar_color_3,'EdgeColor','none');
%        hold on     
%        axis([0 5 0 length(plot_trials_nonCR)+length(plot_trials_nonCR_2)]);
%        hold on
%        axis off 
%     else
%        axis([0 5 0 length(plot_trials_nonCR)]);
%        hold on
%        axis off    
%     end
    
%     subplot('Position',pos_psth_1)  
%     plot(file(cell_ID).(align_info).psth_ex(:,1),smooth(file(cell_ID).(align_info).psth_ex(:,2),25),'Color',bar_color_1,'LineWidth',2.0)
%     hold on
%     if isempty(all_info_2)    
%        ymin_CR=floor(min(file(cell_ID).(align_info).psth_ex(51:1550,2))*0.9);   
%        ymax_CR=ceil(max(file(cell_ID).(align_info).psth_ex(51:1550,2))*1.05); 
%        ymin_nonCR=floor(min(file(cell_ID).(non_info).psth(51:1550,2))*0.9);   
%        ymax_nonCR=ceil(max(file(cell_ID).(non_info).psth(51:1550,2))*1.05); 
%        ymax=max([ymax_CR ymax_nonCR]);
%        ymin=min([ymin_CR ymin_nonCR]);
%        ylim([ymin ymax]); 
%        line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%        line([250 250],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%        line([500 500],[0,ymax],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
%     else
%        plot(file(cell_ID).(align_info_2).psth_ex(:,1),smooth(file(cell_ID).(align_info_2).psth_ex(:,2),25),'Color',bar_color_3,'LineWidth',2.0)
%        hold on      
%        ymin_CR=floor(min(min(file(cell_ID).(align_info).psth_ex(51:1550,2)),min(file(cell_ID).(align_info_2).psth_ex(51:1550,2)))*0.9);   
%        ymax_CR=ceil(max(max(file(cell_ID).(align_info).psth_ex(51:1550,2)),max(file(cell_ID).(align_info_2).psth_ex(51:1550,2)))*1.05); 
%        ymin_nonCR=floor(min(min(file(cell_ID).(non_info).psth(51:1550,2)),min(file(cell_ID).(non_info_2).psth(51:1550,2)))*0.9);   
%        ymax_nonCR=ceil(max(max(file(cell_ID).(non_info).psth(51:1550,2)),max(file(cell_ID).(non_info_2).psth(51:1550,2)))*1.05); 
%        if abs(ymin_CR-ymin_nonCR)<20 && abs(ymax_CR-ymax_nonCR)<20
%           ymax_CR=max([ymax_CR ymax_nonCR]);
%           ymin_CR=min([ymin_CR ymin_nonCR]);       
%        end
%        line([0 0],[0,ymax_CR],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%        line([250 250],[0,ymax_CR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
%        line([500 500],[0,ymax_CR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
%        if ymin_CR==ymax_CR
%           ylim([ymin_CR ymax_CR+1]); 
%        else
%           ylim([ymin_CR ymax_CR]);  
%        end
%     end
%     hold on
%     xlim([-500 1000]);
%     xticks(-500:250:1000);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     title('CR trials');
%     
%     subplot('Position',pos_psth_2)  
%     plot(file(cell_ID).(non_info).psth(:,1),smooth(file(cell_ID).(non_info).psth(:,2),25),'Color',bar_color_1,'LineWidth',2.0)
%     hold on
%     if isempty(all_info_2)    
%        line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%        line([250 250],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%        line([500 500],[0,ymax],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
%        ylim([ymin ymax]); 
%     else
%        plot(file(cell_ID).(non_info_2).psth(:,1),smooth(file(cell_ID).(non_info_2).psth(:,2),25),'Color',bar_color_3,'LineWidth',2.0)
%        hold on   
%        ymin_CR=floor(min(min(file(cell_ID).(align_info).psth_ex(51:1550,2)),min(file(cell_ID).(align_info_2).psth_ex(51:1550,2)))*0.9);   
%        ymax_CR=ceil(max(max(file(cell_ID).(align_info).psth_ex(51:1550,2)),max(file(cell_ID).(align_info_2).psth_ex(51:1550,2)))*1.05); 
%        ymin_nonCR=floor(min(min(file(cell_ID).(non_info).psth(51:1550,2)),min(file(cell_ID).(non_info_2).psth(51:1550,2)))*0.9);   
%        ymax_nonCR=ceil(max(max(file(cell_ID).(non_info).psth(51:1550,2)),max(file(cell_ID).(non_info_2).psth(51:1550,2)))*1.05); 
%        if abs(ymin_CR-ymin_nonCR)<20 && abs(ymax_CR-ymax_nonCR)<20
%           ymax_nonCR=max([ymax_CR ymax_nonCR]);
%           ymin_nonCR=min([ymin_CR ymin_nonCR]);       
%        end
%        line([0 0],[0,ymax_nonCR],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%        line([250 250],[0,ymax_nonCR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
%        line([500 500],[0,ymax_nonCR],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
%        if ymin_nonCR==ymax_nonCR
%           ylim([ymin_nonCR ymax_nonCR+1]); 
%        else
%           ylim([ymin_nonCR ymax_nonCR]);  
%        end
%     end
%     hold on
%     xlim([-500 1000]);
%     xticks(-500:250:1000);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)'); 
%     title('None CR trials');
%     
% 
%     subplot('Position',pos_frq)
%     if isempty(all_info_2)
%        CR_bsl_frq=mean([mod_list(i).(CR_mod_info).bsl_all]);
%        CR_CR_frq=mean([mod_list(i).(CR_mod_info).CR_epoch_all]); 
%        nonCR_bsl_frq=mean([mod_list(i).(nonCR_mod_info).bsl_all]);
%        nonCR_CR_frq=mean([mod_list(i).(nonCR_mod_info).CR_epoch_all]);  
% 
%        CR_bsl_SEM=std([mod_list(i).(CR_mod_info).bsl_all])/sqrt(size(mod_list(i).(CR_mod_info),2));
%        CR_CR_SEM=std([mod_list(i).(CR_mod_info).CR_epoch_all])/sqrt(size(mod_list(i).(CR_mod_info),2)); 
%        nonCR_bsl_SEM=std([mod_list(i).(nonCR_mod_info).bsl_all])/sqrt(size(mod_list(i).(nonCR_mod_info),2));
%        nonCR_CR_SEM=std([mod_list(i).(nonCR_mod_info).CR_epoch_all])/sqrt(size(mod_list(i).(nonCR_mod_info),2));
% 
%        bar_name=categorical({'CRtrial bsl','CRtrial CRepoch','nonCR bsl','nonCR CRepoch'}); 
%        bar_name=reordercats(bar_name,{'CRtrial bsl','CRtrial CRepoch','nonCR bsl','nonCR CRepoch'});
%        bar(bar_name,[CR_bsl_frq CR_CR_frq nonCR_bsl_frq nonCR_CR_frq]);
%        hold on 
%        er = errorbar(1:4,[CR_bsl_frq CR_CR_frq nonCR_bsl_frq nonCR_CR_frq],[CR_bsl_SEM CR_CR_SEM nonCR_bsl_SEM nonCR_CR_SEM],[CR_bsl_SEM CR_CR_SEM nonCR_bsl_SEM nonCR_CR_SEM]);    
%        er.Color = [0 0 0];                            
%        er.LineStyle = 'none'; 
%        hold on      
%        ylabel('Frequency (Hz)');
%        ymax_bar=ceil(max([CR_bsl_frq+CR_bsl_SEM CR_CR_frq+CR_CR_SEM nonCR_bsl_frq+nonCR_bsl_SEM nonCR_CR_frq+nonCR_CR_SEM]));
%        ylim([0 ymax_bar]);            
%     else
%        bsl_frq_1=mean([mod_list(i).(CR_mod_info).bsl_all]);
%        CR_frq_1=mean([mod_list(i).(CR_mod_info).CR_epoch_all]); 
%        bsl_frq_2=mean([mod_list(i).(CR_mod_info_2).bsl_all]);
%        CR_frq_2=mean([mod_list(i).(CR_mod_info_2).CR_epoch_all]);  
% 
%        bsl_SEM_1=std([mod_list(i).(CR_mod_info).bsl_all])/sqrt(size(mod_list(i).(CR_mod_info),2));
%        CR_SEM_1=std([mod_list(i).(CR_mod_info).CR_epoch_all])/sqrt(size(mod_list(i).(CR_mod_info),2)); 
%        bsl_SEM_2=std([mod_list(i).(CR_mod_info_2).bsl_all])/sqrt(size(mod_list(i).(CR_mod_info_2),2));
%        CR_SEM_2=std([mod_list(i).(CR_mod_info_2).CR_epoch_all])/sqrt(size(mod_list(i).(CR_mod_info_2),2));
% 
%        bar_name=categorical(bar_order); 
%        bar_name=reordercats(bar_name,bar_order);
%        bar(bar_name,[bsl_frq_1 bsl_frq_2 CR_frq_1 CR_frq_2]);
%        hold on 
%        er = errorbar(1:4,[bsl_frq_1 bsl_frq_2 CR_frq_1 CR_frq_2],[bsl_SEM_1 bsl_SEM_2 CR_SEM_1 CR_SEM_2],[bsl_SEM_1 bsl_SEM_2 CR_SEM_1 CR_SEM_2]);    
%        er.Color = [0 0 0];                            
%        er.LineStyle = 'none'; 
%        hold on      
%        ylabel('Frequency (Hz)');
%        ymax_bar=ceil(max([bsl_frq_1+bsl_SEM_1 CR_frq_1+CR_SEM_1 bsl_frq_2+bsl_SEM_2 CR_frq_2+CR_SEM_2]));
%        ylim([0 ymax_bar]);                  
%     end
    
%     saveas(gcf,[figure_name ' Cell ' num2str(i) '.tiff']);  
%     close all
end


function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end
