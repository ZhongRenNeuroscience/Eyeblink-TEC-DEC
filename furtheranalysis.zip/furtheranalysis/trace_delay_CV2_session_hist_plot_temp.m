file_CV2=trace_CV2_cal;
t_post=500;
cd 'D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Trace-trained-mice\DCN_mat_output\Qualification\CV2'
BinWidth_CV2=5;
BinWidth_mod=10;
plt_marker_fac='onset';
plt_marker_sup='onset';

CV2_hist_list=struct('cell_ID',[],'hist_info',[]);
for i=1:5
    hist_info=struct('CV2_mean_bsl',[],'CV2_mean_test',[],'CV2_hist',[],'mean_hist',[],'CV2_mean_curve',[],...
                'burst_fac',[],'burst_sup',[],'burst_spk_fac',[],'burst_spk_sup',[],'CV2_temp',[],...
                'fac_CS_hist',[],'sup_CS_hist',[],'fac_CR_hist',[],'sup_CR_hist',[]);
   
    spk_int='spk_int';
    CV2_mean_bsl=struct('trial_num',[],'CV2',[],'mean',[],'t_on',[]);
    CV2_mean_test=struct('trial_num',[],'CV2',[],'mean',[],'t_on',[]);
    CV2_hist=struct('bsl',[],'test',[]);
    mean_hist=struct('bsl',[],'test',[]);
    burst_fac=struct('trial_num',[],'CR_onset',[],'spk',[],'onset',[],'offset',[],'mid_t',[],'peak_t',[]);
    burst_sup=struct('trial_num',[],'CR_onset',[],'spk',[],'onset',[],'offset',[],'mid_t',[],'peak_t',[]);
    i_bsl=0;
    i_test=0;
    i_fac=0;
    i_sup=0;
    
    figure('units','normalized','outerposition',[0 0 1 1]);  
    
    subplot('Position',[0.525 0.7 0.2 0.25])
    [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
    file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
    clear index;
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
                  hold on
               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
                  hold on 
               end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
                  if file_CV2(i).(spk_int)(j).all_info(k).t>=0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
                     hold on
                  elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
                     hold on 
                  end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
                  if file_CV2(i).(spk_int)(j).all_info(k).t>=0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
                     hold on
                  elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
                     hold on                 
                  end
            end
        end
        plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
        plot(0,j,'g.')
        hold on
        plot(t_post,j,'r.')
        hold on       
    end
    xlim([t_post-750 t_post+250]);
    xticks(t_post-750:250:t_post+250);
    ylim([0 j+1]);
    ylabel('Trial number');
    title('CS onset align');
    
    subplot('Position',[0.75 0.7 0.2 0.25])
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
                  plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'k.')
                  hold on
               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
                  plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[0.5 0.5 0.5])
                  hold on 
               end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
               if file_CV2(i).(spk_int)(j).all_info(k).t>=0 
                  plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'m.') 
                  hold on
               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                  plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[1 0.5 1]) 
                  hold on    
               end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
               if file_CV2(i).(spk_int)(j).all_info(k).t>=0 
                  plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'c.') 
                  hold on
               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 
                  plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[0.5 1 1]) 
                  hold on
               end
            end
        end
        plot(0,j,'b*')
        plot(-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'g.')
        hold on
        plot(t_post-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'r.')
        hold on       
    end
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 j+1]);
    ylabel('Trial number');
    title('CR onset align');    
    first_on=(ceil(-file_CV2(i).(spk_int)(1).CR_onset*1000/BinWidth_mod)*BinWidth_mod+500+t_post)/BinWidth_mod+1;
    last_on=(floor((t_post-file_CV2(i).(spk_int)(end).CR_onset*1000)/BinWidth_mod)*BinWidth_mod+500+t_post)/BinWidth_mod;
    
    for j=1:size(file_CV2(i).(spk_int),2)        
        file_CV2(i).(spk_int)(j).all_info=file_CV2(i).(spk_int)(j).all_info(~cellfun(@isempty,{file_CV2(i).(spk_int)(j).all_info.type}));
        test_on=find([file_CV2(i).(spk_int)(j).all_info.t]>=0,1,'first');
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if k<test_on
               i_bsl=i_bsl+1;
               CV2_mean_bsl(i_bsl).trial_num=file_CV2(i).(spk_int)(j).trial_num;
               CV2_mean_bsl(i_bsl).CV2=abs(file_CV2(i).(spk_int)(j).all_info(k).CV2);
               CV2_mean_bsl(i_bsl).mean=file_CV2(i).(spk_int)(j).all_info(k).mean*1000;
               CV2_mean_bsl(i_bsl).t_on=file_CV2(i).(spk_int)(j).all_info(k).t*1000;
            elseif k>=test_on
               i_test=i_test+1;
               CV2_mean_test(i_test).trial_num=file_CV2(i).(spk_int)(j).trial_num;
               CV2_mean_test(i_test).CV2=abs(file_CV2(i).(spk_int)(j).all_info(k).CV2);
               CV2_mean_test(i_test).mean=file_CV2(i).(spk_int)(j).all_info(k).mean*1000;
               CV2_mean_test(i_test).t_on=file_CV2(i).(spk_int)(j).all_info(k).t*1000;
            end            
        end 
        if size(file_CV2(i).(spk_int)(j).event_fac,2)>0
            for k=1:size(file_CV2(i).(spk_int)(j).event_fac,2)
                i_fac=i_fac+1;
                burst_fac(i_fac).trial_num=file_CV2(i).(spk_int)(j).trial_num;
                burst_fac(i_fac).spk=file_CV2(i).(spk_int)(j).event_fac(k).spk;
                burst_fac(i_fac).onset=file_CV2(i).(spk_int)(j).event_fac(k).onset;
                burst_fac(i_fac).offset=file_CV2(i).(spk_int)(j).event_fac(k).offset;
                burst_fac(i_fac).mid_t=file_CV2(i).(spk_int)(j).event_fac(k).mid_t;
                burst_fac(i_fac).peak_t=file_CV2(i).(spk_int)(j).event_fac(k).peak_t;
                burst_fac(i_fac).CR_onset=file_CV2(i).(spk_int)(j).CR_onset;
            end
        end
        if size(file_CV2(i).(spk_int)(j).event_sup,2)>0
            for k=1:size(file_CV2(i).(spk_int)(j).event_sup,2)              
                i_sup=i_sup+1;
                burst_sup(i_sup).trial_num=file_CV2(i).(spk_int)(j).trial_num;
                burst_sup(i_sup).spk=file_CV2(i).(spk_int)(j).event_sup(k).spk;
                burst_sup(i_sup).onset=file_CV2(i).(spk_int)(j).event_sup(k).onset;
                burst_sup(i_sup).offset=file_CV2(i).(spk_int)(j).event_sup(k).offset;
                burst_sup(i_sup).mid_t=file_CV2(i).(spk_int)(j).event_sup(k).mid_t;
                burst_sup(i_sup).peak_t=file_CV2(i).(spk_int)(j).event_sup(k).peak_t;
                burst_sup(i_sup).CR_onset=file_CV2(i).(spk_int)(j).CR_onset;
            end    
        end
    end
    
    burst_fac_spk=struct('data',[],'data_align',[]);
    burst_sup_spk=struct('data',[],'data_align',[]);
    idx_fac=0;
    idx_sup=0;   
    for j=1:size(burst_fac,2)
        for k=1:length(burst_fac(j).spk)
            idx_fac=idx_fac+1;
            burst_fac_spk(idx_fac).data=burst_fac(j).spk(1,k);
            burst_fac_spk(idx_fac).data_align=burst_fac(j).spk(1,k)-burst_fac(j).CR_onset;
        end                
    end
    for j=1:size(burst_sup,2)
        for k=1:round((burst_sup(j).offset-burst_sup(j).onset)*1000)
            idx_sup=idx_sup+1;
            burst_sup_spk(idx_sup).data=burst_sup(j).onset*1000+k-1;
            burst_sup_spk(idx_sup).data_align=(burst_sup(j).onset-burst_sup(j).CR_onset)*1000+k-1;
        end                
    end  
    
%     for j=1:size(burst_fac_D,2)
%         for k=1:length(burst_fac_D(j).spk)
%             idx_fac=idx_fac+1;
%             burst_fac_spk_D(idx_fac).data=burst_fac_D(j).onset;
%             burst_fac_spk_D(idx_fac).data_align=burst_fac_D(j).onset-burst_fac_D(j).CR_onset;
%         end                
%     end
%     for j=1:size(burst_sup_D,2)
%         for k=1:round((burst_sup_D(j).offset-burst_sup_D(j).onset)*1000)
%             idx_sup=idx_sup+1;
%             burst_sup_spk_D(idx_sup).data=burst_sup_D(j).onset*1000;
%             burst_sup_spk_D(idx_sup).data_align=(burst_sup_D(j).onset-burst_sup_D(j).CR_onset)*1000;
%         end                
%     end 
    
    subplot('Position',[0.525 0.4 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h1.FaceColor = [0 0.4 1];
    hold on
    h2=histogram([burst_fac_spk.data]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,t_post],'Normalization','probability');
    h2.FaceColor = [1 0 1];
    hold on
    ymax=ceil(max([h1.BinCounts]/length(h1.Data))*20+0.1)/20;
    xmean_fac=mean(h2.BinCounts(1:500/BinWidth_mod))/length(h2.Data);
    xstd_fac=std(h2.BinCounts(1:500/BinWidth_mod)/length(h2.Data));
    xpeak_fac_1=max(h2.BinCounts(500/BinWidth_mod+1:length(h2.BinCounts)))/length(h2.Data);    
    line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0]);
    line([t_post t_post],[0,ymax],'LineStyle','--','Color',[1 0 0]);
    line([t_post-750,t_post+250],[xmean_fac xmean_fac],'LineStyle','--','Color',[0.5 0.5 0.5]);
    xlim([t_post-750 t_post+250]);
    xticks(t_post-750:250:t_post+250);
    ylabel('Probability');
    title('Facilitation spike distribution');
    fac_CS_hist=zeros(3,size(h2.BinCounts,2));
    fac_CS_hist(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    fac_CS_hist(2,:)=h2.BinCounts;
    fac_CS_hist(3,:)=h2.BinCounts/size(h2.Data,2);
%     title(['Facilitation ' plt_marker_fac ' distribution']);
    
    subplot('Position',[0.525 0.1 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h1.FaceColor = [0 0.4 1];
    hold on
    h2=histogram([burst_sup_spk.data],'BinWidth',BinWidth_mod,'BinLimits',[-500,t_post],'Normalization','probability');
    h2.FaceColor = [0 1 1];
    hold on
    xmean_sup=mean(h2.BinCounts(1:500/BinWidth_mod))/length(h2.Data);
    xstd_sup=std(h2.BinCounts(1:500/BinWidth_mod)/length(h2.Data));
    xpeak_sup_1=max(h2.BinCounts(500/BinWidth_mod+1:length(h2.BinCounts)))/length(h2.Data);
    line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0])
    line([t_post t_post],[0,ymax],'LineStyle','--','Color',[1 0 0]); 
    line([t_post-750,t_post+250],[xmean_sup xmean_sup],'LineStyle','--','Color',[0.5 0.5 0.5]);
    xlim([t_post-750 t_post+250]);
    xticks(t_post-750:250:t_post+250);
    xlabel('Time (ms)');
    ylabel('Probability');
    title('Suppression epoch distribution');
    sup_CS_hist=zeros(3,size(h2.BinCounts,2));
    sup_CS_hist(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    sup_CS_hist(2,:)=h2.BinCounts;
    sup_CS_hist(3,:)=h2.BinCounts/size(h2.Data,2);
%     title(['Suppression ' plt_marker_sup ' distribution']);
    
    subplot('Position',[0.75 0.4 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*-1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram([burst_fac_spk.data_align]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-500-t_post,500],'Normalization','probability');
    h2.FaceColor = [1 0 1];
    hold on
    fac_CR_hist=zeros(4,size(h2.BinCounts,2));
    fac_CR_hist(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    fac_CR_hist(2,:)=h2.BinCounts;
    fac_CR_hist(3,:)=h2.BinCounts/size(h2.Data,2);  
    xpeak_fac_2=max(h2.BinCounts(first_on:last_on))/length(h2.Data); 
    if xpeak_fac_2>xpeak_fac_1 && xpeak_fac_2>xmean_fac+6*xstd_fac
       [~,loc]=min(abs(h2.BinCounts(first_on:last_on)-xpeak_fac_2*length(h2.Data)));
       text(h2.BinEdges(loc+first_on-1),h2.BinCounts(loc+first_on-1)/length(h2.Data)*1.2,'*','FontSize',25,'Color','r','HorizontalAlignment','center'); 
       fac_CR_hist(4,:)=1;
       fac_CR_hist(4,loc+first_on-1)=2;
    end    
    xlim([-500 500]);
    xticks(-500:250:500);
    line([h2.BinEdges(first_on) h2.BinEdges(first_on)],[0,ymax],'LineStyle','--','Color',[0 0 1]); 
    line([h2.BinEdges(last_on+1) h2.BinEdges(last_on+1)],[0,ymax],'LineStyle','--','Color',[0 0 1]); 
    line([-500,500],[xmean_fac xmean_fac],'LineStyle','--','Color',[0.5 0.5 0.5]);
    title('Facilitation spike distribution'); 
%     title(['Facilitation ' plt_marker_fac ' distribution']);
    
    subplot('Position',[0.75 0.1 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*-1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram([burst_sup_spk.data_align],'BinWidth',BinWidth_mod,'BinLimits',[-500-t_post,500],'Normalization','probability');
    h2.FaceColor = [0 1 1];
    hold on
    sup_CR_hist=zeros(4,size(h2.BinCounts,2));
    sup_CR_hist(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    sup_CR_hist(2,:)=h2.BinCounts;
    sup_CR_hist(3,:)=h2.BinCounts/size(h2.Data,2);      
    xpeak_sup_2=max(h2.BinCounts(first_on:last_on))/length(h2.Data); 
    if xpeak_sup_2>xpeak_sup_1 && xpeak_sup_2>xmean_sup+6*xstd_sup
       [~,loc]=min(abs(h2.BinCounts(first_on:last_on)-xpeak_sup_2*length(h2.Data)));
       text(h2.BinEdges(loc+first_on-1),h2.BinCounts(loc+first_on-1)/length(h2.Data)*1.2,'*','FontSize',25,'Color','r','HorizontalAlignment','center');
       sup_CR_hist(4,:)=1;
       sup_CR_hist(4,loc+first_on-1)=2;       
    end  
    xlim([-500 500]);
    xticks(-500:250:500);
    line([h2.BinEdges(first_on) h2.BinEdges(first_on)],[0,ymax],'LineStyle','--','Color',[0 0 1]); 
    line([h2.BinEdges(last_on+1) h2.BinEdges(last_on+1)],[0,ymax],'LineStyle','--','Color',[0 0 1]); 
    line([-500,500],[xmean_sup xmean_sup],'LineStyle','--','Color',[0.5 0.5 0.5]);
    xlabel('Time (ms)');
    title('Suppression epoch distribution');     
%     title(['Suppression ' plt_marker_sup ' distribution']);
    
    subplot('Position',[0.05 0.57 0.2 0.38])
    for m=1:size(CV2_mean_bsl,2)
        plot(CV2_mean_bsl(m).mean,CV2_mean_bsl(m).CV2,'k.')
        hold on
    end
    for m=1:size(CV2_mean_test,2)
        plot(CV2_mean_test(m).mean,CV2_mean_test(m).CV2,'r.')
        hold on
    end   
    xlim([0 100]);
    ylim([0 2]);
    text(75,1.8,'Baseline','Color',[0 0 0],'FontSize',15);
    text(72,1.85,'.','Color',[0 0 0],'FontSize',30);
    text(75,1.7,'CR period','Color',[1 0 0],'FontSize',15);
    text(72,1.75,'.','Color',[1 0 0],'FontSize',30);
    xticks(0:20:100);
    yticks(0:0.5:2);
    ylabel('|CV2|');
    title(['Cell-' num2str(file_CV2(i).cell_ID) '-fac-' num2str(file_CV2(i).mod_info.fac) '-sup-' num2str(file_CV2(i).mod_info.sup)])    
    
    
    subplot('Position',[0.05 0.1 0.42 0.2])
    for m=1:size(CV2_mean_bsl,2)      
        plot(CV2_mean_bsl(m).t_on,CV2_mean_bsl(m).CV2,'.','Color',[0.7 0.7 0.7])
        hold on              
    end
    for m=1:size(CV2_mean_test,2)
        plot(CV2_mean_test(m).t_on,CV2_mean_test(m).CV2,'.','Color',[1 0.7 0.7])
        hold on          
    end
    [~,index] = sortrows([CV2_mean_bsl.t_on].'); 
    CV2_mean_bsl = CV2_mean_bsl(index);
    clear index
    [~,index] = sortrows([CV2_mean_test.t_on].'); 
    CV2_mean_test = CV2_mean_test(index);    
    clear index    
    CV2_temp=struct('mean',[],'SE',[],'p_value',[]);
    i_temp=0;
    temp_on=1;
    for m=1:20
        i_temp=i_temp+1;
        if CV2_mean_bsl(temp_on).t_on<-500+25*m
           temp_off=find([CV2_mean_bsl.t_on]<-500+25*m,1,'last');
           CV2_temp(i_temp).mean=mean([CV2_mean_bsl(temp_on:temp_off).CV2]);
           CV2_temp(i_temp).SE=std([CV2_mean_bsl(temp_on:temp_off).CV2])/sqrt(length([CV2_mean_bsl(temp_on:temp_off).CV2])); 
           temp_on=temp_off+1;
        else
           CV2_temp(i_temp).mean=0;
           CV2_temp(i_temp).SE=0;
        end
        CV2_temp(i_temp).p_value=[];
    end
    temp_on=1;
    for m=1:t_post/25
        i_temp=i_temp+1;
        if temp_on<=size(CV2_mean_test,2) && CV2_mean_test(temp_on).t_on<25*m
           temp_off=find([CV2_mean_test.t_on]<25*m,1,'last');
           CV2_temp(i_temp).mean=mean([CV2_mean_test(temp_on:temp_off).CV2]);
           CV2_temp(i_temp).SE=std([CV2_mean_test(temp_on:temp_off).CV2])/sqrt(length([CV2_mean_test(temp_on:temp_off).CV2])); 
           p_temp=ranksum([CV2_mean_bsl.CV2],[CV2_mean_test(temp_on:temp_off).CV2]);
           CV2_temp(i_temp).p_value=p_temp;
           if p_temp<0.05
              if CV2_temp(i_temp).mean>=mean([CV2_mean_bsl.CV2])
                 plot(25*m-12.5,(CV2_temp(i_temp).mean+CV2_temp(i_temp).SE)*1.2,'r*','MarkerSize',10,'LineWidth',1.5)
                 hold on
              elseif CV2_temp(i_temp).mean<mean([CV2_mean_bsl.CV2])
                 plot(25*m-12.5,(CV2_temp(i_temp).mean-CV2_temp(i_temp).SE)*0.8,'b*','MarkerSize',10,'LineWidth',1.5)
                 hold on
              end
           end
           temp_on=temp_off+1;
        else
           CV2_temp(i_temp).mean=0;
           CV2_temp(i_temp).SE=0;
        end        
    end
    plot(-487.5:25:t_post-12.5,[CV2_temp.mean],'k-')
    hold on
    errorbar(-487.5:25:t_post-12.5,[CV2_temp.mean],[CV2_temp.SE],'k')      
    xlim([-500 t_post]);
    ylim([0 2]);
    xticks(-500:50:t_post);
    yticks(0:0.5:2);
    xlabel('Time (ms)');
    ylabel('|CV2|');
  
    
    subplot('Position',[0.05 0.35 0.2 0.17])
    h1=histogram([CV2_mean_bsl.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([CV2_mean_test.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Mean of ISI pair (ms)');
    ylabel('Probability');  
    mean_hist_bsl=zeros(3,size(h1.BinCounts,2));
    mean_hist_bsl(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    mean_hist_bsl(2,:)=h1.BinCounts;
    mean_hist_bsl(3,:)=h1.BinCounts/size(h1.Data,2);
    mean_hist_test=zeros(3,size(h2.BinCounts,2));
    mean_hist_test(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    mean_hist_test(2,:)=h2.BinCounts;
    mean_hist_test(3,:)=h2.BinCounts/size(h2.Data,2);    
    mean_hist.bsl=mean_hist_bsl;
    mean_hist.test=mean_hist_test;
    
    subplot('Position',[0.42 0.57 0.05 0.17])
    plot(1,mean([CV2_mean_bsl.mean]),'ks','MarkerSize',5)
    hold on
    plot(2,mean([CV2_mean_test.mean]),'rs','MarkerSize',5)
    hold on
    se_bsl=std([CV2_mean_bsl.mean])/sqrt(length([CV2_mean_bsl.mean]));
    se_test=std([CV2_mean_test.mean])/sqrt(length([CV2_mean_test.mean]));
    errorbar(1,mean([CV2_mean_bsl.mean]),se_bsl,'k','CapSize',15)
    hold on
    errorbar(2,mean([CV2_mean_test.mean]),se_test,'r','CapSize',15)
    hold on
    xlim([0 3]);
    xticks([1 2]);
    xticklabels({'Bsl','CR'});
    ylabel('Mean of ISI pair (ms)');    
    p = ranksum([CV2_mean_bsl.mean],[CV2_mean_test.mean]);
    if p<0.05
       text(2.6,mean([CV2_mean_test.mean]),'*','FontSize',20,'Color','r','HorizontalAlignment','center');
    else
       text(2.6,mean([CV2_mean_test.mean]),'ns.','FontSize',15,'HorizontalAlignment','center'); 
    end
    
    subplot('Position',[0.28 0.57 0.11 0.38])
    h1=histogram([CV2_mean_bsl.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([CV2_mean_test.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Probability');
    CV2_hist_bsl=zeros(3,size(h1.BinCounts,2));
    CV2_hist_bsl(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    CV2_hist_bsl(2,:)=h1.BinCounts;
    CV2_hist_bsl(3,:)=h1.BinCounts/size(h1.Data,2);
    CV2_hist_test=zeros(3,size(h2.BinCounts,2));
    CV2_hist_test(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    CV2_hist_test(2,:)=h2.BinCounts;
    CV2_hist_test(3,:)=h2.BinCounts/size(h2.Data,2);    
    CV2_hist.bsl=CV2_hist_bsl;
    CV2_hist.test=CV2_hist_test;
    
    subplot('Position',[0.42 0.78 0.05 0.17])
    plot(1,mean([CV2_mean_bsl.CV2]),'ks','MarkerSize',5)
    hold on
    plot(2,mean([CV2_mean_test.CV2]),'rs','MarkerSize',5)
    hold on
    se_bsl=std([CV2_mean_bsl.CV2])/sqrt(length([CV2_mean_bsl.CV2]));
    se_test=std([CV2_mean_test.CV2])/sqrt(length([CV2_mean_test.CV2]));
    errorbar(1,mean([CV2_mean_bsl.CV2]),se_bsl,'k','CapSize',15)
    hold on
    errorbar(2,mean([CV2_mean_test.CV2]),se_test,'r','CapSize',15)
    hold on
    xlim([0 3]);
    xticks([1 2]);
    xticklabels({'Bsl','CR'});
    ylabel('|CV2|');    
    p = ranksum([CV2_mean_bsl.CV2],[CV2_mean_test.CV2]);
    if p<0.05
       text(2.6,mean([CV2_mean_test.CV2]),'*','FontSize',20,'Color','r','HorizontalAlignment','center');
    else
       text(2.6,mean([CV2_mean_test.CV2]),'ns.','FontSize',15,'HorizontalAlignment','center'); 
    end
    
    subplot('Position',[0.28 0.35 0.19 0.17])
    curve_CV2=struct('mean_lim',[],'bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[]);
    [~,index] = sortrows([CV2_mean_bsl.mean].'); 
    CV2_mean_bsl = CV2_mean_bsl(index);
    clear index
    [~,index] = sortrows([CV2_mean_test.mean].'); 
    CV2_mean_test = CV2_mean_test(index);    
    clear index
    curve_idx=zeros(100/BinWidth_CV2+1,3);
    for n=1:100/BinWidth_CV2
        curve_CV2(n).mean_lim=n*BinWidth_CV2;
        curve_idx(n+1,1)=n*BinWidth_CV2;
        if curve_CV2(n).mean_lim-BinWidth_CV2>max([CV2_mean_bsl.mean])
           curve_idx(n+1,2)=curve_idx(n,2);
        elseif curve_CV2(n).mean_lim<min([CV2_mean_bsl.mean])
           curve_idx(n+1,2)=curve_idx(n,2);
        else
           curve_idx(n+1,2)=find([CV2_mean_bsl.mean]<=curve_CV2(n).mean_lim,1,'last');
        end
        if curve_idx(n+1,2)~=curve_idx(n,2)
           curve_CV2(n).bsl_mean=mean([CV2_mean_bsl(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2]);
           curve_CV2(n).bsl_SE=std([CV2_mean_bsl(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2])/sqrt(length([CV2_mean_bsl(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2])); 
        else
           curve_CV2(n).bsl_mean=0;
           curve_CV2(n).bsl_SE=0;
        end    
        if curve_CV2(n).mean_lim-BinWidth_CV2>max([CV2_mean_test.mean])
           curve_idx(n+1,3)=curve_idx(n,3);
        elseif curve_CV2(n).mean_lim<min([CV2_mean_test.mean])
           curve_idx(n+1,3)=curve_idx(n,3);
        else
           curve_idx(n+1,3)=find([CV2_mean_test.mean]<=curve_CV2(n).mean_lim,1,'last');
        end
        if curve_idx(n+1,3)~=curve_idx(n,3)
           curve_CV2(n).test_mean=mean([CV2_mean_test(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2]);
           curve_CV2(n).test_SE=std([CV2_mean_test(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2])/sqrt(length([CV2_mean_test(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2])); 
        else
           curve_CV2(n).test_mean=0;
           curve_CV2(n).test_SE=0;
        end 
    end
    
    plot([curve_CV2.mean_lim],[curve_CV2.bsl_mean],'k-')
    hold on
    plot([curve_CV2.mean_lim],[curve_CV2.test_mean],'r-')
    hold on
    errorbar([curve_CV2.mean_lim],[curve_CV2.bsl_mean],[curve_CV2.bsl_SE],'k')
    hold on
    errorbar([curve_CV2.mean_lim],[curve_CV2.test_mean],[curve_CV2.test_SE],'r')
    hold on
    xlim([0 100]);
    ylim([0 2]);    
    xticks(0:20:100);
    yticks(0:0.5:2);    
    xlabel('Mean of ISI pair (ms)');
    ylabel('|CV2|'); 
    
    saveas(gcf,[['Cell-' num2str(file_CV2(i).cell_ID) '-fac-' num2str(file_CV2(i).mod_info.fac) '-sup-' num2str(file_CV2(i).mod_info.sup)] '.jpg']);  
    close all
    hist_info.CV2_mean_bsl=CV2_mean_bsl;
    hist_info.CV2_mean_test=CV2_mean_test;
    hist_info.CV2_hist=CV2_hist;
    hist_info.mean_hist=mean_hist;
    hist_info.CV2_mean_curve=curve_CV2;
    hist_info.burst_fac=burst_fac;
    hist_info.burst_sup=burst_sup;
    hist_info.burst_spk_fac=burst_fac_spk;
    hist_info.burst_spk_sup=burst_sup_spk;
    hist_info.CV2_temp=CV2_temp;
    hist_info.fac_CS_hist=fac_CS_hist;
    hist_info.sup_CS_hist=sup_CS_hist;
    hist_info.fac_CR_hist=fac_CR_hist;
    hist_info.sup_CR_hist=sup_CR_hist;    
    CV2_hist_list(i).cell_ID=file_CV2(i).cell_ID;
    CV2_hist_list(i).hist_info=hist_info;
    
end