PC_num=2;

figure;
subplot(2,1,1)
plot(sps_trial(PC_num).early_blk(451:1050,1),sps_trial(PC_num).early_blk(451:1050,2)*100,'c-')
hold on
plot(sps_trial(PC_num).late_blk(451:1050,1),sps_trial(PC_num).late_blk(451:1050,2)*100,'m-')
hold on
xticks([0 250 500]);

subplot(2,1,2)
stairs((-100:10:490),sps_trial(PC_num).t_smth(:,1),'c-')
hold on
stairs((-100:10:490),sps_trial(PC_num).t_smth(:,2),'m-')
hold on 
xticks([0 250 500]);