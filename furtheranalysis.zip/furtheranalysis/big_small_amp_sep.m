type='fac';
fac_form=zeros(size(list_mod.fac,2)-2,5);
fac_trial=struct('fac_num',[],'cell_ID',[],'amp_info',[],'big_info',[],'big_psth',[],'big_blk',[],'sml_info',[],'sml_psth',[],'sml_blk',[]);
k=0;
% first loop for each cell
for i=1:size(list_mod.fac,2)
    if i==33 || i==39
        k=k+1;
        continue    
    end
    j=i-k;
    fac_trial(j).fac_num=i;
    fac_trial(j).cell_ID=list_mod.(type)(i).cell_ID;
% second loop for each trial 
    fac_trial(j).amp_info=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),1);
    for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
        fac_trial(j).amp_info(m,1)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info.CR_amp*100;
    end
    [rank,idx]=sort(fac_trial(j).amp_info);
%     if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 30
%        early=0;
%        late=0;
    if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 40
       big=idx(find(idx,20,'last'),1);
       sml=idx(find(idx,20,'first'),1);
    else
        sz_mod=mod(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
        sz_group=(size(list_mod.(type)(i).all_info.ttt.CR_trial,2)-sz_mod)/2;
        big=idx(find(idx,sz_group+sz_mod,'last'),1);
        sml=idx(find(idx,sz_group,'first'),1);
    end
    fac_trial(j).big_info=struct('trial_num',[],'amp',[],'ifr',[],'blk',[]);
    big_ifr_form=zeros(32001,size(big,1));
    big_blk_form=zeros(31000,size(big,1));
    fac_trial(j).sml_info=struct('trial_num',[],'amp',[],'ifr',[],'blk',[]);
    sml_ifr_form=zeros(32001,size(sml,1));
    sml_blk_form=zeros(31000,size(sml,1));
    for n=1:size(big,1)
        fac_trial(j).big_info(n).trial_num=big(n,1);
        fac_trial(j).big_info(n).amp=list_mod.(type)(i).all_info.ttt.CR_trial(big(n,1)).blk_info.CR_amp*100;
        fac_trial(j).big_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(big(n,1)).ifr_org_Gau(:,2);
        fac_trial(j).big_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(big(n,1)).blk_trace(:,4);
        big_ifr_form(:,n)=fac_trial(j).big_info(n).ifr;
        big_blk_form(:,n)=fac_trial(j).big_info(n).blk;
    end
    for n=1:size(sml,1)
        fac_trial(j).sml_info(n).trial_num=sml(n,1);
        fac_trial(j).sml_info(n).amp=list_mod.(type)(i).all_info.ttt.CR_trial(sml(n,1)).blk_info.CR_amp*100;
        fac_trial(j).sml_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(sml(n,1)).ifr_org_Gau(:,2);
        fac_trial(j).sml_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(sml(n,1)).blk_trace(:,4);
        sml_ifr_form(:,n)=fac_trial(j).sml_info(n).ifr;
        sml_blk_form(:,n)=fac_trial(j).sml_info(n).blk;
    end
    fac_form(j,1)=i;
    fac_form(j,2)=mean([fac_trial(j).big_info.amp]);
    fac_form(j,3)=mean([fac_trial(j).sml_info.amp]);
    big_psth=zeros(32001,3);
    sml_psth=zeros(32001,3);
    big_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    big_psth(:,2)=mean(big_ifr_form,2)*1000;
    big_bsl=mean(big_psth(big_psth(:,1) < 0 & big_psth(:,1) >= -500,2));
    big_sd=std(big_psth(big_psth(:,1) < 0 & big_psth(:,1) >= -500,2));
    big_shrld=big_bsl+3*big_sd;
    big_psth(:,3)=big_psth(:,2)/big_bsl*100;
    fac_form(j,4)=max(big_psth(11001:21001,3));
    
    sml_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    sml_psth(:,2)=mean(sml_ifr_form,2)*1000;
    sml_bsl=mean(sml_psth(sml_psth(:,1)<0 & sml_psth(:,1) >= -500,2));
    sml_sd=std(sml_psth(sml_psth(:,1)<0 & sml_psth(:,1) >= -500,2));
    sml_shrld=sml_bsl+3*sml_sd;
    sml_psth(:,3)=sml_psth(:,2)/sml_bsl*100;
    fac_form(j,5)=max(sml_psth(11001:21001,3));

    
    big_blk=zeros(31000,2);
    sml_blk=zeros(31000,2);
    big_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    big_blk(:,2)=mean(big_blk_form,2);
    fac_trial(j).big_blk=big_blk;
    sml_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    sml_blk(:,2)=mean(sml_blk_form,2);
    fac_trial(j).sml_blk=sml_blk;
    
    fac_trial(j).big_psth=big_psth;
    fac_trial(j).sml_psth=sml_psth;
    
    clear idx rank sz_group sz_mod big_ifr_form big_psth sml_ifr_form sml_psth 
end
clear i j k m n type

type='sup';
sup_form=zeros(size(list_mod.sup,2),5);
sup_trial=struct('sup_num',[],'cell_ID',[],'amp_info',[],'big_info',[],'big_psth',[],'big_blk',[],'sml_info',[],'sml_psth',[],'sml_blk',[]);
k=0;
% first loop for each cell
for i=1:size(list_mod.sup,2)
    j=i-k;
    sup_trial(j).sup_num=i;
    sup_trial(j).cell_ID=list_mod.(type)(i).cell_ID;
% second loop for each trial 
    sup_trial(j).amp_info=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),1);
    for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
        sup_trial(j).amp_info(m,1)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info.CR_amp*100;
    end
    [rank,idx]=sort(sup_trial(j).amp_info);
%     if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 30
%        early=0;
%        late=0;
    if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 40
       big=idx(find(idx,20,'last'),1);
       sml=idx(find(idx,20,'first'),1);
    else
        sz_mod=mod(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
        sz_group=(size(list_mod.(type)(i).all_info.ttt.CR_trial,2)-sz_mod)/2;
        big=idx(find(idx,sz_group+sz_mod,'last'),1);
        sml=idx(find(idx,sz_group,'first'),1);
    end
    sup_trial(j).big_info=struct('trial_num',[],'amp',[],'ifr',[],'blk',[]);
    big_ifr_form=zeros(32001,size(big,1));
    big_blk_form=zeros(31000,size(big,1));
    sup_trial(j).sml_info=struct('trial_num',[],'amp',[],'ifr',[],'blk',[]);
    sml_ifr_form=zeros(32001,size(sml,1));
    sml_blk_form=zeros(31000,size(sml,1));
    for n=1:size(big,1)
        sup_trial(j).big_info(n).trial_num=big(n,1);
        sup_trial(j).big_info(n).amp=list_mod.(type)(i).all_info.ttt.CR_trial(big(n,1)).blk_info.CR_amp*100;
        sup_trial(j).big_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(big(n,1)).ifr_org_Gau(:,2);
        sup_trial(j).big_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(big(n,1)).blk_trace(:,4);
        big_ifr_form(:,n)=sup_trial(j).big_info(n).ifr;
        big_blk_form(:,n)=sup_trial(j).big_info(n).blk;
    end
    for n=1:size(sml,1)
        sup_trial(j).sml_info(n).trial_num=sml(n,1);
        sup_trial(j).sml_info(n).amp=list_mod.(type)(i).all_info.ttt.CR_trial(sml(n,1)).blk_info.CR_amp*100;
        sup_trial(j).sml_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(sml(n,1)).ifr_org_Gau(:,2);
        sup_trial(j).sml_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(sml(n,1)).blk_trace(:,4);
        sml_ifr_form(:,n)=sup_trial(j).sml_info(n).ifr;
        sml_blk_form(:,n)=sup_trial(j).sml_info(n).blk;
    end
    sup_form(j,1)=i;
    sup_form(j,2)=mean([sup_trial(j).big_info.amp]);
    sup_form(j,3)=mean([sup_trial(j).sml_info.amp]);
    big_psth=zeros(32001,3);
    sml_psth=zeros(32001,3);
    big_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    big_psth(:,2)=mean(big_ifr_form,2)*1000;
    big_bsl=mean(big_psth(big_psth(:,1) < 0 & big_psth(:,1) >= -500,2));
    big_sd=std(big_psth(big_psth(:,1) < 0 & big_psth(:,1) >= -500,2));
    big_shrld=big_bsl-3*big_sd;
    big_psth(:,3)=big_psth(:,2)/big_bsl*100;
    sup_form(j,4)=min(big_psth(11001:21001,3));
    
    sml_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    sml_psth(:,2)=mean(sml_ifr_form,2)*1000;
    sml_bsl=mean(sml_psth(sml_psth(:,1)<0 & sml_psth(:,1) >= -500,2));
    sml_sd=std(sml_psth(sml_psth(:,1)<0 & sml_psth(:,1) >= -500,2));
    sml_shrld=sml_bsl-3*sml_sd;
    sml_psth(:,3)=sml_psth(:,2)/sml_bsl*100;
    sup_form(j,5)=min(sml_psth(11001:21001,3));

    
    big_blk=zeros(31000,2);
    sml_blk=zeros(31000,2);
    big_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    big_blk(:,2)=mean(big_blk_form,2);
    sup_trial(j).big_blk=big_blk;
    sml_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    sml_blk(:,2)=mean(sml_blk_form,2);
    sup_trial(j).sml_blk=sml_blk;
    
    sup_trial(j).big_psth=big_psth;
    sup_trial(j).sml_psth=sml_psth;
    
    clear big sml idx rank sz_group sz_mod big_ifr_form big_psth sml_ifr_form sml_psth 
end
clear i j k m n type big_bsl big_sd big_shrld sml_bsl sml_sd sml_shrld

figure;
plot(fac_form(:,4)-fac_form(:,5),fac_form(:,2)-fac_form(:,3),'r.')
hold on
plot(sup_form(:,4)-sup_form(:,5),sup_form(:,2)-sup_form(:,3),'b.')
hold on
xlabel('Mod relative peak high-low (%)');
ylabel('CR relative amp high-low (%)');
xlim([-100 350]);
ylim([0 60]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--');
line([0 0],[0,60],'Color',[0 0 0],'LineStyle','--');
legend({'Facilitation','Suppression'},'Location','northeast');
% line([-300,500],[0 0],'Color',[0 0 0],'LineStyle','--');
