file=trace_T_loco_fix;
mod_file=mod_list_align_loco;
t_post=500;
all_info='all_info';


loco_com=struct('cell_ID',[],'session_ID',[],'CR_fac',[],'CR_sup',[]);
% loco_com=struct('cell_ID',[],'session_ID',[],'CR_fac',[],'CR_sup',[],'mod_fac_amp',[],'mod_sup_amp',[],'CR_onset',[],'CR_amp',[],'bsl_frq',[],'test_frq',[],...
%     'CR_onset_H',[],'CR_onset_L',[],'p_CR_onset',[],'CR_amp_H',[],'CR_amp_L',[],'p_CR_amp',[],'bsl_frq_H',[],'bsl_frq_L',[],'p_bsl_frq',[],'test_frq_H',[],'test_frq_L',[],'p_test_frq',[]);
for i=1:size(file,2)
  CL_locs=struct('nr',[],'t',[],'velo_info',[],'avg_velo',[],'peak_velo',[],'velo_raw',[],'CR_onset',[],'CR_amp',[],'bsl_frq',[],'CR_frq',[]);
  CH_locs=struct('nr',[],'t',[],'velo_info',[],'avg_velo',[],'peak_velo',[],'velo_raw',[],'CR_onset',[],'CR_amp',[],'bsl_frq',[],'CR_frq',[]);
  CL_idx=0;
  CH_idx=0;
  
  [~,index] = sortrows([file(i).(all_info).ttt.CR_trial.avg_velo].');
  file(i).(all_info).ttt.CR_trials = file(i).(all_info).ttt.CR_trial(index);
  clear index;
  velo_C_20f=file(i).(all_info).ttt.CR_trial(20).avg_velo;
  velo_C_20l=file(i).(all_info).ttt.CR_trial(size(file(i).(all_info).ttt.CR_trial,2)-19).avg_velo;
  if velo_C_20f<=0.001
     for k=1:size(file(i).(all_info).ttt.CR_trial,2)
         if file(i).(all_info).ttt.CR_trial(k).avg_velo >=0.001 || file(i).(all_info).ttt.CR_trial(k).peak_velo >=0.05
            CH_idx=CH_idx+1;
            CH_locs(CH_idx).nr=file(i).(all_info).ttt.CR_trial(k).trial_num;
            CH_locs(CH_idx).t=file(i).(all_info).ttt.CR_trial(k).cs_lc;
            CH_locs(CH_idx).velo_info=file(i).(all_info).ttt.CR_trial(k).velo_info;     
            CH_locs(CH_idx).avg_velo=file(i).(all_info).ttt.CR_trial(k).avg_velo;
            CH_locs(CH_idx).peak_velo=file(i).(all_info).ttt.CR_trial(k).peak_velo;
            CH_locs(CH_idx).velo_raw=file(i).(all_info).ttt.CR_trial(k).velo_raw;
            CH_locs(CH_idx).CR_onset=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_onset;
            CH_locs(CH_idx).CR_amp=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_amp;
            bsl_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.CR_trial(k).spk_time<0);
            test_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=0 & file(i).(all_info).ttt.CR_trial(k).spk_time<t_post/1000);
            CH_locs(CH_idx).bsl_frq=length(bsl_frq)/t_pre*1000;
            CH_locs(CH_idx).CR_frq=length(test_frq)/t_post*1000-CH_locs(CH_idx).bsl_frq;
         else
            CL_idx=CL_idx+1;
            CL_locs(CL_idx).nr=file(i).(all_info).ttt.CR_trial(k).trial_num;
            CL_locs(CL_idx).t=file(i).(all_info).ttt.CR_trial(k).cs_lc;
            CL_locs(CL_idx).velo_info=file(i).(all_info).ttt.CR_trial(k).velo_info;   
            CL_locs(CL_idx).avg_velo=file(i).(all_info).ttt.CR_trial(k).avg_velo;
            CL_locs(CL_idx).peak_velo=file(i).(all_info).ttt.CR_trial(k).peak_velo; 
            CL_locs(CL_idx).velo_raw=file(i).(all_info).ttt.CR_trial(k).velo_raw;
            CL_locs(CL_idx).CR_onset=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_onset;
            CL_locs(CL_idx).CR_amp=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_amp;  
            bsl_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.CR_trial(k).spk_time<0);
            test_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=0 & file(i).(all_info).ttt.CR_trial(k).spk_time<t_post/1000);
            CL_locs(CL_idx).bsl_frq=length(bsl_frq)/t_pre*1000;
            CL_locs(CL_idx).CR_frq=length(test_frq)/t_post*1000-CL_locs(CL_idx).bsl_frq;            
         end
     end
  else
     for k=1:size(file(i).(all_info).ttt.CR_trial,2)
         if k>20
            CH_idx=CH_idx+1;
            CH_locs(CH_idx).nr=file(i).(all_info).ttt.CR_trial(k).trial_num;
            CH_locs(CH_idx).t=file(i).(all_info).ttt.CR_trial(k).cs_lc;
            CH_locs(CH_idx).velo_info=file(i).(all_info).ttt.CR_trial(k).velo_info;  
            CH_locs(CH_idx).avg_velo=file(i).(all_info).ttt.CR_trial(k).avg_velo;
            CH_locs(CH_idx).peak_velo=file(i).(all_info).ttt.CR_trial(k).peak_velo;
            CH_locs(CH_idx).velo_raw=file(i).(all_info).ttt.CR_trial(k).velo_raw;
            CH_locs(CH_idx).CR_onset=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_onset;
            CH_locs(CH_idx).CR_amp=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_amp;
            bsl_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.CR_trial(k).spk_time<0);
            test_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=0 & file(i).(all_info).ttt.CR_trial(k).spk_time<t_post/1000);
            CH_locs(CH_idx).bsl_frq=length(bsl_frq)/t_pre*1000;
            CH_locs(CH_idx).CR_frq=length(test_frq)/t_post*1000-CH_locs(CH_idx).bsl_frq;            
         elseif k<=20
            CL_idx=CL_idx+1;
            CL_locs(CL_idx).nr=file(i).(all_info).ttt.CR_trial(k).trial_num;
            CL_locs(CL_idx).t=file(i).(all_info).ttt.CR_trial(k).cs_lc;
            CL_locs(CL_idx).velo_info=file(i).(all_info).ttt.CR_trial(k).velo_info; 
            CL_locs(CL_idx).avg_velo=file(i).(all_info).ttt.CR_trial(k).avg_velo;
            CL_locs(CL_idx).peak_velo=file(i).(all_info).ttt.CR_trial(k).peak_velo;  
            CL_locs(CL_idx).velo_raw=file(i).(all_info).ttt.CR_trial(k).velo_raw;
            CL_locs(CL_idx).CR_onset=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_onset;
            CL_locs(CL_idx).CR_amp=file(i).(all_info).ttt.CR_trial(k).blk_info_new.CR_amp;         
            bsl_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.CR_trial(k).spk_time<0);
            test_frq=file(i).(all_info).ttt.CR_trial(k).spk_time(file(i).(all_info).ttt.CR_trial(k).spk_time>=0 & file(i).(all_info).ttt.CR_trial(k).spk_time<t_post/1000);
            CL_locs(CL_idx).bsl_frq=length(bsl_frq)/t_pre*1000;
            CL_locs(CL_idx).CR_frq=length(test_frq)/t_post*1000-CL_locs(CL_idx).bsl_frq;                   
         end
     end    
  end
  loco_com(i).cell_ID=file(i).cell_ID;
  loco_com(i).session_ID=file(i).file_name;
  loco_com(i).CH_locs=CH_locs;
  loco_com(i).CL_locs=CL_locs;
  loco_com(i).CR_fac=mod_file(i).CR_fac;
  loco_com(i).CR_sup=mod_file(i).CR_sup;
  loco_com(i).CH_onset=mean([CH_locs.CR_onset]);
  loco_com(i).CL_onset=mean([CL_locs.CR_onset]);   
  loco_com(i).CH_amp=mean([CH_locs.CR_amp]);
  loco_com(i).CL_amp=mean([CL_locs.CR_amp]);  
  loco_com(i).CH_bsl_frq=mean([CH_locs.bsl_frq]);
  loco_com(i).CL_bsl_frq=mean([CL_locs.bsl_frq]);   
  loco_com(i).CH_test_frq=mean([CH_locs.CR_frq]);
  loco_com(i).CL_test_frq=mean([CL_locs.CR_frq]);  
end