i=110;
file=DT_list_align;
file_CV2=CV2_cal_2;
ymin_psth_plot=0;
ymax_psth_plot=60;
cd 'D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\example_neurons'


all_info='all_info_D';
align_info='align_info_D';
spk_int='spk_int_D';
t_post=250;
figure('units','normalized','outerposition',[0.25 0 0.4 1]);  
subplot(3,1,1)
trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'CRonset_rank',[],'spk',[]);
for j=1:size(file(i).(all_info).ttt.CR_trial,2)
    trial_info(j).field=j;
    trial_info(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
    trial_info(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
    trial_info(j).CRonset_rank=file(i).(all_info).ttt.CR_trial(j).blk_info.CRonset_rank;
    trial_info(j).spk=file(i).(all_info).ttt.CR_trial(j).spk_time;
end

trial_info = trial_info(all(~cellfun(@isempty,struct2cell(trial_info))));

behavior_mean=zeros(1550,size(trial_info,2));
for m=1:size(trial_info,2)
    behavior_mean(:,m)=file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
end
ymax=max(max(behavior_mean))+0.1;
ymin=min(min(behavior_mean))-0.1;
%     line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
% rectangle('Position',[0,ymin*0.95,250,ymax-ymin],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')
%     line([t_interval t_interval],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
for m=1:size(trial_info,2)
    behavior_mean(:,m)=file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
    plot(file(i).(all_info).ttt.CR_trial(m).blk_smth(:,1),file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2),'linewidth',0.5,'color',[0.9 0.9 0.9])
    hold on
end
plot(file(i).(all_info).ttt.CR_trial(1).blk_smth(:,1),mean(behavior_mean,2),'Color',[0 0 0],'LineWidth',2)
hold on
xlim([-250 750]);
xticks(-250:250:750);
ylim([ymin ymax]);
xlabel('Time(ms)');
ylabel('Normalized eyelid trace')    

subplot(3,1,2)
% rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
% hold on

for m=1:size(trial_info,2)
    hold on
    for n=1:size(trial_info(m).spk,1)
        if trial_info(m).spk(n,1)*1000>=0 && trial_info(m).spk(n,1)*1000<t_post
            plot(trial_info(m).spk(n,1)*1000,m,'k.')
            hold on
        else
            plot(trial_info(m).spk(n,1)*1000,m,'.','Color',[0.5 0.5 0.5])
            hold on
        end
    end
%         plot(0,m,'g.')
%         hold on
%     plot(trial_info(m).CR_onset*1000,m,'b*')
%     hold on
%         plot(t_interval,m,'r.')        
end
hold on
xlim([-250 750]);
xticks(-250:250:750);
ylim([0 m]);
%     line([t_interval t_interval],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
xlabel('Time(ms)');
ylabel('Trial number');

subplot(3,1,3)
%     ymax=max(max(package(i).align_info.psth_ex(51:1051,2)),max(package(i).align_info.psth_align(51:1051,2)))*1.1;   
%     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
%     hold on
%     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
%     hold on    
    plot(file(i).(align_info).psth_ex(:,1),smooth(file(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
    hold on
%     plot(package(i).align_info.psth_align(:,1),smooth(package(i).align_info.psth_align(:,2),20),'b-','LineWidth',2.0)
%     hold on

%     line([-package(i).align_info.t_start -package(i).align_info.t_start],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
%     line([t_interval-package(i).align_info.t_end t_interval-package(i).align_info.t_end],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
%     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    hold on
    xlim([-250 750]);
    ylim([ymin_psth_plot ymax_psth_plot]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Est. Spike Freq. (Hz)');
    hold on
    saveas(gcf,['DT' num2str(i) '-Delay_1' '.tif']);
    close all    

% figure('units','normalized','outerposition',[0 0 1 1]); 
% subplot(3,2,1)
% % rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
% % hold on
% 
% for m=1:size(trial_info,2)
%     hold on
%     Y=ones(length(trial_info(m).spk),1)*m;
%     plot(trial_info(m).spk*1000,Y,'k.')
%     hold on
% %         plot(0,m,'g.')
% %         hold on
%     plot(trial_info(m).CR_onset*1000,m,'b*')
%     hold on
% %         plot(t_interval,m,'r.')        
% end
% hold on
% xlim([-250 750]);
% xticks(-250:250:750);
% ylim([0 m]);
% %     line([t_interval t_interval],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
% xlabel('Time(ms)');
% ylabel('Trial number');
% 
% subplot(3,2,2)
% for j=1:size(file_CV2(i).(spk_int),2)
%     for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
%         if file_CV2(i).(spk_int)(j).all_info(k).mod==0
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
%               hold on 
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
%                  hold on 
%               end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
%                  hold on                 
%               end
%         end
%     end
%     plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
% %     plot(0,j,'g.')
% %     hold on
% %     plot(t_post,j,'r.')
% %     hold on       
% end
% xlim([-250 750]);
% xticks(-250:250:750);
% ylim([0 j+1]);
% ylabel('Trial number');
% 
% subplot(3,2,3)
% [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
% file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
% clear index;
% for j=1:size(file_CV2(i).(spk_int),2)
%     for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
%         if file_CV2(i).(spk_int)(j).all_info(k).mod==0
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
%               hold on 
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
%                  hold on 
%               end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
%                  hold on                 
%               end
%         end
%     end
%     plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
% %     plot(0,j,'g.')
% %     hold on
% %     plot(t_post,j,'r.')
% %     hold on       
% end
% xlim([-250 750]);
% xticks(-250:250:750);
% ylim([0 j+1]);
% ylabel('Trial number');
% title('CS onset align');
% 
% subplot(3,2,4)
% for j=1:size(file_CV2(i).(spk_int),2)
%     for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
%         if file_CV2(i).(spk_int)(j).all_info(k).mod==0
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'k.')
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[0.5 0.5 0.5])
%               hold on 
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'m.') 
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[1 0.5 1]) 
%               hold on    
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'c.') 
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[0.5 1 1]) 
%               hold on
%            end
%         end
%     end
%     plot(0,j,'b*')
%     plot(-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'.','Color',[0 0.8 0],'MarkerSize',15)
%     hold on
%     plot(t_post-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'r.','MarkerSize',15)
%     hold on       
% end
% xlim([-500 500]);
% xticks(-500:250:500);
% ylim([0 j+1]);
% ylabel('Trial number');
% title('CR onset align');    
% 
% subplot(3,2,5)
% %     ymax=max(package(i).align_info.psth_ex(51:1051,2)))*1.1;   
% %     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
% %     hold on
% %     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
% %     hold on    
%     plot(file(i).(align_info).psth_ex(:,1),smooth(file(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
%     hold on
% %     plot(package(i).align_info.psth_align(:,1),smooth(package(i).align_info.psth_align(:,2),20),'b-','LineWidth',2.0)
% %     hold on
% 
% %     line([-package(i).align_info.t_start -package(i).align_info.t_start],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([t_interval-package(i).align_info.t_end t_interval-package(i).align_info.t_end],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%     hold on
%     xlim([-250 750]);
%     ylim([ymin_psth_plot ymax_psth_plot]);
%     xticks(-250:250:750);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     hold on
%     
% subplot(3,2,6)
%       ymax=max(smooth(file(i).(align_info).psth_ex(551:800,2),20));   
% %     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
% %     hold on
% %     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
% %     hold on    
% %     plot(file(i).(align_info).psth_ex(:,1),smooth(file(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
% %     hold on
%     plot(file(i).(align_info).psth_align(:,1),smooth(file(i).(align_info).psth_align(:,2),20),'b-','LineWidth',2.0)
%     hold on
% 
% %     line([-package(i).align_info.t_start -package(i).align_info.t_start],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([t_interval-package(i).align_info.t_end t_interval-package(i).align_info.t_end],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%     hold on
%     xlim([-500 500]);
%     ylim([ymin_psth_plot ymax_psth_plot]);
%     xticks(-500:250:500);
%     line([-500,500],[ymax ymax],'LineStyle','--','Color',[0 0 0],'LineWidth',2.0);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     hold on
%     saveas(gcf,['DT' num2str(i) '-Delay_2' '.tif']);
%     close all    

    
    
all_info='all_info_T';
align_info='align_info_T';
spk_int='spk_int_T';
t_post=500;
figure('units','normalized','outerposition',[0.25 0 0.4 1]);  
subplot(3,1,1)
trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'CRonset_rank',[],'spk',[]);
for j=1:size(file(i).(all_info).ttt.CR_trial,2)
    trial_info(j).field=j;
    trial_info(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
    trial_info(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
    trial_info(j).CRonset_rank=file(i).(all_info).ttt.CR_trial(j).blk_info.CRonset_rank;
    trial_info(j).spk=file(i).(all_info).ttt.CR_trial(j).spk_time;
end

trial_info = trial_info(all(~cellfun(@isempty,struct2cell(trial_info))));

behavior_mean=zeros(1550,size(trial_info,2));
for m=1:size(trial_info,2)
    behavior_mean(:,m)=file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
end
ymax=max(max(behavior_mean))+0.1;
ymin=min(min(behavior_mean))-0.1;
%     line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
% rectangle('Position',[0,ymin*0.95,250,ymax-ymin],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')
%     line([t_interval t_interval],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
for m=1:size(trial_info,2)
    behavior_mean(:,m)=file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
    plot(file(i).(all_info).ttt.CR_trial(m).blk_smth(:,1),file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2),'linewidth',0.5,'color',[0.9 0.9 0.9])
    hold on
end
plot(file(i).(all_info).ttt.CR_trial(1).blk_smth(:,1),mean(behavior_mean,2),'Color',[0 0 0],'LineWidth',2)
hold on
xlim([-250 750]);
xticks(-250:250:750);
ylim([ymin ymax]);
xlabel('Time(ms)');
ylabel('Normalized eyelid trace')    

subplot(3,1,2)
% rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
% hold on

for m=1:size(trial_info,2)
    hold on
    for n=1:size(trial_info(m).spk,1)
        if trial_info(m).spk(n,1)*1000>=0 && trial_info(m).spk(n,1)*1000<t_post
            plot(trial_info(m).spk(n,1)*1000,m,'k.')
            hold on
        else
            plot(trial_info(m).spk(n,1)*1000,m,'.','Color',[0.5 0.5 0.5])
            hold on
        end
    end
end
hold on
xlim([-250 750]);
xticks(-250:250:750);
ylim([0 m]);
%     line([t_interval t_interval],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
xlabel('Time(ms)');
ylabel('Trial number');

subplot(3,1,3)
%     ymax=max(max(package(i).align_info.psth_ex(51:1051,2)),max(package(i).align_info.psth_align(51:1051,2)))*1.1;   
%     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
%     hold on
%     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
%     hold on    
    plot(file(i).(align_info).psth_ex(:,1),smooth(file(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
    hold on
%     plot(package(i).align_info.psth_align(:,1),smooth(package(i).align_info.psth_align(:,2),20),'b-','LineWidth',2.0)
%     hold on

%     line([-package(i).align_info.t_start -package(i).align_info.t_start],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
%     line([t_interval-package(i).align_info.t_end t_interval-package(i).align_info.t_end],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
%     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    hold on
    xlim([-250 750]);
    ylim([ymin_psth_plot ymax_psth_plot]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Est. Spike Freq. (Hz)');
    hold on
    saveas(gcf,['DT' num2str(i) '-Trace_1' '.tif']);
    close all  

% figure('units','normalized','outerposition',[0 0 1 1]); 
% subplot(3,2,1)
% % rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
% % hold on
% 
% for m=1:size(trial_info,2)
%     hold on
%     Y=ones(length(trial_info(m).spk),1)*m;
%     plot(trial_info(m).spk*1000,Y,'k.')
%     hold on
% %         plot(0,m,'g.')
% %         hold on
%     plot(trial_info(m).CR_onset*1000,m,'b*')
%     hold on
% %         plot(t_interval,m,'r.')        
% end
% hold on
% xlim([-250 750]);
% xticks(-250:250:750);
% ylim([0 m]);
% %     line([t_interval t_interval],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
% xlabel('Time(ms)');
% ylabel('Trial number');
% 
% subplot(3,2,2)
% for j=1:size(file_CV2(i).(spk_int),2)
%     for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
%         if file_CV2(i).(spk_int)(j).all_info(k).mod==0
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
%               hold on 
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
%                  hold on 
%               end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
%                  hold on                 
%               end
%         end
%     end
%     plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
% %     plot(0,j,'g.')
% %     hold on
% %     plot(t_post,j,'r.')
% %     hold on       
% end
% xlim([-250 750]);
% xticks(-250:250:750);
% ylim([0 j+1]);
% ylabel('Trial number');
% 
% subplot(3,2,3)
% [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
% file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
% clear index;
% for j=1:size(file_CV2(i).(spk_int),2)
%     for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
%         if file_CV2(i).(spk_int)(j).all_info(k).mod==0
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
%               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
%               hold on 
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
%                  hold on 
%               end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
%               if file_CV2(i).(spk_int)(j).all_info(k).t>=0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
%                  hold on
%               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
%                  hold on                 
%               end
%         end
%     end
%     plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
% %     plot(0,j,'g.')
% %     hold on
% %     plot(t_post,j,'r.')
% %     hold on       
% end
% xlim([-250 750]);
% xticks(-250:250:750);
% ylim([0 j+1]);
% ylabel('Trial number');
% title('CS onset align');
% 
% subplot(3,2,4)
% for j=1:size(file_CV2(i).(spk_int),2)
%     for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
%         if file_CV2(i).(spk_int)(j).all_info(k).mod==0
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'k.')
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[0.5 0.5 0.5])
%               hold on 
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'m.') 
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[1 0.5 1]) 
%               hold on    
%            end
%         elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
%            if file_CV2(i).(spk_int)(j).all_info(k).t>=0 
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'c.') 
%               hold on
%            elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 
%               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'.','Color',[0.5 1 1]) 
%               hold on
%            end
%         end
%     end
%     plot(0,j,'b*')
%     plot(-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'.','Color',[0 0.8 0],'MarkerSize',15)
%     hold on
%     plot(t_post-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'r.','MarkerSize',15)
%     hold on       
% end
% xlim([-500 500]);
% xticks(-500:250:500);
% ylim([0 j+1]);
% ylabel('Trial number');
% title('CR onset align');    
% 
% subplot(3,2,5)
% %     ymax=max(package(i).align_info.psth_ex(51:1051,2)))*1.1;   
% %     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
% %     hold on
% %     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
% %     hold on    
%     plot(file(i).(align_info).psth_ex(:,1),smooth(file(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
%     hold on
% %     plot(package(i).align_info.psth_align(:,1),smooth(package(i).align_info.psth_align(:,2),20),'b-','LineWidth',2.0)
% %     hold on
% 
% %     line([-package(i).align_info.t_start -package(i).align_info.t_start],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([t_interval-package(i).align_info.t_end t_interval-package(i).align_info.t_end],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%     hold on
%     xlim([-250 750]);
%     ylim([ymin_psth_plot ymax_psth_plot]);
%     xticks(-250:250:750);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     hold on
%     
% subplot(3,2,6)
%       ymax=max(smooth(file(i).(align_info).psth_ex(551:800,2),20));   
% %     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
% %     hold on
% %     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
% %     hold on    
% %     plot(file(i).(align_info).psth_ex(:,1),smooth(file(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
% %     hold on
%     plot(file(i).(align_info).psth_align(:,1),smooth(file(i).(align_info).psth_align(:,2),20),'b-','LineWidth',2.0)
%     hold on
% 
% %     line([-package(i).align_info.t_start -package(i).align_info.t_start],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([t_interval-package(i).align_info.t_end t_interval-package(i).align_info.t_end],[ymin_psth_plot ymax_psth_plot],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% %     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%     hold on
%     xlim([-500 500]);
%     ylim([ymin_psth_plot ymax_psth_plot]);
%     xticks(-500:250:500);
%     line([-500,500],[ymax ymax],'LineStyle','--','Color',[0 0 0],'LineWidth',2.0);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     hold on
%     
%     saveas(gcf,['DT' num2str(i) '-Trace_2' '.tif']);
%     close all  