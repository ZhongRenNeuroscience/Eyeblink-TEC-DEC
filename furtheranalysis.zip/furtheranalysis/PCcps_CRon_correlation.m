% To visualize the relationship between complex spikes of Purkinje cells to
% CR onset.--Zhong

cps_blk_cor=struct('cell_ID',[],'form',[],'R',[],'P',[]);
j=1;
figure;
for i=1:size(list_PC,2)
    if isempty(list_PC(i).CR_fac_cps)
       continue
    end
    cps_blk_cor(j).cell_ID=list_PC(i).cell_ID;
    form=struct('CR_on',[],'cps_on',[],'regression',[]);
    n=1;
    for k=1:size(list_PC(i).all_info_cps.ttt.CR_trial,2)
        if isempty(list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time)
           continue
        end
        for m=1:size(list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time,1)
            if list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time(m)>=0 && list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time(m)<0.5 &&...
                    list_PC(i).all_info_cps.ttt.CR_trial(k).blk_info_new.CR_onset>=0.05
               form(n).CR_on=list_PC(i).all_info_cps.ttt.CR_trial(k).blk_info_new.CR_onset;
               form(n).cps_on=list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time(m);
               n=n+1;
            end
        end       
    end
    
    [R,P]=corrcoef([form.CR_on],[form.cps_on]);
    p=polyfit([form.CR_on],[form.cps_on],1);
    regression=p(1)*[form.CR_on]+p(2);
    cps_blk_cor(j).R=R(1,2);
    cps_blk_cor(j).P=P(1,2);
    for x=1:size(form,2)
        form(x).regression=regression(x);
    end
    
    cps_blk_cor(j).form=form;    
   
    subplot(4,7,j)
    hold on
    if list_PC(i).CR_fac_sps > 0
        scatter([form.cps_on]*1000,[form.CR_on]*1000,10,'filled','r');
        hold on
        if P(1,2)<0.05
           plot([form.regression]*1000,[form.CR_on]*1000,'r-');
           hold on
        else
           plot([form.regression]*1000,[form.CR_on]*1000,'Color',[1 0.75 0.75],'LineStyle','-');
           hold on
        end
    elseif list_PC(i).CR_sup_sps > 0
        scatter([form.cps_on]*1000,[form.CR_on]*1000,10,'filled','b');
        hold on
        if P(1,2)<0.05
           plot([form.regression]*1000,[form.CR_on]*1000,'b-');
           hold on
        else
           plot([form.regression]*1000,[form.CR_on]*1000,'Color',[0.75 0.75 1],'LineStyle','-');
           hold on
        end     
    elseif list_PC(i).CR_fac_sps==0 && list_PC(i).CR_sup_sps==0
        scatter([form.cps_on]*1000,[form.CR_on]*1000,10,'filled','k');
        hold on
        if P(1,2)<0.05
           plot([form.regression]*1000,[form.CR_on]*1000,'k-');
           hold on
        else
           plot([form.regression]*1000,[form.CR_on]*1000,'Color',[0.75 0.75 0.75],'LineStyle','-');
           hold on
        end      
    end
        
    set(gca,'xlim',[0 500],'ylim',[0 500]);
    xlabel('cps time (ms)');
    ylabel('CR time (ms)');
    xticks([0 250 500]);
    yticks([0 250 500]);
    title(['PC' num2str(j)]);
    hold on
    
    j=j+1;
end
