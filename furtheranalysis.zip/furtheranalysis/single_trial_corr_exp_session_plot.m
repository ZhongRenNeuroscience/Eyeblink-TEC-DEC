% make it adaptive to both single session and double sessions
trial_mod_list=trial_mod_list_T;
cell_ID=11;
corr_info_type_1='other_corr_info_21';
corr_info_type_2='other_corr_info_21';
reg_type='reg';
xmin=0;
xmax=250;
ymin=0;
ymax=250;
color_D=[1 0.5 0];
color_T=[0.5 0 1];

% for i=cell_ID:cell_ID
for i=1:size(pos_sig_cell_list,2)
    figure;
    cell_ID=trial_mod_list(pos_sig_cell_list(i).cell_ID).cell_ID;
%     scatter(trial_mod_list(cell_ID).(corr_info_type_1).(reg_type)(:,1),trial_mod_list(cell_ID).(corr_info_type_1).(reg_type)(:,2),10,'MarkerFaceColor',color_D,'MarkerEdgeColor','none')
%     hold on
%     plot(trial_mod_list(cell_ID).(corr_info_type_1).(reg_type)(:,1),trial_mod_list(cell_ID).(corr_info_type_1).(reg_type)(:,3),'-','Color',color_D)
%     hold on


    scatter(trial_mod_list(cell_ID).(corr_info_type_2).(reg_type)(:,1),trial_mod_list(cell_ID).(corr_info_type_2).(reg_type)(:,2),10,'MarkerFaceColor',color_T,'MarkerEdgeColor','none')
    hold on
    plot(trial_mod_list(cell_ID).(corr_info_type_2).(reg_type)(:,1),trial_mod_list(cell_ID).(corr_info_type_2).(reg_type)(:,3),'-','Color',color_T)
    hold on
    title(['Cell ' num2str(cell_ID) ' P = ' num2str(pos_sig_cell_list(i).P) ' R = ' num2str(pos_sig_cell_list(i).R)]);
    
    xlim([xmin xmax]);
    ylim([ymin ymax]);
end
