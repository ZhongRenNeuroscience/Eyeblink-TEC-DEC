cps_amp_cor=struct('cell_ID',[],'with_amp',[],'without_amp',[],'with_info',[],'without_info',[]);

j=1;
for i=1:size(list_PC,2)
    
    if isempty(list_PC(i).CR_fac_cps)
       continue
    end
    
    with_info=struct('trial_ID',[],'CR_amp',[]);
    without_info=struct('trial_ID',[],'CR_amp',[]);
    x=1;
    y=1;
    
    for k=1:size(list_PC(i).all_info_cps.ttt.CR_trial,2)
        cps=0;
        if isempty(list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time)
           cps=1;
        else
           for m=1:size(list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time,1)
               if list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time(m)>=0 && list_PC(i).all_info_cps.ttt.CR_trial(k).spk_time(m)<0.5 &&...
                    list_PC(i).all_info_cps.ttt.CR_trial(k).blk_info_new.CR_onset>=0.05
                  cps=2;
                  break
               end
           end
        end
        
        if cps==2
           with_info(x).trial_ID=list_PC(i).all_info_cps.ttt.CR_trial(k).trial_num;
           with_info(x).CR_amp=list_PC(i).all_info_cps.ttt.CR_trial(k).blk_info_new.CR_amp*100;              
           x=x+1;
        else
           without_info(y).trial_ID=list_PC(i).all_info_cps.ttt.CR_trial(k).trial_num;
           without_info(y).CR_amp=list_PC(i).all_info_cps.ttt.CR_trial(k).blk_info_new.CR_amp*100;              
           y=y+1;               
        end                
    end
    
    cps_amp_cor(j).cell_ID=i;
    cps_amp_cor(j).with_amp=mean([with_info.CR_amp]);
    cps_amp_cor(j).without_amp=mean([without_info.CR_amp]);
    cps_amp_cor(j).with_info=with_info;
    cps_amp_cor(j).without_info=without_info;
    
    if list_PC(i).CR_fac_sps>0
       plot(cps_amp_cor(j).with_amp,cps_amp_cor(j).without_amp,'r.','MarkerSize',20)
       hold on
    elseif list_PC(i).CR_sup_sps>0
       plot(cps_amp_cor(j).with_amp,cps_amp_cor(j).without_amp,'b.','MarkerSize',20)
       hold on   
    elseif list_PC(i).CR_fac_sps==0 && list_PC(i).CR_sup_sps==0
       plot(cps_amp_cor(j).with_amp,cps_amp_cor(j).without_amp,'k.','MarkerSize',20)
       hold on  
    end
    j=j+1;
end

% scatter([cps_amp_cor.with_amp],[cps_amp_cor.without_amp],30);
hold on
xlim([0 60]);
ylim([0 60]);
line([0 60],[0 60],'Color','black','LineStyle','--');
xticks([0 20 40 60]);
yticks([0 20 40 60]);
xlabel('CR amp. of cps trials');
ylabel('CR amp. of no-cps trials');