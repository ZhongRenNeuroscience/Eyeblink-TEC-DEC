pack=TD_list_new;
mod_info='mod_info_D';
all_info_1='all_info_T';
all_info_2='all_info_D';
t_find_1=490;
t_find_2=240;
mod_t=struct('cell_ID',[],'mod_tp',[],'onset1',[],'onset2',[],'change1',[],'change2',[],'pkt1',[],'pkt2',[],'psth_info_1',[],'blk_info_1',[],'psth_info_2',[],'blk_info_2',[],'t_test',[],'t_stat',[]);
n=0;

for i=1:size(pack,2)
    if pack(i).CR_fac_D + pack(i).CR_sup_D > 0 && pack(i).CR_fac_T + pack(i).CR_sup_T > 0

% for facilitation neurons  
       if pack(i).CR_fac_D > 0 &&  pack(i).CR_fac_T > 0
          n=n+1;
          mod_t(n).cell_ID=pack(i).cell_ID;
          mod_t(n).mod_tp=1;
          mod_t(n).onset1=pack(i).(mod_info).CRf(1).t_onset;
          [M,I]=max(pack(i).(all_info_1).sss_all.psth.CR_trial.psth_smooth(551:551+t_find_1,2));   
          mod_t(n).change1=M/pack(i).(all_info_1).sss_all.psth.CR_trial.avg_frq*100-100;
          mod_t(n).pkt1=I-1; 
          mod_t(n).psth_info_1=pack(i).(all_info_1).sss_all.psth.CR_trial.psth_smooth;
          mod_t(n).psth_info_1(:,3)=mod_t(n).psth_info_1(:,2)/pack(i).(all_info_1).sss_all.psth.CR_trial.avg_frq*100;
          blk1_raw=pack(i).(all_info_1).sss_all.blk.CR_trial;
          blk1_info=zeros(1550,5);
          blk1_info(:,1)=-550:1:999;
          blk1_form=zeros(1550,size(pack(i).(all_info_1).ttt.CR_trial,2));
          for m=1:size(pack(i).(all_info_1).ttt.CR_trial,2)
              blk1_form(:,m)=pack(i).(all_info_1).ttt.CR_trial(m).blk_smth(:,2)*100;
          end  
          blk1_info(:,2)=mean(blk1_form,2);
          blk1_info(:,3)=std(blk1_form,0,2);
          for k=1:1550
              blk1_info(k,4)=blk1_info(k,2)+blk1_info(k,3);
              blk1_info(k,5)=blk1_info(k,2)-blk1_info(k,3);
          end
          mod_t(n).blk_info_1=blk1_info;
          
%           if size(pack(i).(all_info_2).ttt.CR_trial,2) >= 50
%               onset2_form=zeros(32001,50);
%               for j=size(pack(i).(all_info_2).ttt.CR_trial,2)-49:size(pack(i).(all_info_2).ttt.CR_trial,2)
%                   m=j-size(pack(i).(all_info_2).ttt.CR_trial,2)+50;
%                   onset2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).ifr_org_Gau(:,2);
%               end
%           else
%               onset2_form=zeros(32001,size(pack(i).(all_info_2).ttt.CR_trial,2));
%               for j=1:size(pack(i).(all_info_2).ttt.CR_trial,2)
%                   m=j;
%                   onset2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).ifr_org_Gau(:,2);
%               end
%           end
          md=mod(size(pack(i).(all_info_2).ttt.CR_trial,2),2);
          onset2_form=zeros(32001,(size(pack(i).(all_info_2).ttt.CR_trial,2)-md)/2);
          blk2_form=zeros(1550,(size(pack(i).(all_info_2).ttt.CR_trial,2)-md)/2);
          for j=(size(pack(i).(all_info_2).ttt.CR_trial,2)+md)/2+1:size(pack(i).(all_info_2).ttt.CR_trial,2)
              m=j-(size(pack(i).(all_info_2).ttt.CR_trial,2)+md)/2;
              onset2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).ifr_org_Gau(:,2);
              blk2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).blk_smth(:,2)*100;
          end  
          blk2_info=zeros(1550,5);
          blk2_info(:,1)=-550:1:999;
          blk2_info(:,2)=mean(blk2_form,2);
          blk2_info(:,3)=std(blk2_form,0,2);
          for k=1:1550
              blk2_info(k,4)=blk2_info(k,2)+blk2_info(k,3);
              blk2_info(k,5)=blk2_info(k,2)-blk2_info(k,3);
          end
          mod_t(n).blk_info_2=blk2_info;
  
          onset2_form2=mean(onset2_form,2);
          onset2_info=zeros(1600,3);
          onset2_info(:,1)=-550:1:1049;
          for k=1:1600            
              onset2_info(k,2)=mean(onset2_form2(20*k-19:20*k,1))*1000;
          end
          bsl=mean(onset2_info(51:550,2));
          sd=std(onset2_info(51:550,2));
          thrd=bsl+3*sd;
          mod_t(n).onset2=find(onset2_info(551:551+t_find_2,2)>thrd,1,'first')-1;
          [M,I]=max(onset2_info(551:551+t_find_2,2));
          mod_t(n).change2=M/bsl*100-100;
          mod_t(n).pkt2=I-1;
          onset2_info(:,3)=onset2_info(:,2)/bsl*100;
          mod_t(n).psth_info_2=onset2_info;
       
       
% for suppression neurons       
       elseif pack(i).CR_sup_D > 0 &&  pack(i).CR_sup_T > 0
          n=n+1;
          mod_t(n).cell_ID=pack(i).cell_ID;         
          mod_t(n).mod_tp=2;
          mod_t(n).onset1=pack(i).(mod_info).CRs(1).t_onset;
          [M,I]=min(pack(i).(all_info_1).sss_all.psth.CR_trial.psth_smooth(551:551+t_find_1,2));   
          mod_t(n).change1=-(M/pack(i).(all_info_1).sss_all.psth.CR_trial.avg_frq*100-100);
          mod_t(n).pkt1=I-1; 
          mod_t(n).psth_info_1=pack(i).(all_info_1).sss_all.psth.CR_trial.psth_smooth;
          mod_t(n).psth_info_1(:,3)=mod_t(n).psth_info_1(:,2)/pack(i).(all_info_1).sss_all.psth.CR_trial.avg_frq*100;         
          blk1_raw=pack(i).(all_info_1).sss_all.blk.CR_trial;
          blk1_info=zeros(1550,5);
          blk1_info(:,1)=-550:1:999;
          blk1_form=zeros(1550,size(pack(i).(all_info_1).ttt.CR_trial,2));
          for m=1:size(pack(i).(all_info_1).ttt.CR_trial,2)
              blk1_form(:,m)=pack(i).(all_info_1).ttt.CR_trial(m).blk_smth(:,2)*100;
          end  
          blk1_info(:,2)=mean(blk1_form,2);
          blk1_info(:,3)=std(blk1_form,0,2);
          for k=1:1550
              blk1_info(k,4)=blk1_info(k,2)+blk1_info(k,3);
              blk1_info(k,5)=blk1_info(k,2)-blk1_info(k,3);
          end
          mod_t(n).blk_info_1=blk1_info;        
%           if size(pack(i).(all_info_2).ttt.CR_trial,2) >= 50
%               onset2_form=zeros(32001,50);
%               for j=size(pack(i).(all_info_2).ttt.CR_trial,2)-49:size(pack(i).(all_info_2).ttt.CR_trial,2)
%                   m=j-size(pack(i).(all_info_2).ttt.CR_trial,2)+50;
%                   onset2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).ifr_org_Gau(:,2);
%               end
%           else
%               onset2_form=zeros(32001,size(pack(i).(all_info_2).ttt.CR_trial,2));
%               for j=1:size(pack(i).(all_info_2).ttt.CR_trial,2)
%                   m=j;
%                   onset2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).ifr_org_Gau(:,2);
%               end
%           end

          md=mod(size(pack(i).(all_info_2).ttt.CR_trial,2),2);
          onset2_form=zeros(32001,(size(pack(i).(all_info_2).ttt.CR_trial,2)-md)/2);
          blk2_form=zeros(1550,(size(pack(i).(all_info_2).ttt.CR_trial,2)-md)/2);
          for j=(size(pack(i).(all_info_2).ttt.CR_trial,2)+md)/2+1:size(pack(i).(all_info_2).ttt.CR_trial,2)
              m=j-(size(pack(i).(all_info_2).ttt.CR_trial,2)+md)/2;
              onset2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).ifr_org_Gau(:,2);
              blk2_form(:,m)=pack(i).(all_info_2).ttt.CR_trial(j).blk_smth(:,2)*100;
          end  
           blk2_info=zeros(1550,5);
          blk2_info(:,1)=-550:1:999;
          blk2_info(:,2)=mean(blk2_form,2);
          blk2_info(:,3)=std(blk2_form,0,2);
          for k=1:1550
              blk2_info(k,4)=blk2_info(k,2)+blk2_info(k,3);
              blk2_info(k,5)=blk2_info(k,2)-blk2_info(k,3);
          end
          mod_t(n).blk_info_2=blk2_info;
          
          onset2_form2=mean(onset2_form,2);
          onset2_info=zeros(1600,3);
          onset2_info(:,1)=-550:1:1049;
          for k=1:1600            
              onset2_info(k,2)=mean(onset2_form2(20*k-19:20*k,1))*1000;
          end
          bsl=mean(onset2_info(51:550,2));
          sd=std(onset2_info(51:550,2));
          thrd=bsl-3*sd;
          mod_t(n).onset2=find(onset2_info(556:551+t_find_2,2)<thrd,1,'first')+4;
          [M,I]=min(onset2_info(556:551+t_find_2,2));
          mod_t(n).change2=-(M/bsl*100-100);
          mod_t(n).pkt2=I+4;
          onset2_info(:,3)=onset2_info(:,2)/bsl*100;          
          mod_t(n).psth_info_2=onset2_info;
       end
       t_smth=zeros(25,2);
       for k=1:25
           idx=551+(k-1)*10;
           t_smth(k,1)=mean(mod_t(n).psth_info_1(idx:idx+9,3));
           t_smth(k,2)=mean(mod_t(n).psth_info_2(idx:idx+9,3));
       end
%      [~,p,~,stats]=ttest(t_smth(:,1),t_smth(:,2));
       [p,h,stats] = signrank(t_smth(:,1),t_smth(:,2));
       mod_t(n).t_test=p;
       mod_t(n).t_stat=stats;
       
    else
        continue
    end

end
       mod_t = mod_t(~cellfun(@isempty,{mod_t.onset2}));