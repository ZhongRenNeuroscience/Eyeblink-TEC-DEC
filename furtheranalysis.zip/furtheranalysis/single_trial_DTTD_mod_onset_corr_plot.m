file=file;
mod_list=mod_list_DT;
% all_info_1='all_info_D';
% align_info_1='align_info_D';
t_post_D=250;
% all_info_2='all_info_T';
% align_info_2='align_info_T';
t_post_T=500;
bin=50;
step=10;
t_pre=500;
mod_event_type='mod_event_ifr';
bin_type='bin_ifr';
bsl_mean_type='bsl_mean_ifr';
min_corr_tr_num=10;
other_corr_data_D1='fac_corr_data_D';
other_corr_data_T1='fac_corr_data_T';
other_corr_data_D2='sup_corr_data_D';
other_corr_data_T2='sup_corr_data_T';
other_item_mod_11='fac_amp';
other_item_mod_12='sup_amp';
other_item_bhv_1='CR_onset';
other_item_mod_21='fac_pkt';
other_item_mod_22='sup_pkt';
other_item_bhv_2='CR_onset';


trial_mod_list_DT=struct('cell_ID',[],'CR_fac_D',[],'CR_fac_T',[],'CR_sup_D',[],'CR_sup_T',[],'fac_onset_corr_D',[],'fac_onset_corr_T',[],'fac_onset_corr_all',[],...
'fac_pkt_corr_D',[],'fac_pkt_corr_T',[],'fac_pkt_corr_all',[],'fac_amp_corr_D',[],'fac_amp_corr_T',[],'fac_amp_corr_all',[],...
'sup_onset_corr_D',[],'sup_onset_corr_T',[],'sup_onset_corr_all',[],'sup_pkt_corr_D',[],'sup_pkt_corr_T',[],'sup_pkt_corr_all',[],...
'sup_amp_corr_D',[],'sup_amp_corr_T',[],'sup_amp_corr_all',[],'fac_corr_data_D',[],'fac_corr_data_T',[],'fac_corr_info_D',[],'fac_corr_info_T',[],...
'sup_corr_data_D',[],'sup_corr_data_T',[],'sup_corr_info_D',[],'sup_corr_info_T',[]);
for i=1:size(file,2)
    trial_mod_list_DT(i).cell_ID=i; %file(i).cell_ID;
    if ~isempty(mod_list(i).align_info_D.CR_fac.t_onset)
       trial_mod_list_DT(i).CR_fac_D=1;
    else
       trial_mod_list_DT(i).CR_fac_D=0;
    end
    if ~isempty(mod_list(i).align_info_D.CR_sup.t_onset) 
       trial_mod_list_DT(i).CR_sup_D=1;
    else
       trial_mod_list_DT(i).CR_sup_D=0;
    end
    if ~isempty(mod_list(i).align_info_T.CR_fac.t_onset)
       trial_mod_list_DT(i).CR_fac_T=1;
    else
       trial_mod_list_DT(i).CR_fac_T=0;
    end
    if ~isempty(mod_list(i).align_info_T.CR_sup.t_onset) 
       trial_mod_list_DT(i).CR_sup_T=1;
    else
       trial_mod_list_DT(i).CR_sup_T=0;
    end
    
    fac_corr_data_D=struct('trial_num',[],'CR_onset',[],'CR_amp',[],'CR_pkt',[],'fac_onset',[],'fac_offset',[],'fac_pkt',[],'fac_amp',[]);
    sup_corr_data_D=struct('trial_num',[],'CR_onset',[],'CR_amp',[],'CR_pkt',[],'sup_onset',[],'sup_offset',[],'sup_pkt',[],'sup_amp',[]);
    
    for j=1:size(file(i).all_info_D.ttt.CR_trial,2)
        if ~isempty(file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type)(1).onset)           
            [~,index] = sortrows([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type).type].'); 
            file(i).all_info.ttt.CR_trial(j).mod_trial.(mod_event_type) = file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type)(index); 
            clear index
            
            fac_event=find(ismember([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type).type],1));
            sup_event=find(ismember([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type).type],2));
        else
            fac_event=[];
            sup_event=[];
        end
        if ~isempty(fac_event)
            fac_corr_data_D(j).trial_num=file(i).all_info_D.ttt.CR_trial(j).trial_num;
            fac_corr_data_D(j).CR_onset=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            fac_corr_data_D(j).CR_amp=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            fac_corr_data_D(j).CR_pkt=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            fac_corr_data_D(j).fac_onset=min([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type)(fac_event).onset]);
            fac_corr_data_D(j).fac_offset=max([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type)(fac_event).offset]);
            [fac_amp,fac_pkt_idx]=max(file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_D-bin)/step+1),2));
            fac_corr_data_D(j).fac_amp=fac_amp/file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100;
            fac_corr_data_D(j).fac_pkt=file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+fac_pkt_idx,1);
        else
            fac_corr_data_D(j).trial_num=file(i).all_info_D.ttt.CR_trial(j).trial_num;
            fac_corr_data_D(j).CR_onset=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            fac_corr_data_D(j).CR_amp=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            fac_corr_data_D(j).CR_pkt=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            fac_corr_data_D(j).fac_onset=[];
            fac_corr_data_D(j).fac_offset=[];
            [fac_amp,fac_pkt_idx]=max(file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_D-bin)/step+1),2));
            fac_corr_data_D(j).fac_amp=fac_amp/file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100;
            fac_corr_data_D(j).fac_pkt=file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+fac_pkt_idx,1);                                
        end

        if ~isempty(sup_event)
            sup_corr_data_D(j).trial_num=file(i).all_info_D.ttt.CR_trial(j).trial_num;
            sup_corr_data_D(j).CR_onset=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            sup_corr_data_D(j).CR_amp=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            sup_corr_data_D(j).CR_pkt=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            sup_corr_data_D(j).sup_onset=min([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type)(sup_event).onset]);
            sup_corr_data_D(j).sup_offset=max([file(i).all_info_D.ttt.CR_trial(j).mod_trial.(mod_event_type)(sup_event).offset]);
            [sup_amp,sup_pkt_idx]=min(file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_D-bin)/step+1),2));
            sup_corr_data_D(j).sup_amp=-(sup_amp/file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100);
            sup_corr_data_D(j).sup_pkt=file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+sup_pkt_idx,1);
        else
            sup_corr_data_D(j).trial_num=file(i).all_info_D.ttt.CR_trial(j).trial_num;
            sup_corr_data_D(j).CR_onset=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            sup_corr_data_D(j).CR_amp=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            sup_corr_data_D(j).CR_pkt=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            sup_corr_data_D(j).sup_onset=[];
            sup_corr_data_D(j).sup_offset=[];
            [sup_amp,sup_pkt_idx]=min(file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_D-bin)/step+1),2));
            sup_corr_data_D(j).sup_amp=-(sup_amp/file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100);
            sup_corr_data_D(j).sup_pkt=file(i).all_info_D.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+sup_pkt_idx,1);                                
        end                          
    end   
    trial_mod_list_DT(i).fac_corr_data_D=fac_corr_data_D;
    trial_mod_list_DT(i).sup_corr_data_D=sup_corr_data_D;

    fac_corr_data_T=struct('trial_num',[],'CR_onset',[],'CR_amp',[],'CR_pkt',[],'fac_onset',[],'fac_offset',[],'fac_pkt',[],'fac_amp',[]);
    sup_corr_data_T=struct('trial_num',[],'CR_onset',[],'CR_amp',[],'CR_pkt',[],'sup_onset',[],'sup_offset',[],'sup_pkt',[],'sup_amp',[]);
    
    for j=1:size(file(i).all_info_T.ttt.CR_trial,2)
        if ~isempty(file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type)(1).onset)           
            [~,index] = sortrows([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type).type].'); 
            file(i).all_info.ttt.CR_trial(j).mod_trial.(mod_event_type) = file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type)(index); 
            clear index
            
            fac_event=find(ismember([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type).type],1));
            sup_event=find(ismember([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type).type],2));
        else
            fac_event=[];
            sup_event=[];
        end
        if ~isempty(fac_event)
            fac_corr_data_T(j).trial_num=file(i).all_info_T.ttt.CR_trial(j).trial_num;
            fac_corr_data_T(j).CR_onset=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            fac_corr_data_T(j).CR_amp=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            fac_corr_data_T(j).CR_pkt=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            fac_corr_data_T(j).fac_onset=min([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type)(fac_event).onset]);
            fac_corr_data_T(j).fac_offset=max([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type)(fac_event).offset]);
            [fac_amp,fac_pkt_idx]=max(file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_T-bin)/step+1),2));
            fac_corr_data_T(j).fac_amp=fac_amp/file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100;
            fac_corr_data_T(j).fac_pkt=file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+fac_pkt_idx,1);
        else
            fac_corr_data_T(j).trial_num=file(i).all_info_T.ttt.CR_trial(j).trial_num;
            fac_corr_data_T(j).CR_onset=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            fac_corr_data_T(j).CR_amp=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            fac_corr_data_T(j).CR_pkt=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            fac_corr_data_T(j).fac_onset=[];
            fac_corr_data_T(j).fac_offset=[];
            [fac_amp,fac_pkt_idx]=max(file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_T-bin)/step+1),2));
            fac_corr_data_T(j).fac_amp=fac_amp/file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100;
            fac_corr_data_T(j).fac_pkt=file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+fac_pkt_idx,1);                                
        end

        if ~isempty(sup_event)
            sup_corr_data_T(j).trial_num=file(i).all_info_T.ttt.CR_trial(j).trial_num;
            sup_corr_data_T(j).CR_onset=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            sup_corr_data_T(j).CR_amp=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            sup_corr_data_T(j).CR_pkt=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            sup_corr_data_T(j).sup_onset=min([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type)(sup_event).onset]);
            sup_corr_data_T(j).sup_offset=max([file(i).all_info_T.ttt.CR_trial(j).mod_trial.(mod_event_type)(sup_event).offset]);
            [sup_amp,sup_pkt_idx]=min(file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_T-bin)/step+1),2));
            sup_corr_data_T(j).sup_amp=-(sup_amp/file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100);
            sup_corr_data_T(j).sup_pkt=file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+sup_pkt_idx,1);
        else
            sup_corr_data_T(j).trial_num=file(i).all_info_T.ttt.CR_trial(j).trial_num;
            sup_corr_data_T(j).CR_onset=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            sup_corr_data_T(j).CR_amp=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_amp*100;
            sup_corr_data_T(j).CR_pkt=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            sup_corr_data_T(j).sup_onset=[];
            sup_corr_data_T(j).sup_offset=[];
            [sup_amp,sup_pkt_idx]=min(file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post_T-bin)/step+1),2));
            sup_corr_data_T(j).sup_amp=-(sup_amp/file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100);
            sup_corr_data_T(j).sup_pkt=file(i).all_info_T.ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+sup_pkt_idx,1);                                
        end                          
    end   
    trial_mod_list_DT(i).fac_corr_data_T=fac_corr_data_T;
    trial_mod_list_DT(i).sup_corr_data_T=sup_corr_data_T;


    fac_corr_info_D=struct('R_onset',[],'P_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[]);
    sup_corr_info_D=struct('R_onset',[],'P_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[]);

    fac_onset_form_D=nan(size(fac_corr_data_D,2),3);
    for k=1:size(fac_corr_data_D,2)
        if ~isempty(fac_corr_data_D(k).fac_onset)
            fac_onset_form_D(k,1)=fac_corr_data_D(k).fac_onset;
            fac_onset_form_D(k,2)=fac_corr_data_D(k).CR_onset;
        end
    end  
    fac_onset_form_D=fac_onset_form_D(all(~isnan(fac_onset_form_D(:,1)),2),:);
    fac_onset_form_D=fac_onset_form_D(all(~isinf(fac_onset_form_D(:,1)),2),:);
    if size(fac_onset_form_D,1)>=min_corr_tr_num
        [fac_R_onset,fac_P_onset]=corrcoef(fac_onset_form_D(:,1),fac_onset_form_D(:,2));
        p_fac_onset=polyfit(fac_onset_form_D(:,1),fac_onset_form_D(:,2),1);
        fac_onset_form_D(:,3)=p_fac_onset(1)*fac_onset_form_D(:,1)+p_fac_onset(2);
        fac_corr_info_D.R_onset=fac_R_onset(2,1);
        fac_corr_info_D.P_onset=fac_P_onset(2,1);
        fac_corr_info_D.reg_onset=fac_onset_form_D;   
        if fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)>0
           trial_mod_list_DT(i).fac_onset_corr_D=1;
        elseif fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)<=0
           trial_mod_list_DT(i).fac_onset_corr_D=-1;
        else
           trial_mod_list_DT(i).fac_onset_corr_D=0;
        end
    else
        fac_corr_info_D.R_onset=[];
        fac_corr_info_D.P_onset=[];
        fac_corr_info_D.reg_onset=fac_onset_form_D; 
        trial_mod_list_DT(i).fac_onset_corr_D=[];
    end

    fac_pkt_form_D=nan(size(fac_corr_data_D,2),3);
    for k=1:size(fac_corr_data_D,2)
        if ~isempty(fac_corr_data_D(k).fac_pkt)
            fac_pkt_form_D(k,1)=fac_corr_data_D(k).fac_pkt;
            fac_pkt_form_D(k,2)=fac_corr_data_D(k).CR_pkt;
        end
    end  
    fac_pkt_form_D=fac_pkt_form_D(all(~isnan(fac_pkt_form_D(:,1)),2),:);
    fac_pkt_form_D=fac_pkt_form_D(all(~isinf(fac_pkt_form_D(:,1)),2),:);
    if size(fac_pkt_form_D,1)>=min_corr_tr_num
        [fac_R_pkt,fac_P_pkt]=corrcoef(fac_pkt_form_D(:,1),fac_pkt_form_D(:,2));
        p_fac_pkt=polyfit(fac_pkt_form_D(:,1),fac_pkt_form_D(:,2),1);
        fac_pkt_form_D(:,3)=p_fac_pkt(1)*fac_pkt_form_D(:,1)+p_fac_pkt(2);
        fac_corr_info_D.R_pkt=fac_R_pkt(2,1);
        fac_corr_info_D.P_pkt=fac_P_pkt(2,1);
        fac_corr_info_D.reg_pkt=fac_pkt_form_D;
        if fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)>0
           trial_mod_list_DT(i).fac_pkt_corr_D=1;
        elseif fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)<=0
           trial_mod_list_DT(i).fac_pkt_corr_D=-1;
        else
           trial_mod_list_DT(i).fac_pkt_corr_D=0;
        end
    else
        fac_corr_info_D.R_pkt=[];
        fac_corr_info_D.P_pkt=[];
        fac_corr_info_D.reg_pkt=fac_pkt_form_D; 
        trial_mod_list_DT(i).fac_pkt_corr_D=[];
    end
    
    fac_amp_form_D=nan(size(fac_corr_data_D,2),3);
    for k=1:size(fac_corr_data_D,2)
        if ~isempty(fac_corr_data_D(k).fac_amp)
            fac_amp_form_D(k,1)=fac_corr_data_D(k).fac_amp;
            fac_amp_form_D(k,2)=fac_corr_data_D(k).CR_amp;
        end
    end  
    fac_amp_form_D=fac_amp_form_D(all(~isnan(fac_amp_form_D(:,1)),2),:);
    fac_amp_form_D=fac_amp_form_D(all(~isinf(fac_amp_form_D(:,1)),2),:);
    if size(fac_amp_form_D,1)>=min_corr_tr_num
        [fac_R_amp,fac_P_amp]=corrcoef(fac_amp_form_D(:,1),fac_amp_form_D(:,2));
        p_fac_amp=polyfit(fac_amp_form_D(:,1),fac_amp_form_D(:,2),1);
        fac_amp_form_D(:,3)=p_fac_amp(1)*fac_amp_form_D(:,1)+p_fac_amp(2);
        fac_corr_info_D.R_amp=fac_R_amp(2,1);
        fac_corr_info_D.P_amp=fac_P_amp(2,1);
        fac_corr_info_D.reg_amp=fac_amp_form_D;   
        if fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)>0
           trial_mod_list_DT(i).fac_amp_corr_D=1;
        elseif fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)<=0
           trial_mod_list_DT(i).fac_amp_corr_D=-1;
        else
           trial_mod_list_DT(i).fac_amp_corr_D=0;
        end
    else
        fac_corr_info_D.R_amp=[];
        fac_corr_info_D.P_amp=[];
        fac_corr_info_D.reg_amp=fac_amp_form_D; 
        trial_mod_list_DT(i).fac_amp_corr_D=[];
    end
    
    sup_onset_form_D=nan(size(sup_corr_data_D,2),3);
    for k=1:size(sup_corr_data_D,2)
        if ~isempty(sup_corr_data_D(k).sup_onset)
            sup_onset_form_D(k,1)=sup_corr_data_D(k).sup_onset;
            sup_onset_form_D(k,2)=sup_corr_data_D(k).CR_onset;
        end
    end  
    sup_onset_form_D=sup_onset_form_D(all(~isnan(sup_onset_form_D(:,1)),2),:);
    sup_onset_form_D=sup_onset_form_D(all(~isinf(sup_onset_form_D(:,1)),2),:);
    if size(sup_onset_form_D,1)>=min_corr_tr_num
        [sup_R_onset,sup_P_onset]=corrcoef(sup_onset_form_D(:,1),sup_onset_form_D(:,2));
        p_sup_onset=polyfit(sup_onset_form_D(:,1),sup_onset_form_D(:,2),1);
        sup_onset_form_D(:,3)=p_sup_onset(1)*sup_onset_form_D(:,1)+p_sup_onset(2);
        sup_corr_info_D.R_onset=sup_R_onset(2,1);
        sup_corr_info_D.P_onset=sup_P_onset(2,1);
        sup_corr_info_D.reg_onset=sup_onset_form_D;   
        if sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)>0
           trial_mod_list_DT(i).sup_onset_corr_D=1;
        elseif sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)<=0
           trial_mod_list_DT(i).sup_onset_corr_D=-1;
        else
           trial_mod_list_DT(i).sup_onset_corr_D=0;
        end
    else
        sup_corr_info_D.R_onset=[];
        sup_corr_info_D.P_onset=[];
        sup_corr_info_D.reg_onset=sup_onset_form_D; 
        trial_mod_list_DT(i).sup_onset_corr_D=[];
    end

    sup_pkt_form_D=nan(size(sup_corr_data_D,2),3);
    for k=1:size(sup_corr_data_D,2)
        if ~isempty(sup_corr_data_D(k).sup_pkt)
            sup_pkt_form_D(k,1)=sup_corr_data_D(k).sup_pkt;
            sup_pkt_form_D(k,2)=sup_corr_data_D(k).CR_pkt;
        end
    end  
    sup_pkt_form_D=sup_pkt_form_D(all(~isnan(sup_pkt_form_D(:,1)),2),:);
    sup_pkt_form_D=sup_pkt_form_D(all(~isinf(sup_pkt_form_D(:,1)),2),:);
    if size(sup_pkt_form_D,1)>=min_corr_tr_num
        [sup_R_pkt,sup_P_pkt]=corrcoef(sup_pkt_form_D(:,1),sup_pkt_form_D(:,2));
        p_sup_pkt=polyfit(sup_pkt_form_D(:,1),sup_pkt_form_D(:,2),1);
        sup_pkt_form_D(:,3)=p_sup_pkt(1)*sup_pkt_form_D(:,1)+p_sup_pkt(2);
        sup_corr_info_D.R_pkt=sup_R_pkt(2,1);
        sup_corr_info_D.P_pkt=sup_P_pkt(2,1);
        sup_corr_info_D.reg_pkt=sup_pkt_form_D;
        if sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)>0
           trial_mod_list_DT(i).sup_pkt_corr_D=1;
        elseif sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)<=0
           trial_mod_list_DT(i).sup_pkt_corr_D=-1;
        else
           trial_mod_list_DT(i).sup_pkt_corr_D=0;
        end
    else
        sup_corr_info_D.R_pkt=[];
        sup_corr_info_D.P_pkt=[];
        sup_corr_info_D.reg_pkt=sup_pkt_form_D; 
        trial_mod_list_DT(i).sup_pkt_corr_D=[];
    end
    
    sup_amp_form_D=nan(size(sup_corr_data_D,2),3);
    for k=1:size(sup_corr_data_D,2)
        if ~isempty(sup_corr_data_D(k).sup_amp)
            sup_amp_form_D(k,1)=sup_corr_data_D(k).sup_amp;
            sup_amp_form_D(k,2)=sup_corr_data_D(k).CR_amp;
        end
    end  
    sup_amp_form_D=sup_amp_form_D(all(~isnan(sup_amp_form_D(:,1)),2),:);
    sup_amp_form_D=sup_amp_form_D(all(~isinf(sup_amp_form_D(:,1)),2),:);
    if size(sup_amp_form_D,1)>=min_corr_tr_num
        [sup_R_amp,sup_P_amp]=corrcoef(sup_amp_form_D(:,1),sup_amp_form_D(:,2));
        p_sup_amp=polyfit(sup_amp_form_D(:,1),sup_amp_form_D(:,2),1);
        sup_amp_form_D(:,3)=p_sup_amp(1)*sup_amp_form_D(:,1)+p_sup_amp(2);
        sup_corr_info_D.R_amp=sup_R_amp(2,1);
        sup_corr_info_D.P_amp=sup_P_amp(2,1);
        sup_corr_info_D.reg_amp=sup_amp_form_D;   
        if sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)>0
           trial_mod_list_DT(i).sup_amp_corr_D=1;
        elseif sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)<=0
           trial_mod_list_DT(i).sup_amp_corr_D=-1;
        else
           trial_mod_list_DT(i).sup_amp_corr_D=0;
        end
    else
        sup_corr_info_D.R_amp=[];
        sup_corr_info_D.P_amp=[];
        sup_corr_info_D.reg_amp=sup_amp_form_D; 
        trial_mod_list_DT(i).sup_amp_corr_D=[];
    end
   
    trial_mod_list_DT(i).fac_corr_info_D=fac_corr_info_D;
    trial_mod_list_DT(i).sup_corr_info_D=sup_corr_info_D;     
            
    fac_corr_info_T=struct('R_onset',[],'P_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[]);
    sup_corr_info_T=struct('R_onset',[],'P_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[]);

    fac_onset_form_T=nan(size(fac_corr_data_T,2),3);
    for k=1:size(fac_corr_data_T,2)
        if ~isempty(fac_corr_data_T(k).fac_onset)
            fac_onset_form_T(k,1)=fac_corr_data_T(k).fac_onset;
            fac_onset_form_T(k,2)=fac_corr_data_T(k).CR_onset;
        end
    end  
    fac_onset_form_T=fac_onset_form_T(all(~isnan(fac_onset_form_T(:,1)),2),:);
    fac_onset_form_T=fac_onset_form_T(all(~isinf(fac_onset_form_T(:,1)),2),:);
    if size(fac_onset_form_T,1)>=min_corr_tr_num
        [fac_R_onset,fac_P_onset]=corrcoef(fac_onset_form_T(:,1),fac_onset_form_T(:,2));
        p_fac_onset=polyfit(fac_onset_form_T(:,1),fac_onset_form_T(:,2),1);
        fac_onset_form_T(:,3)=p_fac_onset(1)*fac_onset_form_T(:,1)+p_fac_onset(2);
        fac_corr_info_T.R_onset=fac_R_onset(2,1);
        fac_corr_info_T.P_onset=fac_P_onset(2,1);
        fac_corr_info_T.reg_onset=fac_onset_form_T;   
        if fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)>0
           trial_mod_list_DT(i).fac_onset_corr_T=1;
        elseif fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)<=0
           trial_mod_list_DT(i).fac_onset_corr_T=-1;
        else
           trial_mod_list_DT(i).fac_onset_corr_T=0;
        end
    else
        fac_corr_info_T.R_onset=[];
        fac_corr_info_T.P_onset=[];
        fac_corr_info_T.reg_onset=fac_onset_form_T; 
        trial_mod_list_DT(i).fac_onset_corr_T=[];
    end

    fac_pkt_form_T=nan(size(fac_corr_data_T,2),3);
    for k=1:size(fac_corr_data_T,2)
        if ~isempty(fac_corr_data_T(k).fac_pkt)
            fac_pkt_form_T(k,1)=fac_corr_data_T(k).fac_pkt;
            fac_pkt_form_T(k,2)=fac_corr_data_T(k).CR_pkt;
        end
    end  
    fac_pkt_form_T=fac_pkt_form_T(all(~isnan(fac_pkt_form_T(:,1)),2),:);
    fac_pkt_form_T=fac_pkt_form_T(all(~isinf(fac_pkt_form_T(:,1)),2),:);
    if size(fac_pkt_form_T,1)>=min_corr_tr_num
        [fac_R_pkt,fac_P_pkt]=corrcoef(fac_pkt_form_T(:,1),fac_pkt_form_T(:,2));
        p_fac_pkt=polyfit(fac_pkt_form_T(:,1),fac_pkt_form_T(:,2),1);
        fac_pkt_form_T(:,3)=p_fac_pkt(1)*fac_pkt_form_T(:,1)+p_fac_pkt(2);
        fac_corr_info_T.R_pkt=fac_R_pkt(2,1);
        fac_corr_info_T.P_pkt=fac_P_pkt(2,1);
        fac_corr_info_T.reg_pkt=fac_pkt_form_T;
        if fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)>0
           trial_mod_list_DT(i).fac_pkt_corr_T=1;
        elseif fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)<=0
           trial_mod_list_DT(i).fac_pkt_corr_T=-1;
        else
           trial_mod_list_DT(i).fac_pkt_corr_T=0;
        end
    else
        fac_corr_info_T.R_pkt=[];
        fac_corr_info_T.P_pkt=[];
        fac_corr_info_T.reg_pkt=fac_pkt_form_T; 
        trial_mod_list_DT(i).fac_pkt_corr_T=[];
    end
    
    fac_amp_form_T=nan(size(fac_corr_data_T,2),3);
    for k=1:size(fac_corr_data_T,2)
        if ~isempty(fac_corr_data_T(k).fac_amp)
            fac_amp_form_T(k,1)=fac_corr_data_T(k).fac_amp;
            fac_amp_form_T(k,2)=fac_corr_data_T(k).CR_amp;
        end
    end  
    fac_amp_form_T=fac_amp_form_T(all(~isnan(fac_amp_form_T(:,1)),2),:);
    fac_amp_form_T=fac_amp_form_T(all(~isinf(fac_amp_form_T(:,1)),2),:);
    if size(fac_amp_form_T,1)>=min_corr_tr_num
        [fac_R_amp,fac_P_amp]=corrcoef(fac_amp_form_T(:,1),fac_amp_form_T(:,2));
        p_fac_amp=polyfit(fac_amp_form_T(:,1),fac_amp_form_T(:,2),1);
        fac_amp_form_T(:,3)=p_fac_amp(1)*fac_amp_form_T(:,1)+p_fac_amp(2);
        fac_corr_info_T.R_amp=fac_R_amp(2,1);
        fac_corr_info_T.P_amp=fac_P_amp(2,1);
        fac_corr_info_T.reg_amp=fac_amp_form_T;   
        if fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)>0
           trial_mod_list_DT(i).fac_amp_corr_T=1;
        elseif fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)<=0
           trial_mod_list_DT(i).fac_amp_corr_T=-1;
        else
           trial_mod_list_DT(i).fac_amp_corr_T=0;
        end
    else
        fac_corr_info_T.R_amp=[];
        fac_corr_info_T.P_amp=[];
        fac_corr_info_T.reg_amp=fac_amp_form_T; 
        trial_mod_list_DT(i).fac_amp_corr_T=[];
    end
    
    sup_onset_form_T=nan(size(sup_corr_data_T,2),3);
    for k=1:size(sup_corr_data_T,2)
        if ~isempty(sup_corr_data_T(k).sup_onset)
            sup_onset_form_T(k,1)=sup_corr_data_T(k).sup_onset;
            sup_onset_form_T(k,2)=sup_corr_data_T(k).CR_onset;
        end
    end  
    sup_onset_form_T=sup_onset_form_T(all(~isnan(sup_onset_form_T(:,1)),2),:);
    sup_onset_form_T=sup_onset_form_T(all(~isinf(sup_onset_form_T(:,1)),2),:);
    if size(sup_onset_form_T,1)>=min_corr_tr_num
        [sup_R_onset,sup_P_onset]=corrcoef(sup_onset_form_T(:,1),sup_onset_form_T(:,2));
        p_sup_onset=polyfit(sup_onset_form_T(:,1),sup_onset_form_T(:,2),1);
        sup_onset_form_T(:,3)=p_sup_onset(1)*sup_onset_form_T(:,1)+p_sup_onset(2);
        sup_corr_info_T.R_onset=sup_R_onset(2,1);
        sup_corr_info_T.P_onset=sup_P_onset(2,1);
        sup_corr_info_T.reg_onset=sup_onset_form_T;   
        if sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)>0
           trial_mod_list_DT(i).sup_onset_corr_T=1;
        elseif sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)<=0
           trial_mod_list_DT(i).sup_onset_corr_T=-1;
        else
           trial_mod_list_DT(i).sup_onset_corr_T=0;
        end
    else
        sup_corr_info_T.R_onset=[];
        sup_corr_info_T.P_onset=[];
        sup_corr_info_T.reg_onset=sup_onset_form_T; 
        trial_mod_list_DT(i).sup_onset_corr_T=[];
    end

    sup_pkt_form_T=nan(size(sup_corr_data_T,2),3);
    for k=1:size(sup_corr_data_T,2)
        if ~isempty(sup_corr_data_T(k).sup_pkt)
            sup_pkt_form_T(k,1)=sup_corr_data_T(k).sup_pkt;
            sup_pkt_form_T(k,2)=sup_corr_data_T(k).CR_pkt;
        end
    end  
    sup_pkt_form_T=sup_pkt_form_T(all(~isnan(sup_pkt_form_T(:,1)),2),:);
    sup_pkt_form_T=sup_pkt_form_T(all(~isinf(sup_pkt_form_T(:,1)),2),:);
    if size(sup_pkt_form_T,1)>=min_corr_tr_num
        [sup_R_pkt,sup_P_pkt]=corrcoef(sup_pkt_form_T(:,1),sup_pkt_form_T(:,2));
        p_sup_pkt=polyfit(sup_pkt_form_T(:,1),sup_pkt_form_T(:,2),1);
        sup_pkt_form_T(:,3)=p_sup_pkt(1)*sup_pkt_form_T(:,1)+p_sup_pkt(2);
        sup_corr_info_T.R_pkt=sup_R_pkt(2,1);
        sup_corr_info_T.P_pkt=sup_P_pkt(2,1);
        sup_corr_info_T.reg_pkt=sup_pkt_form_T;
        if sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)>0
           trial_mod_list_DT(i).sup_pkt_corr_T=1;
        elseif sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)<=0
           trial_mod_list_DT(i).sup_pkt_corr_T=-1;
        else
           trial_mod_list_DT(i).sup_pkt_corr_T=0;
        end
    else
        sup_corr_info_T.R_pkt=[];
        sup_corr_info_T.P_pkt=[];
        sup_corr_info_T.reg_pkt=sup_pkt_form_T; 
        trial_mod_list_DT(i).sup_pkt_corr_T=[];
    end
    
    sup_amp_form_T=nan(size(sup_corr_data_T,2),3);
    for k=1:size(sup_corr_data_T,2)
        if ~isempty(sup_corr_data_T(k).sup_amp)
            sup_amp_form_T(k,1)=sup_corr_data_T(k).sup_amp;
            sup_amp_form_T(k,2)=sup_corr_data_T(k).CR_amp;
        end
    end  
    sup_amp_form_T=sup_amp_form_T(all(~isnan(sup_amp_form_T(:,1)),2),:);
    sup_amp_form_T=sup_amp_form_T(all(~isinf(sup_amp_form_T(:,1)),2),:);
    if size(sup_amp_form_T,1)>=min_corr_tr_num
        [sup_R_amp,sup_P_amp]=corrcoef(sup_amp_form_T(:,1),sup_amp_form_T(:,2));
        p_sup_amp=polyfit(sup_amp_form_T(:,1),sup_amp_form_T(:,2),1);
        sup_amp_form_T(:,3)=p_sup_amp(1)*sup_amp_form_T(:,1)+p_sup_amp(2);
        sup_corr_info_T.R_amp=sup_R_amp(2,1);
        sup_corr_info_T.P_amp=sup_P_amp(2,1);
        sup_corr_info_T.reg_amp=sup_amp_form_T;   
        if sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)>0
           trial_mod_list_DT(i).sup_amp_corr_T=1;
        elseif sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)<=0
           trial_mod_list_DT(i).sup_amp_corr_T=-1;
        else
           trial_mod_list_DT(i).sup_amp_corr_T=0;
        end
    else
        sup_corr_info_T.R_amp=[];
        sup_corr_info_T.P_amp=[];
        sup_corr_info_T.reg_amp=sup_amp_form_T; 
        trial_mod_list_DT(i).sup_amp_corr_T=[];
    end
   
    trial_mod_list_DT(i).fac_corr_info_T=fac_corr_info_T;
    trial_mod_list_DT(i).sup_corr_info_T=sup_corr_info_T; 
    
    fac_corr_info_all=struct('R_onset',[],'P_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[]);
    sup_corr_info_all=struct('R_onset',[],'P_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[]);

    fac_onset_form_all=nan(size(fac_corr_data_D,2)+size(fac_corr_data_T,2),3);
    for k=1:size(fac_corr_data_D,2)
        if ~isempty(fac_corr_data_D(k).fac_onset)
            fac_onset_form_all(k,1)=fac_corr_data_D(k).fac_onset;
            fac_onset_form_all(k,2)=fac_corr_data_D(k).CR_onset;
        end
    end  
    for k=size(fac_corr_data_D,2)+1:size(fac_corr_data_D,2)+size(fac_corr_data_T,2)
        if ~isempty(fac_corr_data_T(k-size(fac_corr_data_D,2)).fac_onset)
            fac_onset_form_all(k,1)=fac_corr_data_T(k-size(fac_corr_data_D,2)).fac_onset;
            fac_onset_form_all(k,2)=fac_corr_data_T(k-size(fac_corr_data_D,2)).CR_onset;
        end
    end  
    fac_onset_form_all=fac_onset_form_all(all(~isnan(fac_onset_form_all(:,1)),2),:);
    fac_onset_form_all=fac_onset_form_all(all(~isinf(fac_onset_form_all(:,1)),2),:);
    if size(fac_onset_form_all,1)>=min_corr_tr_num
        [fac_R_onset,fac_P_onset]=corrcoef(fac_onset_form_all(:,1),fac_onset_form_all(:,2));
        p_fac_onset=polyfit(fac_onset_form_all(:,1),fac_onset_form_all(:,2),1);
        fac_onset_form_all(:,3)=p_fac_onset(1)*fac_onset_form_all(:,1)+p_fac_onset(2);
        fac_corr_info_all.R_onset=fac_R_onset(2,1);
        fac_corr_info_all.P_onset=fac_P_onset(2,1);
        fac_corr_info_all.reg_onset=fac_onset_form_all;   
        if fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)>0
           trial_mod_list_DT(i).fac_onset_corr_all=1;
        elseif fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)<=0
           trial_mod_list_DT(i).fac_onset_corr_all=-1;
        else
           trial_mod_list_DT(i).fac_onset_corr_all=0;
        end
    else
        fac_corr_info_all.R_onset=[];
        fac_corr_info_all.P_onset=[];
        fac_corr_info_all.reg_onset=fac_onset_form_all; 
        trial_mod_list_DT(i).fac_onset_corr_all=[];
    end

    fac_pkt_form_all=nan(size(fac_corr_data_D,2)+size(fac_corr_data_T,2),3);
    for k=1:size(fac_corr_data_D,2)
        if ~isempty(fac_corr_data_D(k).fac_pkt)
            fac_pkt_form_all(k,1)=fac_corr_data_D(k).fac_pkt;
            fac_pkt_form_all(k,2)=fac_corr_data_D(k).CR_pkt;
        end
    end  
    for k=size(fac_corr_data_D,2)+1:size(fac_corr_data_D,2)+size(fac_corr_data_T,2)
        if ~isempty(fac_corr_data_T(k-size(fac_corr_data_D,2)).fac_pkt)
            fac_pkt_form_all(k,1)=fac_corr_data_T(k-size(fac_corr_data_D,2)).fac_pkt;
            fac_pkt_form_all(k,2)=fac_corr_data_T(k-size(fac_corr_data_D,2)).CR_pkt;
        end
    end  
    fac_pkt_form_all=fac_pkt_form_all(all(~isnan(fac_pkt_form_all(:,1)),2),:);
    fac_pkt_form_all=fac_pkt_form_all(all(~isinf(fac_pkt_form_all(:,1)),2),:);
    if size(fac_pkt_form_all,1)>=min_corr_tr_num
        [fac_R_pkt,fac_P_pkt]=corrcoef(fac_pkt_form_all(:,1),fac_pkt_form_all(:,2));
        p_fac_pkt=polyfit(fac_pkt_form_all(:,1),fac_pkt_form_all(:,2),1);
        fac_pkt_form_all(:,3)=p_fac_pkt(1)*fac_pkt_form_all(:,1)+p_fac_pkt(2);
        fac_corr_info_all.R_pkt=fac_R_pkt(2,1);
        fac_corr_info_all.P_pkt=fac_P_pkt(2,1);
        fac_corr_info_all.reg_pkt=fac_pkt_form_all;
        if fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)>0
           trial_mod_list_DT(i).fac_pkt_corr_all=1;
        elseif fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)<=0
           trial_mod_list_DT(i).fac_pkt_corr_all=-1;
        else
           trial_mod_list_DT(i).fac_pkt_corr_all=0;
        end
    else
        fac_corr_info_all.R_pkt=[];
        fac_corr_info_all.P_pkt=[];
        fac_corr_info_all.reg_pkt=fac_pkt_form_all; 
        trial_mod_list_DT(i).fac_pkt_corr_all=[];
    end
    
    fac_amp_form_all=nan(size(fac_corr_data_D,2)+size(fac_corr_data_T,2),3);
    for k=1:size(fac_corr_data_D,2)
        if ~isempty(fac_corr_data_D(k).fac_amp)
            fac_amp_form_all(k,1)=fac_corr_data_D(k).fac_amp;
            fac_amp_form_all(k,2)=fac_corr_data_D(k).CR_amp;
        end
    end
    for k=size(fac_corr_data_D,2)+1:size(fac_corr_data_D,2)+size(fac_corr_data_T,2)
        if ~isempty(fac_corr_data_T(k-size(fac_corr_data_D,2)).fac_amp)
            fac_amp_form_all(k,1)=fac_corr_data_T(k-size(fac_corr_data_D,2)).fac_amp;
            fac_amp_form_all(k,2)=fac_corr_data_T(k-size(fac_corr_data_D,2)).CR_amp;
        end
    end  
    fac_amp_form_all=fac_amp_form_all(all(~isnan(fac_amp_form_all(:,1)),2),:);
    fac_amp_form_all=fac_amp_form_all(all(~isinf(fac_amp_form_all(:,1)),2),:);
    if size(fac_amp_form_all,1)>=min_corr_tr_num
        [fac_R_amp,fac_P_amp]=corrcoef(fac_amp_form_all(:,1),fac_amp_form_all(:,2));
        p_fac_amp=polyfit(fac_amp_form_all(:,1),fac_amp_form_all(:,2),1);
        fac_amp_form_all(:,3)=p_fac_amp(1)*fac_amp_form_all(:,1)+p_fac_amp(2);
        fac_corr_info_all.R_amp=fac_R_amp(2,1);
        fac_corr_info_all.P_amp=fac_P_amp(2,1);
        fac_corr_info_all.reg_amp=fac_amp_form_all;   
        if fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)>0
           trial_mod_list_DT(i).fac_amp_corr_all=1;
        elseif fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)<=0
           trial_mod_list_DT(i).fac_amp_corr_all=-1;
        else
           trial_mod_list_DT(i).fac_amp_corr_all=0;
        end
    else
        fac_corr_info_all.R_amp=[];
        fac_corr_info_all.P_amp=[];
        fac_corr_info_all.reg_amp=fac_amp_form_all; 
        trial_mod_list_DT(i).fac_amp_corr_all=[];
    end
    
    sup_onset_form_all=nan(size(sup_corr_data_D,2)+size(sup_corr_data_T,2),3);
    for k=1:size(sup_corr_data_D,2)
        if ~isempty(sup_corr_data_D(k).sup_onset)
            sup_onset_form_all(k,1)=sup_corr_data_D(k).sup_onset;
            sup_onset_form_all(k,2)=sup_corr_data_D(k).CR_onset;
        end
    end
    for k=size(sup_corr_data_D,2)+1:size(sup_corr_data_D,2)+size(sup_corr_data_T,2)
        if ~isempty(sup_corr_data_T(k-size(sup_corr_data_D,2)).sup_onset)
            sup_onset_form_all(k,1)=sup_corr_data_T(k-size(sup_corr_data_D,2)).sup_onset;
            sup_onset_form_all(k,2)=sup_corr_data_T(k-size(sup_corr_data_D,2)).CR_onset;
        end
    end  
    sup_onset_form_all=sup_onset_form_all(all(~isnan(sup_onset_form_all(:,1)),2),:);
    sup_onset_form_all=sup_onset_form_all(all(~isinf(sup_onset_form_all(:,1)),2),:);
    if size(sup_onset_form_all,1)>=min_corr_tr_num
        [sup_R_onset,sup_P_onset]=corrcoef(sup_onset_form_all(:,1),sup_onset_form_all(:,2));
        p_sup_onset=polyfit(sup_onset_form_all(:,1),sup_onset_form_all(:,2),1);
        sup_onset_form_all(:,3)=p_sup_onset(1)*sup_onset_form_all(:,1)+p_sup_onset(2);
        sup_corr_info_all.R_onset=sup_R_onset(2,1);
        sup_corr_info_all.P_onset=sup_P_onset(2,1);
        sup_corr_info_all.reg_onset=sup_onset_form_all;   
        if sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)>0
           trial_mod_list_DT(i).sup_onset_corr_all=1;
        elseif sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)<=0
           trial_mod_list_DT(i).sup_onset_corr_all=-1;
        else
           trial_mod_list_DT(i).sup_onset_corr_all=0;
        end
    else
        sup_corr_info_all.R_onset=[];
        sup_corr_info_all.P_onset=[];
        sup_corr_info_all.reg_onset=sup_onset_form_all; 
        trial_mod_list_DT(i).sup_onset_corr_all=[];
    end

    sup_pkt_form_all=nan(size(sup_corr_data_D,2)+size(sup_corr_data_T,2),3);
    for k=1:size(sup_corr_data_D,2)
        if ~isempty(sup_corr_data_D(k).sup_pkt)
            sup_pkt_form_all(k,1)=sup_corr_data_D(k).sup_pkt;
            sup_pkt_form_all(k,2)=sup_corr_data_D(k).CR_pkt;
        end
    end  
    for k=size(sup_corr_data_D,2)+1:size(sup_corr_data_D,2)+size(sup_corr_data_T,2)
        if ~isempty(sup_corr_data_T(k-size(sup_corr_data_D,2)).sup_pkt)
            sup_pkt_form_all(k,1)=sup_corr_data_T(k-size(sup_corr_data_D,2)).sup_pkt;
            sup_pkt_form_all(k,2)=sup_corr_data_T(k-size(sup_corr_data_D,2)).CR_pkt;
        end
    end 
    sup_pkt_form_all=sup_pkt_form_all(all(~isnan(sup_pkt_form_all(:,1)),2),:);
    sup_pkt_form_all=sup_pkt_form_all(all(~isinf(sup_pkt_form_all(:,1)),2),:);
    if size(sup_pkt_form_all,1)>=min_corr_tr_num
        [sup_R_pkt,sup_P_pkt]=corrcoef(sup_pkt_form_all(:,1),sup_pkt_form_all(:,2));
        p_sup_pkt=polyfit(sup_pkt_form_all(:,1),sup_pkt_form_all(:,2),1);
        sup_pkt_form_all(:,3)=p_sup_pkt(1)*sup_pkt_form_all(:,1)+p_sup_pkt(2);
        sup_corr_info_all.R_pkt=sup_R_pkt(2,1);
        sup_corr_info_all.P_pkt=sup_P_pkt(2,1);
        sup_corr_info_all.reg_pkt=sup_pkt_form_all;
        if sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)>0
           trial_mod_list_DT(i).sup_pkt_corr_all=1;
        elseif sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)<=0
           trial_mod_list_DT(i).sup_pkt_corr_all=-1;
        else
           trial_mod_list_DT(i).sup_pkt_corr_all=0;
        end
    else
        sup_corr_info_all.R_pkt=[];
        sup_corr_info_all.P_pkt=[];
        sup_corr_info_all.reg_pkt=sup_pkt_form_all; 
        trial_mod_list_DT(i).sup_pkt_corr_all=[];
    end
    
    sup_amp_form_all=nan(size(sup_corr_data_D,2)+size(sup_corr_data_T,2),3);
    for k=1:size(sup_corr_data_D,2)
        if ~isempty(sup_corr_data_D(k).sup_amp)
            sup_amp_form_all(k,1)=sup_corr_data_D(k).sup_amp;
            sup_amp_form_all(k,2)=sup_corr_data_D(k).CR_amp;
        end
    end  
    for k=size(sup_corr_data_D,2)+1:size(sup_corr_data_D,2)+size(sup_corr_data_T,2)
        if ~isempty(sup_corr_data_T(k-size(sup_corr_data_D,2)).sup_amp)
            sup_amp_form_all(k,1)=sup_corr_data_T(k-size(sup_corr_data_D,2)).sup_amp;
            sup_amp_form_all(k,2)=sup_corr_data_T(k-size(sup_corr_data_D,2)).CR_amp;
        end
    end  
    sup_amp_form_all=sup_amp_form_all(all(~isnan(sup_amp_form_all(:,1)),2),:);
    sup_amp_form_all=sup_amp_form_all(all(~isinf(sup_amp_form_all(:,1)),2),:);
    if size(sup_amp_form_all,1)>=min_corr_tr_num
        [sup_R_amp,sup_P_amp]=corrcoef(sup_amp_form_all(:,1),sup_amp_form_all(:,2));
        p_sup_amp=polyfit(sup_amp_form_all(:,1),sup_amp_form_all(:,2),1);
        sup_amp_form_all(:,3)=p_sup_amp(1)*sup_amp_form_all(:,1)+p_sup_amp(2);
        sup_corr_info_all.R_amp=sup_R_amp(2,1);
        sup_corr_info_all.P_amp=sup_P_amp(2,1);
        sup_corr_info_all.reg_amp=sup_amp_form_all;   
        if sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)>0
           trial_mod_list_DT(i).sup_amp_corr_all=1;
        elseif sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)<=0
           trial_mod_list_DT(i).sup_amp_corr_all=-1;
        else
           trial_mod_list_DT(i).sup_amp_corr_all=0;
        end
    else
        sup_corr_info_all.R_amp=[];
        sup_corr_info_all.P_amp=[];
        sup_corr_info_all.reg_amp=sup_amp_form_all; 
        trial_mod_list_DT(i).sup_amp_corr_all=[];
    end
   
    trial_mod_list_DT(i).fac_corr_info_all=fac_corr_info_all;
    trial_mod_list_DT(i).sup_corr_info_all=sup_corr_info_all; 
    
    other_corr_info_D_11=other_corr(trial_mod_list_DT(i).(other_corr_data_D1),other_item_mod_11,other_item_bhv_1,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_D_11=other_corr_info_D_11;
    
    other_corr_info_T_11=other_corr(trial_mod_list_DT(i).(other_corr_data_T1),other_item_mod_11,other_item_bhv_1,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_T_11=other_corr_info_T_11;
    
    other_corr_info_D_12=other_corr(trial_mod_list_DT(i).(other_corr_data_D2),other_item_mod_12,other_item_bhv_1,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_D_12=other_corr_info_D_12;
    
    other_corr_info_T_12=other_corr(trial_mod_list_DT(i).(other_corr_data_T2),other_item_mod_12,other_item_bhv_1,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_T_12=other_corr_info_T_12;    
    
    other_corr_info_D_21=other_corr(trial_mod_list_DT(i).(other_corr_data_D1),other_item_mod_21,other_item_bhv_2,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_D_21=other_corr_info_D_21;
    
    other_corr_info_T_21=other_corr(trial_mod_list_DT(i).(other_corr_data_T1),other_item_mod_21,other_item_bhv_2,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_T_21=other_corr_info_T_21;
    
    other_corr_info_D_22=other_corr(trial_mod_list_DT(i).(other_corr_data_D2),other_item_mod_22,other_item_bhv_2,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_D_22=other_corr_info_D_22;
    
    other_corr_info_T_22=other_corr(trial_mod_list_DT(i).(other_corr_data_T2),other_item_mod_22,other_item_bhv_2,min_corr_tr_num);
    trial_mod_list_DT(i).other_corr_info_T_22=other_corr_info_T_22;
end

function corr_info=other_corr(corr_data,item_mod,item_bhv,min_corr_tr_num)
    corr_info=struct('R',[],'P',[],'reg',[]);
    corr_form=nan(size(corr_data,2),3);
    for k=1:size(corr_data,2)
        if ~isempty(corr_data(k).(item_mod))
            corr_form(k,1)=corr_data(k).(item_mod);
            corr_form(k,2)=corr_data(k).(item_bhv);
        end
    end  
    corr_form=corr_form(all(~isnan(corr_form(:,1)),2),:);
    corr_form=corr_form(all(~isinf(corr_form(:,1)),2),:);
    if size(corr_form,1)>=min_corr_tr_num
        [R,P]=corrcoef(corr_form(:,1),corr_form(:,2));
        p_sup_pkt=polyfit(corr_form(:,1),corr_form(:,2),1);
        corr_form(:,3)=p_sup_pkt(1)*corr_form(:,1)+p_sup_pkt(2);
        corr_info.R=R(2,1);
        corr_info.P=P(2,1);
        corr_info.reg=corr_form;
    else
        corr_info.R=[];
        corr_info.P=[];
        corr_info.reg=corr_form; 
    end
end