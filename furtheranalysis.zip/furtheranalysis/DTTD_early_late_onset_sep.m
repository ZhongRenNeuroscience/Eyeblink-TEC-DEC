%Seperate trials by early and late CR onset in both delay and trace session

pack=TD_list;
EL_sep=struct('cell_ID',[],'mod_type',[],'blk_onset_D',[],'early_blk_D',[],'early_info_D',[],'early_blk_mean_D',[],'late_blk_D',[],'late_info_D',[],...
       'late_blk_mean_D',[],'early_ifr_D',[],'early_ifr_mean_D',[],'late_ifr_D',[],'late_ifr_mean_D',[],'blk_onset_T',[],...
       'early_blk_T',[],'early_info_T',[],'early_blk_mean_T',[],'late_blk_T',[],'late_info_T',[],'late_blk_mean_T',[],'early_ifr_T',[],...
       'early_ifr_mean_T',[],'late_ifr_T',[],'late_ifr_mean_T',[]);

fs=0;
% first loop for each cell
for i=1:size(pack,2)
    if pack(i).CR_fac_D > 0 && pack(i).CR_fac_T > 0
       all_info='all_info_D';
       t_test=230;
       fs=fs+1;
       blk_onset=zeros(size(pack(i).(all_info).ttt.CR_trial,2),2);
%        for each trial
       for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
           blk_onset(j,1)=j;
           blk_onset(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;        
       end   
       blk_onset(any(isnan(blk_onset),2),:) = [];
       [rank,idx]=sort(blk_onset(:,2));
       if length(rank) < 40
          early=idx(find(idx,20,'first'),1);
          late=idx(find(idx,20,'last'),1);
       else
          sz_mod=mod(length(rank),2);
          sz_group=(length(rank)-sz_mod)/2;
          early=idx(find(idx,sz_group+sz_mod,'first'),1);
          late=idx(find(idx,sz_group,'last'),1);
       end   
       early_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       early_ifr_form=zeros(1580,size(early,1));
       early_blk_form=zeros(1550,size(early,1));
       late_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       late_ifr_form=zeros(1580,size(late,1));
       late_blk_form=zeros(1550,size(late,1));
       for n=1:size(early,1)
           nn=blk_onset(early(n,1),1);
           early_info(n).trial_num=nn;
           early_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           early_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           early_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           early_ifr_form(:,n)=early_info(n).ifr;
           early_blk_form(:,n)=early_info(n).blk;
       end 
       for n=1:size(late,1)
           nn=blk_onset(late(n,1),1);
           late_info(n).trial_num=nn;
           late_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           late_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           late_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           late_ifr_form(:,n)=late_info(n).ifr;
           late_blk_form(:,n)=late_info(n).blk;
       end
       early_ifr_mean=zeros(1580,2);
       late_ifr_mean=zeros(1580,2);
       early_ifr_mean(:,1)=-540:1:1039;
       early_ifr_mean(:,2)=mean(early_ifr_form,2)*100;
       ear_bsl=mean(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_sd=std(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_shrld=ear_bsl+3*ear_sd;  
       for t=541:541+t_test
           early_tt=t-541;
           if early_ifr_mean(t,2)>=ear_shrld
              break
           end
       end
       if early_tt==t_test
          early_tt=NaN;
       end    

       late_ifr_mean(:,1)=-540:1:1039;
       late_ifr_mean(:,2)=mean(late_ifr_form,2)*100;
       late_bsl=mean(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_sd=std(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_shrld=late_bsl+3*late_sd;
       for t=541:541+t_test
           late_tt=t-541;
           if late_ifr_mean(t,2)>=late_shrld
              break
           end
       end
       if late_tt==t_test
          late_tt=NaN;
       end

       early_blk=zeros(1550,2);
       late_blk=zeros(1550,2);
       early_blk(:,1)=-550:1:999;
       early_blk(:,2)=mean(early_blk_form,2);
       late_blk(:,1)=-550:1:999;
       late_blk(:,2)=mean(late_blk_form,2);

    EL_sep(fs).cell_ID=pack(i).cell_ID;
    EL_sep(fs).mod_type=1;
    EL_sep(fs).blk_onset_D=blk_onset;
    EL_sep(fs).early_blk_D=nanmean([early_info.cr_onset]);
    EL_sep(fs).early_info_D=early_info;
    EL_sep(fs).early_blk_mean_D=early_blk;    
    EL_sep(fs).late_blk_D=nanmean([late_info.cr_onset]);
    EL_sep(fs).late_info_D=late_info;
    EL_sep(fs).late_blk_mean_D=late_blk; 
    EL_sep(fs).early_ifr_D=early_tt;
    EL_sep(fs).early_ifr_mean_D=early_ifr_mean;    
    EL_sep(fs).late_ifr_D=late_tt;
    EL_sep(fs).late_ifr_mean_D=late_ifr_mean;     

% %     for trace part
    all_info='all_info_T';
    t_test=480;
       blk_onset=zeros(size(pack(i).(all_info).ttt.CR_trial,2),2);
%        for each trial
       for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
           blk_onset(j,1)=j;
           blk_onset(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;        
       end   
       blk_onset(any(isnan(blk_onset),2),:) = [];
       [rank,idx]=sort(blk_onset(:,2));
       if length(rank) < 40
          early=idx(find(idx,20,'first'),1);
          late=idx(find(idx,20,'last'),1);
       else
          sz_mod=mod(length(rank),2);
          sz_group=(length(rank)-sz_mod)/2;
          early=idx(find(idx,sz_group+sz_mod,'first'),1);
          late=idx(find(idx,sz_group,'last'),1);
       end   
       early_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       early_ifr_form=zeros(1580,size(early,1));
       early_blk_form=zeros(1550,size(early,1));
       late_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       late_ifr_form=zeros(1580,size(late,1));
       late_blk_form=zeros(1550,size(late,1));
       for n=1:size(early,1)
           nn=blk_onset(early(n,1),1);
           early_info(n).trial_num=nn;
           early_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           early_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           early_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           early_ifr_form(:,n)=early_info(n).ifr;
           early_blk_form(:,n)=early_info(n).blk;
       end 
       for n=1:size(late,1)
           nn=blk_onset(late(n,1),1);
           late_info(n).trial_num=nn;
           late_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           late_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           late_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           late_ifr_form(:,n)=late_info(n).ifr;
           late_blk_form(:,n)=late_info(n).blk;
       end
       early_ifr_mean=zeros(1580,2);
       late_ifr_mean=zeros(1580,2);
       early_ifr_mean(:,1)=-540:1:1039;
       early_ifr_mean(:,2)=mean(early_ifr_form,2)*100;
       ear_bsl=mean(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_sd=std(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_shrld=ear_bsl+3*ear_sd;  
       for t=541:541+t_test
           early_tt=t-541;
           if early_ifr_mean(t,2)>=ear_shrld
              break
           end
       end
       if early_tt==t_test
          early_tt=NaN;
       end    

       late_ifr_mean(:,1)=-540:1:1039;
       late_ifr_mean(:,2)=mean(late_ifr_form,2)*100;
       late_bsl=mean(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_sd=std(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_shrld=late_bsl+3*late_sd;
       for t=541:541+t_test
           late_tt=t-541;
           if late_ifr_mean(t,2)>=late_shrld
              break
           end
       end
       if late_tt==t_test
          late_tt=NaN;
       end

       early_blk=zeros(1550,2);
       late_blk=zeros(1550,2);
       early_blk(:,1)=-550:1:999;
       early_blk(:,2)=mean(early_blk_form,2);
       late_blk(:,1)=-550:1:999;
       late_blk(:,2)=mean(late_blk_form,2);

    EL_sep(fs).blk_onset_T=blk_onset;
    EL_sep(fs).early_blk_T=nanmean([early_info.cr_onset]);
    EL_sep(fs).early_info_T=early_info;
    EL_sep(fs).early_blk_mean_T=early_blk;    
    EL_sep(fs).late_blk_T=nanmean([late_info.cr_onset]);
    EL_sep(fs).late_info_T=late_info;
    EL_sep(fs).late_blk_mean_T=late_blk; 
    EL_sep(fs).early_ifr_T=early_tt;
    EL_sep(fs).early_ifr_mean_T=early_ifr_mean;    
    EL_sep(fs).late_ifr_T=late_tt;
    EL_sep(fs).late_ifr_mean_T=late_ifr_mean;     
    end
    
    % % For suppression neurons
    if pack(i).CR_sup_D > 0 && pack(i).CR_sup_T > 0
       all_info='all_info_D';
       t_test=230;
       fs=fs+1;
       blk_onset=zeros(size(pack(i).(all_info).ttt.CR_trial,2),2);
%        for each trial
       for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
           blk_onset(j,1)=j;
           blk_onset(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;        
       end   
       blk_onset(any(isnan(blk_onset),2),:) = [];
       [rank,idx]=sort(blk_onset(:,2));
       if length(rank) < 40
          early=idx(find(idx,20,'first'),1);
          late=idx(find(idx,20,'last'),1);
       else
          sz_mod=mod(length(rank),2);
          sz_group=(length(rank)-sz_mod)/2;
          early=idx(find(idx,sz_group+sz_mod,'first'),1);
          late=idx(find(idx,sz_group,'last'),1);
       end   
       early_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       early_ifr_form=zeros(1580,size(early,1));
       early_blk_form=zeros(1550,size(early,1));
       late_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       late_ifr_form=zeros(1580,size(late,1));
       late_blk_form=zeros(1550,size(late,1));
       for n=1:size(early,1)
           nn=blk_onset(early(n,1),1);
           early_info(n).trial_num=nn;
           early_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           early_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           early_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           early_ifr_form(:,n)=early_info(n).ifr;
           early_blk_form(:,n)=early_info(n).blk;
       end 
       for n=1:size(late,1)
           nn=blk_onset(late(n,1),1);
           late_info(n).trial_num=nn;
           late_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           late_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           late_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           late_ifr_form(:,n)=late_info(n).ifr;
           late_blk_form(:,n)=late_info(n).blk;
       end
       early_ifr_mean=zeros(1580,2);
       late_ifr_mean=zeros(1580,2);
       early_ifr_mean(:,1)=-540:1:1039;
       early_ifr_mean(:,2)=mean(early_ifr_form,2)*100;
       ear_bsl=mean(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_sd=std(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_shrld=ear_bsl-3*ear_sd;  
       for t=541:541+t_test
           early_tt=t-541;
           if early_ifr_mean(t,2)<=ear_shrld
              break
           end
       end
       if early_tt==t_test
          early_tt=NaN;
       end    

       late_ifr_mean(:,1)=-540:1:1039;
       late_ifr_mean(:,2)=mean(late_ifr_form,2)*100;
       late_bsl=mean(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_sd=std(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_shrld=late_bsl-3*late_sd;
       for t=541:541+t_test
           late_tt=t-541;
           if late_ifr_mean(t,2)<=late_shrld
              break
           end
       end
       if late_tt==t_test
          late_tt=NaN;
       end

       early_blk=zeros(1550,2);
       late_blk=zeros(1550,2);
       early_blk(:,1)=-550:1:999;
       early_blk(:,2)=mean(early_blk_form,2);
       late_blk(:,1)=-550:1:999;
       late_blk(:,2)=mean(late_blk_form,2);

    EL_sep(fs).cell_ID=pack(i).cell_ID;
    EL_sep(fs).mod_type=2;
    EL_sep(fs).blk_onset_D=blk_onset;
    EL_sep(fs).early_blk_D=nanmean([early_info.cr_onset]);
    EL_sep(fs).early_info_D=early_info;
    EL_sep(fs).early_blk_mean_D=early_blk;    
    EL_sep(fs).late_blk_D=nanmean([late_info.cr_onset]);
    EL_sep(fs).late_info_D=late_info;
    EL_sep(fs).late_blk_mean_D=late_blk; 
    EL_sep(fs).early_ifr_D=early_tt;
    EL_sep(fs).early_ifr_mean_D=early_ifr_mean;    
    EL_sep(fs).late_ifr_D=late_tt;
    EL_sep(fs).late_ifr_mean_D=late_ifr_mean;     

% %     for trace part
    all_info='all_info_T';
    t_test=480;
       blk_onset=zeros(size(pack(i).(all_info).ttt.CR_trial,2),2);
%        for each trial
       for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
           blk_onset(j,1)=j;
           blk_onset(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;        
       end   
       blk_onset(any(isnan(blk_onset),2),:) = [];
       [rank,idx]=sort(blk_onset(:,2));
       if length(rank) < 40
          early=idx(find(idx,20,'first'),1);
          late=idx(find(idx,20,'last'),1);
       else
          sz_mod=mod(length(rank),2);
          sz_group=(length(rank)-sz_mod)/2;
          early=idx(find(idx,sz_group+sz_mod,'first'),1);
          late=idx(find(idx,sz_group,'last'),1);
       end   
       early_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       early_ifr_form=zeros(1580,size(early,1));
       early_blk_form=zeros(1550,size(early,1));
       late_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
       late_ifr_form=zeros(1580,size(late,1));
       late_blk_form=zeros(1550,size(late,1));
       for n=1:size(early,1)
           nn=blk_onset(early(n,1),1);
           early_info(n).trial_num=nn;
           early_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           early_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           early_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           early_ifr_form(:,n)=early_info(n).ifr;
           early_blk_form(:,n)=early_info(n).blk;
       end 
       for n=1:size(late,1)
           nn=blk_onset(late(n,1),1);
           late_info(n).trial_num=nn;
           late_info(n).cr_onset=pack(i).(all_info).ttt.CR_trial(nn).blk_info_new.CR_onset*1000;
           late_info(n).ifr=pack(i).(all_info).ttt.CR_trial(nn).ifr_smooth(:,3);
           late_info(n).blk=pack(i).(all_info).ttt.CR_trial(nn).blk_smth(:,2);
           late_ifr_form(:,n)=late_info(n).ifr;
           late_blk_form(:,n)=late_info(n).blk;
       end
       early_ifr_mean=zeros(1580,2);
       late_ifr_mean=zeros(1580,2);
       early_ifr_mean(:,1)=-540:1:1039;
       early_ifr_mean(:,2)=mean(early_ifr_form,2)*100;
       ear_bsl=mean(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_sd=std(early_ifr_mean(early_ifr_mean(:,1) < 0 & early_ifr_mean(:,1) >= -500,2));
       ear_shrld=ear_bsl-3*ear_sd;  
       for t=541:541+t_test
           early_tt=t-541;
           if early_ifr_mean(t,2)<=ear_shrld
              break
           end
       end
       if early_tt==t_test
          early_tt=NaN;
       end    

       late_ifr_mean(:,1)=-540:1:1039;
       late_ifr_mean(:,2)=mean(late_ifr_form,2)*100;
       late_bsl=mean(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_sd=std(late_ifr_mean(late_ifr_mean(:,1)<0 & late_ifr_mean(:,1) >= -500,2));
       late_shrld=late_bsl-3*late_sd;
       for t=541:541+t_test
           late_tt=t-541;
           if late_ifr_mean(t,2)<=late_shrld
              break
           end
       end
       if late_tt==t_test
          late_tt=NaN;
       end

       early_blk=zeros(1550,2);
       late_blk=zeros(1550,2);
       early_blk(:,1)=-550:1:999;
       early_blk(:,2)=mean(early_blk_form,2);
       late_blk(:,1)=-550:1:999;
       late_blk(:,2)=mean(late_blk_form,2);

    EL_sep(fs).blk_onset_T=blk_onset;
    EL_sep(fs).early_blk_T=nanmean([early_info.cr_onset]);
    EL_sep(fs).early_info_T=early_info;
    EL_sep(fs).early_blk_mean_T=early_blk;    
    EL_sep(fs).late_blk_T=nanmean([late_info.cr_onset]);
    EL_sep(fs).late_info_T=late_info;
    EL_sep(fs).late_blk_mean_T=late_blk; 
    EL_sep(fs).early_ifr_T=early_tt;
    EL_sep(fs).early_ifr_mean_T=early_ifr_mean;    
    EL_sep(fs).late_ifr_T=late_tt;
    EL_sep(fs).late_ifr_mean_T=late_ifr_mean;     
    end
    
    
    
end
         