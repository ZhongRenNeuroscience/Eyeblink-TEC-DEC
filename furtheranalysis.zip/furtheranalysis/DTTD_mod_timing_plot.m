figure;
for i=1:size(mod_t,2)
    subplot(7,5,i)
    plot(mod_t(i).psth_info_1(301:1550,1),mod_t(i).psth_info_1(301:1550,3),'c-');
    hold on
    plot(mod_t(i).psth_info_2(301:1550,1),mod_t(i).psth_info_2(301:1550,3),'m-');
    hold on
    plot(mod_t(i).blk_info_1(301:1550,1),mod_t(i).blk_info_1(301:1550,2),'k-');
    hold on
    plot(mod_t(i).blk_info_2(301:1550,1),mod_t(i).blk_info_2(301:1550,2),'k--');
    hold on
    
    ymax1=max(mod_t(i).psth_info_1(301:1550,3));
    ymax2=max(mod_t(i).psth_info_2(301:1550,3));
    ymax=max([ymax1 ymax2])*1.05;
    xlim([-250 1000]);
    ylim([-5 ymax]);
    line([0 0],[0, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
    line([250 250],[0, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
    title(['cell ' num2str(mod_t(i).cell_ID)]);
end

% cell_ID=45;
% bar=5;
% win=5;
% figure;
% j=find([mod_t.cell_ID]==cell_ID);
% smth_form=zeros(1000/bar+1,17);
% for i=1:1000/bar+1
%     smth_form(i,1)=(i-1)*bar-250;
%     smth_form(i,2)=mean(mod_t(j).blk_info_1(301+bar*i-bar+1:301+bar*i,2));
%     smth_form(i,3)=mean(mod_t(j).blk_info_2(301+bar*i-bar+1:301+bar*i,2));
%     smth_form(i,4)=mean(mod_t(j).psth_info_1(301+bar*i-bar+1:301+bar*i,3));
%     smth_form(i,5)=mean(mod_t(j).psth_info_2(301+bar*i-bar+1:301+bar*i,3));
%     smth_form(i,10)=mean(mod_t(j).blk_info_1(301+bar*i-bar+1:301+bar*i,4));
%     smth_form(i,11)=mean(mod_t(j).blk_info_1(301+bar*i-bar+1:301+bar*i,5));
%     smth_form(i,14)=mean(mod_t(j).blk_info_2(301+bar*i-bar+1:301+bar*i,4));
%     smth_form(i,15)=mean(mod_t(j).blk_info_2(301+bar*i-bar+1:301+bar*i,5));
% end
% 
% smth_form(:,6)=smooth(smth_form(:,2),win);
% smth_form(:,7)=smooth(smth_form(:,3),win);
% smth_form(:,8)=smooth(smth_form(:,4),win);
% smth_form(:,9)=smooth(smth_form(:,5),win);
% smth_form(:,12)=smooth(smth_form(:,10),win);
% smth_form(:,13)=smooth(smth_form(:,11),win);
% smth_form(:,16)=smooth(smth_form(:,14),win);
% smth_form(:,17)=smooth(smth_form(:,15),win);
% 
% subplot(2,1,1)
% plot(smth_form(:,1),smth_form(:,6),'c-')
% hold on
% plot(smth_form(:,1),smth_form(:,7),'m-')
% hold on
% % plot(smth_form(:,1),smth_form(:,12),'Color',[0.5 0.5 0.5])
% % hold on
% % plot(smth_form(:,1),smth_form(:,13),'Color',[0.5 0.5 0.5])
% % hold on
% % plot(smth_form(:,1),smth_form(:,16),'Color',[0.5 0.5 0.5])
% % hold on
% % plot(smth_form(:,1),smth_form(:,17),'Color',[0.5 0.5 0.5])
% ymax1=max(smth_form(:,6));
% ymax2=max(smth_form(:,7));
% ymax=max([ymax1 ymax2])*1.05;
% ylabel('Eyelid closure (%)');
% xticks([0 250 500]);
% xlim([-100 700]);
% ylim([-5 ymax]);
% title(['Cell' num2str(cell_ID)]);
% 
% subplot(2,1,2)
% stairs(smth_form(:,1),smth_form(:,8),'c-')
% hold on
% stairs(smth_form(:,1),smth_form(:,9),'m-')
% hold on
% ymax1=max(smth_form(:,8));
% ymax2=max(smth_form(:,9));
% ymax=max([ymax1 ymax2])*1.1;
% ymin1=min(smth_form(:,8));
% ymin2=min(smth_form(:,9));
% ymin=min([ymin1 ymin2])*0.9;
% xlabel('Time (ms)');
% ylabel('Relative firing rate (%)');
% xticks([0 250 500]);
% xlim([-100 700]);
% ylim([ymin ymax]);

% cell_ID=45;
% bar=5;
% win=5;
% figure;
% j=find([mod_t.cell_ID]==cell_ID);
% smth_form=zeros(1000/bar+1,17);
% for i=1:1000/bar+1
%     smth_form(i,1)=(i-1)*bar-250;
%     smth_form(i,2)=mean(mod_t(j).blk_info_1(301+bar*i-bar+1:301+bar*i,2));
%     smth_form(i,3)=mean(mod_t(j).blk_info_2(301+bar*i-bar+1:301+bar*i,2));
%     smth_form(i,4)=mean(mod_t(j).psth_info_1(301+bar*i-bar+1:301+bar*i,3));
%     smth_form(i,5)=mean(mod_t(j).psth_info_2(301+bar*i-bar+1:301+bar*i,3));
%     smth_form(i,10)=mean(mod_t(j).blk_info_1(301+bar*i-bar+1:301+bar*i,4));
%     smth_form(i,11)=mean(mod_t(j).blk_info_1(301+bar*i-bar+1:301+bar*i,5));
%     smth_form(i,14)=mean(mod_t(j).blk_info_2(301+bar*i-bar+1:301+bar*i,4));
%     smth_form(i,15)=mean(mod_t(j).blk_info_2(301+bar*i-bar+1:301+bar*i,5));
% end
% 
% smth_form(:,6)=smooth(smth_form(:,2),win);
% smth_form(:,7)=smooth(smth_form(:,3),win);
% smth_form(:,8)=smooth(smth_form(:,4),win);
% smth_form(:,9)=smooth(smth_form(:,5),win);
% smth_form(:,12)=smooth(smth_form(:,10),win);
% smth_form(:,13)=smooth(smth_form(:,11),win);
% smth_form(:,16)=smooth(smth_form(:,14),win);
% smth_form(:,17)=smooth(smth_form(:,15),win);
% 
% subplot(2,1,1)
% plot(smth_form(:,1),smth_form(:,6),'m-')
% hold on
% plot(smth_form(:,1),smth_form(:,7),'c-')
% hold on
% % plot(smth_form(:,1),smth_form(:,12),'Color',[0.5 0.5 0.5])
% % hold on
% % plot(smth_form(:,1),smth_form(:,13),'Color',[0.5 0.5 0.5])
% % hold on
% % plot(smth_form(:,1),smth_form(:,16),'Color',[0.5 0.5 0.5])
% % hold on
% % plot(smth_form(:,1),smth_form(:,17),'Color',[0.5 0.5 0.5])
% ymax1=max(smth_form(:,6));
% ymax2=max(smth_form(:,7));
% ymax=max([ymax1 ymax2])*1.05;
% ylabel('Eyelid closure (%)');
% xticks([0 250 500]);
% xlim([-100 700]);
% ylim([-5 ymax]);
% title(['Cell' num2str(cell_ID)]);
% 
% subplot(2,1,2)
% stairs(smth_form(:,1),smth_form(:,8),'m-')
% hold on
% stairs(smth_form(:,1),smth_form(:,9),'c-')
% hold on
% ymax1=max(smth_form(:,8));
% ymax2=max(smth_form(:,9));
% ymax=max([ymax1 ymax2])*1.1;
% ymin1=min(smth_form(:,8));
% ymin2=min(smth_form(:,9));
% ymin=min([ymin1 ymin2])*0.9;
% xlabel('Time (ms)');
% ylabel('Relative firing rate (%)');
% xticks([0 250 500]);
% xlim([-100 700]);
% ylim([ymin ymax]);

