file=loco_com;
t_post=500;
cell_ID=200;


figure;
subplot(1,2,1)
hold on
CH_loco_form=zeros(size(file(cell_ID).CH_locs,2),size(file(cell_ID).CH_locs(1).velo_info,1));
for i=1:size(file(cell_ID).CH_locs,2)
    CH_loco_form(i,:)=smooth(file(cell_ID).CH_locs(i).velo_info(:,2));
    plot(file(cell_ID).CH_locs(i).velo_info(:,1)*1000,CH_loco_form(i,:),'linewidth',0.5,'color',[0.9 0.9 0.9])
    hold on
end
% ymin_loco=min(min(CH_loco_form,[],1))-0.01;
% ymax_loco=max(max(CH_loco_form,[],1))+0.01;
ymin_loco=-0.02;
ymax_loco=0.1;
plot(file(cell_ID).CH_locs(1).velo_info(:,1)*1000,mean(CH_loco_form,1),'Color',[0 0 0],'LineWidth',2)
if t_post==500
line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
elseif t_post==250
line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
end
xlim([-500 500]);
xticks(-500:250:500);
yticks(0:0.02:0.1);
ylim([ymin_loco, ymax_loco]);
xlabel('time(ms)');
ylabel('Speed (m/s)') 
title('Locomotion CR trials');

subplot(1,2,2)
hold on
CL_loco_form=zeros(size(file(cell_ID).CL_locs,2),size(file(cell_ID).CL_locs(1).velo_info,1));
for i=1:size(file(cell_ID).CL_locs,2)
    CL_loco_form(i,:)=smooth(file(cell_ID).CL_locs(i).velo_info(:,2));
    plot(file(cell_ID).CL_locs(i).velo_info(:,1)*1000,CL_loco_form(i,:),'linewidth',0.5,'color',[0.9 0.9 0.9])
    hold on
end
plot(file(cell_ID).CL_locs(1).velo_info(:,1)*1000,mean(CL_loco_form,1),'Color',[0 0 0],'LineWidth',2)
if t_post==500
line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
elseif t_post==250
line([0 0],[ymin_loco, ymax_loco],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[ymin_loco, ymax_loco],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
end
xlim([-500 500]);
xticks(-500:250:500);
yticks(0:0.02:0.1);
ylim([ymin_loco, ymax_loco]);
xlabel('time(ms)');
ylabel('Speed (m/s)')    
title('No/Low locomotion CR trials');