% Populational heat map and average PSTH plot

% Data arrangement
list=trace_list_mPFC_ready;
mod_list=PFC_mod_list_T;
bhv_list=blk_sss_T_PFC;
mod_type='mod_type_T';
mod_info='mod_info_T';
align_info_1='align_info';
align_info_2='align_info';
t_pre=-250;
t_post=1000;
bin=50;
step=10;

map=[0,0,0
0,0,0.025
0,0,0.05
0,0,0.075
0,0,0.1
0,0,0.125
0,0,0.15
0,0,0.175
0,0,0.2
0,0,0.225
0,0,0.25
0,0,0.275
0,0,0.3
0,0,0.325
0,0,0.35
0,0,0.375
0,0,0.4
0,0,0.425
0,0,0.45
0,0,0.475
0,0,0.5
0,0,0.525
0,0,0.55
0,0,0.575
0,0,0.6
0,0,0.625
0,0,0.65
0,0,0.675
0,0,0.7
0,0,0.725
0,0,0.75
0,0,0.775
0,0,0.8
0,0,0.825
0,0,0.85
0,0,0.875
0,0,0.9
0,0,0.925
0,0,0.95
0,0,0.975
0,0,1
0.025,0.025,1
0.05,0.05,1
0.075,0.075,1
0.1,0.1,1
0.125,0.125,1
0.15,0.15,1
0.175,0.175,1
0.2,0.2,1
0.225,0.225,1
0.25,0.25,1
0.275,0.275,1
0.3,0.3,1
0.325,0.325,1
0.35,0.35,1
0.375,0.375,1
0.4,0.4,1
0.425,0.425,1
0.45,0.45,1
0.475,0.475,1
0.5,0.5,1
0.525,0.525,1
0.55,0.55,1
0.575,0.575,1
0.6,0.6,1
0.625,0.625,1
0.65,0.65,1
0.675,0.675,1
0.7,0.7,1
0.725,0.725,1
0.75,0.75,1
0.775,0.775,1
0.8,0.8,1
0.825,0.825,1
0.85,0.85,1
0.875,0.875,1
0.9,0.9,1 
0.925,0.925,1
0.95,0.95,1
0.975,0.975,1
1,1,1];

mod_cell_number=struct('fac_cell',[],'sup_cell',[],'non_cell',[]);
fac_cell=struct('cell_ID',[],'session_ID',[],'sort_t',[]);
sup_cell=struct('cell_ID',[],'session_ID',[],'sort_t',[]);
non_cell=struct('cell_ID',[],'session_ID',[],'sort_t',[]);

fac_idx=0;
sup_idx=0;
non_idx=0;

for i=1:size(list,2)
    if mod_list(i).(mod_type)==1
       fac_idx=fac_idx+1;
       fac_cell(fac_idx).cell_ID=i;
       fac_cell(fac_idx).session_ID=mod_list(i).file_name;
    end        
%     if (~isempty(mod_list(i).(align_info_1).CR_fac) && ~isempty(mod_list(i).(align_info_2).CR_fac))
%        fac_idx=fac_idx+1;
%        fac_cell(fac_idx).cell_ID=i;
%        fac_cell(fac_idx).session_ID=mod_list(i).file_name;
%     end
%     if (~isempty(mod_list(i).(align_info_1).CR_sup) && ~isempty(mod_list(i).(align_info_2).CR_sup))
%        sup_idx=sup_idx+1;
%        sup_cell(sup_idx).cell_ID=i; 
%        sup_cell(sup_idx).session_ID=mod_list(i).file_name;
%     end
%     if (isempty(mod_list(i).(align_info_1).CR_fac) || isempty(mod_list(i).(align_info_2).CR_fac)) && (isempty(mod_list(i).(align_info_1).CR_sup) || isempty(mod_list(i).(align_info_2).CR_sup))
%        non_idx=non_idx+1;
%        non_cell(non_idx).cell_ID=i;   
%        non_cell(non_idx).session_ID=mod_list(i).file_name;
%     end  
% %     elseif (~isempty(list(i).(align_info_1)) || ~isempty(list(i).(align_info_2))) && (~isempty(list(i).(align_info_1)) || ~isempty(list(i).(align_info_2)))
% %        if ~isempty(list(i).(align_info_1).CR_fac)
% %           fac_judge_1=list(i).(align_info_1).CR_fac(1).peak-list(i).(align_info_1).bsl_frq_ex;
% %        else
% %           fac_judge_1=0; 
% %        end
% %        if ~isempty(list(i).(align_info_2).CR_fac)
% %           fac_judge_2=list(i).(align_info_2).CR_fac(1).peak-list(i).(align_info_2).bsl_frq_ex;
% %        else
% %           fac_judge_2=0; 
% %        end 
% %        if ~isempty(list(i).(align_info_1).CR_sup)
% %           sup_judge_1=list(i).(align_info_1).CR_sup(1).peak-list(i).(align_info_1).bsl_frq_ex;
% %        else
% %           sup_judge_1=0; 
% %        end
% %        if ~isempty(list(i).(align_info_2).CR_sup)
% %           sup_judge_2=list(i).(align_info_2).CR_sup(1).peak-list(i).(align_info_2).bsl_frq_ex;
% %        else
% %           sup_judge_2=0; 
% %        end 
% %        if fac_judge_1+fac_judge_2+sup_judge_1+sup_judge_2>=0
% %           fac_idx=fac_idx+1;
% %           fac_cell(fac_idx).cell_ID=i;       
% %        elseif fac_judge_1+fac_judge_2+sup_judge_1+sup_judge_2<0 
% %           sup_idx=sup_idx+1;
% %           sup_cell(sup_idx).cell_ID=i;            
% %        end

end

bin_num=(-t_pre+t_post)/step+1;
% facilitation neuron raw data
fac_norm_raw_1=zeros(size(fac_cell,2),bin_num);
fac_norm_raw_2=zeros(size(fac_cell,2),bin_num);
fac_norm_raw_sub=zeros(size(fac_cell,2),(-t_pre+250)/step);
fac_prb_raw_1=zeros(size(fac_cell,2),bin_num);
fac_prb_raw_2=zeros(size(fac_cell,2),bin_num);
fac_prb_raw_sub=zeros(size(fac_cell,2),bin_num);
fac_mod_onset_map_1=zeros(size(fac_cell,2),bin_num);
fac_pk=zeros(size(fac_cell,2),1);
for i=1:size(fac_cell,2)
    cell_ID=fac_cell(i).cell_ID;
    t_start_1=find(list(cell_ID).(align_info_1).psth_ex(:,1)==t_pre,1,'first');
    for j=1:bin_num
        t_idx=t_start_1-bin/2+(j-1)*step;
        fac_norm_raw_1(i,j)=mean(list(cell_ID).(align_info_1).psth_ex(t_idx:t_idx+bin-1,2))/list(cell_ID).(align_info_1).bsl_frq_ex*100;       
    end
    t_start_2=find(list(cell_ID).(align_info_2).psth_ex(:,1)==t_pre,1,'first');
    for j=1:bin_num
        t_idx=t_start_2-bin/2+(j-1)*step;
        fac_norm_raw_2(i,j)=mean(list(cell_ID).(align_info_2).psth_ex(t_idx:t_idx+bin-1,2))/list(cell_ID).(align_info_2).bsl_frq_ex*100;       
    end   
    for j=1:(-t_pre+250)/step
        fac_norm_raw_sub(i,j)=fac_norm_raw_2(i,j)-fac_norm_raw_1(i,j);       
    end   
        
%     t_start_1=find(list(cell_ID).(align_info_1).psth_prb.Gau_psth_shft(:,1)==t_pre,1,'first');
%     prb_bsl_mean_1=mean(list(cell_ID).(align_info_1).psth_prb.Gau_psth_shft(t_start_1:t_start_1-t_pre-1,2));
%     for j=1:bin_num
%         t_idx=t_start_1-bin/2+(j-1)*step;
%         fac_prb_raw_1(i,j)=mean(list(cell_ID).(align_info_1).psth_prb.Gau_psth_shft(t_idx:t_idx+bin-1,2))/prb_bsl_mean_1*100;       
%     end
%     t_start_2=find(list(cell_ID).(align_info_2).psth_prb.Gau_psth_shft(:,1)==t_pre,1,'first');
%     prb_bsl_mean_2=mean(list(cell_ID).(align_info_2).psth_prb.Gau_psth_shft(t_start_1:t_start_1-t_pre-1,2));
%     for j=1:bin_num
%         t_idx=t_start_2-bin/2+(j-1)*step;
%         fac_prb_raw_2(i,j)=mean(list(cell_ID).(align_info_2).psth_prb.Gau_psth_shft(t_idx:t_idx+bin-1,2))/prb_bsl_mean_2*100;   
%     end
%     for j=1:bin_num
%         fac_prb_raw_sub(i,j)=fac_prb_raw_2(i,j)-fac_prb_raw_1(i,j);       
%     end
% %     if ~isempty(list(cell_ID).(align_info_1).CR_fac)
% %        fac_pk(i,1)=list(cell_ID).(align_info_1).CR_fac(1).peak/list(cell_ID).(align_info_1).bsl_frq_ex*100;
% %     else
% %        fac_pk(i,1)=max(list(cell_ID).(align_info_1).psth_ex(t_start_1-t_pre:t_start_1-t_pre+250,2));
% %     end
    
%     fac_pk(i,1)=sum(fac_raw_2(i,26:75));

% %   for InP neurons
%     if ~isempty(mod_list(cell_ID).(align_info_1).CR_fac(1).t_onset)
%        fac_pk(i,1)=mod_list(cell_ID).(align_info_1).CR_fac(1).t_onset;
%     else
%        fac_pk(i,1)=max(mod_list(cell_ID).(align_info_1).psth_ex(551:551+t_post,2))-1;
%     end

% %   for PFC neurons
      fac_pk(i,1)=mod_list(cell_ID).(mod_info).hww_1;

      fac_cell(i).sort_t=fac_pk(i,1);
%     t_mod_onset_idx_1=round(fac_pk(i,1)/step)+(-t_pre/step)+1;
%     fac_mod_onset_map_1(i,t_mod_onset_idx_1)=1;
end
[pk_sort,pk_idx] = sort(fac_pk,'descend');
fac_sort_1=fac_norm_raw_1(pk_idx,:);
fac_sort_2=fac_norm_raw_2(pk_idx,:);
fac_sort_3=fac_norm_raw_sub(pk_idx,:);
fac_sort_4=fac_prb_raw_1(pk_idx,:);
fac_sort_5=fac_prb_raw_2(pk_idx,:);
fac_sort_6=fac_prb_raw_sub(pk_idx,:);
[~,index1]=sortrows([fac_cell.sort_t].'); 
fac_cell=fac_cell(index1); 
clear index1

figure;
subplot(1,2,1)
h=heatmap(fac_sort_1,'GridVisible','off','Colormap',hot);
h.ColorLimits = [100 250];

subplot(1,2,2)
for n=1:size(fac_cell,2)
    session_idx=find(strcmp({bhv_list.session_path},fac_cell(n).session_ID));       
    plot(bhv_list(session_idx).CR_onset,n,'*','Color',[1 0 1])
    hold on    
end
xlim([t_pre t_post]);
ylim([0 size(fac_cell,2)+1]);
xticks([-500 -250 0 250 500 750 1000]);

% figure;
% h=heatmap(fac_sort_2,'GridVisible','off','Colormap',hot);
% h.ColorLimits = [100 160];
% figure;
% h=heatmap(fac_sort_3,'GridVisible','off','Colormap',parula);
% h.ColorLimits = [-20 20];
% figure;
% h=heatmap(fac_sort_4,'GridVisible','off','Colormap',hot);
% h.ColorLimits = [100 160];
% figure;
% h=heatmap(fac_sort_5,'GridVisible','off','Colormap',hot);
% h.ColorLimits = [100 160];
% figure;
% h=heatmap(fac_sort_6,'GridVisible','off','Colormap',parula);
% h.ColorLimits = [-20 20];

figure;
for i=1:length(pk_sort)
    plot(round(pk_sort(length(pk_sort)-i+1,1)/step),i,'k+')
    hold on  
end
xlim([t_pre/step t_post/step]);
ylim([0 size(fac_cell,2)+1]);


fac_norm_mean_sd=zeros(9,bin_num);
for i=1:bin_num
    fac_norm_mean_sd(1,i)=t_pre+(i-1)*step;
    fac_norm_mean_sd(2,i)=mean(fac_sort_1(:,i));
    fac_norm_mean_sd(3,i)=std(fac_sort_1(:,i));
    fac_norm_mean_sd(4,i)=fac_norm_mean_sd(2,i)+fac_norm_mean_sd(3,i)/sqrt(size(fac_cell,2));
    fac_norm_mean_sd(5,i)=fac_norm_mean_sd(2,i)-fac_norm_mean_sd(3,i)/sqrt(size(fac_cell,2));
    fac_norm_mean_sd(6,i)=mean(fac_sort_2(:,i));
    fac_norm_mean_sd(7,i)=std(fac_sort_2(:,i));
    fac_norm_mean_sd(8,i)=fac_norm_mean_sd(6,i)+fac_norm_mean_sd(7,i)/sqrt(size(fac_cell,2));
    fac_norm_mean_sd(9,i)=fac_norm_mean_sd(6,i)-fac_norm_mean_sd(7,i)/sqrt(size(fac_cell,2));
end

figure;
plot(fac_norm_mean_sd(1,:),smooth(fac_norm_mean_sd(2,:),3),'k-')
hold on
plot(fac_norm_mean_sd(1,:),smooth(fac_norm_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
hold on
plot(fac_norm_mean_sd(1,:),smooth(fac_norm_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
hold on 
xlim([t_pre t_post]);
ylim([90 500]);
xticks([-500 -250 0 250 500 750 1000]);

% figure;
% plot(fac_norm_mean_sd(1,:),smooth(fac_norm_mean_sd(6,:),3),'k-')
% hold on
% plot(fac_norm_mean_sd(1,:),smooth(fac_norm_mean_sd(8,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(fac_norm_mean_sd(1,:),smooth(fac_norm_mean_sd(9,:),3),'Color',[0.5 0.5 0.5])
% hold on
% xlim([t_pre t_post]);
% ylim([90 180]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% fac_prb_mean_sd=zeros(9,bin_num);
% for i=1:bin_num
%     fac_prb_mean_sd(1,i)=t_pre+(i-1)*step;
%     fac_prb_mean_sd(2,i)=mean(fac_sort_4(:,i));
%     fac_prb_mean_sd(3,i)=std(fac_sort_4(:,i));
%     fac_prb_mean_sd(4,i)=fac_prb_mean_sd(2,i)+fac_prb_mean_sd(3,i)/sqrt(size(fac_cell,2));
%     fac_prb_mean_sd(5,i)=fac_prb_mean_sd(2,i)-fac_prb_mean_sd(3,i)/sqrt(size(fac_cell,2));
%     fac_prb_mean_sd(6,i)=mean(fac_sort_5(:,i));
%     fac_prb_mean_sd(7,i)=std(fac_sort_5(:,i));
%     fac_prb_mean_sd(8,i)=fac_prb_mean_sd(6,i)+fac_prb_mean_sd(7,i)/sqrt(size(fac_cell,2));
%     fac_prb_mean_sd(9,i)=fac_prb_mean_sd(6,i)-fac_prb_mean_sd(7,i)/sqrt(size(fac_cell,2));
% end
% 
% figure;
% plot(fac_prb_mean_sd(1,:),smooth(fac_prb_mean_sd(2,:),3),'k-')
% hold on
% plot(fac_prb_mean_sd(1,:),smooth(fac_prb_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(fac_prb_mean_sd(1,:),smooth(fac_prb_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre t_post]);
% ylim([90 180]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% figure;
% plot(fac_prb_mean_sd(1,:),smooth(fac_prb_mean_sd(6,:),3),'k-')
% hold on
% plot(fac_prb_mean_sd(1,:),smooth(fac_prb_mean_sd(8,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(fac_prb_mean_sd(1,:),smooth(fac_prb_mean_sd(9,:),3),'Color',[0.5 0.5 0.5])
% hold on
% xlim([t_pre t_post]);
% ylim([90 180]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% fac_sub_norm_mean_sd=zeros(5,(-t_pre+250)/step);
% for i=1:(-t_pre+250)/step
%     fac_sub_norm_mean_sd(1,i)=t_pre+(i-1)*step;
%     fac_sub_norm_mean_sd(2,i)=mean(fac_sort_3(:,i));
%     fac_sub_norm_mean_sd(3,i)=std(fac_sort_3(:,i));
%     fac_sub_norm_mean_sd(4,i)=fac_sub_norm_mean_sd(2,i)+fac_sub_norm_mean_sd(3,i)/sqrt(size(fac_cell,2));
%     fac_sub_norm_mean_sd(5,i)=fac_sub_norm_mean_sd(2,i)-fac_sub_norm_mean_sd(3,i)/sqrt(size(fac_cell,2));
% end
% 
% figure;
% plot(fac_sub_norm_mean_sd(1,:),smooth(fac_sub_norm_mean_sd(2,:),3),'k-')
% hold on
% plot(fac_sub_norm_mean_sd(1,:),smooth(fac_sub_norm_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(fac_sub_norm_mean_sd(1,:),smooth(fac_sub_norm_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre 250]);
% ylim([-40 40]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% fac_sub_prb_mean_sd=zeros(5,bin_num);
% for i=1:bin_num
%     fac_sub_prb_mean_sd(1,i)=t_pre+(i-1)*step;
%     fac_sub_prb_mean_sd(2,i)=mean(fac_sort_6(:,i));
%     fac_sub_prb_mean_sd(3,i)=std(fac_sort_6(:,i));
%     fac_sub_prb_mean_sd(4,i)=fac_sub_prb_mean_sd(2,i)+fac_sub_prb_mean_sd(3,i)/sqrt(size(fac_cell,2));
%     fac_sub_prb_mean_sd(5,i)=fac_sub_prb_mean_sd(2,i)-fac_sub_prb_mean_sd(3,i)/sqrt(size(fac_cell,2));
% end
% 
% figure;
% plot(fac_sub_prb_mean_sd(1,:),smooth(fac_sub_prb_mean_sd(2,:),3),'k-')
% hold on
% plot(fac_sub_prb_mean_sd(1,:),smooth(fac_sub_prb_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(fac_sub_prb_mean_sd(1,:),smooth(fac_sub_prb_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre t_post]);
% ylim([-40 40]);
% xticks([-500 -250 0 250 500 750 1000]);



% % suppression neurons plot
% sup_norm_raw_1=zeros(size(sup_cell,2),bin_num);
% sup_norm_raw_2=zeros(size(sup_cell,2),bin_num);
% sup_norm_raw_sub=zeros(size(sup_cell,2),(-t_pre+250)/step);
% sup_prb_raw_1=zeros(size(sup_cell,2),bin_num);
% sup_prb_raw_2=zeros(size(sup_cell,2),bin_num);
% sup_prb_raw_sub=zeros(size(sup_cell,2),bin_num);
% sup_mod_onset_map_1=zeros(size(sup_cell,2),bin_num);
% sup_pk=zeros(size(sup_cell,2),1);
% for i=1:size(sup_cell,2)
%     cell_ID=sup_cell(i).cell_ID;
%     t_start_1=find(list(cell_ID).(align_info_1).psth_ex(:,1)==t_pre,1,'first');
%     for j=1:bin_num
%         t_idx=t_start_1-bin/2+(j-1)*step;
%         sup_norm_raw_1(i,j)=mean(list(cell_ID).(align_info_1).psth_ex(t_idx:t_idx+bin-1,2))/list(cell_ID).(align_info_1).bsl_frq_ex*100;       
%     end
%     t_start_2=find(list(cell_ID).(align_info_2).psth_ex(:,1)==t_pre,1,'first');
%     for j=1:bin_num
%         t_idx=t_start_2-bin/2+(j-1)*step;
%         sup_norm_raw_2(i,j)=mean(list(cell_ID).(align_info_2).psth_ex(t_idx:t_idx+bin-1,2))/list(cell_ID).(align_info_2).bsl_frq_ex*100;       
%     end   
%     for j=1:(-t_pre+250)/step
%         sup_norm_raw_sub(i,j)=sup_norm_raw_2(i,j)-sup_norm_raw_1(i,j);       
%     end   
%         
% %     t_start_1=find(list(cell_ID).(align_info_1).psth_prb.Gau_psth_shft(:,1)==t_pre,1,'first');
% %     prb_bsl_mean_1=mean(list(cell_ID).(align_info_1).psth_prb.Gau_psth_shft(t_start_1:t_start_1-t_pre-1,2));
% %     for j=1:bin_num
% %         t_idx=t_start_1-bin/2+(j-1)*step;
% %         sup_prb_raw_1(i,j)=mean(list(cell_ID).(align_info_1).psth_prb.Gau_psth_shft(t_idx:t_idx+bin-1,2))/prb_bsl_mean_1*100;       
% %     end
% %     t_start_2=find(list(cell_ID).(align_info_2).psth_prb.Gau_psth_shft(:,1)==t_pre,1,'first');
% %     prb_bsl_mean_2=mean(list(cell_ID).(align_info_2).psth_prb.Gau_psth_shft(t_start_1:t_start_1-t_pre-1,2));
% %     for j=1:bin_num
% %         t_idx=t_start_2-bin/2+(j-1)*step;
% %         sup_prb_raw_2(i,j)=mean(list(cell_ID).(align_info_2).psth_prb.Gau_psth_shft(t_idx:t_idx+bin-1,2))/prb_bsl_mean_2*100;   
% %     end
% %     for j=1:bin_num
% %         sup_prb_raw_sub(i,j)=sup_prb_raw_2(i,j)-sup_prb_raw_1(i,j);       
% %     end
% % %     if ~isempty(list(cell_ID).(align_info_1).CR_fac)
% % %        fac_pk(i,1)=list(cell_ID).(align_info_1).CR_fac(1).peak/list(cell_ID).(align_info_1).bsl_frq_ex*100;
% % %     else
% % %        fac_pk(i,1)=max(list(cell_ID).(align_info_1).psth_ex(t_start_1-t_pre:t_start_1-t_pre+250,2));
% % %     end
%     
% %     fac_pk(i,1)=sum(fac_raw_2(i,26:75));
% 
%     if ~isempty(mod_list(cell_ID).(align_info_1).CR_sup(1).t_onset)
%        sup_pk(i,1)=mod_list(cell_ID).(align_info_1).CR_sup(1).t_onset;
%     else
%        sup_pk(i,1)=max(mod_list(cell_ID).(align_info_1).psth_ex(551:551+t_post,2))-1;
%     end
% %     t_mod_onset_idx_1=round(sup_pk(i,1)/step)+(-t_pre/step)+1;
% %     sup_mod_onset_map_1(i,t_mod_onset_idx_1)=1;
%     sup_cell(i).sort_t=sup_pk(i,1);
% end
% [pk_sort,pk_idx] = sort(sup_pk,'descend');
% sup_sort_1=sup_norm_raw_1(pk_idx,:);
% sup_sort_2=sup_norm_raw_2(pk_idx,:);
% sup_sort_3=sup_norm_raw_sub(pk_idx,:);
% sup_sort_4=sup_prb_raw_1(pk_idx,:);
% sup_sort_5=sup_prb_raw_2(pk_idx,:);
% sup_sort_6=sup_prb_raw_sub(pk_idx,:);
% [~,index1]=sortrows([sup_cell.sort_t].'); 
% sup_cell=sup_cell(index1); 
% clear index1
% 
% figure;
% subplot(1,2,1)
% h=heatmap(100-sup_sort_1,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0 40];
% 
% subplot(1,2,2)
% for n=1:size(sup_cell,2)
%     session_idx=find(strcmp({bhv_list.session_path},sup_cell(n).session_ID));       
%     plot(bhv_list(session_idx).CR_onset,n,'*','Color',[1 0 1])
%     hold on    
% end
% xlim([t_pre t_post]);
% ylim([0 size(sup_cell,2)+1]);
% xticks([-500 -250 0 250 500 750 1000]);
% figure;
% h=heatmap(100-sup_sort_2,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0 40];
% figure;
% h=heatmap(-sup_sort_3,'GridVisible','off','Colormap',parula);
% h.ColorLimits = [-20 20];
% figure;
% h=heatmap(100-sup_sort_4,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0 40];
% figure;
% h=heatmap(100-sup_sort_5,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0 40];
% figure;
% h=heatmap(-sup_sort_6,'GridVisible','off','Colormap',parula);
% h.ColorLimits = [-20 20];

% figure;
% for i=1:length(pk_sort)
%     plot(round(pk_sort(length(pk_sort)-i+1,1)/step),i,'k+')
%     hold on  
% end
% xlim([t_pre/step t_post/step]);
% ylim([0 size(fac_cell,2)+1]);


% sup_norm_mean_sd=zeros(9,bin_num);
% for i=1:bin_num
%     sup_norm_mean_sd(1,i)=t_pre+(i-1)*step;
%     sup_norm_mean_sd(2,i)=mean(sup_sort_1(:,i));
%     sup_norm_mean_sd(3,i)=std(sup_sort_1(:,i));
%     sup_norm_mean_sd(4,i)=sup_norm_mean_sd(2,i)+sup_norm_mean_sd(3,i)/sqrt(size(sup_cell,2));
%     sup_norm_mean_sd(5,i)=sup_norm_mean_sd(2,i)-sup_norm_mean_sd(3,i)/sqrt(size(sup_cell,2));
%     sup_norm_mean_sd(6,i)=mean(sup_sort_2(:,i));
%     sup_norm_mean_sd(7,i)=std(sup_sort_2(:,i));
%     sup_norm_mean_sd(8,i)=sup_norm_mean_sd(6,i)+sup_norm_mean_sd(7,i)/sqrt(size(sup_cell,2));
%     sup_norm_mean_sd(9,i)=sup_norm_mean_sd(6,i)-sup_norm_mean_sd(7,i)/sqrt(size(sup_cell,2));
% end
% 
% figure;
% plot(sup_norm_mean_sd(1,:),smooth(sup_norm_mean_sd(2,:),3),'k-')
% hold on
% plot(sup_norm_mean_sd(1,:),smooth(sup_norm_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(sup_norm_mean_sd(1,:),smooth(sup_norm_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre t_post]);
% ylim([50 110]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% figure;
% plot(sup_norm_mean_sd(1,:),smooth(sup_norm_mean_sd(6,:),3),'k-')
% hold on
% plot(sup_norm_mean_sd(1,:),smooth(sup_norm_mean_sd(8,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(sup_norm_mean_sd(1,:),smooth(sup_norm_mean_sd(9,:),3),'Color',[0.5 0.5 0.5])
% hold on
% xlim([t_pre t_post]);
% ylim([50 110]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% sup_prb_mean_sd=zeros(9,bin_num);
% for i=1:bin_num
%     sup_prb_mean_sd(1,i)=t_pre+(i-1)*step;
%     sup_prb_mean_sd(2,i)=mean(sup_sort_4(:,i));
%     sup_prb_mean_sd(3,i)=std(sup_sort_4(:,i));
%     sup_prb_mean_sd(4,i)=sup_prb_mean_sd(2,i)+sup_prb_mean_sd(3,i)/sqrt(size(sup_cell,2));
%     sup_prb_mean_sd(5,i)=sup_prb_mean_sd(2,i)-sup_prb_mean_sd(3,i)/sqrt(size(sup_cell,2));
%     sup_prb_mean_sd(6,i)=mean(sup_sort_5(:,i));
%     sup_prb_mean_sd(7,i)=std(sup_sort_5(:,i));
%     sup_prb_mean_sd(8,i)=sup_prb_mean_sd(6,i)+sup_prb_mean_sd(7,i)/sqrt(size(sup_cell,2));
%     sup_prb_mean_sd(9,i)=sup_prb_mean_sd(6,i)-sup_prb_mean_sd(7,i)/sqrt(size(sup_cell,2));
% end
% 
% figure;
% plot(sup_prb_mean_sd(1,:),smooth(sup_prb_mean_sd(2,:),3),'k-')
% hold on
% plot(sup_prb_mean_sd(1,:),smooth(sup_prb_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(sup_prb_mean_sd(1,:),smooth(sup_prb_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre t_post]);
% ylim([50 110]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% figure;
% plot(sup_prb_mean_sd(1,:),smooth(sup_prb_mean_sd(6,:),3),'k-')
% hold on
% plot(sup_prb_mean_sd(1,:),smooth(sup_prb_mean_sd(8,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(sup_prb_mean_sd(1,:),smooth(sup_prb_mean_sd(9,:),3),'Color',[0.5 0.5 0.5])
% hold on
% xlim([t_pre t_post]);
% ylim([50 110]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% sup_sub_norm_mean_sd=zeros(5,(-t_pre+250)/step);
% for i=1:(-t_pre+250)/step
%     sup_sub_norm_mean_sd(1,i)=t_pre+(i-1)*step;
%     sup_sub_norm_mean_sd(2,i)=mean(sup_sort_3(:,i));
%     sup_sub_norm_mean_sd(3,i)=std(sup_sort_3(:,i));
%     sup_sub_norm_mean_sd(4,i)=sup_sub_norm_mean_sd(2,i)+sup_sub_norm_mean_sd(3,i)/sqrt(size(sup_cell,2));
%     sup_sub_norm_mean_sd(5,i)=sup_sub_norm_mean_sd(2,i)-sup_sub_norm_mean_sd(3,i)/sqrt(size(sup_cell,2));
% end
% 
% figure;
% plot(sup_sub_norm_mean_sd(1,:),-smooth(sup_sub_norm_mean_sd(2,:),3),'k-')
% hold on
% plot(sup_sub_norm_mean_sd(1,:),-smooth(sup_sub_norm_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(sup_sub_norm_mean_sd(1,:),-smooth(sup_sub_norm_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre 250]);
% ylim([-40 40]);
% xticks([-500 -250 0 250 500 750 1000]);
% 
% sup_sub_prb_mean_sd=zeros(5,bin_num);
% for i=1:bin_num
%     sup_sub_prb_mean_sd(1,i)=t_pre+(i-1)*step;
%     sup_sub_prb_mean_sd(2,i)=mean(sup_sort_6(:,i));
%     sup_sub_prb_mean_sd(3,i)=std(sup_sort_6(:,i));
%     sup_sub_prb_mean_sd(4,i)=sup_sub_prb_mean_sd(2,i)+sup_sub_prb_mean_sd(3,i)/sqrt(size(fac_cell,2));
%     sup_sub_prb_mean_sd(5,i)=sup_sub_prb_mean_sd(2,i)-sup_sub_prb_mean_sd(3,i)/sqrt(size(fac_cell,2));
% end
% 
% figure;
% plot(sup_sub_prb_mean_sd(1,:),-smooth(sup_sub_prb_mean_sd(2,:),3),'k-')
% hold on
% plot(sup_sub_prb_mean_sd(1,:),-smooth(sup_sub_prb_mean_sd(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(sup_sub_prb_mean_sd(1,:),-smooth(sup_sub_prb_mean_sd(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([t_pre t_post]);
% ylim([-40 40]);
% xticks([-500 -250 0 250 500 750 1000]);

% %
% file_bhv=DT_blk_sss;
% t_post=500;
% t_pre=-550;
% dur=1550;
% bin=25;
% step=5;
% 
% behavior_all=zeros((dur-bin)/step,size(file_bhv,2));
% figure;
% for i=1:size(file_bhv,2)
%     blk_curve=smooth_curve(file_bhv(i).behavior_curve(:,1),file_bhv(i).behavior_curve(:,2)*100,bin,step);
% %     plot(blk_curve(:,1),blk_curve(:,2),'Color',[0.9 0.9 0.9],'LineWidth',1)
% %     hold on
%     behavior_all(:,i)=blk_curve(:,2);   
% end
% 
% behavior_pop=zeros((dur-bin)/step,5);
% behavior_pop(:,1)=blk_curve(:,1);
% behavior_pop(:,2)=mean(behavior_all,2);
% behavior_pop(:,3)=std(behavior_all,1,2);
% behavior_pop(:,4)=behavior_pop(:,2)+behavior_pop(:,3);
% behavior_pop(:,5)=behavior_pop(:,2)-behavior_pop(:,3);
% yyaxis right
% plot(behavior_pop(:,1),behavior_pop(:,2),'Color',[0 0 0],'LineWidth',2)
% hold on
% xlim([-500 t_post]);
% ylim([-5 55]);
% xlabel('Time (ms)');
% ylabel('Eyelid closure (%)');
% xticks([-500 -250 0 250 500 1000]);
% yticks([0 50 100]);
% 
% yyaxis left
% plot(fac_mean_sd(1,:),smooth(fac_mean_sd(2,:),3)-100,'k-')
% hold on
% ylim([-10 200]);
% yticks([0 100 200]);
% ylabel('Facilitation (%)');
% 
% % plot(behavior_pop(:,1),behavior_pop(:,4),'Color',[0.5 0.5 0.5],'LineWidth',2)
% % hold on
% % plot(behavior_pop(:,1),behavior_pop(:,5),'Color',[0.5 0.5 0.5],'LineWidth',2)
% % hold on
% line([0 0],[-10, 200],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% line([250 250],[-10, 200],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% line([500 500],[-10, 200],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);


% figure;
% yyaxis right
% plot(behavior_pop(:,1),behavior_pop(:,2),'Color',[0 0 0],'LineWidth',2)
% hold on
% xlim([-250 t_post]);
% ylim([-10 60]);
% xlabel('Time (ms)');
% ylabel('Eyelid closure (%)');
% xticks([-250 0 250 500 1000]);
% yticks([0 50 100]);
% line([0 0],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% line([250 250],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% line([500 500],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% 
% yyaxis left
% plot(sup_mean_sd(1,:),smooth(sup_mean_sd(2,:),3)-100,'k-')
% hold on
% ylim([-60 10]);
% yticks([-50 -25 0]);
% ylabel('Suppression (%)');

% plot(behavior_pop(:,1),behavior_pop(:,4),'Color',[0.5 0.5 0.5],'LineWidth',2)
% hold on
% plot(behavior_pop(:,1),behavior_pop(:,5),'Color',[0.5 0.5 0.5],'LineWidth',2)
% hold on


function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end
