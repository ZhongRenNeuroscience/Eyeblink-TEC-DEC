% DTTD early-late PSTH and temporal compressed for trace paradigm

file=TD_list_align;
t_pre=550;
t_psth=1050;
figure_name='TD';
cd 'D:\Zhong\Trace-trained-mice\T_D_data_output\RasterFigure\EL_comb'
TD_EL_list=struct('cell_ID',[],'early_Ctas_T',[],'early_psth_T',[],'late_Ctas_T',[],'late_psth_T',[]);

for i=1:size(file,2)
    Ctas_early_T=struct('cell',[],'tss',[]);
    Ctas_early_T.tss=struct('trial',[],'t',[]);
    Ctas_early_T.cell=1;
    Ctas_late_T=struct('cell',[],'tss',[]);
    Ctas_late_T.tss=struct('trial',[],'t',[]);
    Ctas_late_T.cell=1;
    
    trial_info_T=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[]);
    for j=1:size(file(i).all_info_T.ttt.CR_trial,2)
        trial_info_T(j).field=j;
        trial_info_T(j).trial_num=file(i).all_info_T.ttt.CR_trial(j).trial_num;
        trial_info_T(j).CR_onset=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_onset;
        trial_info_T(j).spk=file(i).all_info_T.ttt.CR_trial(j).spk_time;
    end
    trial_info_T = trial_info_T(all(~cellfun(@isempty,struct2cell(trial_info_T))));
    [~,index] = sortrows([trial_info_T.CR_onset].'); 
    trial_info_T = trial_info_T(index);
    
    trial_info_D=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[]);
    for j=1:size(file(i).all_info_D.ttt.CR_trial,2)
        trial_info_D(j).field=j;
        trial_info_D(j).trial_num=file(i).all_info_D.ttt.CR_trial(j).trial_num;
        trial_info_D(j).CR_onset=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_onset;
        trial_info_D(j).spk=file(i).all_info_D.ttt.CR_trial(j).spk_time;
    end
    trial_info_D = trial_info_D(all(~cellfun(@isempty,struct2cell(trial_info_D))));
    [~,index] = sortrows([trial_info_D.CR_onset].'); 
    trial_info_D = trial_info_D(index);
    
    if strcmp('TD',figure_name)
       num_mod_T=mod(size(trial_info_T,2),2);
       num_early_T=(size(trial_info_T,2)+num_mod_T)/2;
       num_late_T=(size(trial_info_T,2)-num_mod_T)/2;
    elseif strcmp('DT',figure_name)      
       num_late_T=sum(([trial_info_T.CR_onset])>=0.25);
       if num_late_T>=20
          num_late_T=num_late_T;
       elseif num_late_T>=15 && num_late_T<19
          num_late_T=20;
       elseif num_late_T<15
          num_late_T=round(num_late_T*1.33);
       end
       num_early_T=size(trial_info_T,2)-num_late_T;
    end
    
    for j=1:num_early_T
        Ctas_early_T.tss(j).trial=trial_info_T(j).trial_num;
        Ctas_early_T.tss(j).t=trial_info_T(j).spk;        
    end
    for k=1:num_late_T
        Ctas_late_T.tss(k).trial=trial_info_T(k+num_early_T).trial_num;
        Ctas_late_T.tss(k).t=trial_info_T(k+num_early_T).spk;
    end
    spk_CR_Gau_early_T=spk_Gaussian(Ctas_early_T,t_pre,t_psth,10,3);
    psth_CR_Gau_early_T=Gau_psth_cal(spk_CR_Gau_early_T,t_pre,t_psth,0);
    spk_CR_Gau_late_T=spk_Gaussian(Ctas_late_T,t_pre,t_psth,10,3);
    psth_CR_Gau_late_T=Gau_psth_cal(spk_CR_Gau_late_T,t_pre,t_psth,0);
    
    TD_EL_list(i).cell_ID=file(i).cell_ID;
    TD_EL_list(i).early_Ctas_T=Ctas_early_T;
    TD_EL_list(i).late_Ctas_T=Ctas_late_T;
    TD_EL_list(i).early_psth_T=psth_CR_Gau_early_T;
    TD_EL_list(i).late_psth_T=psth_CR_Gau_late_T;
%     Ctas_press_T=struct('cell',[],'tss',[]);
%     Ctas_press_T.cell=1;
%     Ctas_press_T.tss=struct('trial',[],'t',[]);
%     for n=1:size(trial_info_T,2)
%         Ctas_press_T.tss(n).trial=trial_info_T(n).trial_num;
%         Ctas_press_T.tss(n).t=round([trial_info_T(n).spk],4)/2;       
%     end
%     spk_CR_Gau_press_T=spk_Gaussian(Ctas_press_T,t_pre/2,t_psth/2,10,3);
%     psth_CR_Gau_press_T=Gau_psth_cal(spk_CR_Gau_press_T,t_pre/2,t_psth/2,0);
    
    figure('Name',[figure_name num2str(i)],'NumberTitle','off','units','normalized','outerposition',[0 0 1 1]);
    
    if strcmp('TD',figure_name)
       subplot(3,2,1)
       hold on
    elseif strcmp('DT',figure_name)
       subplot(3,2,2)
       hold on    
    end
    
    behavior_mean_T=zeros(1550,size(file(i).all_info_T.ttt.CR_trial,2));
    for m=1:size(file(i).all_info_T.ttt.CR_trial,2)
        behavior_mean_T(:,m)=file(i).all_info_T.ttt.CR_trial(m).blk_smth(:,2);
        plot(file(i).all_info_T.ttt.CR_trial(m).blk_smth(:,1),file(i).all_info_T.ttt.CR_trial(m).blk_smth(:,2),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    ymax_T=max(max(behavior_mean_T))+0.1;
    ymin_T=min(min(behavior_mean_T))-0.1;
    plot(file(i).all_info_T.ttt.CR_trial(1).blk_smth(:,1),mean(behavior_mean_T,2),'Color',[0 0 0],'LineWidth',2)
    hold on

    line([0 0],[ymin_T, ymax_T],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin_T, ymax_T],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);

    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([ymin_T ymax_T]);
    xlabel('Time(ms)');
    ylabel('Normalized eyelid trace')  
    
    if strcmp('TD',figure_name)
       subplot(3,2,2)
       hold on
    elseif strcmp('DT',figure_name)
       subplot(3,2,1)
       hold on    
    end 
    
    behavior_mean_D=zeros(1550,size(file(i).all_info_D.ttt.CR_trial,2));
    for m=1:size(file(i).all_info_D.ttt.CR_trial,2)
        behavior_mean_D(:,m)=file(i).all_info_D.ttt.CR_trial(m).blk_smth(:,2);
        plot(file(i).all_info_D.ttt.CR_trial(m).blk_smth(:,1),file(i).all_info_D.ttt.CR_trial(m).blk_smth(:,2),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    ymax_D=max(max(behavior_mean_D))+0.1;
    ymin_D=min(min(behavior_mean_D))-0.1;
    plot(file(i).all_info_D.ttt.CR_trial(1).blk_smth(:,1),mean(behavior_mean_D,2),'Color',[0 0 0],'LineWidth',2)
    hold on

    line([0 0],[ymin_D, ymax_D],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin_D, ymax_D],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);

    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([ymin_D ymax_D]);
    xlabel('Time(ms)');
    ylabel('Normalized eyelid trace')      
    
    if strcmp('TD',figure_name)
       subplot(3,2,3)
       hold on
    elseif strcmp('DT',figure_name)
       subplot(3,2,4)
       hold on    
    end
    
    for m=1:size(trial_info_T,2)
    hold on
    Y=ones(length(trial_info_T(m).spk),1)*m;
    plot(trial_info_T(m).spk*1000,Y,'k.')
    hold on
    plot(0,Y,'g.')
    hold on
    plot(trial_info_T(m).CR_onset*1000,Y,'b.')
    hold on
    plot(500,Y,'r.')        
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    xlabel('Time(ms)');
    ylabel('Trial number');
    
    if strcmp('TD',figure_name)
       subplot(3,2,4)
       hold on
    elseif strcmp('DT',figure_name)
       subplot(3,2,3)
       hold on    
    end
    
    for m=1:size(trial_info_D,2)
    hold on
    Y=ones(length(trial_info_D(m).spk),1)*m;
    plot(trial_info_D(m).spk*1000,Y,'k.')
    hold on
    plot(0,Y,'g.')
    hold on
    plot(trial_info_D(m).CR_onset*1000,Y,'b.')
    hold on
    plot(250,Y,'r.')        
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    xlabel('Time(ms)');
    ylabel('Trial number');    
    
    subplot(3,2,5)
    plot(file(i).align_info_T.psth_ex(:,1),file(i).align_info_T.psth_ex(:,2),'k-','LineWidth',1.0,'DisplayName','Trace raw')
    hold on
    plot(file(i).align_info_D.psth_ex(:,1),file(i).align_info_D.psth_ex(:,2),'r-','LineWidth',1.0,'DisplayName','Delay raw')
    hold on

    max_early=max(psth_CR_Gau_early_T.Gau_psth_shft(:,2));
    max_late=max(psth_CR_Gau_late_T.Gau_psth_shft(:,2));
    max_trace=max(file(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
    max_delay=max(file(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
    max_mix=max([max_early max_late max_trace max_delay])*1.1;
    
    min_early=min(psth_CR_Gau_early_T.Gau_psth_shft(:,2));
    min_late=min(psth_CR_Gau_late_T.Gau_psth_shft(:,2));
    min_trace=min(file(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
    min_delay=min(file(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
    min_mix=min([min_early min_late min_trace min_delay])*0.9;
    
    line([0 0],[min_mix, max_mix],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    line([250 250],[min_mix, max_mix],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    line([500 500],[min_mix, max_mix],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    xlim([-250 750]);
    ylim([min_mix max_mix]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Est. Spike Freq. (Hz)');   
    legend('Trace raw','Delay raw');
    
    subplot(3,2,6)
    plot(psth_CR_Gau_early_T.Gau_psth_shft(:,1),psth_CR_Gau_early_T.Gau_psth_shft(:,2),'c-','LineWidth',1.0,'DisplayName','Trace early')
    hold on
    plot(psth_CR_Gau_late_T.Gau_psth_shft(:,1),psth_CR_Gau_late_T.Gau_psth_shft(:,2),'m-','LineWidth',1.0,'DisplayName','Trace late')
    hold on
    
    line([0 0],[min_mix, max_mix],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    line([500 500],[min_mix, max_mix],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    xlim([-250 750]);
    ylim([min_mix max_mix]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Est. Spike Freq. (Hz)');   
    legend(['Trace early' num2str(num_early_T)],['Trace late' num2str(num_late_T)]);
    
    if strcmp('DT',figure_name)
       saveas(gcf,[figure_name num2str(i) '-D-' num2str(file(i).CR_fac_D) '-' num2str(file(i).CR_sup_D) '-T-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '.jpg']);
    elseif strcmp('TD',figure_name)
       saveas(gcf,[figure_name num2str(i) '-T-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '-D-' num2str(file(i).CR_fac_D) '-' num2str(file(i).CR_sup_D) '.jpg']); 
    end
    close all
end
    save('TD_EL_list','TD_EL_list')
