list=TD_blk_sss;
info1='normCR_info_T';
info2='normCR_info_D';
blk_drft_TD=struct('session_ID',[],'first_on',[],'last_on',[],'p1',[],'R',[],'p2',[],'onset_list',[],'mean_list',[],'drift_form',[]);


for i=1:size(list,2)
    tr_num_1st=size(list(i).(info1),1);
    mean_1ist=zeros(tr_num_1st,4);
    for k=1:tr_num_1st
        if ~isnan(list(i).(info1)(k,2))
           mean_1ist(k,2)=list(i).(info1)(k,2);  
        else
           mean_1ist(k,2)=NaN;
        end        
    end
    mean_1ist(any(isnan(mean_1ist),2),:) = [];
    mean_1ist(:,1)=1:1:size(mean_1ist,1);
    mean_1ist(:,4)=mean(mean_1ist(:,2));
    
%     [R,P]=corrcoef(mean_1ist(:,1),mean_1ist(:,2));
    p=polyfit(mean_1ist(:,1),mean_1ist(:,2),1);
    regression=p(1)*mean_1ist(:,1)+p(2);
    mean_1ist(:,3)=regression;
    
    blk_drft_TD(i).mean_list=mean_1ist;
        
    tr_num=size(list(i).(info2),1);
    onset=zeros(tr_num,5);  
    for j=1:tr_num
        if ~isnan(list(i).(info2)(j,2))
        onset(j,2)=list(i).(info2)(j,2);  
        else
        onset(j,2)=NaN;
        end
    end
    onset(any(isnan(onset),2),:) = [];
    onset(:,1)=1:1:size(onset,1);
    tr_num_1=size(onset,1);
    onset(:,1)=1:1:tr_num_1;
    sz_mod=mod(tr_num_1,2);
    first_num=(tr_num_1+sz_mod)/2;
    
    blk_drft_TD(i).session_ID=list(i).session_path;
    blk_drft_TD(i).first_on=mean(onset(1:first_num,2));
    blk_drft_TD(i).last_on=mean(onset(first_num+1:tr_num_1,2));
    onset(1:first_num,5)=blk_drft_TD(i).first_on;
    onset(first_num+1:tr_num_1,5)=blk_drft_TD(i).last_on;

    [~,p]=ttest2(onset(1:first_num,2),onset(first_num+1:tr_num_1,2));
    blk_drft_TD(i).p1=p;
    
    [R,P]=corrcoef(onset(:,1),onset(:,2));
    p=polyfit(onset(:,1),onset(:,2),1);
    regression=p(1)*onset(:,1)+p(2);
    onset(:,3)=regression;
    onset(:,4)=mean(onset(:,2));
    
    blk_drft_TD(i).R=R(2,1);
    blk_drft_TD(i).p2=P(2,1);
    blk_drft_TD(i).onset_list=onset;
    
end

drift_curve_list=drift_curve_plot(blk_drft_TD,'mean_list','onset_list',10);
for i=1:size(list,2)
    blk_drft_TD(i).drift_form=drift_curve_list(i).drift_form;   
end

function drift_curve_list=drift_curve_plot(drft_list,name_1,name_2,bin)

drift_curve_list=struct('session_ID',[],'file_name',[],'drift_form',[]);
for i=1:size(drft_list,2)
    drift_curve_list(i).session_ID=i;
    drift_curve_list(i).file_name=drft_list(i).session_ID;
    drift_form=zeros(size(drft_list(i).(name_1),1)+size(drft_list(i).(name_2),1),3);
    drift_form(1:size(drft_list(i).(name_1)),2)=drft_list(i).(name_1)(:,2);
    drift_form(size(drft_list(i).(name_1))+1:end,2)=drft_list(i).(name_2)(:,2);
    
    for j=1:size(drift_form,1)-bin+1
        drift_form(j,1)=j;
        drift_form(j,3)=mean(drift_form(j:j+bin-1,2));
    end
    drift_form=drift_form(1:size(drift_form,1)-bin+1,:);
    drift_curve_list(i).drift_form=drift_form;
end

end