%Plot early_late_onset_list
%** Unused

figure;
for i=1:16
    subplot(4,4,i)
    plot(EL_sep(i).early_blk_mean_D(:,1),EL_sep(i).early_blk_mean_D(:,2)*100,'k-')
    hold on
    plot(EL_sep(i).late_blk_mean_D(:,1),EL_sep(i).late_blk_mean_D(:,2)*100,'m-')
    hold on
    plot(EL_sep(i).early_blk_mean_T(:,1),EL_sep(i).early_blk_mean_T(:,2)*100,'k--')
    hold on
    plot(EL_sep(i).late_blk_mean_T(:,1),EL_sep(i).late_blk_mean_T(:,2)*100,'m--') 
    hold on
    stairs(EL_sep(i).early_ifr_mean_D(:,1),EL_sep(i).early_ifr_mean_D(:,2),'k-')
    hold on
    stairs(EL_sep(i).late_ifr_mean_D(:,1),EL_sep(i).late_ifr_mean_D(:,2),'m-')    
    hold on
    stairs(EL_sep(i).early_ifr_mean_T(:,1),EL_sep(i).early_ifr_mean_T(:,2),'k--');
    hold on
    stairs(EL_sep(i).late_ifr_mean_T(:,1),EL_sep(i).late_ifr_mean_T(:,2),'m--');
    hold on
    ymax1=max(EL_sep(i).early_ifr_mean_D(:,2));
    ymax2=max(EL_sep(i).early_ifr_mean_T(:,2));
    ymax3=max(EL_sep(i).late_ifr_mean_D(:,2));
    ymax4=max(EL_sep(i).late_ifr_mean_T(:,2));
    ymax=nanmax([ymax1 ymax2 ymax3 ymax4]);
    xlim([-250 1000]);
    ylim([-5 ymax]);
    line([0 0],[-5, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
    line([250 250],[-5, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    line([500 500],[-5, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
end

figure;
for i=17:size(EL_sep,2)
    subplot(4,4,i-16)
    plot(EL_sep(i).early_blk_mean_D(:,1),EL_sep(i).early_blk_mean_D(:,2)*100,'k-')
    hold on
    plot(EL_sep(i).late_blk_mean_D(:,1),EL_sep(i).late_blk_mean_D(:,2)*100,'m-')
    hold on
    plot(EL_sep(i).early_blk_mean_T(:,1),EL_sep(i).early_blk_mean_T(:,2)*100,'k--')
    hold on
    plot(EL_sep(i).late_blk_mean_T(:,1),EL_sep(i).late_blk_mean_T(:,2)*100,'m--') 
    hold on
    stairs(EL_sep(i).early_ifr_mean_D(:,1),EL_sep(i).early_ifr_mean_D(:,2),'k-')
    hold on
    stairs(EL_sep(i).late_ifr_mean_D(:,1),EL_sep(i).late_ifr_mean_D(:,2),'m-')    
    hold on
    stairs(EL_sep(i).early_ifr_mean_T(:,1),EL_sep(i).early_ifr_mean_T(:,2),'k--');
    hold on
    stairs(EL_sep(i).late_ifr_mean_T(:,1),EL_sep(i).late_ifr_mean_T(:,2),'m--');
    ymax1=max(EL_sep(i).early_ifr_mean_D(:,2));
    ymax2=max(EL_sep(i).early_ifr_mean_T(:,2));
    ymax3=max(EL_sep(i).late_ifr_mean_D(:,2));
    ymax4=max(EL_sep(i).late_ifr_mean_T(:,2));
    ymax=nanmax([ymax1 ymax2 ymax3 ymax4])*1.05;
    xlim([-250 1000]);
    ylim([-5 ymax]);
    line([0 0],[-5, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
    line([250 250],[-5, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    line([500 500],[-5, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);    
end