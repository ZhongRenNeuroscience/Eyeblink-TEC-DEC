% Trace list simplify
file=file;

all_info='all_info_D';


for i=1:size(file,2)
    file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'blk_trace');
    file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'ifr_org_Gau'); 
    if ~isempty(file(i).(all_info).ttt.nonCR_trial)
        file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'blk_trace');
        file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'ifr_org_Gau');   
    end
    if ~isempty(file(i).(all_info).ttt.probe_trial)
       file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'blk_trace');
    end
    file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'ifr_org_Gau');     
end

% all_info='all_info_D';
% 
% 
% for i=1:162
%     file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'blk_trace');
%     file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'ifr_org_Gau'); 
%     if ~isempty(file(i).(all_info).ttt.nonCR_trial)
%         file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'blk_trace');
%         file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'ifr_org_Gau');   
%     end   
%     file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'blk_trace');
%     file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'ifr_org_Gau');     
% end
% for i=222:458
%     file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'avg_velo');
%     file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'peak_velo');
%     file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'velo_info');
%     file(i).(all_info).ttt.CR_trial = rmfield(file(i).(all_info).ttt.CR_trial,'velo_raw');    
%     file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'avg_velo');
%     file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'peak_velo');
%     file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'velo_info');
%     file(i).(all_info).ttt.nonCR_trial = rmfield(file(i).(all_info).ttt.nonCR_trial,'velo_raw');  
%     file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'avg_velo');
%     file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'peak_velo');
%     file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'velo_info');
%     file(i).(all_info).ttt.probe_trial = rmfield(file(i).(all_info).ttt.probe_trial,'velo_raw');    
% end