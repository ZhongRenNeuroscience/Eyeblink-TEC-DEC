% behavior onset peak analysis
listing = dir('pack_*');
blk_sss=struct('session_num',[],'session_path',[],'behavior_info',[],'CR_onset',[],'CR_pkt',[],'UR_pkt',[]);

for i=1:size(listing,1)
    load(listing(i).name);
    blk_sss(i).session_num=i;
    blk_sss(i).session_path=listing(i).name;
    behavior_info=zeros(size(package.ttt(1).CR_trial,2),4);
    for j=1:size(package.ttt(1).CR_trial,2)
        behavior_info(j,1)=j;
        behavior_info(j,2)=package.ttt(1).CR_trial(j).blk_info.CR_onset*1000;
        behavior_info(j,3)=package.ttt(1).CR_trial(j).blk_info.CR_peaktime*1000;
        behavior_info(j,4)=package.ttt(1).CR_trial(j).blk_info.UR_peaktime*1000;
        if behavior_info(j,4)>650
           behavior_info(j,4)=NaN;
        end
    end
    blk_sss(i).behavior_info=behavior_info;
    blk_sss(i).CR_onset=nanmean(behavior_info(:,2));
    blk_sss(i).CR_pkt=nanmean(behavior_info(:,3));
    blk_sss(i).UR_pkt=nanmean(behavior_info(:,4));
end

clear i j behavior_info package