% firing rate proportion plot

file=DT_list_align;
figure_name='DT';
cd D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\spk_interval_distribution

spk_interval=struct('cell_ID',[],'mod_info',[],'spk_int_D',[],'spk_int_T',[]);

for i=1:size(file,2)
    spk_interval(i).cell_ID=file(i).cell_ID;
    mod_info=struct('fac_D',[],'fac_T',[],'sup_D',[],'sup_T',[],'motor_relevant_fac_D',[],'motor_relevant_fac_T',[],...
                  'motor_relevant_sup_D',[],'motor_relevant_sup_T',[],'timing_relevant',[],'paradigm_relevant',[]);
    mod_info.fac_D=mod_format(i).fac_D;
    mod_info.fac_T=mod_format(i).fac_T;
    mod_info.sup_D=mod_format(i).sup_D;
    mod_info.sup_T=mod_format(i).sup_T;
    mod_info.motor_relevant_fac_D=mod_format(i).motor_relevant_fac_D;
    mod_info.motor_relevant_fac_T=mod_format(i).motor_relevant_fac_T;
    mod_info.motor_relevant_sup_D=mod_format(i).motor_relevant_sup_D;
    mod_info.motor_relevant_sup_T=mod_format(i).motor_relevant_sup_T;
    mod_info.timing_relevant=mod_format(i).timing_relevant;
    mod_info.paradigm_relevant=mod_format(i).paradigm_relevant;
    spk_interval(i).mod_info=mod_info;
    
    spk_int_D=struct('trial_int',[],'session_bsl',[],'session_test',[],'histo_bsl',[],'histo_test',[]);
    spk_int_T=struct('trial_int',[],'session_bsl',[],'session_test',[],'histo_bsl',[],'histo_test',[]);
    trial_int_D=struct('trial_num',[],'bsl',[],'test',[],'all',[]);
    trial_int_T=struct('trial_num',[],'bsl',[],'test',[],'all',[]);
    int_bsl_D=0;
    int_test_D=0;
    int_bsl_T=0;
    int_test_T=0;
    
    for j=1:size(file(i).all_info_D.ttt.CR_trial,2)
        trial_int_D(j).trial_num=file(i).all_info_D.ttt.CR_trial(j).trial_num;
        bsl=struct('t',[],'interval',[]);
        test=struct('t',[],'interval',[]);
        all=struct('t',[],'interval',[]);
        i_bsl=0;
        i_test=0;
        i_all=0;
        for k=1:size(file(i).all_info_D.ttt.CR_trial(j).spk_time,1)
            if file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)<-0.5
               continue
            elseif file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)>=-0.5 && file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)<0
               i_bsl=i_bsl+1;
               i_all=i_all+1;
               bsl(i_bsl).t=file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1);
               all(i_all).t=file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1);
            elseif file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)>=0 && file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)<0.25
               i_test=i_test+1;
               i_all=i_all+1;
               test(i_test).t=file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1);
               all(i_all).t=file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1);
               if k==size(file(i).all_info_D.ttt.CR_trial(j).spk_time,1)
                  i_test=i_test+1;
                  test(i_test).t=0.25;     
                  i_all=i_all+1;
                  all(i_all).t=0.25;
               end
            elseif file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)>=0.25 && file(i).all_info_D.ttt.CR_trial(j).spk_time(k,1)<1
                if i_test~=0 && test(i_test).t~=0.25
                   i_test=i_test+1;
                   test(i_test).t=0.25;
                   i_all=i_all+1;
                   all(i_all).t=0.25;
                end
                break
            end
        end
        if size(bsl,2)>1
           for m=1:size(bsl,2)-1
               int_bsl_D=int_bsl_D+1;
               bsl(m).interval=bsl(m+1).t-bsl(m).t;
               spk_int_D.session_bsl(int_bsl_D).interval=bsl(m).interval;
           end 
        end
        if size(test,2)>1
           for m=1:size(test,2)-1
               int_test_D=int_test_D+1;
               test(m).interval=test(m+1).t-test(m).t; 
               spk_int_D.session_test(int_test_D).interval=test(m).interval;
           end  
           test(m+1).interval=0;
        end  
        if size(all,2)>1
           for m=1:size(all,2)-1
               all(m).interval=all(m+1).t-all(m).t;
           end 
        end
        trial_int_D(j).bsl=bsl;
        trial_int_D(j).test=test; 
        trial_int_D(j).all=all;
    end
    spk_int_D.trial_int=trial_int_D;
    figure;
    if strcmp('TD',figure_name)
       subplot(1,2,2)
       hold on
    elseif strcmp('DT',figure_name)
       subplot(1,2,1)
       hold on    
    end 
    h_bsl_D = histogram([spk_int_D.session_bsl.interval]*1000,'BinWidth',5,'BinLimits',[0,200],'Normalization','probability');
    hold on
    h_test_D = histogram([spk_int_D.session_test.interval]*1000,'BinWidth',5,'BinLimits',[0,200],'Normalization','probability');
    hold on
    xlabel('Inter-spike-interval (ms)');
    ylabel('Probability');
    title('Delay');
    spk_int_D.histo_bsl.N=h_bsl_D.BinCounts/int_bsl_D;
    spk_int_D.histo_bsl.edges=h_bsl_D.BinEdges;
    spk_int_D.histo_test.N=h_test_D.BinCounts/int_test_D;
    spk_int_D.histo_test.edges=h_test_D.BinEdges;    
    spk_interval(i).spk_int_D=spk_int_D;

    for j=1:size(file(i).all_info_T.ttt.CR_trial,2)
        trial_int_T(j).trial_num=file(i).all_info_T.ttt.CR_trial(j).trial_num;
        bsl=struct('t',[],'interval',[]);
        test=struct('t',[],'interval',[]);
        all=struct('t',[],'interval',[]);
        i_bsl=0;
        i_test=0;
        i_all=0;
        for k=1:size(file(i).all_info_T.ttt.CR_trial(j).spk_time,1)
            if file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)<-0.5
               continue
            elseif file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)>=-0.5 && file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)<0
               i_bsl=i_bsl+1;
               i_all=i_all+1;
               bsl(i_bsl).t=file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1);
               all(i_all).t=file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1);
            elseif file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)>=0 && file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)<0.5
               i_test=i_test+1;
               i_all=i_all+1;
               test(i_test).t=file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1);
               all(i_all).t=file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1);
               if k==size(file(i).all_info_T.ttt.CR_trial(j).spk_time,1)
                  i_test=i_test+1;
                  test(i_test).t=0.5;   
                  i_all=i_all+1;
                  all(i_all).t=0.5;
               end
            elseif file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)>=0.5 && file(i).all_info_T.ttt.CR_trial(j).spk_time(k,1)<1
                if i_test~=0 && test(i_test).t~=0.5
                   i_test=i_test+1;
                   test(i_test).t=0.5;
                   i_all=i_all+1;
                   all(i_all).t=0.5;                   
                end
                break
            end
        end
        if size(bsl,2)>1
           for m=1:size(bsl,2)-1
               int_bsl_T=int_bsl_T+1;
               bsl(m).interval=bsl(m+1).t-bsl(m).t;
               spk_int_T.session_bsl(int_bsl_T).interval=bsl(m).interval;
           end 
        end
        if size(test,2)>1
           for m=1:size(test,2)-1
               int_test_T=int_test_T+1;
               test(m).interval=test(m+1).t-test(m).t; 
               spk_int_T.session_test(int_test_T).interval=test(m).interval;
           end 
           test(m+1).interval=0;
        end 
        if size(all,2)>1
           for m=1:size(all,2)-1
               all(m).interval=all(m+1).t-all(m).t;
           end 
        end        
        trial_int_T(j).bsl=bsl;
        trial_int_T(j).test=test;    
        trial_int_T(j).all=all;  
    end
    spk_int_T.trial_int=trial_int_T;
    if strcmp('TD',figure_name)
       subplot(1,2,1)
       hold on
    elseif strcmp('DT',figure_name)
       subplot(1,2,2)
       hold on    
    end 
    h_bsl_T = histogram([spk_int_T.session_bsl.interval]*1000,'BinWidth',5,'BinLimits',[0,200],'Normalization','probability');
    hold on
    h_test_T = histogram([spk_int_T.session_test.interval]*1000,'BinWidth',5,'BinLimits',[0,200],'Normalization','probability');
    spk_int_T.histo_bsl.N=h_bsl_T.BinCounts/int_bsl_T;
    spk_int_T.histo_bsl.edges=h_bsl_T.BinEdges;
    spk_int_T.histo_test.N=h_test_T.BinCounts/int_test_T;
    spk_int_T.histo_test.edges=h_test_T.BinEdges;    
    spk_interval(i).spk_int_T=spk_int_T;
    xlabel('Inter-spike-interval (ms)');
    ylabel('Probability');
    title('Trace');
    if strcmp('DT',figure_name)
       saveas(gcf,[figure_name num2str(i) '-D-' num2str(file(i).CR_fac_D) '-' num2str(file(i).CR_sup_D) '-T-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '.jpg']);
    elseif strcmp('TD',figure_name)
       saveas(gcf,[figure_name num2str(i) '-T-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '-D-' num2str(file(i).CR_fac_D) '-' num2str(file(i).CR_sup_D) '.jpg']); 
    end
    close all

end