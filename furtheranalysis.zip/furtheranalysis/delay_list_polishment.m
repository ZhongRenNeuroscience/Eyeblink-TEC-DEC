% Delay list polishment

file=Delay_list;



for i=152:191
    for j=1:size(file(i).all_info.ttt.CR_trial,2)        
        blk_smth=file(i).all_info.ttt.CR_trial(j).blk_smth;
        blk_smth(:,2)=[];
        file(i).all_info.ttt.CR_trial(j).blk_smth=blk_smth;               
    end

    if ~isempty(file(i).all_info.ttt.nonCR_trial(1).trial_num)
        for k=1:size(file(i).all_info.ttt.nonCR_trial,2)        
            blk_smth=file(i).all_info.ttt.nonCR_trial(k).blk_smth;
            blk_smth(:,2)=[];
            file(i).all_info.ttt.nonCR_trial(k).blk_smth=blk_smth;               
        end    
    end
                                                  
end