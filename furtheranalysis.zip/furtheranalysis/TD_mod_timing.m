mf=1;
ms=1;

for i=1:size(TD_list,2)
    if TD_list(i).CR_fac_T + TD_list(i).CR_sup_T > 0 && TD_list(i).CR_fac_D + TD_list(i).CR_sup_D > 0
       if TD_list(i).CR_fac_T > 0 && TD_list(i).CR_fac_D > 0
       TD_mod_249_f(mf,1)=i;
       TD_mod_249_f(mf,2)=TD_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(800,2)/TD_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
       TD_mod_249_f(mf,3)=TD_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(800,2)/TD_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;        
       TD_mod_on_f(mf,1)=i;
       TD_mod_on_f(mf,2)=TD_list(i).mod_info_T.CRf(1).t_onset;
       TD_mod_on_f(mf,3)=TD_list(i).mod_info_D.CRf(1).t_onset;
       TD_mod_peak_f(mf,1)=i;
       [M,I]=max(TD_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       TD_mod_peak_f(mf,2)=M/TD_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
       TD_mod_peak_f(mf,4)=I-1;
       [M,I]=max(TD_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       TD_mod_peak_f(mf,3)=M/TD_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
       TD_mod_peak_f(mf,5)=I-1;
       mf=mf+1;
       end
       
       if TD_list(i).CR_sup_T > 0 && TD_list(i).CR_sup_D > 0
       TD_mod_249_s(ms,1)=i;
       TD_mod_249_s(ms,2)=TD_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(800,2)/TD_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
       TD_mod_249_s(ms,3)=TD_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(800,2)/TD_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;        
       TD_mod_on_s(ms,1)=i;
       TD_mod_on_s(ms,2)=TD_list(i).mod_info_T.CRs(1).t_onset;
       TD_mod_on_s(ms,3)=TD_list(i).mod_info_D.CRs(1).t_onset;
       TD_mod_peak_s(ms,1)=i;
       [M,I]=min(TD_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       TD_mod_peak_s(ms,2)=M/TD_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
       TD_mod_peak_s(ms,4)=I-1;
       [M,I]=min(TD_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       TD_mod_peak_s(ms,3)=M/TD_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
       TD_mod_peak_s(ms,5)=I-1;
       ms=ms+1;           
       end
    end
end