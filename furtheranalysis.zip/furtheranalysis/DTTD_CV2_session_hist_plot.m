file_CV2=CV2_cal;
cd D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\CV2\session_plot
BinWidth_CV2=5;
BinWidth_mod=10;
plt_marker_fac='onset';
plt_marker_sup='onset';

CV2_hist_list=struct('cell_ID',[],'hist_info_D',[],'hist_info_T',[]);
for i=1:size(file_CV2,2)
    hist_info_D=struct('CV2_mean_bsl',[],'CV2_mean_test',[],'CV2_hist',[],'mean_hist',[],'CV2_mean_curve',[],'burst_fac',[],'burst_sup',[]);
    hist_info_T=struct('CV2_mean_bsl',[],'CV2_mean_test',[],'CV2_hist',[],'mean_hist',[],'CV2_mean_curve',[],'burst_fac',[],'burst_sup',[]);
   
    spk_int='spk_int_D';
    t_post=250;
    CV2_mean_bsl_D=struct('trial_num',[],'CV2',[],'mean',[]);
    CV2_mean_test_D=struct('trial_num',[],'CV2',[],'mean',[]);
    CV2_hist=struct('bsl',[],'test',[]);
    mean_hist=struct('bsl',[],'test',[]);
    burst_fac_D=struct('trial_num',[],'onset',[],'mid_t',[],'peak_t',[],'CR_align',[]);
    burst_sup_D=struct('trial_num',[],'onset',[],'mid_t',[],'peak_t',[],'CR_align',[]);
    i_bsl=0;
    i_test=0;
    i_fac=0;
    i_sup=0;
    
    figure('units','normalized','outerposition',[0 0 1 1]);  
    
    subplot('Position',[0.525 0.7 0.2 0.25])
    [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
    file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
    clear index;
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
               hold on
            end
        end
        plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
        plot(0,j,'g.')
        hold on
        plot(t_post,j,'r.')
        hold on       
    end
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 j+1]);
    ylabel('Trial number');
    title('CS onset align');
    
    subplot('Position',[0.75 0.7 0.2 0.25])
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'k.')
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'m.') 
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'c.') 
               hold on
            end
        end
        plot(0,j,'b*')
        plot(-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'g.')
        hold on
        plot(t_post-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'r.')
        hold on       
    end
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 j+1]);
    ylabel('Trial number');
    title('CR onset align');    
    
    for j=1:size(file_CV2(i).(spk_int),2)        
        file_CV2(i).(spk_int)(j).all_info=file_CV2(i).(spk_int)(j).all_info(~cellfun(@isempty,{file_CV2(i).(spk_int)(j).all_info.type}));
        test_on=find([file_CV2(i).(spk_int)(j).all_info.t]>=0,1,'first');
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if k<test_on
               i_bsl=i_bsl+1;
               CV2_mean_bsl_D(i_bsl).trial_num=file_CV2(i).(spk_int)(j).trial_num;
               CV2_mean_bsl_D(i_bsl).CV2=abs(file_CV2(i).(spk_int)(j).all_info(k).CV2);
               CV2_mean_bsl_D(i_bsl).mean=file_CV2(i).(spk_int)(j).all_info(k).mean*1000;
            elseif k>=test_on
               i_test=i_test+1;
               CV2_mean_test_D(i_test).trial_num=file_CV2(i).(spk_int)(j).trial_num;
               CV2_mean_test_D(i_test).CV2=abs(file_CV2(i).(spk_int)(j).all_info(k).CV2);
               CV2_mean_test_D(i_test).mean=file_CV2(i).(spk_int)(j).all_info(k).mean*1000;                
            end            
        end 
        if size(file_CV2(i).(spk_int)(j).event_fac,2)>0
            for k=1:size(file_CV2(i).(spk_int)(j).event_fac,2)
                i_fac=i_fac+1;
                burst_fac_D(i_fac).trial_num=file_CV2(i).(spk_int)(j).trial_num;
                burst_fac_D(i_fac).onset=file_CV2(i).(spk_int)(j).event_fac(k).onset;
                burst_fac_D(i_fac).mid_t=file_CV2(i).(spk_int)(j).event_fac(k).mid_t;
                burst_fac_D(i_fac).peak_t=file_CV2(i).(spk_int)(j).event_fac(k).peak_t;
                burst_fac_D(i_fac).CR_align=file_CV2(i).(spk_int)(j).event_fac(k).(plt_marker_fac)-file_CV2(i).(spk_int)(j).CR_onset;
            end
        end
        if size(file_CV2(i).(spk_int)(j).event_sup,2)>0
            for k=1:size(file_CV2(i).(spk_int)(j).event_sup,2)              
                i_sup=i_sup+1;
                burst_sup_D(i_sup).trial_num=file_CV2(i).(spk_int)(j).trial_num;
                burst_sup_D(i_sup).onset=file_CV2(i).(spk_int)(j).event_sup(k).onset;
                burst_sup_D(i_sup).mid_t=file_CV2(i).(spk_int)(j).event_sup(k).mid_t;
                burst_sup_D(i_sup).peak_t=file_CV2(i).(spk_int)(j).event_sup(k).peak_t;
                burst_sup_D(i_sup).CR_align=file_CV2(i).(spk_int)(j).event_sup(k).(plt_marker_sup)-file_CV2(i).(spk_int)(j).CR_onset;
            end    
        end
    end
    
    subplot('Position',[0.525 0.4 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h1.FaceColor = [0 0 1];
    hold on
    h2=histogram([burst_fac_D.onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h2.FaceColor = [1 0 1];
    xlim([-250 750]);
    xticks(-250:250:750);
    ylabel('Probability');
    title(['Facilitation ' plt_marker_fac ' distribution']);
    
    subplot('Position',[0.525 0.1 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h1.FaceColor = [0 0 1];
    hold on
    h2=histogram([burst_sup_D.onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h2.FaceColor = [0 1 1];
    xlim([-250 750]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Probability');
    title(['Suppression ' plt_marker_sup ' distribution']);
    
    subplot('Position',[0.75 0.4 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*-1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram([burst_fac_D.CR_align]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [1 0 1];
    xlim([-500 500]);
    xticks(-500:250:750);
    title(['Facilitation ' plt_marker_fac ' distribution']);
    
    subplot('Position',[0.75 0.1 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*-1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram([burst_sup_D.CR_align]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 1 1];
    xlim([-500 500]);
    xticks(-500:250:750);
    xlabel('Time(ms)');
    title(['Suppression ' plt_marker_sup ' distribution']);
    
    subplot('Position',[0.05 0.4 0.29 0.5])
    for m=1:size(CV2_mean_bsl_D,2)
        plot(CV2_mean_bsl_D(m).mean,CV2_mean_bsl_D(m).CV2,'k.')
        hold on
    end
    for m=1:size(CV2_mean_test_D,2)
        plot(CV2_mean_test_D(m).mean,CV2_mean_test_D(m).CV2,'r.')
        hold on
    end   
    xlim([0 100]);
    ylim([0 2]);
    text(75,1.8,'Baseline','Color',[0 0 0],'FontSize',15);
    text(72,1.85,'.','Color',[0 0 0],'FontSize',30);
    text(75,1.7,'CR period','Color',[1 0 0],'FontSize',15);
    text(72,1.75,'.','Color',[1 0 0],'FontSize',30);
    xticks(0:20:100);
    yticks(0:0.5:2);
    ylabel('|CV2|');
    title(['DT cell-' num2str(file_CV2(i).cell_ID) '-Delay fac-' num2str(file_CV2(i).mod_info.fac_D) '-sup-' num2str(file_CV2(i).mod_info.sup_D)])
    
    subplot('Position',[0.05 0.15 0.29 0.2])
    h1=histogram([CV2_mean_bsl_D.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([CV2_mean_test_D.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Mean of ISI pair (ms)');
    ylabel('Probability');  
    mean_hist_bsl_D=zeros(3,size(h1.BinCounts,2));
    mean_hist_bsl_D(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    mean_hist_bsl_D(2,:)=h1.BinCounts;
    mean_hist_bsl_D(3,:)=h1.BinCounts/size(h1.Data,2);
    mean_hist_test_D=zeros(3,size(h2.BinCounts,2));
    mean_hist_test_D(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    mean_hist_test_D(2,:)=h2.BinCounts;
    mean_hist_test_D(3,:)=h2.BinCounts/size(h2.Data,2);    
    mean_hist.bsl=mean_hist_bsl_D;
    mean_hist.test=mean_hist_test_D;
    
    axes('Position',[0.28 0.2 0.05 0.13])
    box on
    plot(1,mean([CV2_mean_bsl_D.mean]),'ks','MarkerSize',5)
    hold on
    plot(2,mean([CV2_mean_test_D.mean]),'rs','MarkerSize',5)
    hold on
    se_bsl=std([CV2_mean_bsl_D.mean])/sqrt(length([CV2_mean_bsl_D.mean]));
    se_test=std([CV2_mean_test_D.mean])/sqrt(length([CV2_mean_test_D.mean]));
    errorbar(1,mean([CV2_mean_bsl_D.mean]),se_bsl,'k','CapSize',15)
    hold on
    errorbar(2,mean([CV2_mean_test_D.mean]),se_test,'r','CapSize',15)
    hold on
    xlim([0 3]);
    xticks([1 2]);
    xticklabels({'Bsl','CR'});
    ylabel('Mean of ISI pair (ms)');    
    p = ranksum([CV2_mean_bsl_D.mean],[CV2_mean_test_D.mean]);
    if p<0.05
       text(2.6,mean([CV2_mean_test_D.mean]),'*','FontSize',20,'Color','r','HorizontalAlignment','center');
    else
       text(2.6,mean([CV2_mean_test_D.mean]),'ns.','FontSize',15,'HorizontalAlignment','center'); 
    end
    
    subplot('Position',[0.37 0.4 0.12 0.5])
    h1=histogram([CV2_mean_bsl_D.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([CV2_mean_test_D.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Probability');
    CV2_hist_bsl_D=zeros(3,size(h1.BinCounts,2));
    CV2_hist_bsl_D(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    CV2_hist_bsl_D(2,:)=h1.BinCounts;
    CV2_hist_bsl_D(3,:)=h1.BinCounts/size(h1.Data,2);
    CV2_hist_test_D=zeros(3,size(h2.BinCounts,2));
    CV2_hist_test_D(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    CV2_hist_test_D(2,:)=h2.BinCounts;
    CV2_hist_test_D(3,:)=h2.BinCounts/size(h2.Data,2);    
    CV2_hist.bsl=CV2_hist_bsl_D;
    CV2_hist.test=CV2_hist_test_D;
    
    axes('Position',[0.43 0.76 0.05 0.13])
    box on
    plot(1,mean([CV2_mean_bsl_D.CV2]),'ks','MarkerSize',5)
    hold on
    plot(2,mean([CV2_mean_test_D.CV2]),'rs','MarkerSize',5)
    hold on
    se_bsl=std([CV2_mean_bsl_D.CV2])/sqrt(length([CV2_mean_bsl_D.CV2]));
    se_test=std([CV2_mean_test_D.CV2])/sqrt(length([CV2_mean_test_D.CV2]));
    errorbar(1,mean([CV2_mean_bsl_D.CV2]),se_bsl,'k','CapSize',15)
    hold on
    errorbar(2,mean([CV2_mean_test_D.CV2]),se_test,'r','CapSize',15)
    hold on
    xlim([0 3]);
    xticks([1 2]);
    xticklabels({'Bsl','CR'});
    ylabel('|CV2|');    
    p = ranksum([CV2_mean_bsl_D.CV2],[CV2_mean_test_D.CV2]);
    if p<0.05
       text(2.6,mean([CV2_mean_test_D.CV2]),'*','FontSize',20,'Color','r','HorizontalAlignment','center');
    else
       text(2.6,mean([CV2_mean_test_D.CV2]),'ns.','FontSize',15,'HorizontalAlignment','center'); 
    end
    
    subplot('Position',[0.37 0.15 0.12 0.2])
    curve_CV2=struct('mean_lim',[],'bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[]);
    [~,index] = sortrows([CV2_mean_bsl_D.mean].'); 
    CV2_mean_bsl_D = CV2_mean_bsl_D(index);
    clear index
    [~,index] = sortrows([CV2_mean_test_D.mean].'); 
    CV2_mean_test_D = CV2_mean_test_D(index);    
    clear index
    curve_idx=zeros(100/BinWidth_CV2+1,3);
    for n=1:100/BinWidth_CV2
        curve_CV2(n).mean_lim=n*BinWidth_CV2;
        curve_idx(n+1,1)=n*BinWidth_CV2;
        if curve_CV2(n).mean_lim-BinWidth_CV2>max([CV2_mean_bsl_D.mean])
           curve_idx(n+1,2)=curve_idx(n,2);
        elseif curve_CV2(n).mean_lim<min([CV2_mean_bsl_D.mean])
           curve_idx(n+1,2)=curve_idx(n,2);
        else
           curve_idx(n+1,2)=find([CV2_mean_bsl_D.mean]<=curve_CV2(n).mean_lim,1,'last');
        end
        if curve_idx(n+1,2)~=curve_idx(n,2)
           curve_CV2(n).bsl_mean=mean([CV2_mean_bsl_D(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2]);
           curve_CV2(n).bsl_SE=std([CV2_mean_bsl_D(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2])/sqrt(length([CV2_mean_bsl_D(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2])); 
        else
           curve_CV2(n).bsl_mean=0;
           curve_CV2(n).bsl_SE=0;
        end    
        if curve_CV2(n).mean_lim-BinWidth_CV2>max([CV2_mean_test_D.mean])
           curve_idx(n+1,3)=curve_idx(n,3);
        elseif curve_CV2(n).mean_lim<min([CV2_mean_test_D.mean])
           curve_idx(n+1,3)=curve_idx(n,3);
        else
           curve_idx(n+1,3)=find([CV2_mean_test_D.mean]<=curve_CV2(n).mean_lim,1,'last');
        end
        if curve_idx(n+1,3)~=curve_idx(n,3)
           curve_CV2(n).test_mean=mean([CV2_mean_test_D(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2]);
           curve_CV2(n).test_SE=std([CV2_mean_test_D(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2])/sqrt(length([CV2_mean_test_D(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2])); 
        else
           curve_CV2(n).test_mean=0;
           curve_CV2(n).test_SE=0;
        end 
    end
    
    plot([curve_CV2.mean_lim],[curve_CV2.bsl_mean],'k-')
    hold on
    plot([curve_CV2.mean_lim],[curve_CV2.test_mean],'r-')
    hold on
    errorbar([curve_CV2.mean_lim],[curve_CV2.bsl_mean],[curve_CV2.bsl_SE],'k')
    hold on
    errorbar([curve_CV2.mean_lim],[curve_CV2.test_mean],[curve_CV2.test_SE],'r')
    hold on
    xlim([0 100]);
    ylim([0 2]);    
    xticks(0:20:100);
    yticks(0:0.5:2);    
    xlabel('Mean of ISI pair (ms)');
    ylabel('|CV2|'); 
    
    saveas(gcf,[['DT cell-' num2str(file_CV2(i).cell_ID) '-Delay fac-' num2str(file_CV2(i).mod_info.fac_D) '-sup-' num2str(file_CV2(i).mod_info.sup_D)] '.jpg']);  
    close all
    hist_info_D.CV2_mean_bsl=CV2_mean_bsl_D;
    hist_info_D.CV2_mean_test=CV2_mean_test_D;
    hist_info_D.CV2_hist=CV2_hist;
    hist_info_D.mean_hist=mean_hist;
    hist_info_D.CV2_mean_curve=curve_CV2;
    hist_info_D.burst_fac=burst_fac_D;
    hist_info_D.burst_sup=burst_sup_D;
    CV2_hist_list(i).cell_ID=file_CV2(i).cell_ID;
    CV2_hist_list(i).hist_info_D=hist_info_D;


    spk_int='spk_int_T';
    t_post=500;
    CV2_mean_bsl_T=struct('trial_num',[],'CV2',[],'mean',[]);
    CV2_mean_test_T=struct('trial_num',[],'CV2',[],'mean',[]);
    CV2_hist=struct('bsl',[],'test',[]);
    mean_hist=struct('bsl',[],'test',[]);
    burst_fac_T=struct('trial_num',[],'onset',[],'mid_t',[],'peak_t',[],'CR_align',[]);
    burst_sup_T=struct('trial_num',[],'onset',[],'mid_t',[],'peak_t',[],'CR_align',[]);
    i_bsl=0;
    i_test=0;
    i_fac=0;
    i_sup=0;
    
    figure('units','normalized','outerposition',[0 0 1 1]);  
    
    subplot('Position',[0.525 0.7 0.2 0.25])
    [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
    file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
    clear index;
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
               plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
               hold on
            end
        end
        plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
        plot(0,j,'g.')
        hold on
        plot(t_post,j,'r.')
        hold on       
    end
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 j+1]);
    ylabel('Trial number');
    title('CS onset align');
    
    subplot('Position',[0.75 0.7 0.2 0.25])
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'k.')
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'m.') 
               hold on
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
               plot((file_CV2(i).(spk_int)(j).all_info(k).t-file_CV2(i).(spk_int)(j).CR_onset)*1000,j,'c.') 
               hold on
            end
        end
        plot(0,j,'b*')
        plot(-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'g.')
        hold on
        plot(t_post-file_CV2(i).(spk_int)(j).CR_onset*1000,j,'r.')
        hold on       
    end
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 j+1]);
    ylabel('Trial number');
    title('CR onset align');    
    
    for j=1:size(file_CV2(i).(spk_int),2)        
        file_CV2(i).(spk_int)(j).all_info=file_CV2(i).(spk_int)(j).all_info(~cellfun(@isempty,{file_CV2(i).(spk_int)(j).all_info.type}));
        test_on=find([file_CV2(i).(spk_int)(j).all_info.t]>=0,1,'first');
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if k<test_on
               i_bsl=i_bsl+1;
               CV2_mean_bsl_T(i_bsl).trial_num=file_CV2(i).(spk_int)(j).trial_num;
               CV2_mean_bsl_T(i_bsl).CV2=abs(file_CV2(i).(spk_int)(j).all_info(k).CV2);
               CV2_mean_bsl_T(i_bsl).mean=file_CV2(i).(spk_int)(j).all_info(k).mean*1000;
            elseif k>=test_on
               i_test=i_test+1;
               CV2_mean_test_T(i_test).trial_num=file_CV2(i).(spk_int)(j).trial_num;
               CV2_mean_test_T(i_test).CV2=abs(file_CV2(i).(spk_int)(j).all_info(k).CV2);
               CV2_mean_test_T(i_test).mean=file_CV2(i).(spk_int)(j).all_info(k).mean*1000;                
            end            
        end 
        if size(file_CV2(i).(spk_int)(j).event_fac,2)>0
            for k=1:size(file_CV2(i).(spk_int)(j).event_fac,2)
                i_fac=i_fac+1;
                burst_fac_T(i_fac).trial_num=file_CV2(i).(spk_int)(j).trial_num;
                burst_fac_T(i_fac).onset=file_CV2(i).(spk_int)(j).event_fac(k).onset;
                burst_fac_T(i_fac).mid_t=file_CV2(i).(spk_int)(j).event_fac(k).mid_t;
                burst_fac_T(i_fac).peak_t=file_CV2(i).(spk_int)(j).event_fac(k).peak_t;
                burst_fac_T(i_fac).CR_align=file_CV2(i).(spk_int)(j).event_fac(k).(plt_marker_fac)-file_CV2(i).(spk_int)(j).CR_onset;
            end
        end
        if size(file_CV2(i).(spk_int)(j).event_sup,2)>0
            for k=1:size(file_CV2(i).(spk_int)(j).event_sup,2)              
                i_sup=i_sup+1;
                burst_sup_T(i_sup).trial_num=file_CV2(i).(spk_int)(j).trial_num;
                burst_sup_T(i_sup).onset=file_CV2(i).(spk_int)(j).event_sup(k).onset;
                burst_sup_T(i_sup).mid_t=file_CV2(i).(spk_int)(j).event_sup(k).mid_t;
                burst_sup_T(i_sup).peak_t=file_CV2(i).(spk_int)(j).event_sup(k).peak_t;
                burst_sup_T(i_sup).CR_align=file_CV2(i).(spk_int)(j).event_sup(k).(plt_marker_sup)-file_CV2(i).(spk_int)(j).CR_onset;
            end    
        end
    end
    
    subplot('Position',[0.525 0.4 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h1.FaceColor = [0 0 1];
    hold on
    h2=histogram([burst_fac_T.onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h2.FaceColor = [1 0 1];
    xlim([-250 750]);
    xticks(-250:250:750);
    ylabel('Probability');
    title(['Facilitation ' plt_marker_fac ' distribution']);
    
    subplot('Position',[0.525 0.1 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h1.FaceColor = [0 0 1];
    hold on
    h2=histogram([burst_sup_T.onset]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-250,750],'Normalization','probability');
    h2.FaceColor = [0 1 1];
    xlim([-250 750]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Probability');
    title(['Suppression ' plt_marker_sup ' distribution']);
    
    subplot('Position',[0.75 0.4 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*-1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram([burst_fac_T.CR_align]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [1 0 1];
    xlim([-500 500]);
    xticks(-500:250:750);
    title(['Facilitation ' plt_marker_fac ' distribution']);
    
    subplot('Position',[0.75 0.1 0.2 0.25])
    h1=histogram([file_CV2(i).(spk_int).CR_onset]*-1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram([burst_sup_T.CR_align]*1000,'BinWidth',BinWidth_mod,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 1 1];
    xlim([-500 500]);
    xticks(-500:250:750);
    xlabel('Time(ms)');
    title(['Suppression ' plt_marker_sup ' distribution']);
    
    subplot('Position',[0.05 0.4 0.29 0.5])
    for m=1:size(CV2_mean_bsl_T,2)
        plot(CV2_mean_bsl_T(m).mean,CV2_mean_bsl_T(m).CV2,'k.')
        hold on
    end
    for m=1:size(CV2_mean_test_T,2)
        plot(CV2_mean_test_T(m).mean,CV2_mean_test_T(m).CV2,'r.')
        hold on
    end   
    xlim([0 100]);
    ylim([0 2]);
    text(75,1.8,'Baseline','Color',[0 0 0],'FontSize',15);
    text(72,1.85,'.','Color',[0 0 0],'FontSize',30);
    text(75,1.7,'CR period','Color',[1 0 0],'FontSize',15);
    text(72,1.75,'.','Color',[1 0 0],'FontSize',30);
    xticks(0:20:100);
    yticks(0:0.5:2);
    ylabel('|CV2|');
    title(['DT cell-' num2str(file_CV2(i).cell_ID) '-Trace fac-' num2str(file_CV2(i).mod_info.fac_T) '-sup-' num2str(file_CV2(i).mod_info.sup_T)])
    
    subplot('Position',[0.05 0.15 0.29 0.2])
    h1=histogram([CV2_mean_bsl_T.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([CV2_mean_test_T.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Mean of ISI pair (ms)');
    ylabel('Probability');  
    mean_hist_bsl_T=zeros(3,size(h1.BinCounts,2));
    mean_hist_bsl_T(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    mean_hist_bsl_T(2,:)=h1.BinCounts;
    mean_hist_bsl_T(3,:)=h1.BinCounts/size(h1.Data,2);
    mean_hist_test_T=zeros(3,size(h2.BinCounts,2));
    mean_hist_test_T(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    mean_hist_test_T(2,:)=h2.BinCounts;
    mean_hist_test_T(3,:)=h2.BinCounts/size(h2.Data,2);    
    mean_hist.bsl=mean_hist_bsl_T;
    mean_hist.test=mean_hist_test_T;
    
    axes('Position',[0.28 0.2 0.05 0.13])
    box on
    plot(1,mean([CV2_mean_bsl_T.mean]),'ks','MarkerSize',5)
    hold on
    plot(2,mean([CV2_mean_test_T.mean]),'rs','MarkerSize',5)
    hold on
    se_bsl=std([CV2_mean_bsl_T.mean])/sqrt(length([CV2_mean_bsl_T.mean]));
    se_test=std([CV2_mean_test_T.mean])/sqrt(length([CV2_mean_test_T.mean]));
    errorbar(1,mean([CV2_mean_bsl_T.mean]),se_bsl,'k','CapSize',15)
    hold on
    errorbar(2,mean([CV2_mean_test_T.mean]),se_test,'r','CapSize',15)
    hold on
    xlim([0 3]);
    xticks([1 2]);
    xticklabels({'Bsl','CR'});
    ylabel('Mean of ISI pair (ms)');    
    p = ranksum([CV2_mean_bsl_T.mean],[CV2_mean_test_T.mean]);
    if p<0.05
       text(2.6,mean([CV2_mean_test_T.mean]),'*','FontSize',20,'Color','r','HorizontalAlignment','center');
    else
       text(2.6,mean([CV2_mean_test_T.mean]),'ns.','FontSize',15,'HorizontalAlignment','center'); 
    end
    
    subplot('Position',[0.37 0.4 0.12 0.5])
    h1=histogram([CV2_mean_bsl_T.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([CV2_mean_test_T.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Probability');
    CV2_hist_bsl_T=zeros(3,size(h1.BinCounts,2));
    CV2_hist_bsl_T(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    CV2_hist_bsl_T(2,:)=h1.BinCounts;
    CV2_hist_bsl_T(3,:)=h1.BinCounts/size(h1.Data,2);
    CV2_hist_test_T=zeros(3,size(h2.BinCounts,2));
    CV2_hist_test_T(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    CV2_hist_test_T(2,:)=h2.BinCounts;
    CV2_hist_test_T(3,:)=h2.BinCounts/size(h2.Data,2);    
    CV2_hist.bsl=CV2_hist_bsl_T;
    CV2_hist.test=CV2_hist_test_T;
    
    axes('Position',[0.43 0.76 0.05 0.13])
    box on
    plot(1,mean([CV2_mean_bsl_T.CV2]),'ks','MarkerSize',5)
    hold on
    plot(2,mean([CV2_mean_test_T.CV2]),'rs','MarkerSize',5)
    hold on
    se_bsl=std([CV2_mean_bsl_T.CV2])/sqrt(length([CV2_mean_bsl_T.CV2]));
    se_test=std([CV2_mean_test_T.CV2])/sqrt(length([CV2_mean_test_T.CV2]));
    errorbar(1,mean([CV2_mean_bsl_T.CV2]),se_bsl,'k','CapSize',15)
    hold on
    errorbar(2,mean([CV2_mean_test_T.CV2]),se_test,'r','CapSize',15)
    hold on
    xlim([0 3]);
    xticks([1 2]);
    xticklabels({'Bsl','CR'});
    ylabel('|CV2|');    
    p = ranksum([CV2_mean_bsl_T.CV2],[CV2_mean_test_T.CV2]);
    if p<0.05
       text(2.6,mean([CV2_mean_test_T.CV2]),'*','FontSize',20,'Color','r','HorizontalAlignment','center');
    else
       text(2.6,mean([CV2_mean_test_T.CV2]),'ns.','FontSize',15,'HorizontalAlignment','center'); 
    end
    
    subplot('Position',[0.37 0.15 0.12 0.2])
    curve_CV2=struct('mean_lim',[],'bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[]);
    [~,index] = sortrows([CV2_mean_bsl_T.mean].'); 
    CV2_mean_bsl_T = CV2_mean_bsl_T(index);
    clear index
    [~,index] = sortrows([CV2_mean_test_T.mean].'); 
    CV2_mean_test_T = CV2_mean_test_T(index);    
    clear index
    curve_idx=zeros(100/BinWidth_CV2+1,3);
    for n=1:100/BinWidth_CV2
        curve_CV2(n).mean_lim=n*BinWidth_CV2;
        curve_idx(n+1,1)=n*BinWidth_CV2;
        if curve_CV2(n).mean_lim-BinWidth_CV2>max([CV2_mean_bsl_T.mean])
           curve_idx(n+1,2)=curve_idx(n,2);
        elseif curve_CV2(n).mean_lim<min([CV2_mean_bsl_T.mean])
           curve_idx(n+1,2)=curve_idx(n,2);
        else
           curve_idx(n+1,2)=find([CV2_mean_bsl_T.mean]<=curve_CV2(n).mean_lim,1,'last');
        end
        if curve_idx(n+1,2)~=curve_idx(n,2)
           curve_CV2(n).bsl_mean=mean([CV2_mean_bsl_T(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2]);
           curve_CV2(n).bsl_SE=std([CV2_mean_bsl_T(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2])/sqrt(length([CV2_mean_bsl_T(curve_idx(n,2)+1:curve_idx(n+1,2)).CV2])); 
        else
           curve_CV2(n).bsl_mean=0;
           curve_CV2(n).bsl_SE=0;
        end    
        if curve_CV2(n).mean_lim-BinWidth_CV2>max([CV2_mean_test_T.mean])
           curve_idx(n+1,3)=curve_idx(n,3);
        elseif curve_CV2(n).mean_lim<min([CV2_mean_test_T.mean])
           curve_idx(n+1,3)=curve_idx(n,3);
        else
           curve_idx(n+1,3)=find([CV2_mean_test_T.mean]<=curve_CV2(n).mean_lim,1,'last');
        end
        if curve_idx(n+1,3)~=curve_idx(n,3)
           curve_CV2(n).test_mean=mean([CV2_mean_test_T(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2]);
           curve_CV2(n).test_SE=std([CV2_mean_test_T(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2])/sqrt(length([CV2_mean_test_T(curve_idx(n,3)+1:curve_idx(n+1,3)).CV2])); 
        else
           curve_CV2(n).test_mean=0;
           curve_CV2(n).test_SE=0;
        end 
    end
    
    plot([curve_CV2.mean_lim],[curve_CV2.bsl_mean],'k-')
    hold on
    plot([curve_CV2.mean_lim],[curve_CV2.test_mean],'r-')
    hold on
    errorbar([curve_CV2.mean_lim],[curve_CV2.bsl_mean],[curve_CV2.bsl_SE],'k')
    hold on
    errorbar([curve_CV2.mean_lim],[curve_CV2.test_mean],[curve_CV2.test_SE],'r')
    hold on
    xlim([0 100]);
    ylim([0 2]);    
    xticks(0:20:100);
    yticks(0:0.5:2);    
    xlabel('Mean of ISI pair (ms)');
    ylabel('|CV2|'); 
    
    saveas(gcf,[['DT cell-' num2str(file_CV2(i).cell_ID) '-Trace fac-' num2str(file_CV2(i).mod_info.fac_T) '-sup-' num2str(file_CV2(i).mod_info.sup_T)] '.jpg']);  
    close all
    hist_info_T.CV2_mean_bsl=CV2_mean_bsl_T;
    hist_info_T.CV2_mean_test=CV2_mean_test_T;
    hist_info_T.CV2_hist=CV2_hist;
    hist_info_T.mean_hist=mean_hist;
    hist_info_T.CV2_mean_curve=curve_CV2;
    hist_info_T.burst_fac=burst_fac_T;
    hist_info_T.burst_sup=burst_sup_T;
    CV2_hist_list(i).cell_ID=file_CV2(i).cell_ID;
    CV2_hist_list(i).hist_info_T=hist_info_T;
end