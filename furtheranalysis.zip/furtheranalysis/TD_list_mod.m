% The all_cell list in TEC-DEC conversion recordings with the modulation
% type in both CR and UR epoch based on the package file of each single
% recording sessions. --Zhong

listing_T = dir('pack_*_trace*');
listing_D = dir('pack_*_delay*');


TD_list=struct('cell_ID',[],'file_name',[],'Day',[],'cell_num',[],'channel_info_T',[],'CR_fac_T',[],'CR_sup_T',[],'UR_fac_T',[],'UR_sup_T',[],'mod_info_T',[],'all_info_T',[],...
              'channel_info_D',[],'CR_fac_D',[],'CR_sup_D',[],'UR_fac_D',[],'UR_sup_D',[],'mod_info_D',[],'all_info_D',[]);
cell_ID=1;

% first loop for each delay recording session
for i=1:size(listing_T,1)
    load(listing_T(i).name);
    newStr=extractBetween(listing_T(i).name,'pack_','_trace.mat');
%   second loop for each cell
    for j=1:size(package.mod_tp,2)
        TD_list(cell_ID).cell_ID=cell_ID;
        TD_list(cell_ID).file_name=newStr; 
        TD_list(cell_ID).Day=0; 
        TD_list(cell_ID).cell_num=j; 
        TD_list(cell_ID).channel_info_T=package.channel_info(j).ch;
        TD_list(cell_ID).CR_fac_T=package.mod_tp(j).CR_trial.CR_fac; 
        TD_list(cell_ID).CR_sup_T=package.mod_tp(j).CR_trial.CR_sup; 
        TD_list(cell_ID).UR_fac_T=package.mod_tp(j).CR_trial.UR_fac; 
        TD_list(cell_ID).UR_sup_T=package.mod_tp(j).CR_trial.UR_sup;
        TD_list(cell_ID).mod_info_T=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
           TD_list(cell_ID).mod_info_T.CRf=package.mod_tp(j).CR_trial.CR_fac_info;
           TD_list(cell_ID).mod_info_T.CRs=package.mod_tp(j).CR_trial.CR_sup_info;
           TD_list(cell_ID).mod_info_T.URf=package.mod_tp(j).CR_trial.UR_fac_info;
           TD_list(cell_ID).mod_info_T.URs=package.mod_tp(j).CR_trial.UR_sup_info;
        TD_list(cell_ID).all_info_T=struct('sss_all',[],'ttt',[]);
           TD_list(cell_ID).all_info_T.sss_all=struct('blk',[],'behavior',[],'psth',[]);
               TD_list(cell_ID).all_info_T.sss_all.blk=package.blk_avg;
               TD_list(cell_ID).all_info_T.sss_all.behavior=package.behavior_table;
               TD_list(cell_ID).all_info_T.sss_all.psth=package.psth(j);
           TD_list(cell_ID).all_info_T.ttt=package.ttt(j);
        cell_ID=cell_ID+1;
    end
    
    cell_ID=cell_ID-j;
    D_extract=strfind({listing_D.name},newStr);
    D_file=find(~cellfun(@isempty,D_extract));
    load(listing_D(D_file).name);   
    for j=1:size(package.mod_tp,2)
        TD_list(cell_ID).channel_info_D=package.channel_info(j).ch;
        TD_list(cell_ID).CR_fac_D=package.mod_tp(j).CR_trial.CR_fac; 
        TD_list(cell_ID).CR_sup_D=package.mod_tp(j).CR_trial.CR_sup; 
        TD_list(cell_ID).UR_fac_D=package.mod_tp(j).CR_trial.UR_fac; 
        TD_list(cell_ID).UR_sup_D=package.mod_tp(j).CR_trial.UR_sup;
        TD_list(cell_ID).mod_info_D=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
           TD_list(cell_ID).mod_info_D.CRf=package.mod_tp(j).CR_trial.CR_fac_info;
           TD_list(cell_ID).mod_info_D.CRs=package.mod_tp(j).CR_trial.CR_sup_info;
           TD_list(cell_ID).mod_info_D.URf=package.mod_tp(j).CR_trial.UR_fac_info;
           TD_list(cell_ID).mod_info_D.URs=package.mod_tp(j).CR_trial.UR_sup_info;
        TD_list(cell_ID).all_info_D=struct('sss_all',[],'ttt',[]);
           TD_list(cell_ID).all_info_D.sss_all=struct('blk',[],'behavior',[],'psth',[]);
               TD_list(cell_ID).all_info_D.sss_all.blk=package.blk_avg;
               TD_list(cell_ID).all_info_D.sss_all.behavior=package.behavior_table;
               TD_list(cell_ID).all_info_D.sss_all.psth=package.psth(j);
           TD_list(cell_ID).all_info_D.ttt=package.ttt(j);   
        cell_ID=cell_ID+1;
    end   
end