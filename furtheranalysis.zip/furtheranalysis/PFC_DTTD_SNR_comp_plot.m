% PFC DTTD population scatter plot

list=TD_mPFC_ready;
mod_file=PFC_mod_list_TD;
session_2='Delay';
session_1='Trace';
data_2='CR_trial_D';
data_1='CR_trial_T';
comp_item_1='bsl_all';   % bsl_all   CR_epoch_250
comp_item_2='bsl_all';
mod_type_2='mod_type_D';
mod_type_1='mod_type_T';
align_info_2='align_info_D';
align_info_1='align_info_T';
all_info_2='all_info_D';
all_info_1='all_info_T';
bsl_norm_test=0;
bsl_norm_curve=0;
color_1=[1 0.5 0];
color_2=[0.4 0 0.8];
color_n=[0.8 0.8 0.8];

t_pre=-500;
t_post=1000;
bin=50;
step=10;
ymin_1=8;
ymin_2=8;
ymax_1=20;
ymax_2=20;

data_plot=data_org(mod_file,data_1,data_2,comp_item_1,comp_item_2,bsl_norm_test);
idx_1=0;
idx_2=0;
idx_n=0;
idx_fac_1=0;
idx_fac_2=0;
idx_fac_3=0;

fac_cell_1=struct('cell_ID',[],'item_1',[],'item_2',[],'item_21',[],'item_22',[],'item_23',[],'item_24',[],'zscore',[],'zscore_1',[],'zscore_2',[],'zscore_21',[],'zscore_22',[],'zscore_23',[],'zscore_24',[]);
fac_cell_2=struct('cell_ID',[],'item_1',[],'item_2',[],'item_21',[],'item_22',[],'item_23',[],'item_24',[],'zscore',[],'zscore_1',[],'zscore_2',[],'zscore_21',[],'zscore_22',[],'zscore_23',[],'zscore_24',[]);
fac_cell_3=struct('cell_ID',[],'item_1',[],'item_2',[],'item_21',[],'item_22',[],'item_23',[],'item_24',[]);

bsl_sig_list=struct('cell_ID',[],'item_1',[],'item_2',[],'item_21',[],'item_22',[],'item_23',[],'item_24',[],'d_bsl',[],'d_per',[],'CV2',[],'zscore',[],'zscore_1',[],'zscore_2',[],'zscore_21',[],'zscore_22',[],'zscore_23',[],'zscore_24',[]);
bsl_nosig_list=struct('cell_ID',[],'item_1',[],'item_2',[],'item_21',[],'item_22',[],'item_23',[],'item_24',[],'d_bsl',[],'d_per',[],'CV2',[]);

figure;
for i=1:size(data_plot,2)
    if data_plot(i).p>=0.05
       plot(data_plot(i).session_1,data_plot(i).session_2,'.','Color',color_n)
       hold on
       idx_n=idx_n+1;
       bsl_nosig_list(idx_n).cell_ID=mod_file(i).cell_ID;
       bsl_nosig_list(idx_n).item_1=data_plot(i).session_1;
       bsl_nosig_list(idx_n).item_2=data_plot(i).session_2;
       bsl_nosig_list(idx_n).item_21=data_plot(i).session_21;
       bsl_nosig_list(idx_n).item_22=data_plot(i).session_22;
       bsl_nosig_list(idx_n).item_23=data_plot(i).session_23;
       bsl_nosig_list(idx_n).item_24=data_plot(i).session_24;
       bsl_nosig_list(idx_n).d_bsl=data_plot(i).session_2-data_plot(i).session_1;
       bsl_nosig_list(idx_n).d_per=abs(data_plot(i).session_2-data_plot(i).session_1)/data_plot(i).session_1*100;
       bsl_nosig_list(idx_n).CV2=2*abs(data_plot(i).session_2-data_plot(i).session_1)/(data_plot(i).session_2+data_plot(i).session_1);
       if mod_file(i).(mod_type_1)==1 || mod_file(i).(mod_type_2)==1
          idx_fac_3=idx_fac_3+1;
          fac_cell_3(idx_fac_3).cell_ID=mod_file(i).cell_ID;
          fac_cell_3(idx_fac_3).item_1=data_plot(i).session_1;
          fac_cell_3(idx_fac_3).item_2=data_plot(i).session_2;
       end
    elseif data_plot(i).p<0.05 && data_plot(i).session_1>data_plot(i).session_2
       zscore_cell=zscore_cal(list,i,all_info_1,all_info_2,-500,250);
       zscore_bsl_sig_avg=zscore_org(zscore_cell,'bsl_mean');
       plot(data_plot(i).session_1,data_plot(i).session_2,'.','Color',color_1,'MarkerSize',10)
       hold on      
       idx_1=idx_1+1;
       bsl_sig_list(idx_1).cell_ID=mod_file(i).cell_ID;
       bsl_sig_list(idx_1).item_1=data_plot(i).session_1;
       bsl_sig_list(idx_1).item_2=data_plot(i).session_2;
       bsl_sig_list(idx_1).item_21=data_plot(i).session_21;
       bsl_sig_list(idx_1).item_22=data_plot(i).session_22;
       bsl_sig_list(idx_1).item_23=data_plot(i).session_23;
       bsl_sig_list(idx_1).item_24=data_plot(i).session_24;
       bsl_sig_list(idx_1).d_bsl=data_plot(i).session_2-data_plot(i).session_1;
       bsl_sig_list(idx_1).d_per=abs(data_plot(i).session_2-data_plot(i).session_1)/data_plot(i).session_1*100;
       bsl_sig_list(idx_1).CV2=2*abs(data_plot(i).session_2-data_plot(i).session_1)/(data_plot(i).session_2+data_plot(i).session_1);
       bsl_sig_list(idx_1).zscore=zscore_cell;
       bsl_sig_list(idx_1).zscore_1=zscore_bsl_sig_avg.session_1;
       bsl_sig_list(idx_1).zscore_2=zscore_bsl_sig_avg.session_2;
       bsl_sig_list(idx_1).zscore_21=zscore_bsl_sig_avg.session_21;
       bsl_sig_list(idx_1).zscore_22=zscore_bsl_sig_avg.session_22;
       bsl_sig_list(idx_1).zscore_23=zscore_bsl_sig_avg.session_23;
       bsl_sig_list(idx_1).zscore_24=zscore_bsl_sig_avg.session_24;
       if (mod_file(i).(mod_type_1)==1 || mod_file(i).(mod_type_2)==1) && data_plot(i).session_1-data_plot(i).session_2>2
          idx_fac_1=idx_fac_1+1;
          zscore_fac_1_avg=zscore_org(zscore_cell,'CR_max');
          fac_cell_1(idx_fac_1).cell_ID=mod_file(i).cell_ID;
          fac_cell_1(idx_fac_1).item_1=data_plot(i).session_1;
          fac_cell_1(idx_fac_1).item_2=data_plot(i).session_2;
          fac_cell_1(idx_fac_1).item_21=data_plot(i).session_21;
          fac_cell_1(idx_fac_1).item_22=data_plot(i).session_22;
          fac_cell_1(idx_fac_1).item_23=data_plot(i).session_23;
          fac_cell_1(idx_fac_1).item_24=data_plot(i).session_24;
          fac_cell_1(idx_fac_1).zscore=zscore_cell;
          fac_cell_1(idx_fac_1).zscore_1=zscore_fac_1_avg.session_1;
          fac_cell_1(idx_fac_1).zscore_2=zscore_fac_1_avg.session_2;
          fac_cell_1(idx_fac_1).zscore_21=zscore_fac_1_avg.session_21;
          fac_cell_1(idx_fac_1).zscore_22=zscore_fac_1_avg.session_22;
          fac_cell_1(idx_fac_1).zscore_23=zscore_fac_1_avg.session_23;
          fac_cell_1(idx_fac_1).zscore_24=zscore_fac_1_avg.session_24;
       end
    elseif data_plot(i).p<0.05 && data_plot(i).session_1<data_plot(i).session_2
       zscore_cell=zscore_cal(list,i,all_info_1,all_info_2,-500,250);
       zscore_bsl_sig_avg=zscore_org(zscore_cell,'bsl_mean');
       plot(data_plot(i).session_1,data_plot(i).session_2,'.','Color',color_2,'MarkerSize',10)
       hold on 
       idx_1=idx_1+1;
       bsl_sig_list(idx_1).cell_ID=mod_file(i).cell_ID;
       bsl_sig_list(idx_1).item_1=data_plot(i).session_1;
       bsl_sig_list(idx_1).item_2=data_plot(i).session_2;
       bsl_sig_list(idx_1).item_21=data_plot(i).session_21;
       bsl_sig_list(idx_1).item_22=data_plot(i).session_22;
       bsl_sig_list(idx_1).item_23=data_plot(i).session_23;
       bsl_sig_list(idx_1).item_24=data_plot(i).session_24;
       bsl_sig_list(idx_1).d_bsl=data_plot(i).session_2-data_plot(i).session_1;
       bsl_sig_list(idx_1).d_per=abs(data_plot(i).session_2-data_plot(i).session_1)/data_plot(i).session_1*100;
       bsl_sig_list(idx_1).CV2=2*abs(data_plot(i).session_2-data_plot(i).session_1)/(data_plot(i).session_2+data_plot(i).session_1);
       bsl_sig_list(idx_1).zscore=zscore_cell;
       bsl_sig_list(idx_1).zscore_1=zscore_bsl_sig_avg.session_1;
       bsl_sig_list(idx_1).zscore_2=zscore_bsl_sig_avg.session_2;
       bsl_sig_list(idx_1).zscore_21=zscore_bsl_sig_avg.session_21;
       bsl_sig_list(idx_1).zscore_22=zscore_bsl_sig_avg.session_22;
       bsl_sig_list(idx_1).zscore_23=zscore_bsl_sig_avg.session_23;
       bsl_sig_list(idx_1).zscore_24=zscore_bsl_sig_avg.session_24;
       if (mod_file(i).(mod_type_2)==1 || mod_file(i).(mod_type_1)==1) && data_plot(i).session_1-data_plot(i).session_2<-2
          idx_fac_2=idx_fac_2+1;
          zscore_fac_2_avg=zscore_org(zscore_cell,'CR_max');
          fac_cell_2(idx_fac_2).cell_ID=mod_file(i).cell_ID;
          fac_cell_2(idx_fac_2).item_1=data_plot(i).session_1;
          fac_cell_2(idx_fac_2).item_2=data_plot(i).session_2;
          fac_cell_2(idx_fac_2).item_21=data_plot(i).session_21;
          fac_cell_2(idx_fac_2).item_22=data_plot(i).session_22;
          fac_cell_2(idx_fac_2).item_23=data_plot(i).session_23;
          fac_cell_2(idx_fac_2).item_24=data_plot(i).session_24;
          fac_cell_2(idx_fac_2).zscore=zscore_cell;
          fac_cell_2(idx_fac_2).zscore_1=zscore_fac_2_avg.session_1;
          fac_cell_2(idx_fac_2).zscore_2=zscore_fac_2_avg.session_2;
          fac_cell_2(idx_fac_2).zscore_21=zscore_fac_2_avg.session_21;
          fac_cell_2(idx_fac_2).zscore_22=zscore_fac_2_avg.session_22;
          fac_cell_2(idx_fac_2).zscore_23=zscore_fac_2_avg.session_23;
          fac_cell_2(idx_fac_2).zscore_24=zscore_fac_2_avg.session_24;
       end
    end   
end



% % fac_cell_1=list;
% 
% [CR_mean_1,CR_mean_2,CR_std_1,CR_std_2]=mean_std_cal([data_plot.session_1],[data_plot.session_2]);
% plot(CR_mean_1,CR_mean_2,'s','Color',[0 0 0])
% hold on
% errorbar(CR_mean_1,CR_mean_2,CR_std_1/sqrt(size(data_plot,2)),CR_std_1/sqrt(size(data_plot,2)),...
%     CR_std_2/sqrt(size(data_plot,2)),CR_std_2/sqrt(size(data_plot,2)),'Color',[0 0 0]);
% hold on
% 
% title([data_1 ' ' comp_item_1 ' vs. ' data_2 ' ' comp_item_2],'Interpreter', 'none');
% xlim([axis_lim_1 axis_lim_2]);
% ylim([axis_lim_1 axis_lim_2]);
% xticks(axis_lim_1:5:axis_lim_2);
% yticks(axis_lim_1:5:axis_lim_2);
% line([axis_lim_1 axis_lim_2],[axis_lim_1 axis_lim_2],'LineStyle','--','Color','k','LineWidth',1.0);
% if bsl_norm_test==0
%     xlabel([session_1 ' frequency (Hz)']);
%     ylabel([session_2 ' frequency (Hz)']);
% elseif bsl_norm_test==1
%     xlabel([session_1 ' signal-to-baseline (Hz)']);
%     ylabel([session_2 ' signal-to-baseline (Hz)']);
%     line([0 0],[axis_lim_1 axis_lim_2],'LineStyle','--','Color',[0.5 0.5 0.5],'LineWidth',1.0);
%     line([axis_lim_1 axis_lim_2],[0 0],'LineStyle','--','Color',[0.5 0.5 0.5],'LineWidth',1.0);
% end
% 
% bin_num=(-t_pre+t_post)/step+1;
% psth_raw_11=zeros(size(fac_cell_1,2),bin_num);
% psth_raw_12=zeros(size(fac_cell_1,2),bin_num);
% psth_raw_21=zeros(size(fac_cell_2,2),bin_num);
% psth_raw_22=zeros(size(fac_cell_2,2),bin_num);
% 
% for i=1:size(fac_cell_1,2)
%     cell_ID=fac_cell_1(i).cell_ID;
%     t_start_1=find(list(cell_ID).(align_info_1).psth_ex(:,1)==t_pre,1,'first');
%     for j=1:bin_num
%         t_idx=t_start_1-bin/2+(j-1)*step;
%         psth_raw_11(i,j)=mean(list(cell_ID).(align_info_1).psth_ex(t_idx:t_idx+bin-1,2))/(list(cell_ID).(align_info_1).bsl_frq_ex*100)^bsl_norm_curve;       
%     end
%     t_start_2=find(list(cell_ID).(align_info_2).psth_ex(:,1)==t_pre,1,'first');
%     for j=1:bin_num
%         t_idx=t_start_2-bin/2+(j-1)*step;
%         psth_raw_12(i,j)=mean(list(cell_ID).(align_info_2).psth_ex(t_idx:t_idx+bin-1,2))/(list(cell_ID).(align_info_2).bsl_frq_ex*100)^bsl_norm_curve;       
%     end 
% end
% mean_sd_1=zeros(9,bin_num);
% for i=1:bin_num
%     mean_sd_1(1,i)=t_pre+(i-1)*step;
%     mean_sd_1(2,i)=mean(psth_raw_11(:,i));
%     mean_sd_1(3,i)=std(psth_raw_11(:,i));
%     mean_sd_1(4,i)=mean_sd_1(2,i)+mean_sd_1(3,i)/sqrt(size(fac_cell_1,2));
%     mean_sd_1(5,i)=mean_sd_1(2,i)-mean_sd_1(3,i)/sqrt(size(fac_cell_1,2));
%     mean_sd_1(6,i)=mean(psth_raw_12(:,i));
%     mean_sd_1(7,i)=std(psth_raw_12(:,i));
%     mean_sd_1(8,i)=mean_sd_1(6,i)+mean_sd_1(7,i)/sqrt(size(fac_cell_1,2));
%     mean_sd_1(9,i)=mean_sd_1(6,i)-mean_sd_1(7,i)/sqrt(size(fac_cell_1,2));
% end
% 
% figure;
% plot(mean_sd_1(1,:),smooth(mean_sd_1(2,:),3),'k-')
% hold on
% plot(mean_sd_1(1,:),smooth(mean_sd_1(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(mean_sd_1(1,:),smooth(mean_sd_1(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([-250 t_post]);
% ylim([ymin_1 ymax_1]);
% xticks(t_pre:250:t_post);
% 
% figure;
% plot(mean_sd_1(1,:),smooth(mean_sd_1(6,:),3),'k-')
% hold on
% plot(mean_sd_1(1,:),smooth(mean_sd_1(8,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(mean_sd_1(1,:),smooth(mean_sd_1(9,:),3),'Color',[0.5 0.5 0.5])
% hold on
% xlim([-250 t_post]);
% ylim([ymin_1 ymax_1]);
% xticks(t_pre:250:t_post);
% 
% for i=1:size(fac_cell_2,2)
%     cell_ID=fac_cell_2(i).cell_ID;
%     t_start_1=find(list(cell_ID).(align_info_1).psth_ex(:,1)==t_pre,1,'first');
%     for j=1:bin_num
%         t_idx=t_start_1-bin/2+(j-1)*step;
%         psth_raw_21(i,j)=mean(list(cell_ID).(align_info_1).psth_ex(t_idx:t_idx+bin-1,2))/(list(cell_ID).(align_info_1).bsl_frq_ex*100)^bsl_norm_curve;       
%     end
%     t_start_2=find(list(cell_ID).(align_info_2).psth_ex(:,1)==t_pre,1,'first');
%     for j=1:bin_num
%         t_idx=t_start_2-bin/2+(j-1)*step;
%         psth_raw_22(i,j)=mean(list(cell_ID).(align_info_2).psth_ex(t_idx:t_idx+bin-1,2))/(list(cell_ID).(align_info_2).bsl_frq_ex*100)^bsl_norm_curve;       
%     end 
% end
% mean_sd_2=zeros(9,bin_num);
% for i=1:bin_num
%     mean_sd_2(1,i)=t_pre+(i-1)*step;
%     mean_sd_2(2,i)=mean(psth_raw_21(:,i));
%     mean_sd_2(3,i)=std(psth_raw_21(:,i));
%     mean_sd_2(4,i)=mean_sd_2(2,i)+mean_sd_2(3,i)/sqrt(size(fac_cell_2,2));
%     mean_sd_2(5,i)=mean_sd_2(2,i)-mean_sd_2(3,i)/sqrt(size(fac_cell_2,2));
%     mean_sd_2(6,i)=mean(psth_raw_22(:,i));
%     mean_sd_2(7,i)=std(psth_raw_22(:,i));
%     mean_sd_2(8,i)=mean_sd_2(6,i)+mean_sd_2(7,i)/sqrt(size(fac_cell_2,2));
%     mean_sd_2(9,i)=mean_sd_2(6,i)-mean_sd_2(7,i)/sqrt(size(fac_cell_2,2));
% end
% 
% figure;
% plot(mean_sd_2(1,:),smooth(mean_sd_2(2,:),3),'k-')
% hold on
% plot(mean_sd_2(1,:),smooth(mean_sd_2(4,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(mean_sd_2(1,:),smooth(mean_sd_2(5,:),3),'Color',[0.5 0.5 0.5])
% hold on 
% xlim([-250 t_post]);
% ylim([ymin_2 ymax_2]);
% xticks(t_pre:250:t_post);
% 
% figure;
% plot(mean_sd_2(1,:),smooth(mean_sd_2(6,:),3),'k-')
% hold on
% plot(mean_sd_2(1,:),smooth(mean_sd_2(8,:),3),'Color',[0.5 0.5 0.5])
% hold on
% plot(mean_sd_2(1,:),smooth(mean_sd_2(9,:),3),'Color',[0.5 0.5 0.5])
% hold on
% xlim([-250 t_post]);
% ylim([ymin_2 ymax_2]);
% xticks(t_pre:250:t_post);


function data_plot=data_org(mode_file,data_1,data_2,comp_item_1,comp_item_2,bsl_norm)

data_plot=struct('cell_ID',[],'session_1',[],'session_2',[],'p',[],'session_21',[],'session_22',[],'session_23',[],'session_24',[]);

for i=1:size(mode_file,2)
    raw_data_1=zeros(size(mode_file(i).(data_1),2),1);
    raw_data_2=zeros(size(mode_file(i).(data_2),2),1);
    raw_data_20=nan(ceil(size(mode_file(i).(data_2),2)/4),4);
    trial_group=quantile(1:size(mode_file(i).(data_2),2),3);
    trial_group=[0 floor(trial_group(1:3)) size(mode_file(i).(data_2),2)];
    for j=1:size(mode_file(i).(data_1),2)
        if bsl_norm==0
           raw_data_1(j,1)=mode_file(i).(data_1)(j).(comp_item_1);
        elseif bsl_norm==1
           raw_data_1(j,1)=(mode_file(i).(data_1)(j).(comp_item_1)-mode_file(i).(data_1)(j).bsl_all); 
        end
    end  
    for j=1:size(mode_file(i).(data_2),2)
        if bsl_norm==0
           raw_data_2(j,1)=mode_file(i).(data_2)(j).(comp_item_2);
        elseif bsl_norm==1
           raw_data_2(j,1)=(mode_file(i).(data_2)(j).(comp_item_2)-mode_file(i).(data_2)(j).bsl_all); 
        end
    end 
    for n=1:4
        raw_data_20(1:trial_group(n+1)-trial_group(n),n)=raw_data_2(trial_group(n)+1:trial_group(n+1),1);
    end
    
    data_plot(i).cell_ID=mode_file(i).cell_ID;
    data_plot(i).session_1=mean(raw_data_1);
    data_plot(i).session_2=mean(raw_data_2);
    data_plot(i).session_21=nanmean(raw_data_20(:,1));
    data_plot(i).session_22=nanmean(raw_data_20(:,2));
    data_plot(i).session_23=nanmean(raw_data_20(:,3));
    data_plot(i).session_24=nanmean(raw_data_20(:,4));
    data_plot(i).p=ranksum(raw_data_1,raw_data_2);    
end

end

function zscore_plot=zscore_org(zscore_file,field_name)

zscore_plot=struct('session_1',[],'session_2',[],'session_21',[],'session_22',[],'session_23',[],'session_24',[]);


    trial_num_1=sum([zscore_file.trial_type]==1);
    trial_num_2=sum([zscore_file.trial_type]==2);
    raw_data_1=zeros(trial_num_1,1);
    raw_data_2=zeros(trial_num_2,1);
    raw_data_20=nan(ceil(trial_num_2/4),4);
    trial_group=quantile(1:trial_num_2,3);
    trial_group=[0 floor(trial_group(1:3)) trial_num_2];
    for j=1:trial_num_1
        raw_data_1(j,1)=zscore_file(j).(field_name);
    end  
    for j=1:trial_num_2
        raw_data_2(j,1)=zscore_file(j+trial_num_1).(field_name);
    end 
    for n=1:4
        raw_data_20(1:trial_group(n+1)-trial_group(n),n)=raw_data_2(trial_group(n)+1:trial_group(n+1),1);
    end
    
    zscore_plot.session_1=mean(raw_data_1);
    zscore_plot.session_2=mean(raw_data_2);
    zscore_plot.session_21=nanmean(raw_data_20(:,1));
    zscore_plot.session_22=nanmean(raw_data_20(:,2));
    zscore_plot.session_23=nanmean(raw_data_20(:,3));
    zscore_plot.session_24=nanmean(raw_data_20(:,4));
 


end

function [mean_1,mean_2,std_1,std_2]=mean_std_cal(data_1,data_2)
    mean_1=mean(data_1);
    mean_2=mean(data_2);
    std_1=std(data_1);
    std_2=std(data_2);
end

function zscore_cell=zscore_cal(list_file,cell_ID,all_info_1,all_info_2,time_window_bsl,time_window_CR)

zscore_cell=struct('trial_ID',[],'trial_type',[],'zscore',[],'CR_max',[],'bsl_mean',[]);

num_trial_1=size(list_file(cell_ID).(all_info_1).ttt.CR_trial,2);
num_trial_2=size(list_file(cell_ID).(all_info_2).ttt.CR_trial,2);
num_trial=num_trial_1+num_trial_2;
time_range=list_file(cell_ID).(all_info_1).ttt.CR_trial(1).ifr_smooth(:,1);

zscore_raw=nan(length(time_range),num_trial);
for j=1:size(list_file(cell_ID).(all_info_1).ttt.CR_trial,2)
    zscore_cell(j).trial_ID=list_file(cell_ID).(all_info_1).ttt.CR_trial(j).trial_num;
    zscore_cell(j).trial_type=1;
    zscore_raw(:,j)=list_file(cell_ID).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,2);
end
for j=1:size(list_file(cell_ID).(all_info_2).ttt.CR_trial,2)
    zscore_cell(num_trial_1+j).trial_ID=list_file(cell_ID).(all_info_2).ttt.CR_trial(j).trial_num;
    zscore_cell(num_trial_1+j).trial_type=2;
    zscore_raw(:,num_trial_1+j)=list_file(cell_ID).(all_info_2).ttt.CR_trial(j).ifr_smooth(:,2);
end

zscore_matrix=zscore(zscore_raw,0,'all');
output_value_t1=find(time_range==time_window_bsl,1,'first');
output_value_t2=find(time_range==time_window_CR,1,'first');
output_value_t0=find(time_range==0,1,'first');

for j=1:num_trial
    zscore_trial=zeros(length(time_range),2);
    zscore_trial(:,1)=time_range;
    zscore_trial(:,2)=zscore_matrix(:,j);
    zscore_cell(j).zscore=zscore_trial;
    zscore_cell(j).CR_max=max(zscore_trial(output_value_t0:output_value_t2,2));        
    zscore_cell(j).bsl_mean=mean(zscore_trial(output_value_t1:output_value_t0,2));             
end

end