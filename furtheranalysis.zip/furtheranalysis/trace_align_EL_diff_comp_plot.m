file=trace_list;
figure_name='trace_neuron';
cd 'D:\Zhong\Trace-trained-mice\DCN_mat_output\onset_alignment'
trace_EL_list=struct('cell_ID',[],'early_Ctas_T',[],'early_psth_T',[],'late_Ctas_T',[],'late_psth_T',[],'EL_diff_T',[]);
mod_format=struct('cell_ID',[],'fac_T',[],'sup_T',[],'mod_change_fac_T',[],...
                  'mod_change_sup_T',[],'motor_relevant_fac_T',[],...
                  'motor_relevant_sup_T',[],'timing_relevant',[],...
                  'sum_EL_peak',[],'sum_EL_bottom',[]);

for i=1:size(file,2)
    Ctas_early_T=struct('cell',[],'tss',[]);
    Ctas_early_T.tss=struct('trial',[],'t',[]);
    Ctas_early_T.cell=1;
    Ctas_late_T=struct('cell',[],'tss',[]);
    Ctas_late_T.tss=struct('trial',[],'t',[]);
    Ctas_late_T.cell=1;
    
    trial_info_T=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[]);
    for j=1:size(file(i).all_info.ttt.CR_trial,2)
        trial_info_T(j).field=j;
        trial_info_T(j).trial_num=file(i).all_info.ttt.CR_trial(j).trial_num;
        trial_info_T(j).CR_onset=file(i).all_info.ttt.CR_trial(j).blk_info_new.CR_onset;
        trial_info_T(j).spk=file(i).all_info.ttt.CR_trial(j).spk_time;
    end
    trial_info_T = trial_info_T(all(~cellfun(@isempty,struct2cell(trial_info_T))));
    [~,index] = sortrows([trial_info_T.CR_onset].'); 
    trial_info_T = trial_info_T(index);
    

    

    num_mod_T=mod(size(trial_info_T,2),2);
    num_early_T=(size(trial_info_T,2)+num_mod_T)/2;
    num_late_T=(size(trial_info_T,2)-num_mod_T)/2;

    
    for j=1:num_early_T
        Ctas_early_T.tss(j).trial=trial_info_T(j).trial_num;
        Ctas_early_T.tss(j).t=trial_info_T(j).spk;        
    end
    for k=1:num_late_T
        Ctas_late_T.tss(k).trial=trial_info_T(k+num_early_T).trial_num;
        Ctas_late_T.tss(k).t=trial_info_T(k+num_early_T).spk;
    end
    spk_CR_Gau_early_T=spk_Gaussian(Ctas_early_T,550,1050,10,3);
    psth_CR_Gau_early_T=Gau_psth_cal(spk_CR_Gau_early_T,550,1050,0);
    spk_CR_Gau_late_T=spk_Gaussian(Ctas_late_T,550,1050,10,3);
    psth_CR_Gau_late_T=Gau_psth_cal(spk_CR_Gau_late_T,550,1050,0);
    EL_diff_T=psth_CR_Gau_early_T.Gau_psth_shft;
    for n=1:size(EL_diff_T,1)
        EL_diff_T(n,2)=EL_diff_T(n,2)-psth_CR_Gau_late_T.Gau_psth_shft(n,2);        
    end
%     EL_diff_T(:,3)=smooth(EL_diff_T(:,2),10);    
        
    trace_EL_list(i).cell_ID=file(i).cell_ID;
    trace_EL_list(i).early_Ctas_T=Ctas_early_T;
    trace_EL_list(i).late_Ctas_T=Ctas_late_T;
    trace_EL_list(i).early_psth_T=psth_CR_Gau_early_T;
    trace_EL_list(i).late_psth_T=psth_CR_Gau_late_T;
    
    mod_format(i).cell_ID=file(i).new_ID;
 
    peak_align_T=max(file(i).align_info.psth_align(551-file(i).align_info.t_start:1051-file(i).align_info.t_end,2));
    peak_norm_T=max(file(i).align_info.psth_ex(551:1050,2));
    bottom_align_T=min(file(i).align_info.psth_align(551-file(i).align_info.t_start:1051-file(i).align_info.t_end,2));
    bottom_norm_T=min(file(i).align_info.psth_ex(551:1050,2));    
    
%     if file(i).CR_fac_D>0
%        mod_format(i).mod_change_fac_D=(peak_norm_D/file(i).align_info_D.bsl_frq_ex-1)*100;        
%        if mod_format(i).mod_change_fac_D<30
%           file(i).CR_fac_D=0;
%        end
%     end
%     if file(i).CR_fac_T>0
%        mod_format(i).mod_change_fac_T=(peak_norm_T/file(i).align_info_T.bsl_frq_ex-1)*100;    
%        if mod_format(i).mod_change_fac_T<30
%           file(i).CR_fac_T=0;
%        end
%     end
%     if file(i).CR_sup_D>0
%        mod_format(i).mod_change_sup_D=(1-bottom_norm_D/file(i).align_info_D.bsl_frq_ex)*100; 
%        if mod_format(i).mod_change_sup_D<30
%           file(i).CR_sup_D=0;
%        end       
%     end
%     if file(i).CR_sup_T>0
%        mod_format(i).mod_change_sup_T=(1-bottom_norm_T/file(i).align_info_T.bsl_frq_ex)*100; 
%        if mod_format(i).mod_change_sup_T<30
%           file(i).CR_sup_T=0;
%        end
%     end 
    mod_format(i).fac_T=file(i).CR_fac;
    mod_format(i).sup_T=file(i).CR_sup;   
    
    if file(i).CR_fac>0
        if peak_align_T>peak_norm_T && peak_align_T>file(i).align_info.bsl_frq_ex+3*file(i).align_info.SD_ex && peak_align_T/file(i).align_info.bsl_frq_ex>1.3
           mod_format(i).motor_relevant_fac_T=1;       
        else
           mod_format(i).motor_relevant_fac_T=0;        
        end  
    end
    if file(i).CR_sup>0
        if bottom_align_T<bottom_norm_T && bottom_align_T<file(i).align_info.bsl_frq_ex-3*file(i).align_info.SD_ex && bottom_align_T/file(i).align_info.bsl_frq_ex<0.7
           mod_format(i).motor_relevant_sup_T=1;       
        else
           mod_format(i).motor_relevant_sup_T=0;   
        end       
    end
    
    
    
%     figure('Name',[figure_name num2str(i)],'NumberTitle','off','units','normalized','outerposition',[0 0 1 1]);
%        
%     if strcmp('TD',figure_name)
%        subplot(4,2,1)
%        hold on
%     elseif strcmp('DT',figure_name)
%        subplot(4,2,2)
%        hold on    
%     end
    
%     for m=1:size(trial_info_T,2)
%     hold on
%     Y=ones(length(trial_info_T(m).spk),1)*m;
%     plot(trial_info_T(m).spk*1000,Y,'k.')
%     hold on
%     plot(0,Y,'g.')
%     hold on
%     plot(trial_info_T(m).CR_onset*1000,Y,'b.')
%     hold on
%     plot(500,Y,'r.')        
%     end
%     hold on
%     xlim([-250 750]);
%     xticks(-250:250:750);
%     ylim([0 m]);
%     xlabel('Time(ms)');
%     ylabel('Trial number');
%     
%     if strcmp('TD',figure_name)
%        subplot(4,2,2)
%        hold on
%     elseif strcmp('DT',figure_name)
%        subplot(4,2,1)
%        hold on    
%     end
    
%     for m=1:size(trial_info_D,2)
%     hold on
%     Y=ones(length(trial_info_D(m).spk),1)*m;
%     plot(trial_info_D(m).spk*1000,Y,'k.')
%     hold on
%     plot(0,Y,'g.')
%     hold on
%     plot(trial_info_D(m).CR_onset*1000,Y,'b.')
%     hold on
%     plot(250,Y,'r.')        
%     end
%     hold on
%     xlim([-250 750]);
%     xticks(-250:250:750);
%     ylim([0 m]);
%     xlabel('Time(ms)');
%     ylabel('Trial number');   
    
%     if strcmp('TD',figure_name)
%        subplot(4,2,3)
%        hold on
%     elseif strcmp('DT',figure_name)
%        subplot(4,2,4)
%        hold on    
%     end
%     plot(file(i).align_info_T.psth_ex(:,1),file(i).align_info_T.psth_ex(:,2),'k-','LineWidth',1.0)
%     hold on
%     plot(file(i).align_info_T.psth_align(:,1),file(i).align_info_T.psth_align(:,2),'b-','LineWidth',1.0)
%     hold on
%     ymax=max(max(file(i).align_info_T.psth_ex(51:1051,2)),max(file(i).align_info_T.psth_align(51:1051,2)))*1.1;
%     line([-file(i).align_info_T.t_start -file(i).align_info_T.t_start],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',1.0);
%     line([500-file(i).align_info_T.t_end 500-file(i).align_info_T.t_end],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',1.0);
%     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%     hold on
%     xlim([-500 500]);
%     ylim([0 ymax]);
%     xticks(-500:250:500);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     hold on
    
%     if strcmp('TD',figure_name)
%        subplot(4,2,4)
%        hold on
%     elseif strcmp('DT',figure_name)
%        subplot(4,2,3)
%        hold on    
%     end 
%     plot(file(i).align_info_D.psth_ex(:,1),file(i).align_info_D.psth_ex(:,2),'k-','LineWidth',1.0)
%     hold on
%     plot(file(i).align_info_D.psth_align(:,1),file(i).align_info_D.psth_align(:,2),'b-','LineWidth',1.0)
%     hold on
%     ymax=max(max(file(i).align_info_D.psth_ex(51:1051,2)),max(file(i).align_info_D.psth_align(51:1051,2)))*1.1;
%     line([-file(i).align_info_D.t_start -file(i).align_info_D.t_start],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',1.0);
%     line([250-file(i).align_info_D.t_end 250-file(i).align_info_D.t_end],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',1.0);
%     line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
%     hold on
%     xlim([-500 500]);
%     ylim([0 ymax]);
%     xticks(-500:250:500);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');
%     hold on
        
%     subplot(4,2,5)
%     plot(file(i).align_info_T.psth_ex(:,1),file(i).align_info_T.psth_ex(:,2),'k-','LineWidth',1.0,'DisplayName','Trace raw')
%     hold on
%     plot(file(i).align_info_D.psth_ex(:,1),file(i).align_info_D.psth_ex(:,2),'r-','LineWidth',1.0,'DisplayName','Delay raw')
%     hold on

    max_early=max(psth_CR_Gau_early_T.Gau_psth_shft(:,2));
    max_late=max(psth_CR_Gau_late_T.Gau_psth_shft(:,2));
    max_trace=max(file(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
    max_delay=max(file(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
    max_mix=max([max_early max_late max_trace max_delay])*1.1;
    
    min_early=min(psth_CR_Gau_early_T.Gau_psth_shft(:,2));
    min_late=min(psth_CR_Gau_late_T.Gau_psth_shft(:,2));
    min_trace=min(file(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
    min_delay=min(file(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
    min_mix=min([min_early min_late min_trace min_delay])*0.9;
    
%     line([0 0],[min_mix, max_mix],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
%     line([250 250],[min_mix, max_mix],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
%     line([500 500],[min_mix, max_mix],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
%     xlim([-250 750]);
%     ylim([min_mix max_mix]);
%     xticks(-250:250:750);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');   
%     legend('Trace raw','Delay raw');
    
%     subplot(4,2,6)
%     plot(psth_CR_Gau_early_T.Gau_psth_shft(:,1),psth_CR_Gau_early_T.Gau_psth_shft(:,2),'c-','LineWidth',1.0,'DisplayName','Trace early')
%     hold on
%     plot(psth_CR_Gau_late_T.Gau_psth_shft(:,1),psth_CR_Gau_late_T.Gau_psth_shft(:,2),'m-','LineWidth',1.0,'DisplayName','Trace late')
%     hold on
%     
%     line([0 0],[min_mix, max_mix],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
%     line([500 500],[min_mix, max_mix],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
%     xlim([-250 750]);
%     ylim([min_mix max_mix]);
%     xticks(-250:250:750);
%     xlabel('Time(ms)');
%     ylabel('Est. Spike Freq. (Hz)');   
%     legend(['Trace early' num2str(num_early_T)],['Trace late' num2str(num_late_T)]);
    
%     subplot(4,2,7)
    DT_diff=file(i).align_info_D.psth_ex;
    for n=1:size(DT_diff,1)
        DT_diff(n,2)=DT_diff(n,2)-file(i).align_info_T.psth_ex(n,2);   
    end
%     DT_diff(:,3)=smooth(DT_diff(:,2),10);
%     mod_format(i).sum_DT=sum(DT_diff(551:800,2));
%     plot(DT_diff(:,1),DT_diff(:,2),'k-','LineWidth',1.0)
%     y1_max=max(DT_diff(301:800,2))+5;
%     y1_min=min(DT_diff(301:800,2))-5;
%     xlabel('Time(ms)');
%     ylabel('Freq. Delay-Trace (Hz)'); 
%     xlim([-250 250]);
%     ylim([y1_min y1_max]);
%     xticks(-250:250:250);
%     line([0 0],[y1_min y1_max],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
%     hold on
    
    DT_bsl=mean(DT_diff(51:550,2));
    DT_SD=std(DT_diff(51:550,2));
    DT_thrd_up=DT_bsl+3*DT_SD;
    DT_thrd_down=DT_bsl-3*DT_SD;
    [peak_DTdiff,peak_I_DT]=max(DT_diff(551:800,2));
    [bottom_DTdiff,bottom_I_DT]=min(DT_diff(551:800,2));
    
    if min(DT_diff(551:peak_I_DT+550,2))<DT_bsl
       DT_zero_1=find(DT_diff(551:peak_I_DT+550,2)<DT_bsl,1,'last');
    else
       DT_zero_1=1; 
    end
    if min(DT_diff(peak_I_DT+550:800,2))<DT_bsl
       DT_zero_2=find(DT_diff(peak_I_DT+551:800,2)<DT_bsl,1,'first');
    else
       DT_zero_2=250-peak_I_DT; 
    end
    if max(DT_diff(551:bottom_I_DT+550,2))>DT_bsl
       DT_zero_3=find(DT_diff(551:bottom_I_DT+550,2)>DT_bsl,1,'last');
    else
       DT_zero_3=1; 
    end
    if max(DT_diff(bottom_I_DT+550:800,2))>DT_bsl
       DT_zero_4=find(DT_diff(bottom_I_DT+551:800,2)>DT_bsl,1,'first');
    else
       DT_zero_4=250-peak_I_DT; 
    end    
    mod_format(i).sum_DT_peak=sum(DT_diff(550+DT_zero_1:550+peak_I_DT+DT_zero_2,2)-DT_bsl);
    mod_format(i).sum_DT_bottom=sum(DT_diff(550+DT_zero_3:550+bottom_I_DT+DT_zero_4,2)-DT_bsl);    
%     line([-250 250],[DT_bsl DT_bsl],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
    if mod_format(i).sum_DT_peak>1500 && peak_DTdiff>DT_thrd_up
       mod_format(i).paradigm_relevant=1;
    elseif mod_format(i).sum_DT_bottom<-1500 && bottom_DTdiff<DT_thrd_down
       mod_format(i).paradigm_relevant=1;     
    else
       mod_format(i).paradigm_relevant=0;
    end
    
%     subplot(4,2,8)
%     plot(EL_diff_T(:,1),EL_diff_T(:,2),'k-','LineWidth',1.0)
%     y2_max=max(EL_diff_T(301:1300,2))+5;
%     y2_min=min(EL_diff_T(301:1300,2))-5;
%     xlim([-250 750]);
%     ylim([y2_min y2_max]);
%     xticks(-250:250:750);
%     xlabel('Time(ms)');
%     ylabel('Freq. Early-Late (Hz)'); 
%     line([0 0],[y2_min y2_max],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
%     line([500 500],[y2_min y2_max],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
%     hold on
    
    EL_bsl=mean(EL_diff_T(51:550,2));
    EL_SD=std(EL_diff_T(51:550,2));
    EL_thrd_up=EL_bsl+3*EL_SD;
    EL_thrd_down=EL_bsl-3*EL_SD;
    [peak_ELdiff,peak_I_EL]=max(EL_diff_T(551:1050,2));
    [bottom_ELdiff,bottom_I_EL]=min(EL_diff_T(551:1050,2));

    if min(EL_diff_T(551:peak_I_EL+550,2))<EL_bsl
       EL_zero_1=find(EL_diff_T(551:peak_I_EL+550,2)<EL_bsl,1,'last');
    else
       EL_zero_1=1; 
    end
    if min(EL_diff_T(peak_I_EL+550:1050,2))<EL_bsl
       EL_zero_2=find(EL_diff_T(peak_I_EL+551:1050,2)<EL_bsl,1,'first');
    else
       EL_zero_2=500-peak_I_EL; 
    end
    if max(EL_diff_T(551:bottom_I_EL+550,2))>EL_bsl
       EL_zero_3=find(EL_diff_T(551:bottom_I_EL+550,2)>EL_bsl,1,'last');
    else
       EL_zero_3=1; 
    end
    if max(EL_diff_T(bottom_I_EL+550:1050,2))>EL_bsl
       EL_zero_4=find(EL_diff_T(bottom_I_EL+551:1050,2)>EL_bsl,1,'first');
    else
       EL_zero_4=500-bottom_I_EL; 
    end    
    mod_format(i).sum_EL_peak=sum(EL_diff_T(550+EL_zero_1:550+peak_I_EL+EL_zero_2,2)-EL_bsl);
    mod_format(i).sum_EL_bottom=sum(EL_diff_T(550+EL_zero_3:550+bottom_I_EL+EL_zero_4,2)-EL_bsl);
%     line([-250 750],[EL_bsl EL_bsl],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);        

    if mod_format(i).sum_EL_peak>1500 && peak_ELdiff>EL_thrd_up
       mod_format(i).timing_relevant=1;
    elseif mod_format(i).sum_EL_bottom<-1500 && bottom_ELdiff<EL_thrd_down
       mod_format(i).timing_relevant=1;
    else 
       mod_format(i).timing_relevant=0;         
    end
%     if strcmp('DT',figure_name)
%        saveas(gcf,[figure_name num2str(i) '-D-' num2str(file(i).CR_fac_D) '-' num2str(file(i).CR_sup_D) '-T-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '.jpg']);
%     elseif strcmp('TD',figure_name)
%        saveas(gcf,[figure_name num2str(i) '-T-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '-D-' num2str(file(i).CR_fac_D) '-' num2str(file(i).CR_sup_D) '.jpg']); 
%     end
%     close all
end
%     save('TD_EL_list','TD_EL_list')
