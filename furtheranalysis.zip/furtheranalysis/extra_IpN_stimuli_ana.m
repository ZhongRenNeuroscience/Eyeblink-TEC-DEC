% Build IpN electrostimulation dataset

file=BLK_mouse_all;
t_pre=500;
std_idx=6;

info_list=struct('mouse',[],'current',[],'bhv_onset',[],'bhv_pkt',[]);

for i=1:size(file,2)
    info_list(i).mouse=file(i).mouse_nr;
    info_list(i).current=file(i).Current;
    bsl_mean=mean(file(i).mean_trace(1:t_pre));
    bsl_std=std(file(i).mean_trace(1:t_pre));
    info_list(i).bhv_onset=find(file(i).mean_trace(t_pre+1:end)>=bsl_mean+std_idx*bsl_std,1,'first');
    [peak,pkt]=max(file(i).mean_trace(t_pre+1:end));
    info_list(i).bhv_pkt=pkt;
    
    
    
    
end