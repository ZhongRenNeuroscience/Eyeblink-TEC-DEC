list=mod_list_DT;
align_info_1='align_info_D';
align_info_2='align_info_T';
t_pre=-250;
t_post=750; 

mod_align_list=struct('fac_list',[],'sup_list',[],'non_list',[]);
fac_list=struct('cell_ID',[],'mod_tp_1',[],'mod_tp_2',[],'mod_tp_align_1',[],'mod_tp_align_2',[],...
    'mod_amp_CS_fac_1',[],'mod_amp_CR_fac_1',[],'mod_amp_CS_fac_2',[],'mod_amp_CR_fac_2',[],...
    'mod_amp_CS_sup_1',[],'mod_amp_CR_sup_1',[],'mod_amp_CS_sup_2',[],'mod_amp_CR_sup_2',[]);
sup_list=struct('cell_ID',[],'mod_tp_1',[],'mod_tp_2',[],'mod_tp_align_1',[],'mod_tp_align_2',[],...
    'mod_amp_CS_fac_1',[],'mod_amp_CR_fac_1',[],'mod_amp_CS_fac_2',[],'mod_amp_CR_fac_2',[],...
    'mod_amp_CS_sup_1',[],'mod_amp_CR_sup_1',[],'mod_amp_CS_sup_2',[],'mod_amp_CR_sup_2',[]);
non_list=struct('cell_ID',[],'mod_tp_1',[],'mod_tp_2',[],'mod_tp_align_1',[],'mod_tp_align_2',[],...
    'mod_amp_CS_fac_1',[],'mod_amp_CR_fac_1',[],'mod_amp_CS_fac_2',[],'mod_amp_CR_fac_2',[],...
    'mod_amp_CS_sup_1',[],'mod_amp_CR_sup_1',[],'mod_amp_CS_sup_2',[],'mod_amp_CR_sup_2',[]);
fac_idx=0;
sup_idx=0;
non_idx=0;

for i=1:size(list,2)
    if (~isempty(list(i).(align_info_1).CR_fac.t_onset) && ~isempty(list(i).(align_info_2).CR_fac.t_onset))
        fac_idx=fac_idx+1;
        fac_list(fac_idx).cell_ID=i;    
        if ~isempty(list(i).(align_info_1).CR_sup.t_onset)
           fac_list(fac_idx).mod_tp_1=4;
        else
           fac_list(fac_idx).mod_tp_1=1; 
        end  
        if ~isempty(list(i).(align_info_2).CR_sup.t_onset)
           fac_list(fac_idx).mod_tp_2=4;
        else
           fac_list(fac_idx).mod_tp_2=1; 
        end         
        if ~isempty(list(i).(align_info_1).CR_fac_align.t_peak) && isempty(list(i).(align_info_1).CR_sup_align.t_peak)
           fac_list(fac_idx).mod_tp_align_1=1;
        elseif isempty(list(i).(align_info_1).CR_fac_align.t_peak) && ~isempty(list(i).(align_info_1).CR_sup_align.t_peak)
           fac_list(fac_idx).mod_tp_align_1=2; 
        elseif ~isempty(list(i).(align_info_1).CR_fac_align.t_peak) && ~isempty(list(i).(align_info_1).CR_sup_align.t_peak)
           fac_list(fac_idx).mod_tp_align_1=4; 
        else
           fac_list(fac_idx).mod_tp_align_1=3; 
        end
        if ~isempty(list(i).(align_info_2).CR_fac_align.t_peak) && isempty(list(i).(align_info_2).CR_sup_align.t_peak)
           fac_list(fac_idx).mod_tp_align_2=1;
        elseif isempty(list(i).(align_info_2).CR_fac_align.t_peak) && ~isempty(list(i).(align_info_2).CR_sup_align.t_peak)
           fac_list(fac_idx).mod_tp_align_2=2; 
        elseif ~isempty(list(i).(align_info_2).CR_fac_align.t_peak) && ~isempty(list(i).(align_info_2).CR_sup_align.t_peak)
           fac_list(fac_idx).mod_tp_align_2=4;            
        else
           fac_list(fac_idx).mod_tp_align_2=3; 
        end     
        fac_list(fac_idx).mod_amp_CS_fac_1=list(i).(align_info_1).CR_fac.peak-100;
        fac_list(fac_idx).mod_amp_CS_fac_2=list(i).(align_info_2).CR_fac.peak-100;
        fac_list(fac_idx).mod_amp_CR_fac_1=list(i).(align_info_1).CR_fac_align.peak-100;
        fac_list(fac_idx).mod_amp_CR_fac_2=list(i).(align_info_2).CR_fac_align.peak-100; 
        fac_list(fac_idx).mod_amp_CS_sup_1=list(i).(align_info_1).CR_sup.peak-100;
        fac_list(fac_idx).mod_amp_CS_sup_2=list(i).(align_info_2).CR_sup.peak-100;
        fac_list(fac_idx).mod_amp_CR_sup_1=list(i).(align_info_1).CR_sup_align.peak-100;
        fac_list(fac_idx).mod_amp_CR_sup_2=list(i).(align_info_2).CR_sup_align.peak-100; 
    end
    if (~isempty(list(i).(align_info_1).CR_sup.t_onset) && ~isempty(list(i).(align_info_2).CR_sup.t_onset)) 
       sup_idx=sup_idx+1;
       sup_list(sup_idx).cell_ID=i; 
        if ~isempty(list(i).(align_info_1).CR_fac.t_onset)
           sup_list(sup_idx).mod_tp_1=4;
        else
           sup_list(sup_idx).mod_tp_1=2; 
        end  
        if ~isempty(list(i).(align_info_2).CR_fac.t_onset)
           sup_list(sup_idx).mod_tp_2=4;
        else
           sup_list(sup_idx).mod_tp_2=2; 
        end         
        if ~isempty(list(i).(align_info_1).CR_sup_align.t_peak) && isempty(list(i).(align_info_1).CR_fac_align.t_peak)
           sup_list(sup_idx).mod_tp_align_1=2;
        elseif isempty(list(i).(align_info_1).CR_sup_align.t_peak) && ~isempty(list(i).(align_info_1).CR_fac_align.t_peak)
           sup_list(sup_idx).mod_tp_align_1=1; 
        elseif ~isempty(list(i).(align_info_1).CR_sup_align.t_peak) && ~isempty(list(i).(align_info_1).CR_fac_align.t_peak)
           sup_list(sup_idx).mod_tp_align_1=4; 
        else
           sup_list(sup_idx).mod_tp_align_1=3; 
        end
        if ~isempty(list(i).(align_info_2).CR_sup_align.t_peak) && isempty(list(i).(align_info_2).CR_fac_align.t_peak)
           sup_list(sup_idx).mod_tp_align_2=2;
        elseif isempty(list(i).(align_info_2).CR_sup_align.t_peak) && ~isempty(list(i).(align_info_2).CR_fac_align.t_peak)
           sup_list(sup_idx).mod_tp_align_2=1; 
        elseif ~isempty(list(i).(align_info_2).CR_sup_align.t_peak) && ~isempty(list(i).(align_info_2).CR_fac_align.t_peak)
           sup_list(sup_idx).mod_tp_align_2=4;            
        else
           sup_list(sup_idx).mod_tp_align_2=3; 
        end     
        sup_list(sup_idx).mod_amp_CS_fac_1=list(i).(align_info_1).CR_fac.peak-100;
        sup_list(sup_idx).mod_amp_CS_fac_2=list(i).(align_info_2).CR_fac.peak-100;
        sup_list(sup_idx).mod_amp_CR_fac_1=list(i).(align_info_1).CR_fac_align.peak-100;
        sup_list(sup_idx).mod_amp_CR_fac_2=list(i).(align_info_2).CR_fac_align.peak-100; 
        sup_list(sup_idx).mod_amp_CS_sup_1=list(i).(align_info_1).CR_sup.peak-100;
        sup_list(sup_idx).mod_amp_CS_sup_2=list(i).(align_info_2).CR_sup.peak-100;
        sup_list(sup_idx).mod_amp_CR_sup_1=list(i).(align_info_1).CR_sup_align.peak-100;
        sup_list(sup_idx).mod_amp_CR_sup_2=list(i).(align_info_2).CR_sup_align.peak-100;
    end
    if (isempty(list(i).(align_info_1).CR_fac.t_onset) || isempty(list(i).(align_info_2).CR_fac.t_onset)) && (isempty(list(i).(align_info_1).CR_sup.t_onset) || isempty(list(i).(align_info_2).CR_sup.t_onset))
       non_idx=non_idx+1;
       non_list(non_idx).cell_ID=i; 
        if ~isempty(list(i).(align_info_1).CR_fac.t_onset) && isempty(list(i).(align_info_1).CR_sup.t_onset)
           non_list(non_idx).mod_tp_1=1;
        elseif ~isempty(list(i).(align_info_1).CR_sup.t_onset) && isempty(list(i).(align_info_1).CR_fac.t_onset)
           non_list(non_idx).mod_tp_1=2;
        elseif ~isempty(list(i).(align_info_1).CR_sup.t_onset) && ~isempty(list(i).(align_info_1).CR_fac.t_onset)
           non_list(non_idx).mod_tp_1=4;           
        else
           non_list(non_idx).mod_tp_1=3; 
        end
        if ~isempty(list(i).(align_info_2).CR_fac.t_onset) && isempty(list(i).(align_info_2).CR_sup.t_onset)
           non_list(non_idx).mod_tp_2=1;
        elseif ~isempty(list(i).(align_info_2).CR_sup.t_onset) && isempty(list(i).(align_info_2).CR_fac.t_onset)
           non_list(non_idx).mod_tp_2=2;
        elseif ~isempty(list(i).(align_info_2).CR_sup.t_onset) && ~isempty(list(i).(align_info_2).CR_fac.t_onset)
           non_list(non_idx).mod_tp_2=4;           
        else
           non_list(non_idx).mod_tp_2=3; 
        end
        if ~isempty(list(i).(align_info_1).CR_fac_align.t_peak) && isempty(list(i).(align_info_1).CR_sup_align.t_peak) 
           non_list(non_idx).mod_tp_align_1=1;
        elseif ~isempty(list(i).(align_info_1).CR_sup_align.t_peak) && isempty(list(i).(align_info_1).CR_fac_align.t_peak)
           non_list(non_idx).mod_tp_align_1=2;
        elseif ~isempty(list(i).(align_info_1).CR_sup_align.t_peak) && ~isempty(list(i).(align_info_1).CR_fac_align.t_peak)
           non_list(non_idx).mod_tp_align_1=4;           
        else
           non_list(non_idx).mod_tp_align_1=3; 
        end
        if ~isempty(list(i).(align_info_2).CR_fac_align.t_peak) && isempty(list(i).(align_info_2).CR_sup_align.t_peak) 
           non_list(non_idx).mod_tp_align_2=1;
        elseif ~isempty(list(i).(align_info_2).CR_sup_align.t_peak) && isempty(list(i).(align_info_2).CR_fac_align.t_peak)
           non_list(non_idx).mod_tp_align_2=2;
        elseif ~isempty(list(i).(align_info_2).CR_sup_align.t_peak) && ~isempty(list(i).(align_info_2).CR_fac_align.t_peak)
           non_list(non_idx).mod_tp_align_2=4;           
        else
           non_list(non_idx).mod_tp_align_2=3; 
        end    
        non_list(non_idx).mod_amp_CS_fac_1=list(i).(align_info_1).CR_fac.peak-100;
        non_list(non_idx).mod_amp_CS_fac_2=list(i).(align_info_2).CR_fac.peak-100;
        non_list(non_idx).mod_amp_CR_fac_1=list(i).(align_info_1).CR_fac_align.peak-100;
        non_list(non_idx).mod_amp_CR_fac_2=list(i).(align_info_2).CR_fac_align.peak-100;
        non_list(non_idx).mod_amp_CS_sup_1=list(i).(align_info_1).CR_sup.peak-100;
        non_list(non_idx).mod_amp_CS_sup_2=list(i).(align_info_2).CR_sup.peak-100;
        non_list(non_idx).mod_amp_CR_sup_1=list(i).(align_info_1).CR_sup_align.peak-100;
        non_list(non_idx).mod_amp_CR_sup_2=list(i).(align_info_2).CR_sup_align.peak-100;          
    end 
end

figure;
dt_pt=zeros(size(fac_list,2),2);
for i=1:size(fac_list,2)
    plot(fac_list(i).mod_amp_CR_fac_1-fac_list(i).mod_amp_CS_fac_1,fac_list(i).mod_amp_CR_fac_2-fac_list(i).mod_amp_CS_fac_2,'r.')
    hold on
    dt_pt(i,1)=fac_list(i).mod_amp_CR_fac_1-fac_list(i).mod_amp_CS_fac_1;
    dt_pt(i,2)=fac_list(i).mod_amp_CR_fac_2-fac_list(i).mod_amp_CS_fac_2;  
end
mean_1=mean(dt_pt(:,1));
mean_2=mean(dt_pt(:,2));
std_1=std(dt_pt(:,1));
std_2=std(dt_pt(:,2));
plot(mean_1,mean_2,'rs')
hold on
errorbar(mean_1,mean_2,std_2/sqrt(size(fac_list,2)),std_2/sqrt(size(fac_list,2)),...
    std_1/sqrt(size(fac_list,2)),std_1/sqrt(size(fac_list,2)),'Color','r');
hold on
% line([-80 80],[0 0],'LineStyle','--','Color','k');
% line([0 0],[-80 80],'LineStyle','--','Color','k');
% xlim([-80 80]);
% ylim([-80 80]);
% xlabel('DEC \Delta CR-CS aligned modulation peak (%)');
% ylabel('TEC \Delta CR-CS aligned modulation peak (%)');
line([-80 40],[0 0],'LineStyle','--','Color','k');
line([0 0],[-80 40],'LineStyle','--','Color','k');
xlim([-80 40]);
ylim([-80 40]);
xlabel('TEC \Delta CR-CS aligned modulation peak (%)');
ylabel('DEC \Delta CR-CS aligned modulation peak (%)');

figure;
dt_pt=zeros(size(sup_list,2),2);
for i=1:size(sup_list,2)
    plot(sup_list(i).mod_amp_CR_sup_1-sup_list(i).mod_amp_CS_sup_1,sup_list(i).mod_amp_CR_sup_2-sup_list(i).mod_amp_CS_sup_2,'b.')
    hold on  
    dt_pt(i,1)=sup_list(i).mod_amp_CR_sup_1-sup_list(i).mod_amp_CS_sup_1;
    dt_pt(i,2)=sup_list(i).mod_amp_CR_sup_2-sup_list(i).mod_amp_CS_sup_2;
end
mean_1=mean(dt_pt(:,1));
mean_2=mean(dt_pt(:,2));
std_1=std(dt_pt(:,1));
std_2=std(dt_pt(:,2));
plot(mean_1,mean_2,'bs')
hold on
errorbar(mean_1,mean_2,std_2/sqrt(size(sup_list,2)),std_2/sqrt(size(sup_list,2)),...
    std_1/sqrt(size(sup_list,2)),std_1/sqrt(size(sup_list,2)),'Color','b');
hold on
% line([-20 90],[0 0],'LineStyle','--','Color','k');
% line([0 0],[-20 90],'LineStyle','--','Color','k');
% xlim([-20 90]);
% ylim([-20 90]);
% xticks(-20:10:90);
% xlabel('DEC \Delta CR-CS aligned modulation trough (%)');
% ylabel('TEC \Delta CR-CS aligned modulation trough (%)');
line([-20 30],[0 0],'LineStyle','--','Color','k');
line([0 0],[-20 30],'LineStyle','--','Color','k');
xlim([-20 30]);
ylim([-20 30]);
xticks(-20:10:30);
yticks(-20:10:30);
xlabel('TEC \Delta CR-CS aligned modulation trough (%)');
ylabel('DEC \Delta CR-CS aligned modulation trough (%)');