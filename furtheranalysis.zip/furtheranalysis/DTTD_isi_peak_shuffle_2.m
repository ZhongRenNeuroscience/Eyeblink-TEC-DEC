file=DT_list_align;
figure_name='DT';
cd D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\ifr_peak_shuffle_D\new_2
spk_int='spk_int_D';
all_info='all_info_D';
t_pre=550;
t_psth=1050;

mod_ID=0;
isi_peak_shuffle=struct('cell_ID',[],'trial_info',[],'fac_amp_1st',[],'fac_amp_2nd',[],'fac_time_1st',[],'fac_time_2nd',[],'fac_shf_1st',[],'fac_shf_2nd',[],...
                        'sup_amp_1st',[],'sup_amp_2nd',[],'sup_time_1st',[],'sup_time_2nd',[],'sup_shf_1st',[],'sup_shf_2nd',[]);
for i=1:size(file,2)
    if file(i).CR_fac_D+file(i).CR_fac_T+file(i).CR_sup_D+file(i).CR_sup_T==0
       continue
    else
    mod_ID=mod_ID+1;   
    isi_peak_shuffle(mod_ID).cell_ID=file(i).cell_ID;
    trial_info=struct('trial_num',[],'CR_onset',[],'fac_amp_1st',[],'fac_amp_2nd',[],...
        'sup_amp_1st',[],'sup_amp_2nd',[]);
    
    
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        trial_info(j).trial_num=spk_interval(i).(spk_int).trial_int(j).trial_num;
        trial_info(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
        if size(spk_interval(i).(spk_int).trial_int(j).test,2)>3
           [pks_sup,locs_sup]=findpeaks([spk_interval(i).(spk_int).trial_int(j).test.interval],'NPeaks',2,'SortStr','descend');
        else
            pks_sup=0;            
            locs_sup=0;
        end
        if size(locs_sup,2)==2
           trial_info(j).sup_amp_1st=(spk_interval(i).(spk_int).trial_int(j).test(locs_sup(1)).t+spk_interval(i).(spk_int).trial_int(j).test(locs_sup(1)+1).t)/2;
           trial_info(j).sup_amp_2nd=(spk_interval(i).(spk_int).trial_int(j).test(locs_sup(2)).t+spk_interval(i).(spk_int).trial_int(j).test(locs_sup(2)+1).t)/2;
        end
        if size(spk_interval(i).(spk_int).trial_int(j).test,2)>3
           [pks_fac,locs_fac]=findpeaks(-[spk_interval(i).(spk_int).trial_int(j).test.interval],'NPeaks',2,'SortStr','descend');
        else
           pks_fac=0;
           locs_fac=0;
        end
        if size(locs_fac,2)==2           
           trial_info(j).fac_amp_1st=(spk_interval(i).(spk_int).trial_int(j).test(locs_fac(1)).t+spk_interval(i).(spk_int).trial_int(j).test(locs_fac(1)+1).t)/2;
           trial_info(j).fac_amp_2nd=(spk_interval(i).(spk_int).trial_int(j).test(locs_fac(2)).t+spk_interval(i).(spk_int).trial_int(j).test(locs_fac(2)+1).t)/2;
        end
    end 
    isi_peak_shuffle(mod_ID).trial_info=trial_info;
       
    fac_amp_1st=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).fac_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=trial_info(j).fac_amp_1st;
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;    
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_fac_amp_1st=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_fac_amp_1st=Gau_psth_cal(spk_fac_amp_1st,t_pre,t_psth,0);
    fac_amp_1st.Ctas=Ctas;
    fac_amp_1st.psth=psth_fac_amp_1st;
    isi_peak_shuffle(mod_ID).fac_amp_1st=fac_amp_1st;
    
    fac_amp_2nd=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).fac_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=trial_info(j).fac_amp_2nd;
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;    
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_fac_amp_2nd=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_fac_amp_2nd=Gau_psth_cal(spk_fac_amp_2nd,t_pre,t_psth,0);
    fac_amp_2nd.Ctas=Ctas;
    fac_amp_2nd.psth=psth_fac_amp_2nd;
    isi_peak_shuffle(mod_ID).fac_amp_2nd=fac_amp_2nd;    
        
    fac_time_1st=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).fac_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=min([trial_info(j).fac_amp_1st trial_info(j).fac_amp_2nd]);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_fac_time_1st=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_fac_time_1st=Gau_psth_cal(spk_fac_time_1st,t_pre,t_psth,0);
    fac_time_1st.Ctas=Ctas;
    fac_time_1st.psth=psth_fac_time_1st;
    isi_peak_shuffle(mod_ID).fac_time_1st=fac_time_1st;
    
    fac_time_2nd=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).fac_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=max([trial_info(j).fac_amp_1st trial_info(j).fac_amp_2nd]);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_fac_time_2nd=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_fac_time_2nd=Gau_psth_cal(spk_fac_time_2nd,t_pre,t_psth,0);
    fac_time_2nd.Ctas=Ctas;
    fac_time_2nd.psth=psth_fac_time_2nd;
    isi_peak_shuffle(mod_ID).fac_time_2nd=fac_time_2nd;
        
    fac_shf_1st=struct('Ctas',[],'psth',[]);    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).fac_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=randsample([trial_info(j).fac_amp_1st trial_info(j).fac_amp_2nd],1);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_fac_shf_1st=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_fac_shf_1st=Gau_psth_cal(spk_fac_shf_1st,t_pre,t_psth,0);
    fac_shf_1st.Ctas=Ctas;
    fac_shf_1st.psth=psth_fac_shf_1st;
    isi_peak_shuffle(mod_ID).fac_shf_1st=fac_shf_1st;    
    
    fac_shf_2nd=struct('Ctas',[],'psth',[]);    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).fac_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=randsample([trial_info(j).fac_amp_1st trial_info(j).fac_amp_2nd],1);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_fac_shf_2nd=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_fac_shf_2nd=Gau_psth_cal(spk_fac_shf_2nd,t_pre,t_psth,0);
    fac_shf_2nd.Ctas=Ctas;
    fac_shf_2nd.psth=psth_fac_shf_2nd;
    isi_peak_shuffle(mod_ID).fac_shf_2nd=fac_shf_2nd;    
    
    sup_amp_1st=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).sup_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=trial_info(j).sup_amp_1st;
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;    
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_sup_amp_1st=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_sup_amp_1st=Gau_psth_cal(spk_sup_amp_1st,t_pre,t_psth,0);
    sup_amp_1st.Ctas=Ctas;
    sup_amp_1st.psth=psth_sup_amp_1st;
    isi_peak_shuffle(mod_ID).sup_amp_1st=sup_amp_1st;
    
    sup_amp_2nd=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).sup_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=trial_info(j).sup_amp_2nd;
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;    
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_sup_amp_2nd=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_sup_amp_2nd=Gau_psth_cal(spk_sup_amp_2nd,t_pre,t_psth,0);
    sup_amp_2nd.Ctas=Ctas;
    sup_amp_2nd.psth=psth_sup_amp_2nd;
    isi_peak_shuffle(mod_ID).sup_amp_2nd=sup_amp_2nd;
        
    sup_time_1st=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).sup_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=min([trial_info(j).sup_amp_1st trial_info(j).sup_amp_2nd]);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_sup_time_1st=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_sup_time_1st=Gau_psth_cal(spk_sup_time_1st,t_pre,t_psth,0);
    sup_time_1st.Ctas=Ctas;
    sup_time_1st.psth=psth_sup_time_1st;
    isi_peak_shuffle(mod_ID).sup_time_1st=sup_time_1st;
    
    sup_time_2nd=struct('Ctas',[],'psth',[]);
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).sup_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=max([trial_info(j).sup_amp_1st trial_info(j).sup_amp_2nd]);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_sup_time_2nd=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_sup_time_2nd=Gau_psth_cal(spk_sup_time_2nd,t_pre,t_psth,0);
    sup_time_2nd.Ctas=Ctas;
    sup_time_2nd.psth=psth_sup_time_2nd;
    isi_peak_shuffle(mod_ID).sup_time_2nd=sup_time_2nd;
        
    sup_shf_1st=struct('Ctas',[],'psth',[]);    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).sup_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=randsample([trial_info(j).sup_amp_1st trial_info(j).sup_amp_2nd],1);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_sup_shf_1st=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_sup_shf_1st=Gau_psth_cal(spk_sup_shf_1st,t_pre,t_psth,0);
    sup_shf_1st.Ctas=Ctas;
    sup_shf_1st.psth=psth_sup_shf_1st;
    isi_peak_shuffle(mod_ID).sup_shf_1st=sup_shf_1st;    
    
    sup_shf_2nd=struct('Ctas',[],'psth',[]);    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[],'t_align',[],'t_onset',[]);
    Ctas.cell=1;
    for j=1:size(spk_interval(i).(spk_int).trial_int,2)
        if ~isempty(trial_info(j).sup_amp_1st)
           tss(j).trial=spk_interval(i).(spk_int).trial_int(j).trial_num;
           tss(j).t_align=randsample([trial_info(j).sup_amp_1st trial_info(j).sup_amp_2nd],1);
           tss(j).t=[file(i).(all_info).ttt.CR_trial(j).spk_time]-tss(j).t_align;  
           tss(j).t_onset=trial_info(j).CR_onset;
        end
    end
    tss=tss(~cellfun(@isempty,{tss.t}));
    Ctas.tss=tss;
    spk_sup_shf_2nd=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_sup_shf_2nd=Gau_psth_cal(spk_sup_shf_2nd,t_pre,t_psth,0);
    sup_shf_2nd.Ctas=Ctas;
    sup_shf_2nd.psth=psth_sup_shf_2nd;
    isi_peak_shuffle(mod_ID).sup_shf_2nd=sup_shf_2nd;           
                
    end
end