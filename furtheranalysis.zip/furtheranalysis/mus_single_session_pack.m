date='210521';
mouse_ID='10025-02F';
injection='saline';
session_1='trace_1';
session_2='trace_s';
session_3='delay_s';
save_path='D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Muscimol_data\TD_package';

package_session=struct('mouse_ID',[],'date',[],'CR_onset',[],'CR_amp',[],'CR_per',[],'eyelid_curve',[]);
package_session.mouse_ID=mouse_ID;
package_session.date=date;

package_session.CR_onset=struct('norm_1_mean',[],'prb_1_mean',[],'norm_2_mean',[],'prb_2_mean',[],'norm_3_mean',[],'prb_3_mean',[],...
    'norm_1_trial',[],'prb_1_trial',[],'norm_2_trial',[],'prb_2_trial',[],'norm_3_trial',[],'prb_3_trial',[]);
package_session.CR_amp=struct('norm_1_mean',[],'prb_1_mean',[],'norm_2_mean',[],'prb_2_mean',[],'norm_3_mean',[],'prb_3_mean',[],...
    'norm_1_trial',[],'prb_1_trial',[],'norm_2_trial',[],'prb_2_trial',[],'norm_3_trial',[],'prb_3_trial',[]);
package_session.CR_per=struct('norm_1_mean',[],'prb_1_mean',[],'norm_2_mean',[],'prb_2_mean',[],'norm_3_mean',[],'prb_3_mean',[]);
package_session.eyelid_curve=struct('norm_1_mean',[],'prb_1_mean',[],'norm_2_mean',[],'prb_2_mean',[],'norm_3_mean',[],'prb_3_mean',[],...
    'norm_1_trial',[],'prb_1_trial',[],'norm_2_trial',[],'prb_2_trial',[],'norm_3_trial',[],'prb_3_trial',[]);

filename=[date '_' session_1 '_pair.mat'];
load(filename)
package_session.CR_onset.norm_1_mean=behavior_form(end).CR_on;
package_session.CR_onset.norm_1_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.CR_onset.norm_1_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.CR_onset.norm_1_trial(k).value=behavior_form(k).CR_on;
end

package_session.CR_amp.norm_1_mean=behavior_form(end).CR_amp;
package_session.CR_amp.norm_1_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.CR_amp.norm_1_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.CR_amp.norm_1_trial(k).value=behavior_form(k).CR_amp;
end

package_session.CR_per.norm_1_mean=behavior_form(end).CR_rate;

package_session.eyelid_curve.norm_1_mean=behavior_form(end).blk_trace;
package_session.eyelid_curve.norm_1_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.eyelid_curve.norm_1_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.eyelid_curve.norm_1_trial(k).value=behavior_form(k).blk_trace;
end


filename=[date '_' session_1 '_probe.mat'];
load(filename)
package_session.CR_onset.prb_1_mean=behavior_form_prb(end).CR_on;
package_session.CR_onset.prb_1_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.CR_onset.prb_1_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.CR_onset.prb_1_trial(k).value=behavior_form_prb(k).CR_on;
end

package_session.CR_amp.prb_1_mean=behavior_form_prb(end).CR_amp;
package_session.CR_amp.prb_1_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.CR_amp.prb_1_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.CR_amp.prb_1_trial(k).value=behavior_form_prb(k).CR_amp;
end

package_session.CR_per.prb_1_mean=behavior_form_prb(end).CR_rate;

package_session.eyelid_curve.prb_1_mean=behavior_form_prb(end).blk_trace;
package_session.eyelid_curve.prb_1_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.eyelid_curve.prb_1_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.eyelid_curve.prb_1_trial(k).value=behavior_form_prb(k).blk_trace;
end



filename=[date '_' session_2 '_pair.mat'];
load(filename)
package_session.CR_onset.norm_2_mean=behavior_form(end).CR_on;
package_session.CR_onset.norm_2_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.CR_onset.norm_2_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.CR_onset.norm_2_trial(k).value=behavior_form(k).CR_on;
end

package_session.CR_amp.norm_2_mean=behavior_form(end).CR_amp;
package_session.CR_amp.norm_2_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.CR_amp.norm_2_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.CR_amp.norm_2_trial(k).value=behavior_form(k).CR_amp;
end

package_session.CR_per.norm_2_mean=behavior_form(end).CR_rate;

package_session.eyelid_curve.norm_2_mean=behavior_form(end).blk_trace;
package_session.eyelid_curve.norm_2_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.eyelid_curve.norm_2_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.eyelid_curve.norm_2_trial(k).value=behavior_form(k).blk_trace;
end


filename=[date '_' session_2 '_probe.mat'];
load(filename)
package_session.CR_onset.prb_2_mean=behavior_form_prb(end).CR_on;
package_session.CR_onset.prb_2_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.CR_onset.prb_2_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.CR_onset.prb_2_trial(k).value=behavior_form_prb(k).CR_on;
end

package_session.CR_amp.prb_2_mean=behavior_form_prb(end).CR_amp;
package_session.CR_amp.prb_2_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.CR_amp.prb_2_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.CR_amp.prb_2_trial(k).value=behavior_form_prb(k).CR_amp;
end

package_session.CR_per.prb_2_mean=behavior_form_prb(end).CR_rate;

package_session.eyelid_curve.prb_2_mean=behavior_form_prb(end).blk_trace;
package_session.eyelid_curve.prb_2_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.eyelid_curve.prb_2_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.eyelid_curve.prb_2_trial(k).value=behavior_form_prb(k).blk_trace;
end



filename=[date '_' session_3 '_pair.mat'];
load(filename)
package_session.CR_onset.norm_3_mean=behavior_form(end).CR_on;
package_session.CR_onset.norm_3_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.CR_onset.norm_3_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.CR_onset.norm_3_trial(k).value=behavior_form(k).CR_on;
end

package_session.CR_amp.norm_3_mean=behavior_form(end).CR_amp;
package_session.CR_amp.norm_3_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.CR_amp.norm_3_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.CR_amp.norm_3_trial(k).value=behavior_form(k).CR_amp;
end

package_session.CR_per.norm_3_mean=behavior_form(end).CR_rate;

package_session.eyelid_curve.norm_3_mean=behavior_form(end).blk_trace;
package_session.eyelid_curve.norm_3_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form,2)-1
    package_session.eyelid_curve.norm_3_trial(k).trial_num=behavior_form(k).trial_num;
    package_session.eyelid_curve.norm_3_trial(k).value=behavior_form(k).blk_trace;
end


filename=[date '_' session_3 '_probe.mat'];
load(filename)
package_session.CR_onset.prb_3_mean=behavior_form_prb(end).CR_on;
package_session.CR_onset.prb_3_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.CR_onset.prb_3_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.CR_onset.prb_3_trial(k).value=behavior_form_prb(k).CR_on;
end

package_session.CR_amp.prb_3_mean=behavior_form_prb(end).CR_amp;
package_session.CR_amp.prb_3_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.CR_amp.prb_3_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.CR_amp.prb_3_trial(k).value=behavior_form_prb(k).CR_amp;
end

package_session.CR_per.prb_3_mean=behavior_form_prb(end).CR_rate;

package_session.eyelid_curve.prb_3_mean=behavior_form_prb(end).blk_trace;
package_session.eyelid_curve.prb_3_trial=struct('trial_num',[],'value',[]);
for k=1:size(behavior_form_prb,2)-1
    package_session.eyelid_curve.prb_3_trial(k).trial_num=behavior_form_prb(k).trial_num;
    package_session.eyelid_curve.prb_3_trial(k).value=behavior_form_prb(k).blk_trace;
end

cd(save_path)
save_filename=(['pack_' mouse_ID '_' date '_' injection '.mat']);
save(save_filename,'package_session');


