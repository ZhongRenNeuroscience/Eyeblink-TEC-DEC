% Replaced by DTTD_all_behavior_timing_analysis. --Zhong
listing_D = dir('pack_delay_*');
listing_T = dir('pack_trace_*');

TD_blk_sss=struct('session_num',[],'session_path',[],'normCR_info_T',[],'prbCR_info_T',[],'t_hist_T',[],'CR_onset_T',[],'CR_250_T',[],'CR_pkt_T',[],'CR_amp_T',[],'UR_pkt_T',[],...
                  'normCR_info_D',[],'prbCR_info_D',[],'t_hist_D',[],'CR_onset_D',[],'CR_250_D',[],'CR_pkt_D',[],'CR_amp_D',[],'UR_pkt_D',[]);

for i=1:size(listing_T,1)
    load(listing_T(i).name);
    newStr=extractAfter(listing_T(i).name,'pack_trace_');
    TD_blk_sss(i).session_num=i;
    TD_blk_sss(i).session_path=newStr;
    normCR_info_T=zeros(size(package.ttt(1).CR_trial,2),4);
    for j=1:size(package.ttt(1).CR_trial,2)
        normCR_info_T(j,1)=j;
        normCR_info_T(j,2)=package.ttt(1).CR_trial(j).blk_info.CR_onset*1000;
        normCR_info_T(j,3)=package.ttt(1).CR_trial(j).blk_trace(16001,4)*100;
        normCR_info_T(j,4)=package.ttt(1).CR_trial(j).blk_info.UR_peaktime*1000;
        if normCR_info_T(j,4)>650
           normCR_info_T(j,4)=NaN;
        end
    end
    TD_blk_sss(i).normCR_info_T=normCR_info_T;
    TD_blk_sss(i).CR_onset_T=nanmean(normCR_info_T(:,2));
    TD_blk_sss(i).CR_250_T=nanmean(normCR_info_T(:,3));    
    TD_blk_sss(i).UR_pkt_T=nanmean(normCR_info_T(:,4));
    
    t_hist_T(1,1)=length(find(normCR_info_T(:,2)>=50 & normCR_info_T(:,2)<100));
    t_hist_T(1,2)=length(find(normCR_info_T(:,2)>=100 & normCR_info_T(:,2)<150));
    t_hist_T(1,3)=length(find(normCR_info_T(:,2)>=150 & normCR_info_T(:,2)<200));
    t_hist_T(1,4)=length(find(normCR_info_T(:,2)>=200 & normCR_info_T(:,2)<250));
    t_hist_T(1,5)=length(find(normCR_info_T(:,2)>=250 & normCR_info_T(:,2)<300));
    t_hist_T(1,6)=length(find(normCR_info_T(:,2)>=300 & normCR_info_T(:,2)<350));    
    t_hist_T(1,7)=length(find(normCR_info_T(:,2)>=350 & normCR_info_T(:,2)<400));
    t_hist_T(1,8)=length(find(normCR_info_T(:,2)>=400 & normCR_info_T(:,2)<450));
    t_hist_T(1,9)=length(find(normCR_info_T(:,2)>=450 & normCR_info_T(:,2)<500));    
    t_hist_T(2,:)=t_hist_T(1,:)/size(package.ttt(1).CR_trial,2)*100;
    TD_blk_sss(i).t_hist_T=t_hist_T;  

    for j=1:size(package.ttt(1).probe_trial,2)
        prbCR_info_T(j,1)=j;
        if package.ttt(1).probe_trial(j).blk_info.CR_onset > 0
           prbCR_info_T(j,2)=package.ttt(1).probe_trial(j).blk_info.CR_peaktime*1000;
           prbCR_info_T(j,3)=package.ttt(1).probe_trial(j).blk_info.CR_amp*100;   
        else
           prbCR_info_T(j,2)=NaN;
           prbCR_info_T(j,3)=NaN; 
        end
    end
    TD_blk_sss(i).prbCR_info_T=prbCR_info_T;
    TD_blk_sss(i).CR_pkt_T=nanmean(prbCR_info_T(:,2));
    TD_blk_sss(i).CR_amp_T=nanmean(prbCR_info_T(:,3));    

    D_extract=strfind({listing_T.name},newStr);
    D_file=find(~cellfun(@isempty,D_extract));
    load(listing_D(D_file).name);   

    normCR_info_D=zeros(size(package.ttt(1).CR_trial,2),3);
    for j=1:size(package.ttt(1).CR_trial,2)
        normCR_info_D(j,1)=j;
        normCR_info_D(j,2)=package.ttt(1).CR_trial(j).blk_info.CR_onset*1000;
        normCR_info_D(j,3)=package.ttt(1).CR_trial(j).blk_trace(16001,4)*100;
        normCR_info_D(j,4)=package.ttt(1).CR_trial(j).blk_info.UR_peaktime*1000;
        if normCR_info_D(j,4)>650
           normCR_info_D(j,4)=NaN;
        end
    end
    TD_blk_sss(i).normCR_info_D=normCR_info_D;
    TD_blk_sss(i).CR_onset_D=nanmean(normCR_info_D(:,2));
    TD_blk_sss(i).CR_250_D=nanmean(normCR_info_D(:,3));  
    TD_blk_sss(i).UR_pkt_D=nanmean(normCR_info_D(:,4));
    t_hist_D(1,1)=length(find(normCR_info_D(:,2)>=50 & normCR_info_D(:,2)<100));
    t_hist_D(1,2)=length(find(normCR_info_D(:,2)>=100 & normCR_info_D(:,2)<150));
    t_hist_D(1,3)=length(find(normCR_info_D(:,2)>=150 & normCR_info_D(:,2)<200));
    t_hist_D(1,4)=length(find(normCR_info_D(:,2)>=200 & normCR_info_D(:,2)<250));  
    t_hist_D(2,:)=t_hist_D(1,:)/size(package.ttt(1).CR_trial,2)*100;
    TD_blk_sss(i).t_hist_D=t_hist_D;
    
    for j=1:size(package.ttt(1).probe_trial,2)
        prbCR_info_D(j,1)=j;
        if package.ttt(1).probe_trial(j).blk_info.CR_onset > 0
           prbCR_info_D(j,2)=package.ttt(1).probe_trial(j).blk_info.CR_peaktime*1000;
           prbCR_info_D(j,3)=package.ttt(1).probe_trial(j).blk_info.CR_amp*100;  
        else
           prbCR_info_D(j,2)=NaN;
           prbCR_info_D(j,3)=NaN;                          
        end
    end
    TD_blk_sss(i).prbCR_info_D=prbCR_info_D;
    TD_blk_sss(i).CR_pkt_D=nanmean(prbCR_info_D(:,2));
    TD_blk_sss(i).CR_amp_D=nanmean(prbCR_info_D(:,3));    
end
