%Trial to trial analysis: The correlation test (and the significance of the correlation) to each single neuron of the magnitude of
%modulation and behavior in trial basis. 

pack=list_PC;
all_info='all_info_sps';
t_find=500;
t_find=t_find-20;
k=1;
ttt_PC=struct('cell_ID',[],'ttt',[],'Rf',[],'Pf',[],'Rs',[],'Ps',[],'bsl_frq',[],'mod_f',[],'mod_s',[]);
% first loop for each cell
for i=1:size(pack,2)
    if isempty(list_PC(i).CR_fac_cps)
        continue
    end        
   ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
   ttt=zeros(ttt_sz,6);
   for j=1:ttt_sz
       if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > 2
       ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
       ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
       ttt(j,3)=max(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100;    
       ttt(j,4)=min(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100; 
       else 
       ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
       ttt(j,2)=NaN;
       ttt(j,3)=NaN;              
       end
   end  
   ttt(any(isnan(ttt),2),:) = [];
   ttt(any(isinf(ttt),2),:) = [];
    
    [Rf,Pf]=corrcoef(ttt(:,3),ttt(:,2));
    pf=polyfit(ttt(:,3),ttt(:,2),1);
    regression=pf(1)*ttt(:,3)+pf(2);
    ttt_PC(k).Rf=Rf(1,2);
    ttt_PC(k).Pf=Pf(1,2);
    ttt(:,5)=regression;
    
    [Rs,Ps]=corrcoef(ttt(:,4),ttt(:,2));
    ps=polyfit(ttt(:,4),ttt(:,2),1);
    regression=ps(1)*ttt(:,4)+ps(2);
    ttt_PC(k).Rs=Rs(1,2);
    ttt_PC(k).Ps=Ps(1,2);
    ttt(:,6)=regression;
    
    ttt_PC(k).cell_ID=pack(i).cell_ID;
    ttt_PC(k).ttt=ttt;
    
    ttt_PC(k).bsl_frq=pack(i).(all_info).sss_all.psth.CR_trial.bsl_frq;
    ttt_PC(k).mod_f=pack(i).CR_fac_sps;
    ttt_PC(k).mod_s=pack(i).CR_sup_sps;
    
    k=k+1;

end

