figure;

for i=41:79
    subplot(8,5,i-40)
    plot(trial_info(i).blk_smth(:,1),trial_info(i).blk_smth(:,2))
    hold on
    text(trial_info(i).CR_onset*1000,1,'*','HorizontalAlignment','center')
    hold on
    xlim([-500 1000]);
    ylim([-0.1 1.1]);
    
    
end