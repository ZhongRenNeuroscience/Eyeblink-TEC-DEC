% figure;
% 
% for i=1:size(blk_drft,2)
%     if blk_drft(i).p2 < 0.05 && blk_drft(i).R > 0
%        plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
%        hold on
%     else
%        plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'Color',[0.75 0.75 0.75],'LineStyle','-') 
%        hold on
%     end
% end
% 
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% % xlim([0 150]);
% % ylim([125 225]);
% % yticks(125:25:225);
% 
% 
% 
% 
% figure;
% 
% for i=1:size(blk_drft,2)
%     if blk_drft(i).p2 < 0.05 && blk_drft(i).R < 0
%        plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
%        hold on
%     else
%        plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'Color',[0.75 0.75 0.75],'LineStyle','-') 
%        hold on
%     end
% end
% 
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% xlim([0 150]);
% ylim([125 225]);
% yticks(125:25:225);

% i=1;
% 
% figure;
% plot (blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,2),'k.')
% hold on 
% plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
% hold on
% xlim([0 60]);
% ylim([100 250]);
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% text(45,120,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(45,110,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);
% 
% i=9;
% 
% figure;
% plot (blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,2),'k.')
% hold on 
% plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
% hold on
% xlim([0 86]);
% ylim([100 250]);
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% text(66,120,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(66,110,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);

% i=10;
% 
% figure;
% plot (blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,2),'k.')
% hold on 
% plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
% hold on
% xlim([0 166]);
% ylim([50 500]);
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% text(115,100,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(115,75,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);
% 
% i=6;
% 
% figure;
% plot (blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,2),'k.')
% hold on 
% plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
% hold on
% xlim([0 157]);
% ylim([50 500]);
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% text(115,100,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(115,75,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);


i=25;
blk_drft=blk_drft_TD;
bin=10;

figure;
plot (blk_drft(i).mean_list(:,1),blk_drft(i).mean_list(:,2),'k.','MarkerSize',10)
% scatter (blk_drft(i).mean_list(:,1),blk_drft(i).mean_list(:,2),25,'k','square','filled')
hold on 
% plot(blk_drft(i).mean_list(:,1),blk_drft(i).mean_list(:,4),'k-')
% hold on
% scatter (blk_drft(i).onset_list(:,1)+size(blk_drft(i).mean_list,1)+1,blk_drft(i).onset_list(:,2),25,'k','square','filled')
plot (blk_drft(i).onset_list(:,1)+size(blk_drft(i).mean_list,1)+1,blk_drft(i).onset_list(:,2),'k.','MarkerSize',10)
hold on 
% plot(blk_drft(i).onset_list(:,1)+size(blk_drft(i).mean_list,1)+1,blk_drft(i).onset_list(:,5),'k-')
% plot(blk_drft(i).onset_list(:,1)+size(blk_drft(i).mean_list,1)+1,blk_drft(i).onset_list(:,5),'k-')
% plot(blk_drft(i).onset_list(:,1)+size(blk_drft(i).mean_list,1)+1,blk_drft(i).onset_list(:,5),'k-')
% hold on
plot(blk_drft(i).drift_form(:,1)+bin/2,blk_drft(i).drift_form(:,3),'k-')
hold on
xlim([0 size(blk_drft(i).mean_list,1)+size(blk_drft(i).onset_list,1)+2]);
ylim([100 500]);
line([size(blk_drft(i).mean_list,1)+1 size(blk_drft(i).mean_list,1)+1],[100 500],'Color',[0 0 0],'LineStyle','--');
xlabel('Number of CR trials');
ylabel('CR onset (ms)');
xticks([0:10:size(blk_drft(i).mean_list,1) size(blk_drft(i).mean_list,1)...
    size(blk_drft(i).mean_list,1)+1:10:size(blk_drft(i).mean_list,1)+size(blk_drft(i).onset_list,1)+1 size(blk_drft(i).mean_list,1)+size(blk_drft(i).onset_list,1)+1]);
% text(45,120,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(45,110,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);


% subplot (1,2,2)
% plot (blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,2),'k.')
% hold on 
% plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
% hold on
% xlim([0 60]);
% ylim([100 250]);
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% text(45,120,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(45,110,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);

% i=11;
% 
% figure;
% plot (blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,2),'k.')
% hold on 
% plot(blk_drft(i).onset_list(:,1),blk_drft(i).onset_list(:,3),'k-')
% hold on
% xlim([0 86]);
% ylim([100 250]);
% xlabel('Number of CR trials');
% ylabel('CR onset (ms)');
% text(66,120,['r=' num2str(blk_drft(i).R)],'Color','black','FontSize',12);
% text(66,110,['p=' num2str(blk_drft(i).p2)],'Color','black','FontSize',12);