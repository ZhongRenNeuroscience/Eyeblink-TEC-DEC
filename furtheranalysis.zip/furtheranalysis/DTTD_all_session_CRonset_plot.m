sss_list_1=TD_blk_sss;
sss_list_2=TD_blk_sss_PFC;
bsl_epoch='normCR_info_T';
trial_dot_num=760;
plot_idx_D=1;
plot_idx_T=0;
ymax=150;
ymin=0;
% cd 'D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Wrapup_2\FigureTD behavior'

single_session_list=struct('session_ID',[],'file_name',[],'bsl_onset',[],'trial_info_D',[],'trial_info_T',[]);
all_session_list_D=struct('X_D',[],'Y_D_1',[],'Y_D_2',[]);
all_session_list_T=struct('X_T',[],'Y_T_1',[],'Y_T_2',[]);
session_idx=0;
trial_idx_D=0;
trial_idx_T=0;
for i=1:size(sss_list_1,2)
    session_idx=session_idx+1;
    single_session_list(session_idx).session_ID=session_idx;
    single_session_list(session_idx).file_name=sss_list_1(i).session_path;    
    single_session_list(session_idx).bsl_onset=mean(sss_list_1(i).(bsl_epoch)(:,2));
    trial_info_D=zeros(size(sss_list_1(i).normCR_info_D,1),5);
    trial_info_T=zeros(size(sss_list_1(i).normCR_info_T,1),5);
    
    for j=1:size(sss_list_1(i).normCR_info_D,1)
        trial_idx_D=trial_idx_D+1;
        trial_info_D(j,1)=j;
        trial_info_D(j,2)=j/size(sss_list_1(i).normCR_info_D,1)*100;
        trial_info_D(j,3)=sss_list_1(i).normCR_info_D(j,2);
        trial_info_D(j,4)=sss_list_1(i).normCR_info_D(j,2)/single_session_list(session_idx).bsl_onset*100;
        all_session_list_D(trial_idx_D).X_D=trial_info_D(j,2);
        all_session_list_D(trial_idx_D).Y_D_1=trial_info_D(j,4);
    end
    p_D=polyfit(trial_info_D(:,2),trial_info_D(:,4),1);
    regression_D=p_D(1)*trial_info_D(:,2)+p_D(2);
    trial_info_D(:,5)=regression_D;  
    single_session_list(session_idx).trial_info_D=trial_info_D;
    
    for j=1:size(sss_list_1(i).normCR_info_T,1)
        trial_idx_T=trial_idx_T+1;
        trial_info_T(j,1)=j;
        trial_info_T(j,2)=j/size(sss_list_1(i).normCR_info_T,1)*100;
        trial_info_T(j,3)=sss_list_1(i).normCR_info_T(j,2);
        trial_info_T(j,4)=sss_list_1(i).normCR_info_T(j,2)/single_session_list(session_idx).bsl_onset*100; 
        all_session_list_T(trial_idx_T).X_T=trial_info_T(j,2);
        all_session_list_T(trial_idx_T).Y_T_1=trial_info_T(j,4);
    end
    p_T=polyfit(trial_info_T(:,2),trial_info_T(:,4),1);
    regression_T=p_T(1)*trial_info_T(:,2)+p_T(2);
    trial_info_T(:,5)=regression_T;          
    single_session_list(session_idx).trial_info_T=trial_info_T;
end

if ~isempty(sss_list_2)
    for i=1:size(sss_list_2,2)
        session_idx=session_idx+1;
        single_session_list(session_idx).session_ID=session_idx;
        single_session_list(session_idx).file_name=sss_list_2(i).session_path;    
        single_session_list(session_idx).bsl_onset=mean(sss_list_2(i).(bsl_epoch)(:,2));
        trial_info_D=zeros(size(sss_list_2(i).normCR_info_D,1),5);
        trial_info_T=zeros(size(sss_list_2(i).normCR_info_T,1),5);

        for j=1:size(sss_list_2(i).normCR_info_D,1)
            trial_idx_D=trial_idx_D+1;
            trial_info_D(j,1)=j;
            trial_info_D(j,2)=j/size(sss_list_2(i).normCR_info_D,1)*100;
            trial_info_D(j,3)=sss_list_2(i).normCR_info_D(j,2);
            trial_info_D(j,4)=sss_list_2(i).normCR_info_D(j,2)/single_session_list(session_idx).bsl_onset*100; 
            all_session_list_D(trial_idx_D).X_D=trial_info_D(j,2);
            all_session_list_D(trial_idx_D).Y_D_1=trial_info_D(j,4);
        end
        p_D=polyfit(trial_info_D(:,2),trial_info_D(:,4),1);
        regression_D=p_D(1)*trial_info_D(:,2)+p_D(2);
        trial_info_D(:,5)=regression_D;  
        single_session_list(session_idx).trial_info_D=trial_info_D;

        for j=1:size(sss_list_2(i).normCR_info_T,1)
            trial_idx_T=trial_idx_T+1;
            trial_info_T(j,1)=j;
            trial_info_T(j,2)=j/size(sss_list_2(i).normCR_info_T,1)*100;
            trial_info_T(j,3)=sss_list_2(i).normCR_info_T(j,2);
            trial_info_T(j,4)=sss_list_2(i).normCR_info_T(j,2)/single_session_list(session_idx).bsl_onset*100;    
            all_session_list_T(trial_idx_T).X_T=trial_info_T(j,2);
            all_session_list_T(trial_idx_T).Y_T_1=trial_info_T(j,4);
        end
        p_T=polyfit(trial_info_T(:,2),trial_info_T(:,4),1);
        regression_T=p_T(1)*trial_info_T(:,2)+p_T(2);
        trial_info_T(:,5)=regression_T;   
        single_session_list(session_idx).trial_info_T=trial_info_T;
    end                
end

p_all_D=polyfit([all_session_list_D.X_D],[all_session_list_D.Y_D_1],1);
regression_all_D=p_all_D(1)*[all_session_list_D.X_D]+p_all_D(2);
for i=1:length(regression_all_D)
    all_session_list_D(i).Y_D_2=regression_all_D(i);   
end

p_all_T=polyfit([all_session_list_T.X_T],[all_session_list_T.Y_T_1],1);
regression_all_T=p_all_T(1)*[all_session_list_T.X_T]+p_all_T(2);
for i=1:length(regression_all_T)
    all_session_list_T(i).Y_T_2=regression_all_T(i);   
end

DT_sum=size(all_session_list_D,2)+size(all_session_list_T,2);
plot_prop_D=size(all_session_list_D,2)/DT_sum;
plot_prop_T=size(all_session_list_T,2)/DT_sum;
plot_plus_D=plot_idx_D*(size(all_session_list_D,2)*plot_idx_T+size(all_session_list_T,2)*plot_idx_D)/DT_sum*100;
plot_plus_T=plot_idx_T*(size(all_session_list_D,2)*plot_idx_T+size(all_session_list_T,2)*plot_idx_D)/DT_sum*100;

drift_curve_list=drift_curve_plot(single_session_list,'trial_info_D','trial_info_T',10);
drift_curve_final=struct('session_ID',[],'curve_1',[],'curve_2',[],'curve_merge',[],'curve_final',[]);
for i=1:size(drift_curve_list,2)
    drift_curve_final(i).session_ID=drift_curve_list(i).session_ID;
    curve_1=zeros(drift_curve_list(i).tr_num_1,2);
    curve_2=zeros(drift_curve_list(i).tr_num_2,2);
    curve_1(:,1)=1:drift_curve_list(i).tr_num_1;
    curve_1(:,2)=curve_1(:,1)/drift_curve_list(i).tr_num_1*100;
    curve_1(:,3)=curve_1(:,2)*plot_prop_D+plot_plus_D;
    curve_1(:,4)=drift_curve_list(i).drift_form(1:drift_curve_list(i).tr_num_1,3);
    curve_2(:,1)=1:drift_curve_list(i).tr_num_2;
    curve_2(:,2)=curve_2(:,1)/drift_curve_list(i).tr_num_2*100;
    curve_2(:,3)=curve_2(:,2)*plot_prop_T+plot_plus_T;
    curve_2(:,4)=drift_curve_list(i).drift_form(drift_curve_list(i).tr_num_1+1:end,3);
    curve_merge=zeros(size(drift_curve_list(i).drift_form,1),2);
    curve_merge(1:drift_curve_list(i).tr_num_1,1)=curve_1(:,3);
    curve_merge(1:drift_curve_list(i).tr_num_1,2)=curve_1(:,4);
    curve_merge(drift_curve_list(i).tr_num_1+1:end,1)=curve_2(:,3);
    curve_merge(drift_curve_list(i).tr_num_1+1:end,2)=curve_2(:,4);    
    [~,idx]=sort(curve_merge(:,1));
    curve_merge=curve_merge(idx,:);
    curve_merge(any(curve_merge==0,2),:) = [];
    
    curve_final=zeros(floor(curve_merge(end,1))-ceil(curve_merge(1,1))+1,2);
    curve_final(:,1)=ceil(curve_merge(1,1)):1:floor(curve_merge(end,1));
    curve_final(:,2)=interp1(curve_merge(:,1),curve_merge(:,2),curve_final(:,1),'spline');
    
    drift_curve_final(i).curve_1=curve_1;
    drift_curve_final(i).curve_2=curve_2;
    drift_curve_final(i).curve_merge=curve_merge;
    drift_curve_final(i).curve_final=curve_final;
end

figure;
final_curve_all=nan(100,size(drift_curve_final,2));
for i=1:size(drift_curve_final,2)
    plot(drift_curve_final(i).curve_final(:,1),smooth(drift_curve_final(i).curve_final(:,2),5),'-','Color',[0.8 0.8 0.8],'LineWidth',0.5)
    hold on
    final_curve_all(drift_curve_final(i).curve_final(1,1):drift_curve_final(i).curve_final(end,1),i)=drift_curve_final(i).curve_final(:,2);  
end
final_curve_plot=nan(100,5);
final_curve_plot(:,1)=1:1:100;
final_curve_plot(:,2)=nanmean(final_curve_all,2);
final_curve_plot(:,3)=nanstd(final_curve_all,0,2);
final_curve_plot(:,4)=final_curve_plot(:,2)+final_curve_plot(:,3)/sqrt(size(drift_curve_final,2));

final_curve_plot(:,5)=final_curve_plot(:,2)-final_curve_plot(:,3)/sqrt(size(drift_curve_final,2));

plot(final_curve_plot(5:96,1),smooth(final_curve_plot(5:96,2),5),'k-','LineWidth',2)
hold on
plot(final_curve_plot(5:96,1),smooth(final_curve_plot(5:96,4),5),'-','Color',[0.5 0.5 0.5],'LineWidth',2)
hold on
plot(final_curve_plot(5:96,1),smooth(final_curve_plot(5:96,5),5),'-','Color',[0.5 0.5 0.5],'LineWidth',2)
hold on
xlim([0 100]);
ylim([0 150]);
yticks(0:50:150);
line([floor(plot_plus_D) floor(plot_plus_D)],[0 150],'LineStyle','--');


% num_figure_D=ceil(size(all_session_list_D,2)/trial_dot_num);
% num_figure_T=ceil(size(all_session_list_T,2)/trial_dot_num);
% 
% for m=1:num_figure_D
%     tr_start=(m-1)*trial_dot_num+1;
%     if m*trial_dot_num>size(all_session_list_D,2)
%        tr_end=size(all_session_list_D,2);
%     else
%        tr_end=m*trial_dot_num;
%     end
%     figure;
%     for i=tr_start:tr_end
%         plot(all_session_list_D(i).X_D*plot_prop_D+plot_plus_D,all_session_list_D(i).Y_D_1,'.','Color',[1 0.9 0.8],'MarkerSize',3)
%         hold on  
%     end
%     xlim([0 100]);
%     ylim([ymin ymax]);
%     xticks(0:20:100);
%     yticks(ymin:50:ymax);
%     saveas(gcf,['CR_onset_D_' num2str(m) '.pdf']);
%     close all
% end
% 
% 
% for m=1:num_figure_T
%     tr_start=(m-1)*trial_dot_num+1;
%     if m*trial_dot_num>size(all_session_list_T,2)
%        tr_end=size(all_session_list_T,2);
%     else
%        tr_end=m*trial_dot_num;
%     end
%     figure;
%     for i=tr_start:tr_end
%         plot(all_session_list_T(i).X_T*plot_prop_T+plot_plus_T,all_session_list_T(i).Y_T_1,'.','Color',[1 0.8 0.9],'MarkerSize',3)
%         hold on  
%     end
%     xlim([0 100]);
%     ylim([ymin ymax]);
%     xticks(0:20:100);
%     yticks(ymin:50:ymax);
%     saveas(gcf,['CR_onset_T_' num2str(m) '.pdf']);
%     close all
% end
% 
% figure;
% for i=1:size(single_session_list,2)
%     plot(single_session_list(i).trial_info_D(:,2)*plot_prop_D+plot_plus_D,single_session_list(i).trial_info_D(:,5),'-','Color',[1 0.8 0.6],'LineWidth',0.3)
%     hold on
%     plot(single_session_list(i).trial_info_T(:,2)*plot_prop_T+plot_plus_T,single_session_list(i).trial_info_T(:,5),'-','Color',[1 0.6 0.8],'LineWidth',0.3)
%     hold on        
% end
% plot([all_session_list_D.X_D]*plot_prop_D+plot_plus_D,[all_session_list_D.Y_D_2],'-','Color',[1 0.5 0],'LineWidth',1)
% hold on
% plot([all_session_list_T.X_T]*plot_prop_T+plot_plus_T,[all_session_list_T.Y_T_2],'-','Color',[1 0 0.5],'LineWidth',1)
% hold on
% xlim([0 100]);
% ylim([ymin ymax]);
% xticks(0:20:100);
% yticks(ymin:50:ymax);
% xlabel('Recording trial progress (%)');
% ylabel('Norm. CR onset (%)');
% saveas(gcf,'CR_onset_all_reg.pdf');
% close all

function drift_curve_list=drift_curve_plot(drft_list,name_1,name_2,bin)

drift_curve_list=struct('session_ID',[],'file_name',[],'drift_form',[],'tr_num_1',[],'tr_num_2',[]);
for i=1:size(drft_list,2)
    drift_curve_list(i).session_ID=i;
    drift_curve_list(i).file_name=drft_list(i).session_ID;
    drift_form=zeros(size(drft_list(i).(name_1),1)+size(drft_list(i).(name_2),1),3);
    drift_form(1:size(drft_list(i).(name_1)),2)=drft_list(i).(name_1)(:,4);
    drift_form(size(drft_list(i).(name_1))+1:end,2)=drft_list(i).(name_2)(:,4);
    drift_curve_list(i).tr_num_1=size(drft_list(i).(name_1),1);
    drift_curve_list(i).tr_num_2=size(drft_list(i).(name_2),1);
    
    for j=1:size(drift_form,1)-bin+1
        drift_form(j,1)=j;
        drift_form(j+bin/2,3)=mean(drift_form(j:j+bin-1,2));
    end
%     drift_form=drift_form(1:size(drift_form,1)-bin+1,:);
    drift_curve_list(i).drift_form=drift_form;
end

end

function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end