% listing_D = dir('pack_delay_*');
% listing_T = dir('pack_trace_*');

pack=TD_list_sim_prb;
velocity_curve_bin=10;
[d,id]=findgroups({pack.file_name});
slope_cal_range=[0.1 0.9];
CR_onset_v_thrd=0.002;
CR_onset_amp_thrd=0.05;

TD_blk_sss=struct('session_num',[],'session_path',[],'Mouse_ID',[],'normCR_info_D',[],'prbCR_info_D',[],'t_hist_D',[],'normCR_onset_D',[],'CR_250_D',[],'CR_pkt_D',[],'CR_amp_D',[],'UR_pkt_D',[],...
                  'CR_per_D',[],'normCR_slope_D',[],'normCR_velocity_D',[],'normCR_onset_v_D',[],'normCR_onset_amp_D',[],'prbCR_on_D',[],'prbCR_per_D',[],'prbCR_slope_D',[],'prbCR_velocity_D',[],'prbCR_onset_v_D',[],'prbCR_onset_amp_D',[],'behavior_curve_trial_D',[],'behavior_curve_session_D',[],...
                  'normCR_info_T',[],'prbCR_info_T',[],'t_hist_T',[],'normCR_onset_T',[],'CR_250_T',[],'CR_pkt_T',[],'CR_amp_T',[],'UR_pkt_T',[],...
                  'CR_per_T',[],'normCR_slope_T',[],'normCR_velocity_T',[],'early_per',[],'normCR_onset_v_T',[],'normCR_onset_amp_T',[],'prbCR_on_T',[],'prbCR_per_T',[],'prbCR_slope_T',[],'prbCR_velocity_T',[],'prbCR_onset_v_T',[],'prbCR_onset_amp_T',[],'behavior_curve_trial_T',[],'behavior_curve_session_T',[],'norm_CRamp_D',[],'norm_CRpkt_D',[],'norm_CRnum_D',[],'norm_trnum_D',[],'norm_CRamp_T',[],'norm_CRpkt_T',[],'norm_CRnum_T',[],'norm_trnum_T',[]);

          
              
for i=1:max(d)
%     load(listing_D(i).name);
%     newStr=extractAfter(listing_D(i).name,'pack_delay_');
%     DT_blk_sss(i).session_num=i;
%     DT_blk_sss(i).session_path=newStr;
%     normCR_info_D=zeros(size(package.ttt(1).CR_trial,2),4);

    extract=strfind({pack.file_name},id(i));
    file=find(~cellfun(@isempty,extract));
    TD_blk_sss(i).session_num=i;
    TD_blk_sss(i).session_path=char(id(i));
%     DT_blk_sss(i).Mouse_ID=pack(file(1)).Mouse_ID;
    all_info='all_info_D'; 
    t_post=250;
    m=0;
    normCR_info_D=zeros(size(pack(file(1)).(all_info).ttt.CR_trial,2),10);
    behavior_curve_D=struct('norm_trial',[],'prb_trial',[]);
    behavior_curve_trial_D=struct('norm_trial',[],'prb_trial',[]);
    behavior_curve_D.norm_trial=struct('blk_curve',[],'velocity_curve',[]);
    norm_behavior_curve_trial_D=struct('trial_num',[],'blk_curve',[],'velocity_curve',[]);
    norm_behavior_curve_trial_raw_D=zeros(1550,size(pack(file(1)).(all_info).ttt.CR_trial,2));
    norm_velocity_curve_trial_raw_D=zeros(1550/velocity_curve_bin,size(pack(file(1)).(all_info).ttt.CR_trial,2));
    behavior_curve_D.norm_trial.blk_curve=zeros(1550,2);
    behavior_curve_D.norm_trial.velocity_curve=zeros(1550/velocity_curve_bin,2);  
    behavior_curve_D.norm_trial.blk_curve(:,1)=-550:1:999;
    for j=1:size(pack(file(1)).(all_info).ttt.CR_trial,2)
        if pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset > 0
            normCR_info_D(j,1)=j;
            normCR_info_D(j,2)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            normCR_info_D(j,3)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(801,2)*100;
            normCR_info_D(j,4)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.UR_peaktime;
            normCR_info_D(j,5)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            normCR_info_D(j,7)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            if isempty(slope_cal_range)
                if normCR_info_D(j,7)-normCR_info_D(j,2)>0
                   normCR_info_D(j,6)=normCR_info_D(j,5)/(normCR_info_D(j,7)-normCR_info_D(j,2));
                else
                   normCR_info_D(j,6)=NaN;
                end
            else
                if normCR_info_D(j,7)-normCR_info_D(j,2)>0
                   amp_idx_1=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*slope_cal_range(1);
                   amp_idx_2=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*slope_cal_range(2); 
                   [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2),[0 t_post],[amp_idx_1 amp_idx_1],1);
                   [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2),[0 t_post],[amp_idx_2 amp_idx_2],1);
                   if length(inter_t_1)>1
                       [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-normCR_info_D(j,2)));
                       inter_amp_1=inter_amp_1(inter_t_1_idx);
                   end
                   if isempty(inter_t_1)
                       inter_t_1=NaN;
                       inter_amp_1=NaN;
                   end
                   if length(inter_t_2)>1
                       inter_t_2=inter_t_2(1);
                       inter_amp_2=inter_amp_2(1);
                   end 
                   if isempty(inter_t_2)
                       inter_t_2=NaN;
                       inter_amp_2=NaN;
                   end
                   normCR_info_D(j,6)=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
                else
                   normCR_info_D(j,6)=NaN;
                end                                                
            end
    
            norm_behavior_curve_trial_D(j).trial_num=j;
            norm_behavior_curve_trial_D(j).blk_curve=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth;
            norm_behavior_curve_trial_raw_D(:,j)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2);
            
            velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
            for k=1:1550/velocity_curve_bin
                k_1=(k-1)*velocity_curve_bin+1;
                k_2=k*velocity_curve_bin;
                velocity_curve_trial(k,1)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_1,1)+velocity_curve_bin/2;
                velocity_curve_trial(k,2)=(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_2,2)-pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_1,2))/velocity_curve_bin;          
            end
            norm_behavior_curve_trial_D(j).velocity_curve=velocity_curve_trial;
            norm_velocity_curve_trial_raw_D(:,j)=velocity_curve_trial(:,2);
            if j==1
                t_idx=find(velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<t_post);
                behavior_curve_D.norm_trial.velocity_curve(:,1)=velocity_curve_trial(:,1);
            end
            normCR_info_D(j,8)=max(velocity_curve_trial(t_idx,2));
            
            t_50=find(velocity_curve_trial(:,1)<=50,1,'last');
            t_end=find(velocity_curve_trial(:,1)<=t_post,1,'last');
            t_onset_v=find(velocity_curve_trial(t_50+1:t_end,2)>=CR_onset_v_thrd,1,'first');
            if ~isempty(t_onset_v)
                normCR_info_D(j,9)=velocity_curve_trial(t_50+t_onset_v,1);    
            else
                normCR_info_D(j,9)=NaN;
            end
            
            t_50=find(norm_behavior_curve_trial_D(j).blk_curve(:,1)<=50,1,'last');
            t_end=find(norm_behavior_curve_trial_D(j).blk_curve(:,1)<=t_post,1,'last');
            t_onset_amp=find(norm_behavior_curve_trial_D(j).blk_curve(t_50+1:t_end,2)>=CR_onset_amp_thrd,1,'first');
            if ~isempty(t_onset_amp)
                normCR_info_D(j,10)=norm_behavior_curve_trial_D(j).blk_curve(t_50+t_onset_amp,1);    
            else
                normCR_info_D(j,10)=NaN;
            end    
            
        else
            normCR_info_D(j,1)=j;
            normCR_info_D(j,2)=NaN;
            normCR_info_D(j,3)=NaN;
            normCR_info_D(j,4)=NaN;
            normCR_info_D(j,5)=NaN;
            normCR_info_D(j,6)=NaN;
            normCR_info_D(j,7)=NaN;
            normCR_info_D(j,8)=NaN;
            normCR_info_D(j,9)=NaN;
            normCR_info_D(j,10)=NaN;
            m=m+1;
        end
    end
    behavior_curve_D.norm_trial.blk_curve(:,2)=mean(norm_behavior_curve_trial_raw_D,2);
    behavior_curve_D.norm_trial.velocity_curve(:,2)=mean(norm_velocity_curve_trial_raw_D,2);
    
    TD_blk_sss(i).normCR_info_D=normCR_info_D;
    TD_blk_sss(i).normCR_onset_D=nanmean(normCR_info_D(:,2));
    TD_blk_sss(i).CR_250_D=nanmean(normCR_info_D(:,3));    
    TD_blk_sss(i).UR_pkt_D=nanmean(normCR_info_D(:,4));
    TD_blk_sss(i).norm_CRamp_D=nanmean(normCR_info_D(:,5));
    TD_blk_sss(i).normCR_slope_D=nanmean(normCR_info_D(:,6));
    TD_blk_sss(i).norm_CRpkt_D=nanmean(normCR_info_D(:,7));
    TD_blk_sss(i).normCR_velocity_D=nanmean(normCR_info_D(:,8));
    TD_blk_sss(i).behavior_curve_trial_D.norm_trial=norm_behavior_curve_trial_D;
    TD_blk_sss(i).normCR_onset_v_D=nanmean(normCR_info_D(:,9));
    TD_blk_sss(i).normCR_onset_amp_D=nanmean(normCR_info_D(:,10));
    
    t_hist_D(1,1)=length(find(normCR_info_D(:,2)>=50 & normCR_info_D(:,2)<100));
    t_hist_D(1,2)=length(find(normCR_info_D(:,2)>=100 & normCR_info_D(:,2)<150));
    t_hist_D(1,3)=length(find(normCR_info_D(:,2)>=150 & normCR_info_D(:,2)<200));
    t_hist_D(1,4)=length(find(normCR_info_D(:,2)>=200 & normCR_info_D(:,2)<250));  
    t_hist_D(2,:)=t_hist_D(1,:)/(size(pack(file(1)).(all_info).ttt.CR_trial,2)-m)*100;
    TD_blk_sss(i).t_hist_D=t_hist_D;

    prbCR_info_D=zeros(size(pack(file(1)).(all_info).ttt.probe_trial,2),8);
    behavior_curve_D.prb_trial=struct('blk_curve',[],'velocity_curve',[]);
    prb_behavior_curve_trial_D=struct('trial_num',[],'blk_curve',[],'velocity_curve',[]);
    prb_behavior_curve_trial_raw_D=zeros(1550,size(pack(file(1)).(all_info).ttt.probe_trial,2));
    prb_velocity_curve_trial_raw_D=zeros(1550/velocity_curve_bin,size(pack(file(1)).(all_info).ttt.probe_trial,2));
    behavior_curve_D.prb_trial.blk_curve=zeros(1550,2);
    behavior_curve_D.prb_trial.velocity_curve=zeros(1550/velocity_curve_bin,2);  
    behavior_curve_D.prb_trial.blk_curve(:,1)=-550:1:999;
    n=0;
    for j=1:size(pack(file(1)).(all_info).ttt.probe_trial,2)
        prbCR_info_D(j,1)=j;
        if pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset > 0
            prbCR_info_D(j,2)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_peaktime*1000;
            prbCR_info_D(j,3)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_amp*100;  
            prbCR_info_D(j,4)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset*1000;
            if isempty(slope_cal_range)
                if prbCR_info_D(j,2)-prbCR_info_D(j,4)>0
                   prbCR_info_D(j,5)=prbCR_info_D(j,3)/(prbCR_info_D(j,2)-prbCR_info_D(j,4));
                else
                   prbCR_info_D(j,5)=NaN;
                end
            else
                if prbCR_info_D(j,2)-prbCR_info_D(j,4)>0
                   amp_idx_1=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_amp*slope_cal_range(1);
                   amp_idx_2=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_amp*slope_cal_range(2); 
                   [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2),[0 prbCR_info_D(j,2)],[amp_idx_1 amp_idx_1],1);
                   [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2),[0 prbCR_info_D(j,2)],[amp_idx_2 amp_idx_2],1);
                   if length(inter_t_1)>1
                       [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-prbCR_info_D(j,4)));
                       inter_amp_1=inter_amp_1(inter_t_1_idx);
                   end
                   if isempty(inter_t_1)
                       inter_t_1=NaN;
                       inter_amp_1=NaN;
                   end
                   if length(inter_t_2)>1
                       inter_t_2=inter_t_2(1);
                       inter_amp_2=inter_amp_2(1);
                   end 
                   if isempty(inter_t_2)
                       inter_t_2=NaN;
                       inter_amp_2=NaN;
                   end
                   prbCR_info_D(j,5)=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
                else
                   prbCR_info_D(j,5)=NaN;
                end                                                
            end 
            
            n=n+1;
           
            prb_behavior_curve_trial_D(j).trial_num=j;
            prb_behavior_curve_trial_D(j).blk_curve=pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth;
            prb_behavior_curve_trial_raw_D(:,j)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2);
            
            velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
            for k=1:1550/velocity_curve_bin
                k_1=(k-1)*velocity_curve_bin+1;
                k_2=k*velocity_curve_bin;
                velocity_curve_trial(k,1)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(k_1,1)+velocity_curve_bin/2;
                velocity_curve_trial(k,2)=(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(k_2,2)-pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(k_1,2))/velocity_curve_bin;          
            end
            prb_behavior_curve_trial_D(j).velocity_curve=velocity_curve_trial;
            prb_velocity_curve_trial_raw_D(:,j)=velocity_curve_trial(:,2);
            
            if behavior_curve_D.prb_trial.velocity_curve(1,1)==0
                behavior_curve_D.prb_trial.velocity_curve(:,1)=velocity_curve_trial(:,1);
            end
            t_idx=find(velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<=prbCR_info_D(j,2));
            prbCR_info_D(j,6)=max(velocity_curve_trial(t_idx,2));
            
            t_50=find(velocity_curve_trial(:,1)<=50,1,'last');
            t_end=find(velocity_curve_trial(:,1)<=t_post,1,'last');
            t_onset_v=find(velocity_curve_trial(t_50+1:t_end,2)>=CR_onset_v_thrd,1,'first');
            if ~isempty(t_onset_v)
                prbCR_info_D(j,7)=velocity_curve_trial(t_50+t_onset_v,1);    
            else
                prbCR_info_D(j,7)=NaN;
            end
            
            t_50=find(prb_behavior_curve_trial_D(j).blk_curve(:,1)<=50,1,'last');
            t_end=find(prb_behavior_curve_trial_D(j).blk_curve(:,1)<=t_post,1,'last');
            t_onset_amp=find(prb_behavior_curve_trial_D(j).blk_curve(t_50+1:t_end,2)>=CR_onset_amp_thrd,1,'first');
            if ~isempty(t_onset_amp)
                prbCR_info_D(j,8)=prb_behavior_curve_trial_D(j).blk_curve(t_50+t_onset_amp,1);    
            else
                prbCR_info_D(j,8)=NaN;
            end    
        else
           prbCR_info_D(j,2)=NaN;
           prbCR_info_D(j,3)=NaN; 
           prbCR_info_D(j,4)=NaN; 
           prbCR_info_D(j,5)=NaN;
           prbCR_info_D(j,6)=NaN;
           prbCR_info_D(j,7)=NaN;
           prbCR_info_D(j,8)=NaN;
        end
    end
    behavior_curve_D.prb_trial.blk_curve(:,2)=mean(prb_behavior_curve_trial_raw_D,2);
    behavior_curve_D.prb_trial.velocity_curve(:,2)=mean(prb_velocity_curve_trial_raw_D,2);
    
    TD_blk_sss(i).prbCR_info_D=prbCR_info_D;
    TD_blk_sss(i).CR_pkt_D=nanmean(prbCR_info_D(:,2));
    TD_blk_sss(i).CR_amp_D=nanmean(prbCR_info_D(:,3));  
    TD_blk_sss(i).prbCR_on_D=nanmean(prbCR_info_D(:,4));
    TD_blk_sss(i).prbCR_slope_D=nanmean(prbCR_info_D(:,5));
    TD_blk_sss(i).prbCR_velocity_D=nanmean(prbCR_info_D(:,6));
    TD_blk_sss(i).behavior_curve_session_D=behavior_curve_D;
    TD_blk_sss(i).behavior_curve_trial_D.prb_trial=prb_behavior_curve_trial_D;
    TD_blk_sss(i).prbCR_onset_v_D=nanmean(prbCR_info_D(:,7));
    TD_blk_sss(i).prbCR_onset_amp_D=nanmean(prbCR_info_D(:,8));
%     DT_blk_sss_PFC(i).prbCR_per_D=n/j*100;
    
%% another way to calculate the probe trial CR percentage
   prb_idx=0;
   prb_CR_idx=0;
   for n=1:size(pack(file(1)).(all_info).sss_all.behavior,1)-7
       if pack(file(1)).(all_info).sss_all.behavior{n,3}==0
          prb_idx= prb_idx+1;
          if pack(file(1)).(all_info).sss_all.behavior{n,2}==1
             prb_CR_idx=prb_CR_idx+1;
          end
       end
   end
   TD_blk_sss(i).prbCR_per_D=prb_CR_idx/prb_idx*100; 




    
    
%%
    
    TD_blk_sss(i).norm_CRnum_D=size(pack(file(1)).(all_info).ttt.CR_trial,2)-m;
    TD_blk_sss(i).norm_trnum_D=size(pack(file(1)).(all_info).ttt.CR_trial,2)+size(pack(file(1)).(all_info).ttt.nonCR_trial,2);
    TD_blk_sss(i).CR_per_D=(size(pack(file(1)).(all_info).ttt.CR_trial,2)-m)/(size(pack(file(1)).(all_info).ttt.CR_trial,2)+size(pack(file(1)).(all_info).ttt.nonCR_trial,2))*100;

%     T_extract=strfind({listing_T.name},newStr);
%     T_file=find(~cellfun(@isempty,T_extract));
%     load(listing_T(T_file).name);   

    all_info='all_info_T'; 
    t_post=500;
    m=0;
    normCR_info_T=zeros(size(pack(file(1)).(all_info).ttt.CR_trial,2),10);
    behavior_curve_T=struct('norm_trial',[],'prb_trial',[]);
    behavior_curve_trial_T=struct('norm_trial',[],'prb_trial',[]);
    behavior_curve_T.norm_trial=struct('blk_curve',[],'velocity_curve',[]);
    norm_behavior_curve_trial_T=struct('trial_num',[],'blk_curve',[],'velocity_curve',[]);
    norm_behavior_curve_trial_raw_T=zeros(1550,size(pack(file(1)).(all_info).ttt.CR_trial,2));
    norm_velocity_curve_trial_raw_T=zeros(1550/velocity_curve_bin,size(pack(file(1)).(all_info).ttt.CR_trial,2));
    behavior_curve_T.norm_trial.blk_curve=zeros(1550,2);
    behavior_curve_T.norm_trial.velocity_curve=zeros(1550/velocity_curve_bin,2);  
    behavior_curve_T.norm_trial.blk_curve(:,1)=-550:1:999;
    for j=1:size(pack(file(1)).(all_info).ttt.CR_trial,2)
        if pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset > 0
            normCR_info_T(j,1)=j;
            normCR_info_T(j,2)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            normCR_info_T(j,3)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(801,2)*100;
            normCR_info_T(j,4)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.UR_peaktime;
            normCR_info_T(j,5)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            normCR_info_T(j,7)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            if isempty(slope_cal_range)
                if normCR_info_T(j,7)-normCR_info_T(j,2)>0
                   normCR_info_T(j,6)=normCR_info_T(j,5)/(normCR_info_T(j,7)-normCR_info_T(j,2));
                else
                   normCR_info_T(j,6)=NaN;
                end
            else
                if normCR_info_T(j,7)-normCR_info_T(j,2)>0
                   amp_idx_1=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*slope_cal_range(1);
                   amp_idx_2=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*slope_cal_range(2); 
                   [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2),[0 t_post],[amp_idx_1 amp_idx_1],1);
                   [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2),[0 t_post],[amp_idx_2 amp_idx_2],1);
                   if length(inter_t_1)>1
                       [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-normCR_info_T(j,2)));
                       inter_amp_1=inter_amp_1(inter_t_1_idx);
                   end
                   if isempty(inter_t_1)
                       inter_t_1=NaN;
                       inter_amp_1=NaN;
                   end
                   if length(inter_t_2)>1
                       inter_t_2=inter_t_2(1);
                       inter_amp_2=inter_amp_2(1);
                   end 
                   if isempty(inter_t_2)
                       inter_t_2=NaN;
                       inter_amp_2=NaN;
                   end
                   normCR_info_T(j,6)=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
                else
                   normCR_info_T(j,6)=NaN;
                end                                                
            end     
            
            norm_behavior_curve_trial_T(j).trial_num=j;
            norm_behavior_curve_trial_T(j).blk_curve=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth;
            norm_behavior_curve_trial_raw_T(:,j)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2);
            
            velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
            for k=1:1550/velocity_curve_bin
                k_1=(k-1)*velocity_curve_bin+1;
                k_2=k*velocity_curve_bin;
                velocity_curve_trial(k,1)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_1,1)+velocity_curve_bin/2;
                velocity_curve_trial(k,2)=(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_2,2)-pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_1,2))/velocity_curve_bin;          
            end
            norm_behavior_curve_trial_T(j).velocity_curve=velocity_curve_trial;
            norm_velocity_curve_trial_raw_T(:,j)=velocity_curve_trial(:,2);
            if j==1
                t_idx=find(velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<t_post);
                behavior_curve_T.norm_trial.velocity_curve(:,1)=velocity_curve_trial(:,1);
            end
            normCR_info_T(j,8)=max(velocity_curve_trial(t_idx,2));
            
            t_50=find(velocity_curve_trial(:,1)<=50,1,'last');
            t_end=find(velocity_curve_trial(:,1)<=t_post,1,'last');
            t_onset_v=find(velocity_curve_trial(t_50+1:t_end,2)>=CR_onset_v_thrd,1,'first');
            if ~isempty(t_onset_v)
                normCR_info_T(j,9)=velocity_curve_trial(t_50+t_onset_v,1);    
            else
                normCR_info_T(j,9)=NaN;
            end
            
            t_50=find(norm_behavior_curve_trial_T(j).blk_curve(:,1)<=50,1,'last');
            t_end=find(norm_behavior_curve_trial_T(j).blk_curve(:,1)<=t_post,1,'last');
            t_onset_amp=find(norm_behavior_curve_trial_T(j).blk_curve(t_50+1:t_end,2)>=CR_onset_amp_thrd,1,'first');
            if ~isempty(t_onset_amp)
                normCR_info_T(j,10)=norm_behavior_curve_trial_T(j).blk_curve(t_50+t_onset_amp,1);    
            else
                normCR_info_T(j,10)=NaN;
            end  
        else
            normCR_info_T(j,1)=j;
            normCR_info_T(j,2)=NaN;
            normCR_info_T(j,3)=NaN;
            normCR_info_T(j,4)=NaN;
            normCR_info_T(j,5)=NaN;
            normCR_info_T(j,6)=NaN;
            normCR_info_T(j,7)=NaN;
            normCR_info_T(j,8)=NaN;
            normCR_info_T(j,9)=NaN;
            normCR_info_T(j,10)=NaN;
            m=m+1;
        end
    end
    behavior_curve_T.norm_trial.blk_curve(:,2)=mean(norm_behavior_curve_trial_raw_T,2);
    behavior_curve_T.norm_trial.velocity_curve(:,2)=mean(norm_velocity_curve_trial_raw_T,2);
    
    TD_blk_sss(i).normCR_info_T=normCR_info_T;
    TD_blk_sss(i).normCR_onset_T=nanmean(normCR_info_T(:,2));
    TD_blk_sss(i).CR_250_T=nanmean(normCR_info_T(:,3));  
    TD_blk_sss(i).UR_pkt_T=nanmean(normCR_info_T(:,4));
    TD_blk_sss(i).norm_CRamp_T=nanmean(normCR_info_T(:,5));
    TD_blk_sss(i).normCR_slope_T=nanmean(normCR_info_T(:,6));
    TD_blk_sss(i).norm_CRpkt_T=nanmean(normCR_info_T(:,7));
    TD_blk_sss(i).normCR_velocity_T=nanmean(normCR_info_T(:,8));
    TD_blk_sss(i).behavior_curve_trial_T.norm_trial=norm_behavior_curve_trial_T;
    TD_blk_sss(i).normCR_onset_v_T=nanmean(normCR_info_T(:,9));
    TD_blk_sss(i).normCR_onset_amp_T=nanmean(normCR_info_T(:,10));
    
    t_hist_T(1,1)=length(find(normCR_info_T(:,2)>=50 & normCR_info_T(:,2)<100));
    t_hist_T(1,2)=length(find(normCR_info_T(:,2)>=100 & normCR_info_T(:,2)<150));
    t_hist_T(1,3)=length(find(normCR_info_T(:,2)>=150 & normCR_info_T(:,2)<200));
    t_hist_T(1,4)=length(find(normCR_info_T(:,2)>=200 & normCR_info_T(:,2)<250));
    t_hist_T(1,5)=length(find(normCR_info_T(:,2)>=250 & normCR_info_T(:,2)<300));
    t_hist_T(1,6)=length(find(normCR_info_T(:,2)>=300 & normCR_info_T(:,2)<350));    
    t_hist_T(1,7)=length(find(normCR_info_T(:,2)>=350 & normCR_info_T(:,2)<400));
    t_hist_T(1,8)=length(find(normCR_info_T(:,2)>=400 & normCR_info_T(:,2)<450));
    t_hist_T(1,9)=length(find(normCR_info_T(:,2)>=450 & normCR_info_T(:,2)<500));    
    t_hist_T(2,:)=t_hist_T(1,:)/(size(pack(file(1)).(all_info).ttt.CR_trial,2)-m)*100;
    TD_blk_sss(i).t_hist_T=t_hist_T;
    early=sum(t_hist_T(1,1:4));
    
    prbCR_info_T=zeros(size(pack(file(1)).(all_info).ttt.probe_trial,2),8);
    behavior_curve_T.prb_trial=struct('blk_curve',[],'velocity_curve',[]);
    prb_behavior_curve_trial_T=struct('trial_num',[],'blk_curve',[],'velocity_curve',[]);
    prb_behavior_curve_trial_raw_T=zeros(1550,size(pack(file(1)).(all_info).ttt.probe_trial,2));
    prb_velocity_curve_trial_raw_T=zeros(1550/velocity_curve_bin,size(pack(file(1)).(all_info).ttt.probe_trial,2));
    behavior_curve_T.prb_trial.blk_curve=zeros(1550,2);
    behavior_curve_T.prb_trial.velocity_curve=zeros(1550/velocity_curve_bin,2);  
    behavior_curve_T.prb_trial.blk_curve(:,1)=-550:1:999;
    n=0;
    for j=1:size(pack(file(1)).(all_info).ttt.probe_trial,2)
        prbCR_info_T(j,1)=j;
        if pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset > 0
           prbCR_info_T(j,2)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_peaktime*1000;
           prbCR_info_T(j,3)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_amp*100;   
           prbCR_info_T(j,4)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset*1000;   
            if isempty(slope_cal_range)
                if prbCR_info_T(j,2)-prbCR_info_T(j,4)>0
                   prbCR_info_T(j,5)=prbCR_info_T(j,3)/(prbCR_info_T(j,2)-prbCR_info_T(j,4));
                else
                   prbCR_info_T(j,5)=NaN;
                end
            else
                if prbCR_info_T(j,2)-prbCR_info_T(j,4)>0
                   amp_idx_1=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_amp*slope_cal_range(1);
                   amp_idx_2=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_amp*slope_cal_range(2); 
                   [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2),[0 prbCR_info_T(j,2)],[amp_idx_1 amp_idx_1],1);
                   [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2),[0 prbCR_info_T(j,2)],[amp_idx_2 amp_idx_2],1);
                   if length(inter_t_1)>1
                       [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-prbCR_info_T(j,4)));
                       inter_amp_1=inter_amp_1(inter_t_1_idx);
                   end
                   if isempty(inter_t_1)
                       inter_t_1=NaN;
                       inter_amp_1=NaN;
                   end
                   if length(inter_t_2)>1
                       inter_t_2=inter_t_2(1);
                       inter_amp_2=inter_amp_2(1);
                   end 
                   if isempty(inter_t_2)
                       inter_t_2=NaN;
                       inter_amp_2=NaN;
                   end
                   prbCR_info_T(j,5)=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
                else
                   prbCR_info_T(j,5)=NaN;
                end                                                
            end           
           n=n+1;
           
            prb_behavior_curve_trial_T(j).trial_num=j;
            prb_behavior_curve_trial_T(j).blk_curve=pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth;
            prb_behavior_curve_trial_raw_T(:,j)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2);
            
            velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
            for k=1:1550/velocity_curve_bin
                k_1=(k-1)*velocity_curve_bin+1;
                k_2=k*velocity_curve_bin;
                velocity_curve_trial(k,1)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(k_1,1)+velocity_curve_bin/2;
                velocity_curve_trial(k,2)=(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(k_2,2)-pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(k_1,2))/velocity_curve_bin;          
            end
            prb_behavior_curve_trial_T(j).velocity_curve=velocity_curve_trial;
            prb_velocity_curve_trial_raw_T(:,j)=velocity_curve_trial(:,2);
            
            if behavior_curve_T.prb_trial.velocity_curve(1,1)==0
                behavior_curve_T.prb_trial.velocity_curve(:,1)=velocity_curve_trial(:,1);
            end
            t_idx=find(velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<=prbCR_info_T(j,2));
            prbCR_info_T(j,6)=max(velocity_curve_trial(t_idx,2));
            
            t_50=find(velocity_curve_trial(:,1)<=50,1,'last');
            t_end=find(velocity_curve_trial(:,1)<=t_post,1,'last');
            t_onset_v=find(velocity_curve_trial(t_50+1:t_end,2)>=CR_onset_v_thrd,1,'first');
            if ~isempty(t_onset_v)
                prbCR_info_T(j,7)=velocity_curve_trial(t_50+t_onset_v,1);    
            else
                prbCR_info_T(j,7)=NaN;
            end
            
            t_50=find(prb_behavior_curve_trial_T(j).blk_curve(:,1)<=50,1,'last');
            t_end=find(prb_behavior_curve_trial_T(j).blk_curve(:,1)<=t_post,1,'last');
            t_onset_amp=find(prb_behavior_curve_trial_T(j).blk_curve(t_50+1:t_end,2)>=CR_onset_amp_thrd,1,'first');
            if ~isempty(t_onset_amp)
                prbCR_info_T(j,8)=prb_behavior_curve_trial_T(j).blk_curve(t_50+t_onset_amp,1);    
            else
                prbCR_info_T(j,8)=NaN;
            end    
        else
           prbCR_info_T(j,2)=NaN;
           prbCR_info_T(j,3)=NaN;        
           prbCR_info_T(j,4)=NaN;
           prbCR_info_T(j,5)=NaN;
           prbCR_info_T(j,6)=NaN;
           prbCR_info_T(j,7)=NaN;
           prbCR_info_T(j,8)=NaN;
        end
    end
    behavior_curve_T.prb_trial.blk_curve(:,2)=mean(prb_behavior_curve_trial_raw_T,2);
    behavior_curve_T.prb_trial.velocity_curve(:,2)=mean(prb_velocity_curve_trial_raw_T,2);
    
    TD_blk_sss(i).prbCR_info_T=prbCR_info_T;
    TD_blk_sss(i).CR_pkt_T=nanmean(prbCR_info_T(:,2));
    TD_blk_sss(i).CR_amp_T=nanmean(prbCR_info_T(:,3));     
    TD_blk_sss(i).prbCR_on_T=nanmean(prbCR_info_T(:,4));
    TD_blk_sss(i).prbCR_slope_T=nanmean(prbCR_info_T(:,5));
    TD_blk_sss(i).prbCR_velocity_T=nanmean(prbCR_info_T(:,6));
    TD_blk_sss(i).behavior_curve_session_T=behavior_curve_T;
    TD_blk_sss(i).behavior_curve_trial_T.prb_trial=prb_behavior_curve_trial_T;
    TD_blk_sss(i).prbCR_onset_v_T=nanmean(prbCR_info_T(:,7));
    TD_blk_sss(i).prbCR_onset_amp_T=nanmean(prbCR_info_T(:,8));
%     DT_blk_sss_PFC(i).prbCR_per_T=n/j*100;
    
%% another way to calculate the probe trial CR percentage
   prb_idx=0;
   prb_CR_idx=0;
   for n=1:size(pack(file(1)).(all_info).sss_all.behavior,1)-7
       if pack(file(1)).(all_info).sss_all.behavior{n,3}==0
          prb_idx= prb_idx+1;
          if pack(file(1)).(all_info).sss_all.behavior{n,2}==1
             prb_CR_idx=prb_CR_idx+1;
          end
       end
   end
   TD_blk_sss(i).prbCR_per_T=prb_CR_idx/prb_idx*100; 
   
   %%
    
    TD_blk_sss(i).norm_CRnum_T=size(pack(file(1)).(all_info).ttt.CR_trial,2)-m;
    TD_blk_sss(i).norm_trnum_T=size(pack(file(1)).(all_info).ttt.CR_trial,2)+size(pack(file(1)).(all_info).ttt.nonCR_trial,2);
    TD_blk_sss(i).CR_per_T=(size(pack(file(1)).(all_info).ttt.CR_trial,2)-m)/(size(pack(file(1)).(all_info).ttt.CR_trial,2)+size(pack(file(1)).(all_info).ttt.nonCR_trial,2))*100;
    TD_blk_sss(i).early_per=early/(size(pack(file(1)).(all_info).ttt.CR_trial,2)+size(pack(file(1)).(all_info).ttt.nonCR_trial,2))*100;
end
