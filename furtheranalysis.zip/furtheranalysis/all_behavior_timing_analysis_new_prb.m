% behavior onset peak analysis


% for a=1:size(list_mod.fac,2)
%     pack(a)=list_mod.fac(a);
% end
% for b=1:size(list_mod.sup,2)
%     pack(a+b)=list_mod.sup(b);
% end
% for c=1:size(list_mod.non,2)
%     pack(a+b+c)=list_mod.non(c);
% end

pack=DT_list_sim;

[d,id]=findgroups({pack.file_name});
all_info='all_info_D';

blk_sss_Delay_prb=struct('session_num',[],'session_path',[],'behavior_info',[],'CR_onset',[],'CR_pkt',[],'CR_amp',[],'CR_v',[]);

for i=1:max(d)
    extract=strfind({pack.file_name},id(i));
    file=find(~cellfun(@isempty,extract));
    blk_sss_Delay_prb(i).session_num=i;
    blk_sss_Delay_prb(i).session_path=char(id(i));
    behavior_info=zeros(size(pack(file(1)).(all_info).ttt.probe_trial,2),5);
    for j=1:size(pack(file(1)).(all_info).ttt.probe_trial,2)
        behavior_info(j,1)=j;
        if pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset > 0
        behavior_info(j,2)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_onset*1000;
        behavior_info(j,3)=pack(file(1)).(all_info).ttt.probe_trial(j).blk_info_new.CR_peaktime*1000;
        behavior_info(j,4)=max(pack(file(1)).(all_info).ttt.probe_trial(j).blk_smth(:,2)*100);
        if behavior_info(j,3)-behavior_info(j,2)>0
           behavior_info(j,5)=behavior_info(j,4)/(behavior_info(j,3)-behavior_info(j,2));
        else
           behavior_info(j,5)=NaN;
        end
        else
        behavior_info(j,2)=NaN;
        behavior_info(j,3)=NaN;
        behavior_info(j,4)=NaN;
        behavior_info(j,5)=NaN;
        end
    end
    blk_sss_Delay_prb(i).behavior_info=behavior_info;
    blk_sss_Delay_prb(i).CR_onset=nanmean(behavior_info(:,2));
    blk_sss_Delay_prb(i).CR_pkt=nanmean(behavior_info(:,3));
    blk_sss_Delay_prb(i).CR_amp=nanmean(behavior_info(:,4));
    blk_sss_Delay_prb(i).CR_v=nanmean(behavior_info(:,5));
end

clear i j behavior_info package