trial_mod_list=trial_mod_list_DT;
corr_info_1='fac_corr_info_D';
corr_info_2='fac_corr_info_T';
cell_type_1='CR_fac_D';
cell_type_2='CR_fac_T';
reg_type='reg_onset';
color_1=[1 0.5 0];
color_2=[0.5 0 1];
ymin=-100;
ymax=250;

mean_list=struct('cell_ID',[],'mod_mean_1',[],'bhv_mean_1',[],'d_mean_1',[],'mod_mean_2',[],'bhv_mean_2',[],'d_mean_2',[]);
cell_idx=0;
for i=1:size(trial_mod_list,2)
    if trial_mod_list(i).(cell_type_1)==1 && trial_mod_list(i).(cell_type_2)==1
       cell_idx=cell_idx+1;
       mean_list(cell_idx).cell_ID=trial_mod_list(i).cell_ID;
       mean_list(cell_idx).mod_mean_1=mean(trial_mod_list(i).(corr_info_1).(reg_type)(:,1));
       mean_list(cell_idx).bhv_mean_1=mean(trial_mod_list(i).(corr_info_1).(reg_type)(:,2));
       mean_list(cell_idx).d_mean_1=mean_list(cell_idx).bhv_mean_1-mean_list(cell_idx).mod_mean_1;
       mean_list(cell_idx).mod_mean_2=mean(trial_mod_list(i).(corr_info_2).(reg_type)(:,1));
       mean_list(cell_idx).bhv_mean_2=mean(trial_mod_list(i).(corr_info_2).(reg_type)(:,2));
       mean_list(cell_idx).d_mean_2=mean_list(cell_idx).bhv_mean_2-mean_list(cell_idx).mod_mean_2;              
    end
    
end

cell_plot_ID=25;
trial_max=80;
if size(trial_mod_list(cell_plot_ID).(corr_info_1).(reg_type),1)<=trial_max
    plot_trials_1=1:size(trial_mod_list(cell_plot_ID).(corr_info_1).(reg_type),1);
    d_mod_bhv_1=zeros(size(trial_mod_list(cell_plot_ID).(corr_info_1).(reg_type),1),1);
else
    plot_trials_1=randperm(size(trial_mod_list(cell_plot_ID).(corr_info_1).(reg_type),1),trial_max);
    plot_trials_1=sort(plot_trials_1);
    d_mod_bhv_1=zeros(trial_max,1);
end
if size(trial_mod_list(cell_plot_ID).(corr_info_2).(reg_type),1)<=trial_max
    plot_trials_2=1:size(trial_mod_list(cell_plot_ID).(corr_info_2).(reg_type),1);
    d_mod_bhv_2=zeros(size(trial_mod_list(cell_plot_ID).(corr_info_2).(reg_type),1),1);
else
    plot_trials_2=randperm(size(trial_mod_list(cell_plot_ID).(corr_info_2).(reg_type),1),trial_max);
    plot_trials_2=sort(plot_trials_2);    
    d_mod_bhv_2=zeros(trial_max,1);
end

figure;
subplot(2,1,1)
for j=1:size(plot_trials_1,2)
    trial_ID=plot_trials_1(j);
    d_mod_bhv_1(j,1)=trial_mod_list(cell_plot_ID).(corr_info_1).(reg_type)(trial_ID,2)-trial_mod_list(cell_plot_ID).(corr_info_1).(reg_type)(trial_ID,1);
    plot(j,d_mod_bhv_1(j,1),'.','Color',color_1)
    hold on    
end
line([1 size(plot_trials_1,2)],[mean(d_mod_bhv_1) mean(d_mod_bhv_1)],'Color',color_1);
hold on

for j=1:size(plot_trials_2,2)
    trial_ID=plot_trials_2(j);
    d_mod_bhv_2(j,1)=trial_mod_list(cell_plot_ID).(corr_info_2).(reg_type)(trial_ID,2)-trial_mod_list(cell_plot_ID).(corr_info_2).(reg_type)(trial_ID,1);
    plot(j+size(plot_trials_1,2),d_mod_bhv_2(j,1),'.','Color',color_2)
    hold on    
end
line([size(plot_trials_1,2)+1 size(plot_trials_1,2)+size(plot_trials_2,2)],[mean(d_mod_bhv_2) mean(d_mod_bhv_2)],'Color',color_2);
hold on

line([size(plot_trials_1,2)+0.5 size(plot_trials_1,2)+0.5],[ymin ymax],'LineStyle','--');
xlim([0 size(plot_trials_1,2)+size(plot_trials_2,2)+1]);
ylim([ymin ymax]);
yticks(ymin:50:ymax);
xlabel('Trial number');
ylabel('d(CR-mod) (ms)');
title(['Cell ' num2str(cell_plot_ID)]);

subplot(2,1,2)
h1=histogram(d_mod_bhv_1);
h1.BinWidth=50;
h1.BinLimits=[ymin ymax];
h1.FaceColor=color_1;
h1.Normalization='probability';
hold on
h2=histogram(d_mod_bhv_2);
h2.BinWidth=50;
h2.BinLimits=[ymin ymax];
h2.FaceColor=color_2;
h2.Normalization='probability';
hold on
p=ranksum(d_mod_bhv_1,d_mod_bhv_2);
xlim([ymin ymax]);
ylim([0 1]);
xticks(ymin:50:ymax);
text(ymax*0.7,0.8,['p=' num2str(p)]);



