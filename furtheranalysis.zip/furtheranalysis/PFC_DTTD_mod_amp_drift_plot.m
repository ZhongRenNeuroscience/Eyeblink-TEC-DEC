list=TD_mPFC_ready;
mod_list=PFC_mod_list_TD;
% bhv_list=TD_blk_sss_PFC;
cell_list=bsl_sig_list;     %  bsl_sig_list   fac_cell_1
ephys_plot_item=0;       %  1=CR epoch   0=baseline
CR_trial_2='CR_trial_D';
CR_trial_1='CR_trial_T';
all_info_2='all_info_D';
all_info_1='all_info_T';

bar_color_1=[0.4 0 0.8];
bar_color_2=[1 0.5 0];

bin=10;
ymin=0;
ymax=20;

for i=78:78%size(cell_list,2)
    cell_ID=cell_list(i).cell_ID;
    
    mod_trial=nan(size(mod_list(cell_ID).(CR_trial_1),2)+size(mod_list(cell_ID).(CR_trial_2),2),5);
    width=ceil(size(mod_list(cell_ID).(CR_trial_2),2)/4);
    ratio=size(mod_list(cell_ID).(CR_trial_1),2)/width;
    errorbar_data=zeros(5,5);
    figure;
    for j=1:size(mod_list(cell_ID).(CR_trial_1),2)
        k=j;
        mod_trial(k,1)=k;
        if ephys_plot_item==1
            mod_trial(k,2)=mod_list(cell_ID).(CR_trial_1)(j).CR_epoch_250-mod_list(cell_ID).(CR_trial_1)(j).bsl_all;
        elseif ephys_plot_item==0
            mod_trial(k,2)=mod_list(cell_ID).(CR_trial_1)(j).bsl_all;
        end
        mod_trial(k,3)=list(cell_ID).(all_info_1).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
        subplot(2,1,1)
        plot(mod_trial(k,1)/ratio,mod_trial(k,2),'.','Color',bar_color_1)
        hold on        
        subplot(2,1,2)
        plot(mod_trial(k,1)/ratio,mod_trial(k,3),'.','Color',bar_color_1)
        hold on        
    end
    k_1=k;
    errorbar_data(1,1)=mod_trial(k_1,1)/ratio/2;
    errorbar_data(2,1)=mean(mod_trial(1:k_1,2));
    errorbar_data(3,1)=std(mod_trial(1:k_1,2))/sqrt(k_1);
    errorbar_data(4,1)=mean(mod_trial(1:k_1,3));
    errorbar_data(5,1)=std(mod_trial(1:k_1,3))/sqrt(k_1);
    
    p_1=polyfit(mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),1),mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),2),1);
    regression_1=p_1(1)*mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),1)+p_1(2);
    mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),4)=regression_1;
    
    p_2=polyfit(mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),1),mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),3),1);
    regression_2=p_2(1)*mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),1)+p_2(2);
    mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),5)=regression_2;
    
    subplot(2,1,1)
%     plot(mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),1),mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),4),'-','Color',bar_color_1)
%     hold on
    line([ceil(k_1/ratio) ceil(k_1/ratio)],[-500 500],'Color','k','LineStyle','--');
    subplot(2,1,2)
%     plot(mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),1),mod_trial(1:size(mod_list(cell_ID).(CR_trial_1),2),5),'-','Color',bar_color_1)
%     hold on
    line([ceil(k_1/ratio) ceil(k_1/ratio)],[-500 500],'Color','k','LineStyle','--');
    
    for j=1:size(mod_list(cell_ID).(CR_trial_2),2)
        k=j+size(mod_list(cell_ID).(CR_trial_1),2);
        mod_trial(k,1)=k;
        if ephys_plot_item==1
            mod_trial(k,2)=mod_list(cell_ID).(CR_trial_2)(j).CR_epoch_250-mod_list(cell_ID).(CR_trial_2)(j).bsl_all;
        elseif ephys_plot_item==0    
            mod_trial(k,2)=mod_list(cell_ID).(CR_trial_2)(j).bsl_all;
        end 
        mod_trial(k,3)=list(cell_ID).(all_info_2).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
        subplot(2,1,1)
        plot(width+j,mod_trial(k,2),'.','Color',bar_color_2)
        hold on
        subplot(2,1,2)
        plot(width+j,mod_trial(k,3),'.','Color',bar_color_2)
        hold on
    end
    
    trial_group=quantile(1:size(mod_list(cell_ID).(CR_trial_2),2),3);
    trial_group=[0 floor(trial_group(1:3)) size(mod_list(cell_ID).(CR_trial_2),2)];
    for n=1:4
        errorbar_data(1,n+1)=(trial_group(n+1)+trial_group(n))/2+mod_trial(k_1,1)/ratio;
        errorbar_data(2,n+1)=mean(mod_trial(trial_group(n)+k_1+1:trial_group(n+1)+k_1,2));
        errorbar_data(3,n+1)=std(mod_trial(trial_group(n)+k_1+1:trial_group(n+1)+k_1,2))/sqrt(trial_group(n+1)-trial_group(n)); 
        errorbar_data(4,n+1)=mean(mod_trial(trial_group(n)+k_1+1:trial_group(n+1)+k_1,3));
        errorbar_data(5,n+1)=std(mod_trial(trial_group(n)+k_1+1:trial_group(n+1)+k_1,3))/sqrt(trial_group(n+1)-trial_group(n));   
    end
    
%     p_1=polyfit(mod_trial(k_1+1:k,1),mod_trial(k_1+1:k,2),1);
%     regression_1=p_1(1)*mod_trial(k_1+1:k,1)+p_1(2);
%     mod_trial(k_1+1:k,4)=regression_1; 
%     
%     p_2=polyfit(mod_trial(k_1+1:k,1),mod_trial(k_1+1:k,3),1);
%     regression_2=p_2(1)*mod_trial(k_1+1:k,1)+p_2(2);
%     mod_trial(k_1+1:k,5)=regression_2;   
%     
    subplot(2,1,1)
%     plot(mod_trial(k_1+1:k,1),mod_trial(k_1+1:k,4),'-','Color',bar_color_2)
%     hold on
    errorbar(errorbar_data(1,:),errorbar_data(2,:),errorbar_data(3,:))
    xlabel('Trial')
    ylabel('Modulation (Hz)','Interpreter','none')
    ymin=floor(min(mod_trial(:,2))/5)*5;
    ymax=ceil(max(mod_trial(:,2))/5)*5;
    ylim([-20 60]);
    title(['Cell_' num2str(cell_ID)],'Interpreter','none');
%     
    subplot(2,1,2)
%     plot(mod_trial(k_1+1:k,1),mod_trial(k_1+1:k,5),'-','Color',bar_color_2)
%     hold on
    errorbar(errorbar_data(1,:),errorbar_data(4,:),errorbar_data(5,:))
    ylabel('CR onset (ms)','Interpreter','none')    
    ymin=floor(min(mod_trial(:,3))/25)*25;
    ymax=ceil(max(mod_trial(:,3))/25)*25;
    ylim([100 500]);
    
    fig=gcf;
    orient(fig,'landscape');
    figure_name=[['Cell_' num2str(cell_ID)] '.pdf'];
    saveas(fig,figure_name)
%     ylim([ymin ymax]);
    
    % include_1=floor(size(mod_list(cell_ID).(CR_trial_1),2)/4);
    % [R,P]=corrcoef(mod_trial(size(mod_list(cell_ID).(CR_trial_1),2)-include_1:end,1),mod_trial(size(mod_list(cell_ID).(CR_trial_1),2)-include_1:end,2));

    % 
    % plot(mod_trial(size(mod_list(cell_ID).(CR_trial_1),2)-include_1:end,1),mod_trial(size(mod_list(cell_ID).(CR_trial_1),2)-include_1:end,3),'k-')
    % hold on

%     plot(mod_trial(bin/2+1:size(mod_trial,1)-bin/2+1,1),smooth(mod_trial(bin/2+1:size(mod_trial,1)-bin/2+1,3)),'k-')
%     hold on
%     ylim([ymin ymax]);
%     yticks(ymin:5:ymax);
%     xlabel('trials');
%     ylabel('Norm. Facilitation (Hz)');

end


