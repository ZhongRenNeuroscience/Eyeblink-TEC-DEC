file=TD_list_sim;
all_info_1='all_info_T';
all_info_2='all_info_D';
align_info_1='align_info_T';
align_info_2='align_info_D';
t_interval_1=500;
t_interval_2=500;
t_pre=550;
t_psth=1050;



for i=1:size(file,2)
    
    Ptas_1=struct('cell',[],'tss',[]);
    tss_1=struct('trial',[],'t',[]);
    Ptas_1.cell=1;
    
    file(i).(all_info_1).ttt.probe_trial = file(i).(all_info_1).ttt.probe_trial(~cellfun(@isempty,{file(i).(all_info_1).ttt.probe_trial.spk_time}));
    k=1;
    for j=1:size(file(i).(all_info_1).ttt.probe_trial,2)
        if ~isempty(file(i).(all_info_1).ttt.probe_trial(j).blk_info_new.CR_amp) && ~isempty(file(i).(all_info_1).ttt.probe_trial(j).blk_info_new.CR_onset)
            if file(i).(all_info_1).ttt.probe_trial(j).blk_info_new.CR_amp>0.05 && file(i).(all_info_1).ttt.probe_trial(j).blk_info_new.CR_onset>0.05
               tss_1(k).trial=file(i).(all_info_1).ttt.probe_trial(j).trial_num;
               tss_1(k).t=file(i).(all_info_1).ttt.probe_trial(j).spk_time;
               k=k+1;
            else
               file(i).(all_info_1).ttt.probe_trial(j).trial_num=[];
            end
            Ptas_1.tss=tss_1;     
        end
    end
    spk_prb_Gau_1=spk_Gaussian(Ptas_1,t_pre,t_psth,10,3);
    psth_prb_Gau_1=Gau_psth_cal(spk_prb_Gau_1,t_pre,t_psth,0);
    psth_prb_Gau_1.Gau_psth_org=[];
    mod_prb_1=modulation_type(t_pre-50,t_interval_1,psth_prb_Gau_1,3,10);
    
    file(i).(align_info_1).psth_prb=psth_prb_Gau_1;
    file(i).(align_info_1).mod_prb=mod_prb_1;
        
    
    Ptas_2=struct('cell',[],'tss',[]);
    tss_2=struct('trial',[],'t',[]);
    Ptas_2.cell=1;
    
    file(i).(all_info_2).ttt.probe_trial = file(i).(all_info_2).ttt.probe_trial(~cellfun(@isempty,{file(i).(all_info_2).ttt.probe_trial.spk_time}));
    k=1;
    for j=1:size(file(i).(all_info_2).ttt.probe_trial,2)
        if ~isempty(file(i).(all_info_2).ttt.probe_trial(j).blk_info_new.CR_amp) && ~isempty(file(i).(all_info_2).ttt.probe_trial(j).blk_info_new.CR_onset)
            if file(i).(all_info_2).ttt.probe_trial(j).blk_info_new.CR_amp>0.05 && file(i).(all_info_2).ttt.probe_trial(j).blk_info_new.CR_onset>0.05
               tss_2(k).trial=file(i).(all_info_2).ttt.probe_trial(j).trial_num;
               tss_2(k).t=file(i).(all_info_2).ttt.probe_trial(j).spk_time;
               k=k+1;
            else
               file(i).(all_info_2).ttt.probe_trial(j).trial_num=[];
            end
            Ptas_2.tss=tss_2;  
        end
    end
    spk_prb_Gau_2=spk_Gaussian(Ptas_2,t_pre,t_psth,10,3);
    psth_prb_Gau_2=Gau_psth_cal(spk_prb_Gau_2,t_pre,t_psth,0);
    psth_prb_Gau_2.Gau_psth_org=[];
    mod_prb_2=modulation_type(t_pre-50,t_interval_2,psth_prb_Gau_2,3,10);
    
    file(i).(align_info_2).psth_prb=psth_prb_Gau_2;
    file(i).(align_info_2).mod_prb=mod_prb_2;
end
