file=DT_list_align;
figure_name='DT';
cd D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\CV2
CV2_set='value';  %'value' of 'percent'
CV2_thrd=0.5;
mean_thrd=0.25;

CV2_cal=struct('cell_ID',[],'mod_info',[],'spk_int_D',[],'spk_int_T',[]);

for i=1:size(file,2)
    CV2_cal(i).cell_ID=file(i).cell_ID;
    mod_info=struct('fac_D',[],'fac_T',[],'sup_D',[],'sup_T',[],'motor_relevant_fac_D',[],'motor_relevant_fac_T',[],...
                  'motor_relevant_sup_D',[],'motor_relevant_sup_T',[],'timing_relevant',[],'paradigm_relevant',[]);
    mod_info.fac_D=mod_format(i).fac_D;
    mod_info.fac_T=mod_format(i).fac_T;
    mod_info.sup_D=mod_format(i).sup_D;
    mod_info.sup_T=mod_format(i).sup_T;
    mod_info.motor_relevant_fac_D=mod_format(i).motor_relevant_fac_D;
    mod_info.motor_relevant_fac_T=mod_format(i).motor_relevant_fac_T;
    mod_info.motor_relevant_sup_D=mod_format(i).motor_relevant_sup_D;
    mod_info.motor_relevant_sup_T=mod_format(i).motor_relevant_sup_T;
    mod_info.timing_relevant=mod_format(i).timing_relevant;
    mod_info.paradigm_relevant=mod_format(i).paradigm_relevant;
    CV2_cal(i).mod_info=mod_info;
    
    spk_int_D=struct('trial_num',[],'CR_onset',[],'all_info',[],'event_fac',[],'event_sup',[]);
    spk_int_T=struct('trial_num',[],'CR_onset',[],'all_info',[],'event_fac',[],'event_sup',[]);
    
    session='all_info_D';
    t_post=0.25;
    for j=1:size(file(i).(session).ttt.CR_trial,2)
        spk_int_D(j).trial_num=file(i).(session).ttt.CR_trial(j).trial_num;
        spk_int_D(j).CR_onset=file(i).(session).ttt.CR_trial(j).blk_info_new.CR_onset;
        all_info=struct('t',[],'interval',[],'mean',[],'CV2',[],'type',[],'mod',[]);
        event_fac=struct('spk',[],'spk_count',[],'interval',[],'onset',[],'offset',[],'duration',[],'mid_t',[],'avg_ISI',[],'peak_t',[],'peak_dur',[]);
        event_sup=struct('spk',[],'spk_count',[],'interval',[],'onset',[],'offset',[],'duration',[],'mid_t',[],'avg_ISI',[],'peak_t',[],'peak_dur',[]);
        i_all=0;
        for k=1:size(file(i).(session).ttt.CR_trial(j).spk_time,1)
            if file(i).(session).ttt.CR_trial(j).spk_time(k,1)<-0.5
               continue
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=-0.5 && file(i).(session).ttt.CR_trial(j).spk_time(k,1)<0
               i_all=i_all+1;
               all_info(i_all).mod=0;
               all_info(i_all).t=file(i).(session).ttt.CR_trial(j).spk_time(k,1);
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=0 && file(i).(session).ttt.CR_trial(j).spk_time(k,1)<t_post
               i_all=i_all+1;
               all_info(i_all).mod=0;
               all_info(i_all).t=file(i).(session).ttt.CR_trial(j).spk_time(k,1);
               if k==size(file(i).(session).ttt.CR_trial(j).spk_time,1)    
                  i_all=i_all+1;
                  all_info(i_all).mod=0;
                  all_info(i_all).t=t_post;
               end
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=t_post && file(i).(session).ttt.CR_trial(j).spk_time(k,1)<1
                if i_all~=0 && all_info(i_all).t<t_post
                   i_all=i_all+1;
                   all_info(i_all).mod=0;
                   all_info(i_all).t=t_post;
                end
                   i_all=i_all+1;
                   all_info(i_all).mod=0;
                   all_info(i_all).t=file(i).(session).ttt.CR_trial(j).spk_time(k,1);
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=1      
                   break
            end
        end
        if size(all_info,2)>1
           for m=1:size(all_info,2)-1
               all_info(m).interval=all_info(m+1).t-all_info(m).t;
           end 
        end
        if size(all_info,2)>2
           for m=1:size(all_info,2)-2
               all_info(m).mean=(all_info(m+1).interval+all_info(m).interval)/2;
               all_info(m).CV2=(all_info(m+1).interval-all_info(m).interval)/all_info(m).mean;
           end 
        end
        test_on=find([all_info.t]>=0,1,'first');
        test_off=find([all_info.t]>=t_post,1,'first');
        if test_off>2
            if strcmp('percent',CV2_set)
               CV2_down=prctile([all_info(1:test_off-2).CV2],CV2_thrd*100);
               CV2_up=prctile([all_info(1:test_off-2).CV2],100-CV2_thrd*100);
            elseif strcmp('value',CV2_set)
               CV2_down=-CV2_thrd;
               CV2_up=CV2_thrd;
            end
            mean_down=prctile([all_info(1:test_off-2).mean],mean_thrd*100);
            mean_up=prctile([all_info(1:test_off-2).mean],100-mean_thrd*100);  

            for m=1:test_off-2
                if all_info(m).CV2>CV2_up && all_info(m).mean< mean_down
                   all_info(m).type=3;
                elseif all_info(m).CV2<=CV2_up && all_info(m).CV2>=CV2_down && all_info(m).mean< mean_down
                   all_info(m).type=2;
                elseif all_info(m).CV2<CV2_down && all_info(m).mean< mean_down
                   all_info(m).type=1;
                elseif all_info(m).CV2>CV2_up && all_info(m).mean>= mean_down && all_info(m).mean<= mean_up
                   all_info(m).type=6;
                elseif all_info(m).CV2<=CV2_up && all_info(m).CV2>=CV2_down && all_info(m).mean>= mean_down && all_info(m).mean<= mean_up
                   all_info(m).type=5;
                elseif all_info(m).CV2<CV2_down && all_info(m).mean>= mean_down && all_info(m).mean<= mean_up
                   all_info(m).type=4;    
                elseif all_info(m).CV2>CV2_up && all_info(m).mean> mean_up
                   all_info(m).type=9;
                elseif all_info(m).CV2<=CV2_up && all_info(m).CV2>=CV2_down && all_info(m).mean> mean_up
                   all_info(m).type=8;
                elseif all_info(m).CV2<CV2_down && all_info(m).mean>= mean_up
                   all_info(m).type=7;         
                end
            end       
            if all_info(test_off-2).type<=7
               all_info(test_off-2).type=[];
               test_off=test_off-1;
            end
            idx_fac=0;
            idx_sup=0;
            if test_off-2>test_on
               for m=test_on:test_off-2
                   if all_info(m).type<=3
                      if m-test_on >0 && all_info(m-1).type>3
                         idx_fac=idx_fac+1;
                         if all_info(m-1).type==4 || all_info(m-1).type==7
                            event_fac(idx_fac).onset=all_info(m).t;
                         else 
                            event_fac(idx_fac).onset=all_info(m+1).t;
                         end
                      elseif m-test_on==0
                         idx_fac=idx_fac+1;
                         event_fac(idx_fac).onset=all_info(m).t;
                      end
                      if test_off-2-m>0 && all_info(m+1).type>3
                         if all_info(m).type==3
                            event_fac(idx_fac).offset=all_info(m+1).t;
                         else
                            event_fac(idx_fac).offset=all_info(m+2).t; 
                         end
                      elseif test_off-2-m==0
                         event_fac(idx_fac).offset=all_info(m+2).t;                                                                          
                      end
                   end
                   if all_info(m).type>=7
                      if m-test_on >0 && all_info(m-1).type<7
                         idx_sup=idx_sup+1;
                         if all_info(m-1).type==3 || all_info(m-1).type==6
                            event_sup(idx_sup).onset=all_info(m).t;
                         else 
                            event_sup(idx_sup).onset=all_info(m+1).t;
                         end
                      elseif m-test_on==0
                         idx_sup=idx_sup+1;
                         event_sup(idx_sup).onset=all_info(m).t;
                      end
                      if test_off-2-m>0 && all_info(m+1).type<7
                         if all_info(m).type==7
                            event_sup(idx_sup).offset=all_info(m+1).t;
                         else
                            event_sup(idx_sup).offset=all_info(m+2).t; 
                         end
                      elseif test_off-2-m==0
                         event_sup(idx_sup).offset=all_info(m+2).t; 
                      end
                   end                                          
               end
               for n=1:size(event_fac,2)
                   if ~isempty(event_fac(n).onset)
                      mod_on=find([all_info.t]==event_fac(n).onset,1,'first');
                      mod_off=find([all_info.t]==event_fac(n).offset,1,'first');
                      event_fac(n).spk=[all_info(mod_on:mod_off).t];
                      event_fac(n).spk_count=size(event_fac(n).spk,2);
                      event_fac(n).duration=event_fac(n).offset-event_fac(n).onset;
                      event_fac(n).mid_t=(event_fac(n).offset+event_fac(n).onset)/2;
                      if size(event_fac(n).spk,2)>1
                         event_fac(n).interval=[all_info(mod_on:mod_off-1).interval];
                         event_fac(n).avg_ISI=mean([all_info(mod_on:mod_off-1).interval]);
                         [event_fac(n).peak_dur,i_pk]=min(event_fac(n).interval);
                         event_fac(n).peak_t=(all_info(mod_on+i_pk-1).t+all_info(mod_on+i_pk).t)/2;
                         for p=mod_on:mod_off-1
                             all_info(p).mod=1;
                         end
                      end
                   end                  
               end
               event_fac=event_fac(~cellfun(@isempty,{event_fac.onset}));
               event_fac=event_fac(~cellfun(@isempty,{event_fac.interval}));
                   
               for n=1:size(event_sup,2)
                   if ~isempty(event_sup(n).onset)
                      mod_on=find([all_info.t]==event_sup(n).onset,1,'first');
                      mod_off=find([all_info.t]==event_sup(n).offset,1,'first');                     
                      event_sup(n).spk=[all_info(mod_on:mod_off).t];
                      event_sup(n).spk_count=size(event_sup(n).spk,2);
                      event_sup(n).duration=event_sup(n).offset-event_sup(n).onset;
                      event_sup(n).mid_t=(event_sup(n).offset+event_sup(n).onset)/2;
                      if size(event_sup(n).spk,2)>1
                         event_sup(n).interval=[all_info(mod_on:mod_off-1).interval];
                         event_sup(n).avg_ISI=mean([all_info(mod_on:mod_off-1).interval]);
                         [event_sup(n).peak_dur,i_pk]=max(event_sup(n).interval);
                         event_sup(n).peak_t=(all_info(mod_on+i_pk-1).t+all_info(mod_on+i_pk).t)/2;
                         for p=mod_on:mod_off-1
                             all_info(p).mod=2;
                         end
                      end
                   end                  
               end  
               event_sup=event_sup(~cellfun(@isempty,{event_sup.onset}));
               event_sup=event_sup(~cellfun(@isempty,{event_sup.interval}));
            end                                    
            
        end
        spk_int_D(j).all_info=all_info;
        spk_int_D(j).event_fac=event_fac;
        spk_int_D(j).event_sup=event_sup;
    end
     
    session='all_info_T';
    t_post=0.5;
    for j=1:size(file(i).(session).ttt.CR_trial,2)    
        spk_int_T(j).trial_num=file(i).(session).ttt.CR_trial(j).trial_num;
        spk_int_T(j).CR_onset=file(i).(session).ttt.CR_trial(j).blk_info_new.CR_onset;
        all_info=struct('t',[],'interval',[],'mean',[],'CV2',[],'type',[],'mod',[]);
        event_fac=struct('spk',[],'spk_count',[],'interval',[],'onset',[],'offset',[],'duration',[],'mid_t',[],'avg_ISI',[],'peak_t',[],'peak_dur',[]);
        event_sup=struct('spk',[],'spk_count',[],'interval',[],'onset',[],'offset',[],'duration',[],'mid_t',[],'avg_ISI',[],'peak_t',[],'peak_dur',[]);
        i_all=0;
        for k=1:size(file(i).(session).ttt.CR_trial(j).spk_time,1)
            if file(i).(session).ttt.CR_trial(j).spk_time(k,1)<-0.5
               continue
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=-0.5 && file(i).(session).ttt.CR_trial(j).spk_time(k,1)<0
               i_all=i_all+1;
               all_info(i_all).mod=0;
               all_info(i_all).t=file(i).(session).ttt.CR_trial(j).spk_time(k,1);
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=0 && file(i).(session).ttt.CR_trial(j).spk_time(k,1)<t_post
               i_all=i_all+1;
               all_info(i_all).mod=0;
               all_info(i_all).t=file(i).(session).ttt.CR_trial(j).spk_time(k,1);
               if k==size(file(i).(session).ttt.CR_trial(j).spk_time,1)    
                  i_all=i_all+1;
                  all_info(i_all).mod=0;
                  all_info(i_all).t=t_post;
               end
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=t_post && file(i).(session).ttt.CR_trial(j).spk_time(k,1)<1
                if i_all~=0 && all_info(i_all).t<t_post
                   i_all=i_all+1;
                   all_info(i_all).mod=0;
                   all_info(i_all).t=t_post;
                end
                   i_all=i_all+1;
                   all_info(i_all).mod=0;
                   all_info(i_all).t=file(i).(session).ttt.CR_trial(j).spk_time(k,1);
            elseif file(i).(session).ttt.CR_trial(j).spk_time(k,1)>=1      
                   break
            end
        end
        if size(all_info,2)>1
           for m=1:size(all_info,2)-1
               all_info(m).interval=all_info(m+1).t-all_info(m).t;
           end 
        end
        if size(all_info,2)>2
           for m=1:size(all_info,2)-2
               all_info(m).mean=(all_info(m+1).interval+all_info(m).interval)/2;
               all_info(m).CV2=(all_info(m+1).interval-all_info(m).interval)/all_info(m).mean;
           end 
        end
        test_on=find([all_info.t]>=0,1,'first');
        test_off=find([all_info.t]>=t_post,1,'first');
        if test_off>2
            if strcmp('percent',CV2_set)
               CV2_down=prctile([all_info(1:test_off-2).CV2],CV2_thrd*100);
               CV2_up=prctile([all_info(1:test_off-2).CV2],100-CV2_thrd*100);
            elseif strcmp('value',CV2_set)
               CV2_down=-CV2_thrd;
               CV2_up=CV2_thrd;
            end
            mean_down=prctile([all_info(1:test_off-2).mean],mean_thrd*100);
            mean_up=prctile([all_info(1:test_off-2).mean],100-mean_thrd*100);  

            for m=1:test_off-2
                if all_info(m).CV2>CV2_up && all_info(m).mean< mean_down
                   all_info(m).type=3;
                elseif all_info(m).CV2<=CV2_up && all_info(m).CV2>=CV2_down && all_info(m).mean< mean_down
                   all_info(m).type=2;
                elseif all_info(m).CV2<CV2_down && all_info(m).mean< mean_down
                   all_info(m).type=1;
                elseif all_info(m).CV2>CV2_up && all_info(m).mean>= mean_down && all_info(m).mean<= mean_up
                   all_info(m).type=6;
                elseif all_info(m).CV2<=CV2_up && all_info(m).CV2>=CV2_down && all_info(m).mean>= mean_down && all_info(m).mean<= mean_up
                   all_info(m).type=5;
                elseif all_info(m).CV2<CV2_down && all_info(m).mean>= mean_down && all_info(m).mean<= mean_up
                   all_info(m).type=4;    
                elseif all_info(m).CV2>CV2_up && all_info(m).mean> mean_up
                   all_info(m).type=9;
                elseif all_info(m).CV2<=CV2_up && all_info(m).CV2>=CV2_down && all_info(m).mean> mean_up
                   all_info(m).type=8;
                elseif all_info(m).CV2<CV2_down && all_info(m).mean>= mean_up
                   all_info(m).type=7;         
                end
            end       
            if all_info(test_off-2).type<=7
               all_info(test_off-2).type=[];
               test_off=test_off-1;
            end
            idx_fac=0;
            idx_sup=0;
            if test_off-2>test_on
               for m=test_on:test_off-2
                   if all_info(m).type<=3
                      if m-test_on >0 && all_info(m-1).type>3
                         idx_fac=idx_fac+1;
                         if all_info(m-1).type==4 || all_info(m-1).type==7
                            event_fac(idx_fac).onset=all_info(m).t;
                         else 
                            event_fac(idx_fac).onset=all_info(m+1).t;
                         end
                      elseif m-test_on==0
                         idx_fac=idx_fac+1;
                         event_fac(idx_fac).onset=all_info(m).t;
                      end
                      if test_off-2-m>0 && all_info(m+1).type>3
                         if all_info(m).type==3
                            event_fac(idx_fac).offset=all_info(m+1).t;
                         else
                            event_fac(idx_fac).offset=all_info(m+2).t; 
                         end
                      elseif test_off-2-m==0
                         event_fac(idx_fac).offset=all_info(m+2).t;                                                                          
                      end
                   end
                   if all_info(m).type>=7
                      if m-test_on >0 && all_info(m-1).type<7
                         idx_sup=idx_sup+1;
                         if all_info(m-1).type==3 || all_info(m-1).type==6
                            event_sup(idx_sup).onset=all_info(m).t;
                         else 
                            event_sup(idx_sup).onset=all_info(m+1).t;
                         end
                      elseif m-test_on==0
                         idx_sup=idx_sup+1;
                         event_sup(idx_sup).onset=all_info(m).t;
                      end
                      if test_off-2-m>0 && all_info(m+1).type<7
                         if all_info(m).type==7
                            event_sup(idx_sup).offset=all_info(m+1).t;
                         else
                            event_sup(idx_sup).offset=all_info(m+2).t; 
                         end
                      elseif test_off-2-m==0
                         event_sup(idx_sup).offset=all_info(m+2).t; 
                      end
                   end                                          
               end
               for n=1:size(event_fac,2)
                   if ~isempty(event_fac(n).onset)
                      mod_on=find([all_info.t]==event_fac(n).onset,1,'first');
                      mod_off=find([all_info.t]==event_fac(n).offset,1,'first'); 
                      event_fac(n).spk=[all_info(mod_on:mod_off).t];
                      event_fac(n).spk_count=size(event_fac(n).spk,2);
                      event_fac(n).duration=event_fac(n).offset-event_fac(n).onset;
                      event_fac(n).mid_t=(event_fac(n).offset+event_fac(n).onset)/2;
                      if size(event_fac(n).spk,2)>1
                         event_fac(n).interval=[all_info(mod_on:mod_off-1).interval];
                         event_fac(n).avg_ISI=mean([all_info(mod_on:mod_off-1).interval]);
                         [event_fac(n).peak_dur,i_pk]=min(event_fac(n).interval);
                         event_fac(n).peak_t=(all_info(mod_on+i_pk-1).t+all_info(mod_on+i_pk).t)/2;
                         for p=mod_on:mod_off-1
                             all_info(p).mod=1;
                         end                         
                      end
                   end                  
               end
               event_fac=event_fac(~cellfun(@isempty,{event_fac.onset}));
               event_fac=event_fac(~cellfun(@isempty,{event_fac.interval}));
               for n=1:size(event_sup,2)
                   if ~isempty(event_sup(n).onset)
                      mod_on=find([all_info.t]==event_sup(n).onset,1,'first');
                      mod_off=find([all_info.t]==event_sup(n).offset,1,'first'); 
                      event_sup(n).spk=[all_info(mod_on:mod_off).t];
                      event_sup(n).spk_count=size(event_sup(n).spk,2);
                      event_sup(n).duration=event_sup(n).offset-event_sup(n).onset;
                      event_sup(n).mid_t=(event_sup(n).offset+event_sup(n).onset)/2;
                      if size(event_sup(n).spk,2)>1
                         event_sup(n).interval=[all_info(mod_on:mod_off-1).interval];
                         event_sup(n).avg_ISI=mean([all_info(mod_on:mod_off-1).interval]);
                         [event_sup(n).peak_dur,i_pk]=max(event_sup(n).interval);
                         event_sup(n).peak_t=(all_info(mod_on+i_pk-1).t+all_info(mod_on+i_pk).t)/2;
                         for p=mod_on:mod_off-1
                             all_info(p).mod=2;
                         end                         
                      end
                   end                  
               end    
               event_sup=event_sup(~cellfun(@isempty,{event_sup.onset}));
               event_sup=event_sup(~cellfun(@isempty,{event_sup.interval}));
            end                                    
            
        end
        spk_int_T(j).all_info=all_info;
        spk_int_T(j).event_fac=event_fac;
        spk_int_T(j).event_sup=event_sup;        
        
    end
    CV2_cal(i).spk_int_D=spk_int_D;
    CV2_cal(i).spk_int_T=spk_int_T;    

end