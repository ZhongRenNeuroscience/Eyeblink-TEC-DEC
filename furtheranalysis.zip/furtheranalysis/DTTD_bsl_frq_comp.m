file=TD_list_sim_prb;
bsl_frq_list=struct('cell_ID',[],'bsl_frq_D',[],'bsl_frq_T',[]);

for i=1:size(file,2)
    bsl_frq_list(i).cell_ID=file(i).cell_ID;
    bsl_frq_list(i).bsl_frq_D=file(i).align_info_D.bsl_frq_ex;
    bsl_frq_list(i).bsl_frq_T=file(i).align_info_T.bsl_frq_ex;

end