file_CV2=CV2_cal_2;
file_hist=CV2_hist_list;
cd D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\CV2\session_merge
BinWidth_CV2=5;
BinWidth_mod=10;

position_L_CV2_scatter=[0.05 0.65 0.15 0.3];
position_L_mean_hist=[0.05 0.44 0.15 0.15];
position_L_CV2_hist=[0.23 0.65 0.1 0.3];
position_L_raster=[0.23 0.44 0.1 0.15];
position_L_CV2_temp=[0.05 0.05 0.28 0.33];
position_M_CV2_scatter=[0.36 0.65 0.15 0.3];
position_M_mean_hist=[0.36 0.44 0.15 0.15];
position_M_CV2_hist=[0.54 0.65 0.1 0.3];
position_M_raster=[0.54 0.44 0.1 0.15];
position_M_CV2_temp=[0.36 0.05 0.28 0.33];
position_R_mean_comp=[0.68 0.65 0.12 0.3];
position_R_CV2_comp=[0.83 0.65 0.12 0.3];
position_R_CV2_temp_cohend=[0.68 0.44 0.27 0.16];
position_R_CV2_temp=[0.68 0.05 0.27 0.33];

cohensd_list=struct('Delay_info',[],'Trace_info',[],'cohensd',[]);

for i=1:151
    figure('units','normalized','outerposition',[0 0 1 1]);  
    
    spk_int='spk_int_D';
    hist_info='hist_info_D';
    t_post=250;
    
    subplot('Position',position_L_raster)    
    [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
    file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
    clear index;
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
                  hold on
               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
                  hold on 
               end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
                  if file_CV2(i).(spk_int)(j).all_info(k).t>=0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
                     hold on
                  elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
                     hold on 
                  end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
                  if file_CV2(i).(spk_int)(j).all_info(k).t>=0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
                     hold on
                  elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
                     hold on                 
                  end
            end
        end
        plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
        plot(0,j,'g.')
        hold on
        plot(t_post,j,'r.')
        hold on       
    end
    xlim([-(750-t_post)/2 (750+t_post)/2]);
    xticks(0:250:t_post);
    ylim([0 j+1]);
    xlabel('Time (ms)');
    ylabel('Trial number');
    
    subplot('Position',position_L_CV2_scatter)  
    for m=1:size(file_hist(i).(hist_info).CV2_mean_bsl,2)
        plot(file_hist(i).(hist_info).CV2_mean_bsl(m).mean,file_hist(i).(hist_info).CV2_mean_bsl(m).CV2,'k.')
        hold on
    end
    for m=1:size(file_hist(i).(hist_info).CV2_mean_test,2)
        plot(file_hist(i).(hist_info).CV2_mean_test(m).mean,file_hist(i).(hist_info).CV2_mean_test(m).CV2,'r.')
        hold on
    end   
    xlim([0 100]);
    ylim([0 2]);
    text(65,1.8,'Baseline','Color',[0 0 0],'FontSize',12);
    text(62,1.85,'.','Color',[0 0 0],'FontSize',25);
    text(65,1.65,'CR period','Color',[1 0 0],'FontSize',12);
    text(62,1.7,'.','Color',[1 0 0],'FontSize',25);
    xticks(0:20:100);
    yticks(0:0.5:2);
    ylabel('|CV2|');
    title(['DT cell-' num2str(file_CV2(i).cell_ID) '-Delay']);
    
    subplot('Position',position_L_mean_hist)
    h1=histogram([file_hist(i).(hist_info).CV2_mean_bsl.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([file_hist(i).(hist_info).CV2_mean_test.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Mean of ISI pair (ms)');
    ylabel('Probability');     
    
    subplot('Position',position_L_CV2_hist)
    h1=histogram([file_hist(i).(hist_info).CV2_mean_bsl.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([file_hist(i).(hist_info).CV2_mean_test.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Probability');    
    
    subplot('Position',position_L_CV2_temp)
    for m=1:size(file_hist(i).(hist_info).CV2_mean_bsl,2)
        plot(file_hist(i).(hist_info).CV2_mean_bsl(m).t_on,file_hist(i).(hist_info).CV2_mean_bsl(m).CV2,'.','Color',[0.7 0.7 0.7])
        hold on              
    end
    for m=1:size(file_hist(i).(hist_info).CV2_mean_test,2)
        plot(file_hist(i).(hist_info).CV2_mean_test(m).t_on,file_hist(i).(hist_info).CV2_mean_test(m).CV2,'.','Color',[1 0.7 0.7])
        hold on          
    end
    plot(-487.5:25:t_post-12.5,[file_hist(i).(hist_info).CV2_temp.mean],'k-')
    hold on
    errorbar(-487.5:25:t_post-12.5,[file_hist(i).(hist_info).CV2_temp.mean],[file_hist(i).(hist_info).CV2_temp.SE],'k')      
    hold on
    for m=1:t_post/25
        if file_hist(i).(hist_info).CV2_temp(m+20).p_value<0.05
           if file_hist(i).(hist_info).CV2_temp(m+20).mean>mean([file_hist(i).(hist_info).CV2_mean_bsl.CV2])
              plot(25*m-12.5,(file_hist(i).(hist_info).CV2_temp(m+20).mean+file_hist(i).(hist_info).CV2_temp(m+20).SE)*1.2,'r*','MarkerSize',10,'LineWidth',1.5)
              hold on
           elseif file_hist(i).(hist_info).CV2_temp(m+20).mean<mean([file_hist(i).(hist_info).CV2_mean_bsl.CV2])
              plot(25*m-12.5,(file_hist(i).(hist_info).CV2_temp(m+20).mean-file_hist(i).(hist_info).CV2_temp(m+20).SE)*0.8,'b*','MarkerSize',10,'LineWidth',1.5)
              hold on
           end
        end                
    end
    xlim([-500 t_post]);
    ylim([0 2]);
    xticks(-500:250:t_post);
    yticks(0:0.5:2);
    xlabel('Time (ms)');
    ylabel('|CV2|');     
    
    spk_int='spk_int_T';
    hist_info='hist_info_T';
    t_post=500;
    
    subplot('Position',position_M_raster)    
    [~,index] = sortrows([file_CV2(i).(spk_int).CR_onset].');
    file_CV2(i).(spk_int) = file_CV2(i).(spk_int)(index);
    clear index;
    for j=1:size(file_CV2(i).(spk_int),2)
        for k=1:size(file_CV2(i).(spk_int)(j).all_info,2)
            if file_CV2(i).(spk_int)(j).all_info(k).mod==0
               if file_CV2(i).(spk_int)(j).all_info(k).t>=0 && file_CV2(i).(spk_int)(j).all_info(k).t*1000<t_post
                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'k.')
                  hold on
               elseif file_CV2(i).(spk_int)(j).all_info(k).t<0 || file_CV2(i).(spk_int)(j).all_info(k).t*1000>=t_post
                  plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 0.5 0.5])
                  hold on 
               end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==1
                  if file_CV2(i).(spk_int)(j).all_info(k).t>=0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'m.') 
                     hold on
                  elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[1 0.5 1]) 
                     hold on 
                  end
            elseif file_CV2(i).(spk_int)(j).all_info(k).mod==2
                  if file_CV2(i).(spk_int)(j).all_info(k).t>=0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'c.') 
                     hold on
                  elseif file_CV2(i).(spk_int)(j).all_info(k).t<0
                     plot(file_CV2(i).(spk_int)(j).all_info(k).t*1000,j,'.','Color',[0.5 1 1]) 
                     hold on                 
                  end
            end
        end
        plot(file_CV2(i).(spk_int)(j).CR_onset*1000,j,'b*')
        plot(0,j,'g.')
        hold on
        plot(t_post,j,'r.')
        hold on       
    end
    xlim([-(750-t_post)/2 (750+t_post)/2]);
    xticks(0:250:t_post);
    ylim([0 j+1]);
    xlabel('Time (ms)');
    ylabel('Trial number');
    
    subplot('Position',position_M_CV2_scatter)  
    for m=1:size(file_hist(i).(hist_info).CV2_mean_bsl,2)
        plot(file_hist(i).(hist_info).CV2_mean_bsl(m).mean,file_hist(i).(hist_info).CV2_mean_bsl(m).CV2,'k.')
        hold on
    end
    for m=1:size(file_hist(i).(hist_info).CV2_mean_test,2)
        plot(file_hist(i).(hist_info).CV2_mean_test(m).mean,file_hist(i).(hist_info).CV2_mean_test(m).CV2,'r.')
        hold on
    end   
    xlim([0 100]);
    ylim([0 2]);
%     text(65,1.8,'Baseline','Color',[0 0 0],'FontSize',15);
%     text(62,1.85,'.','Color',[0 0 0],'FontSize',30);
%     text(65,1.65,'CR period','Color',[1 0 0],'FontSize',15);
%     text(62,1.7,'.','Color',[1 0 0],'FontSize',30);
    xticks(0:20:100);
    yticks(0:0.5:2);
    ylabel('|CV2|');
    title(['DT cell-' num2str(file_CV2(i).cell_ID) '-Trace']);
    
    subplot('Position',position_M_mean_hist)
    h1=histogram([file_hist(i).(hist_info).CV2_mean_bsl.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([file_hist(i).(hist_info).CV2_mean_test.mean],'BinWidth',BinWidth_CV2,'BinLimits',[0,100],'Normalization','probability');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Mean of ISI pair (ms)');
    ylabel('Probability');     
    
    subplot('Position',position_M_CV2_hist)
    h1=histogram([file_hist(i).(hist_info).CV2_mean_bsl.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h1.FaceColor = [0 0 0];
    hold on
    h2=histogram([file_hist(i).(hist_info).CV2_mean_test.CV2],'BinWidth',0.1,'BinLimits',[0,2],'Normalization','probability','Orientation', 'horizontal');
    h2.FaceColor = [1 0 0];
    hold on 
    xlabel('Probability');    
    
    subplot('Position',position_M_CV2_temp)
    for m=1:size(file_hist(i).(hist_info).CV2_mean_bsl,2)
        plot(file_hist(i).(hist_info).CV2_mean_bsl(m).t_on,file_hist(i).(hist_info).CV2_mean_bsl(m).CV2,'.','Color',[0.7 0.7 0.7])
        hold on              
    end
    for m=1:size(file_hist(i).(hist_info).CV2_mean_test,2)
        plot(file_hist(i).(hist_info).CV2_mean_test(m).t_on,file_hist(i).(hist_info).CV2_mean_test(m).CV2,'.','Color',[1 0.7 0.7])
        hold on          
    end
    plot(-487.5:25:t_post-12.5,[file_hist(i).(hist_info).CV2_temp.mean],'k-')
    hold on
    errorbar(-487.5:25:t_post-12.5,[file_hist(i).(hist_info).CV2_temp.mean],[file_hist(i).(hist_info).CV2_temp.SE],'k')      
    hold on
    for m=1:t_post/25
        if file_hist(i).(hist_info).CV2_temp(m+20).p_value<0.05
           if file_hist(i).(hist_info).CV2_temp(m+20).mean>mean([file_hist(i).(hist_info).CV2_mean_bsl.CV2])
              plot(25*m-12.5,(file_hist(i).(hist_info).CV2_temp(m+20).mean+file_hist(i).(hist_info).CV2_temp(m+20).SE)*1.2,'r*','MarkerSize',10,'LineWidth',1.5)
              hold on
           elseif file_hist(i).(hist_info).CV2_temp(m+20).mean<mean([file_hist(i).(hist_info).CV2_mean_bsl.CV2])
              plot(25*m-12.5,(file_hist(i).(hist_info).CV2_temp(m+20).mean-file_hist(i).(hist_info).CV2_temp(m+20).SE)*0.8,'b*','MarkerSize',10,'LineWidth',1.5)
              hold on
           end
        end                
    end
    xlim([-500 t_post]);
    ylim([0 2]);
    xticks(-500:250:t_post);
    yticks(0:0.5:2);
    xlabel('Time (ms)');
    ylabel('|CV2|');  
    
    session_output=struct('cell_ID',[],'pmean_D',[],'pmean_T',[],'CV2_D',[],'CV2_T',[]);
    pmean_D=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[]);
    pmean_T=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[]);
    CV2_D=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[]);
    CV2_T=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[]);
    
    pmean_D.bsl_mean=mean([file_hist(i).hist_info_D.CV2_mean_bsl.mean]);
    pmean_D.test_mean=mean([file_hist(i).hist_info_D.CV2_mean_test.mean]);
    pmean_T.bsl_mean=mean([file_hist(i).hist_info_T.CV2_mean_bsl.mean]);
    pmean_T.test_mean=mean([file_hist(i).hist_info_T.CV2_mean_test.mean]);
    pmean_D.bsl_SE=std([file_hist(i).hist_info_D.CV2_mean_bsl.mean])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_bsl.mean]));
    pmean_D.test_SE=std([file_hist(i).hist_info_D.CV2_mean_test.mean])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_test.mean]));
    pmean_T.bsl_SE=std([file_hist(i).hist_info_T.CV2_mean_bsl.mean])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_bsl.mean]));
    pmean_T.test_SE=std([file_hist(i).hist_info_T.CV2_mean_test.mean])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_test.mean])); 
    p_1= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.mean],[file_hist(i).hist_info_D.CV2_mean_test.mean]);
    p_2= ranksum([file_hist(i).hist_info_T.CV2_mean_bsl.mean],[file_hist(i).hist_info_T.CV2_mean_test.mean]);
    p_3= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.mean],[file_hist(i).hist_info_T.CV2_mean_bsl.mean]);
    p_4= ranksum([file_hist(i).hist_info_D.CV2_mean_test.mean],[file_hist(i).hist_info_T.CV2_mean_test.mean]);
    pmean_D.p_value=p_1;
    pmean_T.p_value=p_2;
    
    subplot('Position',position_R_mean_comp)
    plot(1,pmean_D.bsl_mean,'ks','MarkerSize',5)
    hold on
    plot(2,pmean_D.test_mean,'rs','MarkerSize',5)
    hold on
    plot(3,pmean_T.bsl_mean,'ks','MarkerSize',5)
    hold on
    plot(4,pmean_T.test_mean,'rs','MarkerSize',5)
    hold on       
    errorbar(1,pmean_D.bsl_mean,pmean_D.bsl_SE,'k','CapSize',15)
    hold on
    errorbar(2,pmean_D.test_mean,pmean_D.test_SE,'r','CapSize',15)
    hold on
    errorbar(3,pmean_T.bsl_mean,pmean_T.bsl_SE,'k','CapSize',15)
    hold on
    errorbar(4,pmean_T.test_mean,pmean_T.test_SE,'r','CapSize',15)
    hold on    
    if p_1<0.05
       plot(2,(pmean_D.test_mean+pmean_D.test_SE)*1.1,'r*','MarkerSize',7,'LineWidth',1);
       hold on
    end
    if p_2<0.05
       plot(4,(pmean_T.test_mean+pmean_T.test_SE)*1.1,'r*','MarkerSize',7,'LineWidth',1);
       hold on
    end    
    if p_3<0.05
       plot(3,(pmean_T.bsl_mean+pmean_T.bsl_SE)*1.1,'k*','MarkerSize',7,'LineWidth',1);
       hold on
    end    
    if p_4<0.05
       plot(4,(pmean_T.test_mean+pmean_T.test_SE)*1.2,'k*','MarkerSize',7,'LineWidth',1);
       hold on
    end 
    xlim([0 5]);
    xticks([1 2 3 4]);
    xticklabels({'Bsl_D','CR_D','Bsl_T','CR_T'});
    ylabel('Mean of ISI pair (ms)');   
    
    subplot('Position',position_R_CV2_comp)
    CV2_D.bsl_mean=mean([file_hist(i).hist_info_D.CV2_mean_bsl.CV2]);
    CV2_D.test_mean=mean([file_hist(i).hist_info_D.CV2_mean_test.CV2]);
    CV2_T.bsl_mean=mean([file_hist(i).hist_info_T.CV2_mean_bsl.CV2]);
    CV2_T.test_mean=mean([file_hist(i).hist_info_T.CV2_mean_test.CV2]);
    CV2_D.bsl_SE=std([file_hist(i).hist_info_D.CV2_mean_bsl.CV2])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_bsl.CV2]));
    CV2_D.test_SE=std([file_hist(i).hist_info_D.CV2_mean_test.CV2])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_test.CV2]));
    CV2_T.bsl_SE=std([file_hist(i).hist_info_T.CV2_mean_bsl.CV2])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_bsl.CV2]));
    CV2_T.test_SE=std([file_hist(i).hist_info_T.CV2_mean_test.CV2])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_test.CV2])); 
    p_1= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.CV2],[file_hist(i).hist_info_D.CV2_mean_test.CV2]);
    p_2= ranksum([file_hist(i).hist_info_T.CV2_mean_bsl.CV2],[file_hist(i).hist_info_T.CV2_mean_test.CV2]);
    p_3= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.CV2],[file_hist(i).hist_info_T.CV2_mean_bsl.CV2]);
    p_4= ranksum([file_hist(i).hist_info_D.CV2_mean_test.CV2],[file_hist(i).hist_info_T.CV2_mean_test.CV2]);
    CV2_D.p_value=p_1;
    CV2_T.p_value=p_2;
    
    plot(1,CV2_D.bsl_mean,'ks','MarkerSize',5)
    hold on
    plot(2,CV2_D.test_mean,'rs','MarkerSize',5)
    hold on
    plot(3,CV2_T.bsl_mean,'ks','MarkerSize',5)
    hold on
    plot(4,CV2_T.test_mean,'rs','MarkerSize',5)
    hold on       
    errorbar(1,CV2_D.bsl_mean,CV2_D.bsl_SE,'k','CapSize',15)
    hold on
    errorbar(2,CV2_D.test_mean,CV2_D.test_SE,'r','CapSize',15)
    hold on
    errorbar(3,CV2_T.bsl_mean,CV2_T.bsl_SE,'k','CapSize',15)
    hold on
    errorbar(4,CV2_T.test_mean,CV2_T.test_SE,'r','CapSize',15)
    hold on    
    if p_1<0.05
       plot(2,(CV2_D.test_mean+CV2_D.test_SE)*1.03,'r*','MarkerSize',7,'LineWidth',1);
       hold on
    end
    if p_2<0.05
       plot(4,(CV2_T.test_mean+CV2_T.test_SE)*1.03,'r*','MarkerSize',7,'LineWidth',1);
       hold on
    end    
    if p_3<0.05
       plot(3,(CV2_T.bsl_mean+CV2_T.bsl_SE)*1.03,'k*','MarkerSize',7,'LineWidth',1);
       hold on
    end    
    if p_4<0.05
       plot(4,(CV2_T.test_mean+CV2_T.test_SE)*1.07,'k*','MarkerSize',7,'LineWidth',1);
       hold on
    end  
    xlim([0 5]);
    xticks([1 2 3 4]);
    xticklabels({'Bsl_D','CR_D','Bsl_T','CR_T'});
    ylabel('|CV2|');   
    
    session_output(i).cell_ID=file_hist(i).cell_ID;
    session_output(i).pmean_D=pmean_D;
    session_output(i).pmean_T=pmean_T;
    session_output(i).CV2_D=CV2_D;
    session_output(i).CV2_T=CV2_T;    
    
    subplot('Position',position_R_CV2_temp)
    plot(-487.5:25:237.5,[file_hist(i).hist_info_D.CV2_temp.mean],'k-')
    hold on
    errorbar(-487.5:25:237.5,[file_hist(i).hist_info_D.CV2_temp.mean],[file_hist(i).hist_info_D.CV2_temp.SE],'k')      
    hold on  
    plot(-487.5:25:487.5,[file_hist(i).hist_info_T.CV2_temp.mean],'r-')
    hold on
    errorbar(-487.5:25:487.5,[file_hist(i).hist_info_T.CV2_temp.mean],[file_hist(i).hist_info_T.CV2_temp.SE],'r')      
    hold on 
    line([0 0],[0,2],'LineStyle','--','Color',[0 1 0]);
    xlim([-500 500]);
    ylim([0 2]);
    xticks(-500:250:500);
    yticks(0:0.5:2);
    xlabel('Time (ms)');
    ylabel('|CV2|');   
    text(275,1.8,'Delay','Color',[0 0 0],'FontSize',15);
    text(230,1.83,'-','Color',[0 0 0],'FontSize',30);
    text(275,1.6,'Trace','Color',[1 0 0],'FontSize',15);
    text(230,1.63,'-','Color',[1 0 0],'FontSize',30);  
    
    subplot('Position',position_R_CV2_temp_cohend)
    [~,index] = sortrows([file_hist(i).hist_info_D.CV2_mean_bsl.t_on].'); 
    file_hist(i).hist_info_D.CV2_mean_bsl = file_hist(i).hist_info_D.CV2_mean_bsl(index);
    clear index
    [~,index] = sortrows([file_hist(i).hist_info_D.CV2_mean_test.t_on].'); 
    file_hist(i).hist_info_D.CV2_mean_test = file_hist(i).hist_info_D.CV2_mean_test(index);    
    clear index    
    CV2_temp_D=struct('mean',[],'var',[],'number',[]);
    i_temp=0;
    temp_on=1;
    for m=1:20
        i_temp=i_temp+1;
        if file_hist(i).hist_info_D.CV2_mean_bsl(temp_on).t_on<-500+25*m
           temp_off=find([file_hist(i).hist_info_D.CV2_mean_bsl.t_on]<-500+25*m,1,'last');
           CV2_temp_D(i_temp).number=temp_off-temp_on+1;
           CV2_temp_D(i_temp).mean=mean([file_hist(i).hist_info_D.CV2_mean_bsl(temp_on:temp_off).CV2]);
           if temp_off-temp_on>=1
              CV2_temp_D(i_temp).var=var([file_hist(i).hist_info_D.CV2_mean_bsl(temp_on:temp_off).CV2]); 
           else 
              CV2_temp_D(i_temp).var=0;
           end
           temp_on=temp_off+1;
        else
           CV2_temp_D(i_temp).mean=0;
           CV2_temp_D(i_temp).var=0;
           CV2_temp_D(i_temp).number=0;
        end
    end   
    temp_on=1;
    for m=1:10
        i_temp=i_temp+1;
        if temp_on<=size(file_hist(i).hist_info_D.CV2_mean_test,2) && file_hist(i).hist_info_D.CV2_mean_test(temp_on).t_on<25*m
           temp_off=find([file_hist(i).hist_info_D.CV2_mean_test.t_on]<25*m,1,'last');
           CV2_temp_D(i_temp).number=temp_off-temp_on+1;           
           CV2_temp_D(i_temp).mean=mean([file_hist(i).hist_info_D.CV2_mean_test(temp_on:temp_off).CV2]);
           if temp_off-temp_on>=1
              CV2_temp_D(i_temp).var=var([file_hist(i).hist_info_D.CV2_mean_test(temp_on:temp_off).CV2]);
           else
              CV2_temp_D(i_temp).var=0;
           end
           temp_on=temp_off+1;
        else
           CV2_temp_D(i_temp).mean=0;
           CV2_temp_D(i_temp).var=0;
           CV2_temp_D(i_temp).number=0;
        end        
    end   
    
    [~,index] = sortrows([file_hist(i).hist_info_T.CV2_mean_bsl.t_on].'); 
    file_hist(i).hist_info_T.CV2_mean_bsl = file_hist(i).hist_info_T.CV2_mean_bsl(index);
    clear index
    [~,index] = sortrows([file_hist(i).hist_info_T.CV2_mean_test.t_on].'); 
    file_hist(i).hist_info_T.CV2_mean_test = file_hist(i).hist_info_T.CV2_mean_test(index);    
    clear index    
    CV2_temp_T=struct('mean',[],'var',[],'number',[]);
    i_temp=0;
    temp_on=1;
    for m=1:20
        i_temp=i_temp+1;
        if file_hist(i).hist_info_T.CV2_mean_bsl(temp_on).t_on<-500+25*m
           temp_off=find([file_hist(i).hist_info_T.CV2_mean_bsl.t_on]<-500+25*m,1,'last');
           CV2_temp_T(i_temp).number=temp_off-temp_on+1;
           CV2_temp_T(i_temp).mean=mean([file_hist(i).hist_info_T.CV2_mean_bsl(temp_on:temp_off).CV2]);
           if temp_off-temp_on>=1
              CV2_temp_T(i_temp).var=var([file_hist(i).hist_info_T.CV2_mean_bsl(temp_on:temp_off).CV2]); 
           else
              CV2_temp_T(i_temp).var=0;
           end
           temp_on=temp_off+1;
        else
           CV2_temp_T(i_temp).mean=0;
           CV2_temp_T(i_temp).var=0;
           CV2_temp_T(i_temp).number=0;
        end
    end
    temp_on=1;
    for m=1:20
        i_temp=i_temp+1;
        if temp_on<=size(file_hist(i).hist_info_T.CV2_mean_test,2) && file_hist(i).hist_info_T.CV2_mean_test(temp_on).t_on<25*m
           temp_off=find([file_hist(i).hist_info_T.CV2_mean_test.t_on]<25*m,1,'last');
           CV2_temp_T(i_temp).number=temp_off-temp_on+1;
           CV2_temp_T(i_temp).mean=mean([file_hist(i).hist_info_T.CV2_mean_test(temp_on:temp_off).CV2]);
           if temp_off-temp_on>=1
              CV2_temp_T(i_temp).var=var([file_hist(i).hist_info_T.CV2_mean_test(temp_on:temp_off).CV2]);
           else
               CV2_temp_T(i_temp).var=0;
           end
           temp_on=temp_off+1;
        else
           CV2_temp_T(i_temp).mean=0;
           CV2_temp_T(i_temp).var=0;
           CV2_temp_T(i_temp).number=0;
        end        
    end 
    cohend=zeros(30,2);
    for m=1:30
        cohend(m,1)=-512.5+m*25;
        cohend(m,2)=CV2_temp_T(m).mean-CV2_temp_D(m).mean;
        if CV2_temp_T(m).number+CV2_temp_D(m).number-2>0
           cohend(m,3)=sqrt(((CV2_temp_T(m).number-1)*CV2_temp_T(m).var+(CV2_temp_D(m).number-1)*CV2_temp_D(m).var)/(CV2_temp_T(m).number+CV2_temp_D(m).number-2));
           cohend(m,4)=cohend(m,2)/cohend(m,3);
        else
           cohend(m,3)=0;
           cohend(m,4)=0;
        end       
    end
    plot(cohend(:,1),cohend(:,4),'k-')
    hold on
    line([0 0],[-1.5,1.5],'LineStyle','--','Color',[0 1 0]);
    line([-500 250],[0 0],'LineStyle','-','Color',[0.5 0.5 0.5]);
    xlim([-500 250]);
    ylim([-1.5 1.5]);
    xticks(-500:250:250);
    yticks(-1.5:0.5:1.5);
    xlabel('Time (ms)');
    ylabel('|CV2| Cohens d'); 
    
    cohensd_list(i).Delay_info=CV2_temp_D;
    cohensd_list(i).Trace_info=CV2_temp_T;
    cohensd_list(i).cohensd=cohend;
    
    saveas(gcf,[['DT cell-' num2str(file_CV2(i).cell_ID)] '.jpg']);  
    close all    
end