j=0;
figure;

for i=1:size(ttt_PC,2)
    
    if ttt_PC(i).Pf < 0.05
       plot (ttt_PC(i).ttt(:,3),ttt_PC(i).ttt(:,5),'r-')
       hold on
       if ttt_PC(i).mod_f > 0
          plot (ttt_PC(i).ttt(:,3),ttt_PC(i).ttt(:,5),'r.','MarkerSize',15)
          hold on
       end
    else
       plot (ttt_PC(i).ttt(:,3),ttt_PC(i).ttt(:,5),'Color',[1 0.75 0.75],'LineStyle','-')
       hold on
       if ttt_PC(i).mod_f > 0
          plot (ttt_PC(i).ttt(:,3),ttt_PC(i).ttt(:,5),'Color',[1 0.75 0.75],'marker','.','MarkerSize',15)
          hold on
       end
    end

end

xlim([0 250]);
ylim([0 50]);
xticks(0:50:250);
yticks(0:10:50);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');

figure;

for i=1:size(ttt_PC,2)
    if ttt_PC(i).Ps < 0.05
       plot (-ttt_PC(i).ttt(:,4),ttt_PC(i).ttt(:,6),'b-')
       hold on
       if ttt_PC(i).mod_s > 0
          plot (ttt_PC(i).ttt(:,3),ttt_PC(i).ttt(:,5),'b.','MarkerSize',15)
          hold on
       end
    else
       plot (-ttt_PC(i).ttt(:,4),ttt_PC(i).ttt(:,6),'Color',[0.75 0.75 1],'LineStyle','-')
       hold on
       if ttt_PC(i).mod_s > 0
          plot (ttt_PC(i).ttt(:,3),ttt_PC(i).ttt(:,5),'Color',[0.75 0.75 1],'marker','.','MarkerSize',15)
          hold on
       end
    end
end

xlim([10 100]);
ylim([0 50]);
xticks(10:10:100);
yticks(0:10:50);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');