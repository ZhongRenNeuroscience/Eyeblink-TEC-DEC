cps_frq=struct('cell_ID',[],'bsl_frq',[],'CR_frq',[],'CR_ratio',[]);
j=1;
for i=1:size(list_PC,2)
    if isempty(list_PC(i).CR_fac_cps)
        continue
    end
     
    cps_frq(j).cell_ID=list_PC(i).cell_ID;
    cps_frq(j).bsl_frq=list_PC(i).all_info_cps.sss_all.psth.CR_trial.bsl_frq;
    cps_frq(j).CR_frq=list_PC(i).all_info_cps.sss_all.psth.CR_trial.test_frq;
    cps_frq(j).CR_ratio=(cps_frq(j).CR_frq/cps_frq(j).bsl_frq)*100-100;
    
    j=j+1;
    
end