% mPFC modulation detection

%%% To be continued with DTTD PSTH comparison

file=trace_list_mPFC_ready;
PFC_mod_list_T=struct('cell_ID',[],'file_name',[],'cell_num',[],'channel_info',[],'CR_trial_T',[],'nonCR_trial_T',[],'probe_trial_T',[],'test_result_T',[],'mod_type_T',[],'mod_info_T',[]);
% PFC_mod_list_D=struct('cell_ID',[],'file_name',[],'cell_num',[],'channel_info',[],'CR_trial_D',[],'nonCR_trial_D',[],'probe_trial_D',[],'test_result_D',[],'mod_type_D',[],'mod_info_D',[]);
% PFC_mod_list_TD=struct('cell_ID',[],'file_name',[],'channel_info',[],'CR_trial_T',[],'nonCR_trial_T',[],'probe_trial_T',[],'test_result_T',[],'mod_type_T',[],...
%       'CR_trial_D',[],'nonCR_trial_D',[],'probe_trial_D',[],'test_result_D',[],'mod_type_D',[],'mod_info_D',[],'test_result_DTTD',[]);
t_pre=500;
bin_size=100;
step=50;

% add_back_neuron_D=[25 43];

for i=1:size(file,2)
    PFC_mod_list_T(i).cell_ID=file(i).cell_ID;
    PFC_mod_list_T(i).file_name=file(i).file_name;
    PFC_mod_list_T(i).cell_num=file(i).cell_num;
% %     PFC_mod_list(i).channel_info=file(i).channel_info;
%     
    all_info='all_info';
    align_info='align_info';
    t_post=500;
    t_afterUS=500;
    t_psth=1000;
    CR_trial_list=struct('trial_num',[],'bsl_all',[],'CR_epoch_all',[],'CR_epoch_250',[],'CR_epoch_500',[],'ifr_pkt',[],'ifr_amp',[],'UR_epoch_all',[],'bin_data',[]);
    nonCR_trial_list=struct('trial_num',[],'bsl_all',[],'CR_epoch_all',[],'CR_epoch_250',[],'CR_epoch_500',[],'ifr_pkt',[],'ifr_amp',[],'UR_epoch_all',[],'bin_data',[]);
    probe_trial_list=struct('trial_num',[],'bsl_all',[],'CR_epoch_all',[],'CR_epoch_250',[],'CR_epoch_500',[],'ifr_pkt',[],'ifr_amp',[],'UR_epoch_all',[],'bin_data',[]);
    mod_info=struct('mod_pkt',[],'mod_amp',[],'hww',[],'hww_1',[],'hww_2',[],'hww_amp',[]);
    
    if ~isempty(file(i).(all_info).ttt.CR_trial(1).trial_num)
        for j=1:size(file(i).(all_info).ttt.CR_trial,2)
            CR_trial_list(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
            CR_trial_list(j).bsl_all=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<0))/t_pre*1000;
            CR_trial_list(j).CR_epoch_all=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<t_post/1000))/t_post*1000;
            CR_trial_list(j).CR_epoch_250=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<0.25))/250*1000;
            CR_trial_list(j).CR_epoch_500=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=0.25 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<0.5))/250*1000;
            CR_trial_list(j).UR_epoch_all=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=t_post/1000 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<t_psth/1000))/t_afterUS*1000;
            t_ifr_start=find(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,1)==0,1,'first');
            [ifr_pk,ifr_pkt]=max(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+t_post-1,4));
            if ifr_pk>0
               CR_trial_list(j).ifr_amp=ifr_pk;
               CR_trial_list(j).ifr_pkt=ifr_pkt-1;
            else
               CR_trial_list(j).ifr_amp=[];
               CR_trial_list(j).ifr_pkt=[];          
            end
            bin_data=struct('t',[],'frq',[]);
            for k=1:(t_psth+t_pre)/step-1
                t_1=-t_pre+(k-1)*step;
                t_2=-t_pre+(k-1)*step+bin_size;
                bin_data(k).t=(t_1+t_2)/2;
                bin_data(k).frq=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<t_2/1000))/bin_size*1000;                                                
            end
            CR_trial_list(j).bin_data=bin_data;
        end
    end
    PFC_mod_list_T(i).CR_trial_T=CR_trial_list;
    
    if ~isempty(file(i).(all_info).ttt.nonCR_trial(1).trial_num)
        for j=1:size(file(i).(all_info).ttt.nonCR_trial,2)
            nonCR_trial_list(j).trial_num=file(i).(all_info).ttt.nonCR_trial(j).trial_num;
            nonCR_trial_list(j).bsl_all=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<0))/t_pre*1000;
            nonCR_trial_list(j).CR_epoch_all=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<t_post/1000))/t_post*1000;
            nonCR_trial_list(j).CR_epoch_250=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<0.25))/250*1000;
            nonCR_trial_list(j).CR_epoch_500=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=0.25 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<0.5))/250*1000;
            nonCR_trial_list(j).UR_epoch_all=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=t_post/1000 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<t_psth/1000))/t_afterUS*1000;
            t_ifr_start=find(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1)==0,1,'first');
            [ifr_pk,ifr_pkt]=max(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+t_post-1,4));
            if ifr_pk>0
               nonCR_trial_list(j).ifr_amp=ifr_pk;
               nonCR_trial_list(j).ifr_pkt=ifr_pkt-1;
            else
               nonCR_trial_list(j).ifr_amp=[];
               nonCR_trial_list(j).ifr_pkt=[];          
            end
            bin_data=struct('t',[],'frq',[]);
            for k=1:(t_psth+t_pre)/step-1
                t_1=-t_pre+(k-1)*step;
                t_2=-t_pre+(k-1)*step+bin_size;
                bin_data(k).t=(t_1+t_2)/2;
                bin_data(k).frq=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<t_2/1000))/bin_size*1000;                                                
            end
            nonCR_trial_list(j).bin_data=bin_data;
        end
    end    
    PFC_mod_list_T(i).nonCR_trial_T=nonCR_trial_list;
    
    if ~isempty(file(i).(all_info).ttt.probe_trial(1).trial_num)
        for j=1:size(file(i).(all_info).ttt.probe_trial,2)
            probe_trial_list(j).trial_num=file(i).(all_info).ttt.probe_trial(j).trial_num;
            probe_trial_list(j).bsl_all=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0))/t_pre*1000;
            probe_trial_list(j).CR_epoch_all=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<t_post/1000))/t_post*1000;
            probe_trial_list(j).CR_epoch_250=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0.25))/250*1000;
            probe_trial_list(j).CR_epoch_500=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=0.25 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0.5))/250*1000;
            probe_trial_list(j).UR_epoch_all=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=t_post/1000 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<t_psth/1000))/t_afterUS*1000;
            t_ifr_start=find(file(i).(all_info).ttt.probe_trial(j).ifr_smooth(:,1)==0,1,'first');
            [ifr_pk,ifr_pkt]=max(file(i).(all_info).ttt.probe_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+t_post-1,4));
            if ifr_pk>0
               probe_trial_list(j).ifr_amp=ifr_pk;
               probe_trial_list(j).ifr_pkt=ifr_pkt-1;
            else
               probe_trial_list(j).ifr_amp=[];
               probe_trial_list(j).ifr_pkt=[];          
            end
            bin_data=struct('t',[],'frq',[]);
            for k=1:(t_psth+t_pre)/step-1
                t_1=-t_pre+(k-1)*step;
                t_2=-t_pre+(k-1)*step+bin_size;
                bin_data(k).t=(t_1+t_2)/2;
                bin_data(k).frq=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<t_2/1000))/bin_size*1000;                                                
            end
            probe_trial_list(j).bin_data=bin_data;
        end
    end    
    PFC_mod_list_T(i).probe_trial_T=probe_trial_list;    
    
    test_result=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
    CR_trial_test=struct('p_bsl_CR',[],'p_bsl_UR',[],'p_CR_UR',[],'mod_time_info',[]);
    nonCR_trial_test=struct('p_bsl_CR',[],'p_bsl_UR',[],'p_CR_UR',[],'mod_time_info',[]);
    probe_trial_test=struct('p_bsl_CR',[],'p_bsl_UR',[],'p_CR_UR',[],'mod_time_info',[]);
    
    CR_trial_test.p_bsl_CR=signrank([CR_trial_list.bsl_all],[CR_trial_list.CR_epoch_all]);
    CR_trial_test.p_bsl_UR=signrank([CR_trial_list.bsl_all],[CR_trial_list.UR_epoch_all]);
    CR_trial_test.p_CR_UR=signrank([CR_trial_list.CR_epoch_all],[CR_trial_list.UR_epoch_all]);
    if CR_trial_test.p_bsl_CR<0.05
       mean_bsl=mean([CR_trial_list.bsl_all]);
       mean_CR=mean([CR_trial_list.CR_epoch_all]); 
       if mean_CR>mean_bsl
          PFC_mod_list_T(i).mod_type_T=1;
          t_start=find(file(i).(align_info).psth_ex(:,1)==0);
          [mod_amp,mod_pkt]=max(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2));
          mod_info.mod_amp=mod_amp/file(i).(align_info).bsl_frq_ex*100;
          mod_info.mod_pkt=mod_pkt-1;
          mod_info.hw_amp=(mod_amp+file(i).(align_info).bsl_frq_ex)/2;
          mod_info.hww_1=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)>=mod_info.hw_amp,1,'first');
          if file(i).(align_info).psth_ex(t_start+t_post-1,2)>=mod_info.hw_amp
             mod_info.hww_2=t_post;
          else
             mod_info.hww_2=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)>=mod_info.hw_amp,1,'last');
          end      
          mod_info.hww=mod_info.hww_2-mod_info.hww_1-1;
       elseif mean_CR<mean_bsl
          PFC_mod_list_T(i).mod_type_T=2; 
          t_start=find(file(i).(align_info).psth_ex(:,1)==0);
          [mod_amp,mod_pkt]=min(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2));
          mod_info.mod_amp=mod_amp/file(i).(align_info).bsl_frq_ex*100;
          mod_info.mod_pkt=mod_pkt-1;
          mod_info.hw_amp=(mod_amp+file(i).(align_info).bsl_frq_ex)/2;
          mod_info.hww_1=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)<=mod_info.hw_amp,1,'first');
          if file(i).(align_info).psth_ex(t_start+t_post-1,2)<=mod_info.hw_amp
             mod_info.hww_2=t_post;
          else
             mod_info.hww_2=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)<=mod_info.hw_amp,1,'last');
          end      
          mod_info.hww=mod_info.hww_2-mod_info.hww_1-1;
       end
    else
       PFC_mod_list_T(i).mod_type_T=0; 
       mod_info.mod_amp=[];
       mod_info.mod_pkt=[];
       mod_info.mod_hww=[];
       mod_info.hw_amp=[];
       mod_info.hww_1=[];
       mod_info.hww_2=[];
    end 
    PFC_mod_list_T(i).mod_info_T=mod_info;
 
    mod_time_info=struct('t',[],'type',[],'p',[]);
    sig_idx=0;
    for k=1:size(CR_trial_list(1).bin_data,2)
        mod_time_org=struct('frq',[]);
        t_real=CR_trial_list(1).bin_data(k).t;
        for j=1:size(file(i).(all_info).ttt.CR_trial,2)
            mod_time_org(j).frq=CR_trial_list(j).bin_data(k).frq;
        end
        p_value_t=ranksum([CR_trial_list.bsl_all],[mod_time_org.frq]);
        if p_value_t<0.05
           sig_idx=sig_idx+1;
           mod_time_info(sig_idx).t=t_real;
           mod_time_info(sig_idx).p=p_value_t;
           mean_bsl=mean([CR_trial_list.bsl_all]);
           mean_time=mean([mod_time_org.frq]);            
           if mean_time>mean_bsl
              mod_time_info(sig_idx).type=1;
        elseif mean_time<mean_bsl
              mod_time_info(sig_idx).type=2;
           end                      
        end
    end
    CR_trial_test.mod_time_info=mod_time_info;
    test_result.CR_trial=CR_trial_test;
    
    nonCR_trial_test.p_bsl_CR=ranksum([nonCR_trial_list.bsl_all],[nonCR_trial_list.CR_epoch_all]);
    nonCR_trial_test.p_bsl_UR=ranksum([nonCR_trial_list.bsl_all],[nonCR_trial_list.UR_epoch_all]);
    nonCR_trial_test.p_CR_UR=ranksum([nonCR_trial_list.CR_epoch_all],[nonCR_trial_list.UR_epoch_all]);  
    mod_time_info=struct('t',[],'type',[],'p',[]);
    sig_idx=0;
    for k=1:size(nonCR_trial_list(1).bin_data,2)
        mod_time_org=struct('frq',[]);
        t_real=nonCR_trial_list(1).bin_data(k).t;
        for j=1:size(file(i).(all_info).ttt.nonCR_trial,2)
            mod_time_org(j).frq=nonCR_trial_list(j).bin_data(k).frq;
        end
        p_value_t=ranksum([nonCR_trial_list.bsl_all],[mod_time_org.frq]);
        if p_value_t<0.05
           sig_idx=sig_idx+1;
           mod_time_info(sig_idx).t=t_real;
           mod_time_info(sig_idx).p=p_value_t;
           mean_bsl=mean([nonCR_trial_list.bsl_all]);
           mean_time=mean([mod_time_org.frq]);            
           if mean_time>mean_bsl
              mod_time_info(sig_idx).type=1;
           elseif mean_time<mean_bsl
              mod_time_info(sig_idx).type=2;
           end                      
        end
    end    
    nonCR_trial_test.mod_time_info=mod_time_info;
    test_result.nonCR_trial=nonCR_trial_test;

    probe_trial_test.p_bsl_CR=ranksum([probe_trial_list.bsl_all],[probe_trial_list.CR_epoch_all]);
    probe_trial_test.p_bsl_UR=ranksum([probe_trial_list.bsl_all],[probe_trial_list.UR_epoch_all]);
    probe_trial_test.p_CR_UR=ranksum([probe_trial_list.CR_epoch_all],[probe_trial_list.UR_epoch_all]);  
    mod_time_info=struct('t',[],'type',[],'p',[]);
    sig_idx=0;
    for k=1:size(probe_trial_list(1).bin_data,2)
        mod_time_org=struct('frq',[]);
        t_real=probe_trial_list(1).bin_data(k).t;
        for j=1:size(file(i).(all_info).ttt.probe_trial,2)
            mod_time_org(j).frq=probe_trial_list(j).bin_data(k).frq;
        end
        p_value_t=ranksum([probe_trial_list.bsl_all],[mod_time_org.frq]);
        if p_value_t<0.05
           sig_idx=sig_idx+1;
           mod_time_info(sig_idx).t=t_real;
           mod_time_info(sig_idx).p=p_value_t;
           mean_bsl=mean([probe_trial_list.bsl_all]);
           mean_time=mean([mod_time_org.frq]);            
           if mean_time>mean_bsl
              mod_time_info(sig_idx).type=1;
           elseif mean_time<mean_bsl
              mod_time_info(sig_idx).type=2;
           end                      
        end
    end    
    probe_trial_test.mod_time_info=mod_time_info;
    test_result.probe_trial=probe_trial_test;
    
    PFC_mod_list_T(i).test_result_T=test_result;    

    
%     all_info='all_info_D';
%     align_info='align_info_D';
%     t_post=250;
%     t_afterUS=500;
%     t_psth=1000;
%     CR_trial_list=struct('trial_num',[],'bsl_all',[],'CR_epoch_all',[],'CR_epoch_250',[],'CR_epoch_500',[],'UR_epoch_all',[],'bin_data',[]);
%     nonCR_trial_list=struct('trial_num',[],'bsl_all',[],'CR_epoch_all',[],'CR_epoch_250',[],'CR_epoch_500',[],'UR_epoch_all',[],'bin_data',[]);
%     probe_trial_list=struct('trial_num',[],'bsl_all',[],'CR_epoch_all',[],'CR_epoch_250',[],'CR_epoch_500',[],'UR_epoch_all',[],'bin_data',[]);
%     mod_info=struct('mod_pkt',[],'mod_amp',[],'hww',[],'hww_1',[],'hww_2',[],'hww_amp',[]);
% 
%     if ~isempty(file(i).(all_info).ttt.CR_trial(1).trial_num)
%         for j=1:size(file(i).(all_info).ttt.CR_trial,2)
%             CR_trial_list(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
%             CR_trial_list(j).bsl_all=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<0))/t_pre*1000;
%             CR_trial_list(j).CR_epoch_all=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<t_post/1000))/t_post*1000;
%             CR_trial_list(j).CR_epoch_250=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<0.25))/250*1000;
%             CR_trial_list(j).CR_epoch_500=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=0.25 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<0.5))/250*1000;
%             CR_trial_list(j).UR_epoch_all=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=t_post/1000 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<t_psth/1000))/t_afterUS*1000;
%             t_ifr_start=find(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,1)==0,1,'first');
%             [ifr_pk,ifr_pkt]=max(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+t_post-1,4));
%             if ifr_pk>0
%                CR_trial_list(j).ifr_amp=ifr_pk;
%                CR_trial_list(j).ifr_pkt=ifr_pkt-1;
%             else
%                CR_trial_list(j).ifr_amp=[];
%                CR_trial_list(j).ifr_pkt=[];          
%             end
%             bin_data=struct('t',[],'frq',[]);
%             for k=1:(t_psth+t_pre)/step-1
%                 t_1=-t_pre+(k-1)*step;
%                 t_2=-t_pre+(k-1)*step+bin_size;
%                 bin_data(k).t=(t_1+t_2)/2;
%                 bin_data(k).frq=length(find([file(i).(all_info).ttt.CR_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info).ttt.CR_trial(j).spk_time]<t_2/1000))/bin_size*1000;                                                
%             end
%             CR_trial_list(j).bin_data=bin_data;
%         end
%     end
%     PFC_mod_list_T(i).CR_trial_D=CR_trial_list;
%     
%     if ~isempty(file(i).(all_info).ttt.nonCR_trial(1).trial_num)
%         for j=1:size(file(i).(all_info).ttt.nonCR_trial,2)
%             nonCR_trial_list(j).trial_num=file(i).(all_info).ttt.nonCR_trial(j).trial_num;
%             nonCR_trial_list(j).bsl_all=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<0))/t_pre*1000;
%             nonCR_trial_list(j).CR_epoch_all=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<t_post/1000))/t_post*1000;
%             nonCR_trial_list(j).CR_epoch_250=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<0.25))/250*1000;
%             nonCR_trial_list(j).CR_epoch_500=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=0.25 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<0.5))/250*1000;
%             nonCR_trial_list(j).UR_epoch_all=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=t_post/1000 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<t_psth/1000))/t_afterUS*1000;
%             t_ifr_start=find(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1)==0,1,'first');
%             [ifr_pk,ifr_pkt]=max(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+t_post-1,4));
%             if ifr_pk>0
%                nonCR_trial_list(j).ifr_amp=ifr_pk;
%                nonCR_trial_list(j).ifr_pkt=ifr_pkt-1;
%             else
%                nonCR_trial_list(j).ifr_amp=[];
%                nonCR_trial_list(j).ifr_pkt=[];          
%             end
%             bin_data=struct('t',[],'frq',[]);
%             for k=1:(t_psth+t_pre)/step-1
%                 t_1=-t_pre+(k-1)*step;
%                 t_2=-t_pre+(k-1)*step+bin_size;
%                 bin_data(k).t=(t_1+t_2)/2;
%                 bin_data(k).frq=length(find([file(i).(all_info).ttt.nonCR_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info).ttt.nonCR_trial(j).spk_time]<t_2/1000))/bin_size*1000;                                                
%             end
%             nonCR_trial_list(j).bin_data=bin_data;
%         end
%     end    
%     PFC_mod_list_T(i).nonCR_trial_D=nonCR_trial_list;
%     
%     if ~isempty(file(i).(all_info).ttt.probe_trial(1).trial_num)
%         for j=1:size(file(i).(all_info).ttt.probe_trial,2)
%             probe_trial_list(j).trial_num=file(i).(all_info).ttt.probe_trial(j).trial_num;
%             probe_trial_list(j).bsl_all=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0))/t_pre*1000;
%             probe_trial_list(j).CR_epoch_all=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0.5))/500*1000;
%             probe_trial_list(j).CR_epoch_250=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=0 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0.25))/250*1000;
%             probe_trial_list(j).CR_epoch_500=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=0.25 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<0.5))/250*1000;
%             probe_trial_list(j).UR_epoch_all=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=t_post/1000 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<t_psth/1000))/t_afterUS*1000;
%             t_ifr_start=find(file(i).(all_info).ttt.probe_trial(j).ifr_smooth(:,1)==0,1,'first');
%             [ifr_pk,ifr_pkt]=max(file(i).(all_info).ttt.probe_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+t_post-1,4));
%             if ifr_pk>0
%                probe_trial_list(j).ifr_amp=ifr_pk;
%                probe_trial_list(j).ifr_pkt=ifr_pkt-1;
%             else
%                probe_trial_list(j).ifr_amp=[];
%                probe_trial_list(j).ifr_pkt=[];          
%             end
%             bin_data=struct('t',[],'frq',[]);
%             for k=1:(t_psth+t_pre)/step-1
%                 t_1=-t_pre+(k-1)*step;
%                 t_2=-t_pre+(k-1)*step+bin_size;
%                 bin_data(k).t=(t_1+t_2)/2;
%                 bin_data(k).frq=length(find([file(i).(all_info).ttt.probe_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info).ttt.probe_trial(j).spk_time]<t_2/1000))/bin_size*1000;                                                
%             end
%             probe_trial_list(j).bin_data=bin_data;
%         end
%     end    
%     PFC_mod_list_T(i).probe_trial_D=probe_trial_list;    
%     
%     test_result=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
%     CR_trial_test=struct('p_bsl_CR',[],'p_bsl_UR',[],'p_CR_UR',[],'mod_time_info',[]);
%     nonCR_trial_test=struct('p_bsl_CR',[],'p_bsl_UR',[],'p_CR_UR',[],'mod_time_info',[]);
%     probe_trial_test=struct('p_bsl_CR',[],'p_bsl_UR',[],'p_CR_UR',[],'mod_time_info',[]);
%     
%     CR_trial_test.p_bsl_CR=signrank([CR_trial_list.bsl_all],[CR_trial_list.CR_epoch_all]);
%     CR_trial_test.p_bsl_UR=signrank([CR_trial_list.bsl_all],[CR_trial_list.UR_epoch_all]);
%     CR_trial_test.p_CR_UR=signrank([CR_trial_list.CR_epoch_all],[CR_trial_list.UR_epoch_all]);
%     if CR_trial_test.p_bsl_CR<0.05 %|| any(add_back_neuron_D == i)
%        mean_bsl=mean([CR_trial_list.bsl_all]);
%        mean_CR=mean([CR_trial_list.CR_epoch_all]); 
%        if mean_CR>mean_bsl
%           PFC_mod_list_T(i).mod_type_D=1;
%           t_start=find(file(i).(align_info).psth_ex(:,1)==0);
%           [mod_amp,mod_pkt]=max(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2));
%           mod_info.mod_amp=mod_amp/file(i).(align_info).bsl_frq_ex*100;
%           mod_info.mod_pkt=mod_pkt-1;
%           mod_info.hw_amp=(mod_amp+file(i).(align_info).bsl_frq_ex)/2;
%           mod_info.hww_1=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)>=mod_info.hw_amp,1,'first');
%           if file(i).(align_info).psth_ex(t_start+t_post-1,2)>=mod_info.hw_amp
%              mod_info.hww_2=t_post;
%           else
%              mod_info.hww_2=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)>=mod_info.hw_amp,1,'last');
%           end      
%           mod_info.hww=mod_info.hww_2-mod_info.hww_1-1;
%        elseif mean_CR<mean_bsl
%           PFC_mod_list_T(i).mod_type_D=2; 
%           t_start=find(file(i).(align_info).psth_ex(:,1)==0);
%           [mod_amp,mod_pkt]=min(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2));
%           mod_info.mod_amp=mod_amp/file(i).(align_info).bsl_frq_ex*100;
%           mod_info.mod_pkt=mod_pkt-1;
%           mod_info.hw_amp=(mod_amp+file(i).(align_info).bsl_frq_ex)/2;
%           mod_info.hww_1=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)<=mod_info.hw_amp,1,'first');
%           if file(i).(align_info).psth_ex(t_start+t_post-1,2)<=mod_info.hw_amp
%              mod_info.hww_2=t_post;
%           else
%              mod_info.hww_2=find(file(i).(align_info).psth_ex(t_start:t_start+t_post-1,2)<=mod_info.hw_amp,1,'last');
%           end      
%           mod_info.hww=mod_info.hww_2-mod_info.hww_1-1;
%        end
%     else
%        PFC_mod_list_T(i).mod_type_D=0; 
%        mod_info.mod_amp=[];
%        mod_info.mod_pkt=[];
%        mod_info.mod_hww=[];
%        mod_info.hw_amp=[];
%        mod_info.hww_1=[];
%        mod_info.hww_2=[];
%     end 
%     PFC_mod_list_T(i).mod_info_D=mod_info;
% 
%     mod_time_info=struct('t',[],'type',[],'p',[]);
%     sig_idx=0;
%     for k=1:size(CR_trial_list(1).bin_data,2)
%         mod_time_org=struct('frq',[]);
%         t_real=CR_trial_list(1).bin_data(k).t;
%         for j=1:size(file(i).(all_info).ttt.CR_trial,2)
%             mod_time_org(j).frq=CR_trial_list(j).bin_data(k).frq;
%         end
%         p_value_t=ranksum([CR_trial_list.bsl_all],[mod_time_org.frq]);
%         if p_value_t<0.05
%            sig_idx=sig_idx+1;
%            mod_time_info(sig_idx).t=t_real;
%            mod_time_info(sig_idx).p=p_value_t;
%            mean_bsl=mean([CR_trial_list.bsl_all]);
%            mean_time=mean([mod_time_org.frq]);            
%            if mean_time>mean_bsl
%               mod_time_info(sig_idx).type=1;
%            elseif mean_time<mean_bsl
%               mod_time_info(sig_idx).type=2;
%            end                      
%         end
%     end
%     CR_trial_test.mod_time_info=mod_time_info;
%     test_result.CR_trial=CR_trial_test;
%     
%     nonCR_trial_test.p_bsl_CR=ranksum([nonCR_trial_list.bsl_all],[nonCR_trial_list.CR_epoch_all]);
%     nonCR_trial_test.p_bsl_UR=ranksum([nonCR_trial_list.bsl_all],[nonCR_trial_list.UR_epoch_all]);
%     nonCR_trial_test.p_CR_UR=ranksum([nonCR_trial_list.CR_epoch_all],[nonCR_trial_list.UR_epoch_all]);  
%     mod_time_info=struct('t',[],'type',[],'p',[]);
%     sig_idx=0;
%     for k=1:size(nonCR_trial_list(1).bin_data,2)
%         mod_time_org=struct('frq',[]);
%         t_real=nonCR_trial_list(1).bin_data(k).t;
%         for j=1:size(file(i).(all_info).ttt.nonCR_trial,2)
%             mod_time_org(j).frq=nonCR_trial_list(j).bin_data(k).frq;
%         end
%         p_value_t=ranksum([nonCR_trial_list.bsl_all],[mod_time_org.frq]);
%         if p_value_t<0.05
%            sig_idx=sig_idx+1;
%            mod_time_info(sig_idx).t=t_real;
%            mod_time_info(sig_idx).p=p_value_t;
%            mean_bsl=mean([nonCR_trial_list.bsl_all]);
%            mean_time=mean([mod_time_org.frq]);            
%            if mean_time>mean_bsl
%               mod_time_info(sig_idx).type=1;
%            elseif mean_time<mean_bsl
%               mod_time_info(sig_idx).type=2;
%            end                      
%         end
%     end    
%     nonCR_trial_test.mod_time_info=mod_time_info;
%     test_result.nonCR_trial=nonCR_trial_test;
% 
%     probe_trial_test.p_bsl_CR=ranksum([probe_trial_list.bsl_all],[probe_trial_list.CR_epoch_all]);
%     probe_trial_test.p_bsl_UR=ranksum([probe_trial_list.bsl_all],[probe_trial_list.UR_epoch_all]);
%     probe_trial_test.p_CR_UR=ranksum([probe_trial_list.CR_epoch_all],[probe_trial_list.UR_epoch_all]);  
%     mod_time_info=struct('t',[],'type',[],'p',[]);
%     sig_idx=0;
%     for k=1:size(probe_trial_list(1).bin_data,2)
%         mod_time_org=struct('frq',[]);
%         t_real=probe_trial_list(1).bin_data(k).t;
%         for j=1:size(file(i).(all_info).ttt.probe_trial,2)
%             mod_time_org(j).frq=probe_trial_list(j).bin_data(k).frq;
%         end
%         p_value_t=ranksum([probe_trial_list.bsl_all],[mod_time_org.frq]);
%         if p_value_t<0.05
%            sig_idx=sig_idx+1;
%            mod_time_info(sig_idx).t=t_real;
%            mod_time_info(sig_idx).p=p_value_t;
%            mean_bsl=mean([probe_trial_list.bsl_all]);
%            mean_time=mean([mod_time_org.frq]);            
%            if mean_time>mean_bsl
%               mod_time_info(sig_idx).type=1;
%            elseif mean_time<mean_bsl
%               mod_time_info(sig_idx).type=2;
%            end                      
%         end
%     end    
%     probe_trial_test.mod_time_info=mod_time_info;
%     test_result.probe_trial=probe_trial_test;
%     
%     PFC_mod_list_T(i).test_result_D=test_result;
      
end

% PFC_fac_list_T=struct('cell_ID',[],'mod_pkt',[],'mod_amp',[],'hww',[],'hww_1',[],'hww_2',[],'hw_amp',[]);
% mod_type='mod_type_T';
% mod_info='mod_info_T';
% fac_idx=0;
% 
% for i=1:size(PFC_mod_list,2)
%     if PFC_mod_list(i).(mod_type)==1
%        fac_idx=fac_idx+1;
%        PFC_fac_list_T(fac_idx).cell_ID=PFC_mod_list(i).cell_ID;
%        PFC_fac_list_T(fac_idx).mod_pkt=PFC_mod_list(i).(mod_info).mod_pkt;
%        PFC_fac_list_T(fac_idx).mod_amp=PFC_mod_list(i).(mod_info).mod_amp;
%        PFC_fac_list_T(fac_idx).hww=PFC_mod_list(i).(mod_info).hww;
%        PFC_fac_list_T(fac_idx).hww_1=PFC_mod_list(i).(mod_info).hww_1;
%        PFC_fac_list_T(fac_idx).hww_2=PFC_mod_list(i).(mod_info).hww_2;
%        PFC_fac_list_T(fac_idx).hw_amp=PFC_mod_list(i).(mod_info).hw_amp;
%     end
% end

