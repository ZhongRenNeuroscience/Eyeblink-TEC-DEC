trial_mod_list=trial_mod_list_DT;
corr_info_1='fac_corr_info_D';
corr_info_2='fac_corr_info_T';
cell_type_1='CR_fac_D';
cell_type_2='CR_fac_T';
R_type='R_pkt';
P_type='P_pkt';

RP_list=struct('cell_ID',[],'R_1',[],'R_2',[],'P_1',[],'P_2',[]);
cell_idx=0;
for i=1:size(trial_mod_list,2)
    if trial_mod_list(i).(cell_type_1)==1 && trial_mod_list(i).(cell_type_2)==1
       cell_idx=cell_idx+1;
       RP_list(cell_idx).cell_ID=trial_mod_list(i).cell_ID;
       RP_list(cell_idx).R_1=trial_mod_list(i).(corr_info_1).(R_type);
       RP_list(cell_idx).P_1=-log10(trial_mod_list(i).(corr_info_1).(P_type));
       RP_list(cell_idx).R_2=trial_mod_list(i).(corr_info_2).(R_type);
       RP_list(cell_idx).P_2=-log10(trial_mod_list(i).(corr_info_2).(P_type));    
    end
    
end

