% plot heat map

path=list_PC;
cell=4;

amp=zeros(size(path(cell).all_info_sps.ttt.CR_trial,2),1);
for i=1:size(path(cell).all_info_sps.ttt.CR_trial,2)
%     amp(i,1)=path(cell).all_info.ttt.CR_trial(i).blk_info.CR_amp*100;
    amp(i,1)=max(path(cell).all_info_sps.ttt.CR_trial(i).ifr_smooth(541:1041,3));
end

[~,idx]=sort(amp);

ifr=zeros(length(amp),501);
blk=zeros(length(amp),501);
for j=1:length(amp)
    k=idx(j);
    ifr(j,:)=path(cell).all_info_sps.ttt.CR_trial(k).ifr_smooth(541:1041,3)';
    blk(j,:)=path(cell).all_info_sps.ttt.CR_trial(k).blk_smth(551:1051,2)';   
end


figure;
h=heatmap(ifr,'GridVisible','off','Colormap',hot);
h.ColorLimits = [1.0 1.7];

figure;
h=heatmap(blk,'GridVisible','off','Colormap',hot);
h.ColorLimits = [0.02 0.2];

% path=list_mod.sup;
% cell=11;
% 
% amp=zeros(size(path(cell).all_info.ttt.CR_trial,2),1);
% for i=1:size(path(cell).all_info.ttt.CR_trial,2)
% %     amp(i,1)=path(cell).all_info.ttt.CR_trial(i).blk_info.CR_amp*100;
%     amp(i,1)=min(path(cell).all_info.ttt.CR_trial(i).ifr_smooth(541:1041,3));
% end
% 
% [~,idx]=sort(amp);
%  
% ifr=zeros(length(amp),501);
% blk=zeros(length(amp),501);
% for j=1:length(amp)
%     k=idx(j);
%     ifr(j,:)=path(cell).all_info.ttt.CR_trial(k).ifr_smooth(541:1041,3)';
%     blk(j,:)=path(cell).all_info.ttt.CR_trial(k).blk_smth(551:1051,2)';      
% end

map=[0,0,0
0,0,0.025
0,0,0.05
0,0,0.075
0,0,0.1
0,0,0.125
0,0,0.15
0,0,0.175
0,0,0.2
0,0,0.225
0,0,0.25
0,0,0.275
0,0,0.3
0,0,0.325
0,0,0.35
0,0,0.375
0,0,0.4
0,0,0.425
0,0,0.45
0,0,0.475
0,0,0.5
0,0,0.525
0,0,0.55
0,0,0.575
0,0,0.6
0,0,0.625
0,0,0.65
0,0,0.675
0,0,0.7
0,0,0.725
0,0,0.75
0,0,0.775
0,0,0.8
0,0,0.825
0,0,0.85
0,0,0.875
0,0,0.9
0,0,0.925
0,0,0.95
0,0,0.975
0,0,1
0.025,0.025,1
0.05,0.05,1
0.075,0.075,1
0.1,0.1,1
0.125,0.125,1
0.15,0.15,1
0.175,0.175,1
0.2,0.2,1
0.225,0.225,1
0.25,0.25,1
0.275,0.275,1
0.3,0.3,1
0.325,0.325,1
0.35,0.35,1
0.375,0.375,1
0.4,0.4,1
0.425,0.425,1
0.45,0.45,1
0.475,0.475,1
0.5,0.5,1
0.525,0.525,1
0.55,0.55,1
0.575,0.575,1
0.6,0.6,1
0.625,0.625,1
0.65,0.65,1
0.675,0.675,1
0.7,0.7,1
0.725,0.725,1
0.75,0.75,1
0.775,0.775,1
0.8,0.8,1
0.825,0.825,1
0.85,0.85,1
0.875,0.875,1
0.9,0.9,1 
0.925,0.925,1
0.95,0.95,1
0.975,0.975,1
1,1,1];

% figure;
% h=heatmap(1-ifr,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0.5 1];
% 
% figure;
% h=heatmap(blk,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0 0.3];

% cell=14;
% 
% amp=zeros(size(path(cell).all_info_sps.ttt.CR_trial,2),1);
% for i=1:size(path(cell).all_info_sps.ttt.CR_trial,2)
% %     amp(i,1)=path(cell).all_info.ttt.CR_trial(i).blk_info.CR_amp*100;
%     amp(i,1)=min(path(cell).all_info_sps.ttt.CR_trial(i).ifr_smooth(541:1041,3));
% end
% 
% [~,idx]=sort(amp);
%  
% ifr=zeros(length(amp),501);
% blk=zeros(length(amp),501);
% for j=1:length(amp)
%     k=idx(j);
%     ifr(length(amp)-j+1,:)=path(cell).all_info_sps.ttt.CR_trial(k).ifr_smooth(541:1041,3)';
%     blk(length(amp)-j+1,:)=path(cell).all_info_sps.ttt.CR_trial(k).blk_smth(551:1051,2)';      
% end
% 
% figure;
% h=heatmap(1-ifr,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0.25 0.6];
% 
% figure;
% h=heatmap(blk,'GridVisible','off','Colormap',map);
% h.ColorLimits = [0.02 0.3];