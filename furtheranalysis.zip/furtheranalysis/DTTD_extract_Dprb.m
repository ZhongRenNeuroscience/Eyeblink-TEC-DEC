D_time=struct('CRonset',[],'CRamp',[],'CRpkt',[]);

for i=1:size(DT_blk_sss,2)
    D_time(i).CRonset=nanmean(DT_blk_sss(i).prbCR_info_D(:,4));
    D_time(i).CRamp=nanmean(DT_blk_sss(i).prbCR_info_D(:,3));
    D_time(i).CRpkt=nanmean(DT_blk_sss(i).prbCR_info_D(:,2));
      
end