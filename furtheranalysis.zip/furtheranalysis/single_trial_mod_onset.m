file=delay_list_2021;
all_info_1='all_info';
t_post_1=250;
all_info_2=[];
t_post_2=250;
bin=50;
step=10;
t_pre=500;
dur=1000;
thrd_SD=3;
thrd_mod_dur=10;

thrd_mod_dur=thrd_mod_dur/step;

for i=1:size(file,2)
    mod_trial=struct('bin_spk',[],'bsl_mean_spk',[],'bsl_SD_spk',[],'bsl_mod_spk_diff',[],'mod_event_spk',[],'bin_ifr',[],'bsl_mean_ifr',[],'bsl_SD_ifr',[],'mod_event_ifr',[]);
    for j=1:size(file(i).(all_info_1).ttt.CR_trial,2)        
        bin_spk=zeros((t_pre+dur-bin)/step+1,2);
        for k=1:(t_pre+dur-bin)/step+1
            t_1=-t_pre+(k-1)*step;
            t_2=-t_pre+(k-1)*step+bin;
            bin_spk(k,1)=(t_1+t_2)/2;
            bin_spk(k,2)=length(find([file(i).(all_info_1).ttt.CR_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info_1).ttt.CR_trial(j).spk_time]<t_2/1000))/bin*1000;            
        end
        mod_trial.bin_spk=bin_spk;
        mod_trial.bsl_mean_spk=mean(bin_spk(1:(t_pre-bin)/step+1,2));
        mod_trial.bsl_SD_spk=std(bin_spk(1:(t_pre-bin)/step+1,2));
        bsl_spk_num=length(find([file(i).(all_info_1).ttt.CR_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info_1).ttt.CR_trial(j).spk_time]<0))/t_pre*t_post_1;
        mod_spk_num=length(find([file(i).(all_info_1).ttt.CR_trial(j).spk_time]>=0 & [file(i).(all_info_1).ttt.CR_trial(j).spk_time]<t_post_1/1000));
        mod_trial.bsl_mod_spk_diff=mod_spk_num-bsl_spk_num;
        mod_event_spk=struct('onset',[],'offset',[],'pkt',[],'amp',[],'type',[]);
        thrd_up_spk=mod_trial.bsl_mean_spk+thrd_SD*mod_trial.bsl_SD_spk;
        thrd_down_spk=mod_trial.bsl_mean_spk-thrd_SD*mod_trial.bsl_SD_spk;  
        if thrd_down_spk<0
           thrd_down_spk=0;
        end
        spk_mod_idx=0;
          
        fac_dtn=bin_spk(t_pre/step+1:(t_pre+t_post_1-bin)/step+1,2)>= thrd_up_spk;
        [fac_region, fac_num_region]=bwlabel(fac_dtn);
        fac_size = regionprops(fac_region,'Area');  
        if fac_num_region>0
           for m=1:fac_num_region
               if fac_size(m).Area >= thrd_mod_dur
                  spk_mod_idx=spk_mod_idx+1;
                  onset_idx=find(fac_region==m,1,'first');
                  offset_idx=find(fac_region==m,1,'last');
                  mod_event_spk(spk_mod_idx).onset=(onset_idx-1)*step+bin/2;
                  mod_event_spk(spk_mod_idx).offset=(offset_idx-1)*step+bin/2;
                  [pk_value,pkt]=max(bin_spk((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                  mod_event_spk(spk_mod_idx).pkt=bin_spk(t_pre/step+pkt+onset_idx-1,1);
                  mod_event_spk(spk_mod_idx).amp=pk_value/mod_trial.bsl_mean_spk*100-100;
                  mod_event_spk(spk_mod_idx).type=1;            
               end
           end
        end
        
        sup_dtn=bin_spk(t_pre/step+1:(t_pre+t_post_1-bin)/step+1,2)<= thrd_down_spk;
        [sup_region, sup_num_region]=bwlabel(sup_dtn);
        sup_size = regionprops(sup_region,'Area');  
        if sup_num_region>0
           for m=1:sup_num_region
               if sup_size(m).Area >= thrd_mod_dur
                  spk_mod_idx=spk_mod_idx+1;
                  onset_idx=find(sup_region==m,1,'first');
                  offset_idx=find(sup_region==m,1,'last');
                  mod_event_spk(spk_mod_idx).onset=(onset_idx-1)*step+bin/2;
                  mod_event_spk(spk_mod_idx).offset=(offset_idx-1)*step+bin/2;
                  [pk_value,pkt]=min(bin_spk((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                  mod_event_spk(spk_mod_idx).pkt=bin_spk(t_pre/step+pkt+onset_idx-1,1);
                  mod_event_spk(spk_mod_idx).amp=-(pk_value/mod_trial.bsl_mean_spk*100-100);
                  mod_event_spk(spk_mod_idx).type=2;            
               end
           end
        end 
        mod_trial.mod_event_spk=mod_event_spk;   
   
        bin_ifr=zeros((t_pre+dur-bin)/step+1,2);
        for k=1:(t_pre+dur-bin)/step+1
            t_1=-t_pre+(k-1)*step;
            t_2=-t_pre+(k-1)*step+bin;
            t_1_idx=find(file(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,1)==t_1,1,'first');
            t_2_idx=find(file(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(:,1)==t_2,1,'first');
            bin_ifr(k,1)=(t_1+t_2)/2;
            bin_ifr(k,2)=mean(file(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(t_1_idx:t_2_idx-1,2));            
        end
        mod_trial.bin_ifr=bin_ifr;
        mod_trial.bsl_mean_ifr=nanmean(bin_ifr(1:(t_pre-bin)/step+1,2));
        mod_trial.bsl_SD_ifr=nanstd(bin_ifr(1:(t_pre-bin)/step+1,2));
        mod_event_ifr=struct('onset',[],'offset',[],'pkt',[],'amp',[],'type',[]);
        thrd_up_ifr=mod_trial.bsl_mean_ifr+thrd_SD*mod_trial.bsl_SD_ifr;
        thrd_down_ifr=mod_trial.bsl_mean_ifr-thrd_SD*mod_trial.bsl_SD_ifr;
        if thrd_down_ifr<0
           thrd_down_ifr=0;
        end
        ifr_mod_idx=0;
          
        fac_dtn=bin_ifr(t_pre/step+1:(t_pre+t_post_1-bin)/step+1,2)>= thrd_up_ifr;
        [fac_region, fac_num_region]=bwlabel(fac_dtn);
        fac_size = regionprops(fac_region,'Area');  
        if fac_num_region>0
           for m=1:fac_num_region
               if fac_size(m).Area >= thrd_mod_dur
                  ifr_mod_idx=ifr_mod_idx+1;
                  onset_idx=find(fac_region==m,1,'first');
                  offset_idx=find(fac_region==m,1,'last');
                  mod_event_ifr(ifr_mod_idx).onset=(onset_idx-1)*step+bin/2;
                  mod_event_ifr(ifr_mod_idx).offset=(offset_idx-1)*step+bin/2;
                  [pk_value,pkt]=max(bin_ifr((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                  mod_event_ifr(ifr_mod_idx).pkt=bin_ifr(t_pre/step+pkt+onset_idx-1,1);
                  mod_event_ifr(ifr_mod_idx).amp=pk_value/mod_trial.bsl_mean_ifr*100-100;
                  mod_event_ifr(ifr_mod_idx).type=1;            
               end
           end
        end    

        sup_dtn=bin_ifr(t_pre/step+1:(t_pre+t_post_1-bin)/step+1,2)<= thrd_down_ifr;
        [sup_region, sup_num_region]=bwlabel(sup_dtn);
        sup_size = regionprops(sup_region,'Area');  
        if sup_num_region>0
           for m=1:sup_num_region
               if sup_size(m).Area >= thrd_mod_dur
                  ifr_mod_idx=ifr_mod_idx+1;
                  onset_idx=find(sup_region==m,1,'first');
                  offset_idx=find(sup_region==m,1,'last');
                  mod_event_ifr(ifr_mod_idx).onset=(onset_idx-1)*step+bin/2;
                  mod_event_ifr(ifr_mod_idx).offset=(offset_idx-1)*step+bin/2;
                  [pk_value,pkt]=min(bin_ifr((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                  mod_event_ifr(ifr_mod_idx).pkt=bin_ifr(t_pre/step+pkt+onset_idx-1,1);
                  mod_event_ifr(ifr_mod_idx).amp=-(pk_value/mod_trial.bsl_mean_ifr*100-100);
                  mod_event_ifr(ifr_mod_idx).type=2;            
               end
           end
        end  
        mod_trial.mod_event_ifr=mod_event_ifr;
        file(i).(all_info_1).ttt.CR_trial(j).mod_trial=mod_trial; 
    end
    

    if ~isempty(all_info_2)
        mod_trial=struct('bin_spk',[],'bsl_mean_spk',[],'bsl_SD_spk',[],'bsl_mod_spk_diff',[],'mod_event_spk',[],'bin_ifr',[],'bsl_mean_ifr',[],'bsl_SD_ifr',[],'mod_event_ifr',[]);
        for j=1:size(file(i).(all_info_2).ttt.CR_trial,2)        
            bin_spk=zeros((t_pre+dur-bin)/step+1,2);
            for k=1:(t_pre+dur-bin)/step+1
                t_1=-t_pre+(k-1)*step;
                t_2=-t_pre+(k-1)*step+bin;
                bin_spk(k,1)=(t_1+t_2)/2;
                bin_spk(k,2)=length(find([file(i).(all_info_2).ttt.CR_trial(j).spk_time]>=t_1/1000 & [file(i).(all_info_2).ttt.CR_trial(j).spk_time]<t_2/1000))/bin*1000;            
            end
            mod_trial.bin_spk=bin_spk;
            mod_trial.bsl_mean_spk=mean(bin_spk(1:(t_pre-bin)/step+1,2));
            mod_trial.bsl_SD_spk=std(bin_spk(1:(t_pre-bin)/step+1,2));
            bsl_spk_num=length(find([file(i).(all_info_2).ttt.CR_trial(j).spk_time]>=-t_pre/1000 & [file(i).(all_info_2).ttt.CR_trial(j).spk_time]<0))/t_pre*t_post_2;
            mod_spk_num=length(find([file(i).(all_info_2).ttt.CR_trial(j).spk_time]>=0 & [file(i).(all_info_2).ttt.CR_trial(j).spk_time]<t_post_2/1000));
            mod_trial.bsl_mod_spk_diff=mod_spk_num-bsl_spk_num;
            mod_event_spk=struct('onset',[],'offset',[],'pkt',[],'amp',[],'type',[]);
            thrd_up_spk=mod_trial.bsl_mean_spk+thrd_SD*mod_trial.bsl_SD_spk;
            thrd_down_spk=mod_trial.bsl_mean_spk-thrd_SD*mod_trial.bsl_SD_spk;    
            if thrd_down_spk<0
               thrd_down_spk=0;
            end
            spk_mod_idx=0;

            fac_dtn=bin_spk(t_pre/step+1:(t_pre+t_post_2-bin)/step+1,2)>= thrd_up_spk;
            [fac_region, fac_num_region]=bwlabel(fac_dtn);
            fac_size = regionprops(fac_region,'Area');  
            if fac_num_region>0
               for m=1:fac_num_region
                   if fac_size(m).Area >= thrd_mod_dur
                      spk_mod_idx=spk_mod_idx+1;
                      onset_idx=find(fac_region==m,1,'first');
                      offset_idx=find(fac_region==m,1,'last');
                      mod_event_spk(spk_mod_idx).onset=(onset_idx-1)*step+bin/2;
                      mod_event_spk(spk_mod_idx).offset=(offset_idx-1)*step+bin/2;
                      [pk_value,pkt]=max(bin_spk((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                      mod_event_spk(spk_mod_idx).pkt=bin_spk(t_pre/step+pkt+onset_idx-1,1);
                      mod_event_spk(spk_mod_idx).amp=pk_value/mod_trial.bsl_mean_spk*100-100;
                      mod_event_spk(spk_mod_idx).type=1;            
                   end
               end
            end

            sup_dtn=bin_spk(t_pre/step+1:(t_pre+t_post_2-bin)/step+1,2)<= thrd_down_spk;
            [sup_region, sup_num_region]=bwlabel(sup_dtn);
            sup_size = regionprops(sup_region,'Area');  
            if sup_num_region>0
               for m=1:sup_num_region
                   if sup_size(m).Area >= thrd_mod_dur
                      spk_mod_idx=spk_mod_idx+1;
                      onset_idx=find(sup_region==m,1,'first');
                      offset_idx=find(sup_region==m,1,'last');
                      mod_event_spk(spk_mod_idx).onset=(onset_idx-1)*step+bin/2;
                      mod_event_spk(spk_mod_idx).offset=(offset_idx-1)*step+bin/2;
                      [pk_value,pkt]=min(bin_spk((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                      mod_event_spk(spk_mod_idx).pkt=bin_spk(t_pre/step+pkt+onset_idx-1,1);
                      mod_event_spk(spk_mod_idx).amp=-(pk_value/mod_trial.bsl_mean_spk*100-100);
                      mod_event_spk(spk_mod_idx).type=2;            
                   end
               end
            end 
            mod_trial.mod_event_spk=mod_event_spk;   

            bin_ifr=zeros((t_pre+dur-bin)/step+1,2);
            for k=1:(t_pre+dur-bin)/step+1
                t_1=-t_pre+(k-1)*step;
                t_2=-t_pre+(k-1)*step+bin;
                t_1_idx=find(file(i).(all_info_2).ttt.CR_trial(j).ifr_smooth(:,1)==t_1,1,'first');
                t_2_idx=find(file(i).(all_info_2).ttt.CR_trial(j).ifr_smooth(:,1)==t_2,1,'first');
                bin_ifr(k,1)=(t_1+t_2)/2;
                bin_ifr(k,2)=mean(file(i).(all_info_2).ttt.CR_trial(j).ifr_smooth(t_1_idx:t_2_idx-1,2));            
            end
            mod_trial.bin_ifr=bin_ifr;
            mod_trial.bsl_mean_ifr=nanmean(bin_ifr(1:(t_pre-bin)/step+1,2));
            mod_trial.bsl_SD_ifr=nanstd(bin_ifr(1:(t_pre-bin)/step+1,2));
            mod_event_ifr=struct('onset',[],'offset',[],'pkt',[],'amp',[],'type',[]);
            thrd_up_ifr=mod_trial.bsl_mean_ifr+thrd_SD*mod_trial.bsl_SD_ifr;
            thrd_down_ifr=mod_trial.bsl_mean_ifr-thrd_SD*mod_trial.bsl_SD_ifr;   
            if thrd_down_ifr<0
               thrd_down_ifr=0;
            end
            ifr_mod_idx=0;

            fac_dtn=bin_ifr(t_pre/step+1:(t_pre+t_post_2-bin)/step+1,2)>= thrd_up_ifr;
            [fac_region, fac_num_region]=bwlabel(fac_dtn);
            fac_size = regionprops(fac_region,'Area');  
            if fac_num_region>0
               for m=1:fac_num_region
                   if fac_size(m).Area >= thrd_mod_dur
                      ifr_mod_idx=ifr_mod_idx+1;
                      onset_idx=find(fac_region==m,1,'first');
                      offset_idx=find(fac_region==m,1,'last');
                      mod_event_ifr(ifr_mod_idx).onset=(onset_idx-1)*step+bin/2;
                      mod_event_ifr(ifr_mod_idx).offset=(offset_idx-1)*step+bin/2;
                      [pk_value,pkt]=max(bin_ifr((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                      mod_event_ifr(ifr_mod_idx).pkt=bin_ifr(t_pre/step+pkt+onset_idx-1,1);
                      mod_event_ifr(ifr_mod_idx).amp=pk_value/mod_trial.bsl_mean_ifr*100-100;
                      mod_event_ifr(ifr_mod_idx).type=1;            
                   end
               end
            end    

            sup_dtn=bin_ifr(t_pre/step+1:(t_pre+t_post_2-bin)/step+1,2)<= thrd_down_ifr;
            [sup_region, sup_num_region]=bwlabel(sup_dtn);
            sup_size = regionprops(sup_region,'Area');  
            if sup_num_region>0
               for m=1:sup_num_region
                   if sup_size(m).Area >= thrd_mod_dur
                      ifr_mod_idx=ifr_mod_idx+1;
                      onset_idx=find(sup_region==m,1,'first');
                      offset_idx=find(sup_region==m,1,'last');
                      mod_event_ifr(ifr_mod_idx).onset=(onset_idx-1)*step+bin/2;
                      mod_event_ifr(ifr_mod_idx).offset=(offset_idx-1)*step+bin/2;
                      [pk_value,pkt]=min(bin_ifr((t_pre/step+onset_idx):(t_pre/step+offset_idx),2));
                      mod_event_ifr(ifr_mod_idx).pkt=bin_ifr(t_pre/step+pkt+onset_idx-1,1);
                      mod_event_ifr(ifr_mod_idx).amp=-(pk_value/mod_trial.bsl_mean_ifr*100-100);
                      mod_event_ifr(ifr_mod_idx).type=2;            
                   end
               end
            end  
            mod_trial.mod_event_ifr=mod_event_ifr;
            file(i).(all_info_2).ttt.CR_trial(j).mod_trial=mod_trial; 
        end
    end

end

