% Plot the UR modulation analysis result: the example neuron raster,
% all UR facilitation or suppression neurons average, and the CR-UR
% modulation magnitude correlation results. --Zhong 

% T=-500:5:1000;
% 
% type='fac';
% cell_num=24;
% 
% figure;
% 
% subplot(2,1,1)
% hold on
% 
% for m=1:size(list_mod.fac(cell_num).all_info.ttt.CR_trial,2)
%     hold on
%     Y=ones(length(list_mod.fac(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
%     plot(list_mod.fac(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'Color',[1,0.5,0],'LineStyle','none','Marker','.')
% end
% line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([0 m]);
% xlabel('Time (ms)');
% ylabel('CR trial number');
% xticks([-250 0 250 500 1000]);
% yticks([0 10 20 30 40 50]);
% 
% subplot(2,1,2)
% plot(T,fac_URsmth(:,4),'Color',[1,0.5,0],'LineWidth',1)
% hold on
% plot(T,fac_URsmth(:,5),'Color',[0.5,0.5,0.5],'LineWidth',1)
% hold on
% plot(T,fac_URsmth(:,6),'Color',[0.5,0.5,0.5],'LineWidth',1)
% xlabel('Time (ms)');
% ylabel('Relative firing rate (%)');
% xlim([-250 1000])
% ylim([50 200]);
% line([0 0],[50,200],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[50,200],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[50,200],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% text(-150,175,'n = 161','Color',[1,0.5,0],'FontSize',10);
% xticks([-250 0 250 500 1000]);
% 
% type='sup';
% cell_num=13;
% 
% figure;
% subplot(2,1,1)
% hold on
% 
% for m=1:size(list_mod.sup(cell_num).all_info.ttt.CR_trial,2)
%     hold on
%     Y=ones(length(list_mod.sup(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
%     plot(list_mod.sup(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'Color',[0.5,0,1],'LineStyle','none','Marker','.')
% end
% line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([0 m]);
% xlabel('Time (ms)');
% ylabel('CR trial number');
% xticks([-250 0 250 500 1000]);
% yticks([0 10 20 30 40]);
% 
% subplot(2,1,2)
% plot(T,sup_URsmth(:,4),'Color',[0.5,0,1],'LineWidth',1)
% hold on
% plot(T,sup_URsmth(:,5),'Color',[0.5,0.5,0.5],'LineWidth',1)
% hold on
% plot(T,sup_URsmth(:,6),'Color',[0.5,0.5,0.5],'LineWidth',1)
% xlabel('Time (ms)');
% ylabel('Relative firing rate (%)');
% xlim([-250 1000]);
% ylim([0 150]);
% line([0 0],[0,150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0,150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0,150],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% text(-150,125,'n = 45','Color',[0.5,0,1],'FontSize',10);
% xticks([-500 0 250 500 1000]);
% 
% 
% figure;
% 
% subplot(2,1,1)
% type='fac';
% cell_num=29;
% 
% for m=1:size(list_mod.fac(cell_num).all_info.ttt.CR_trial,2)
%     hold on
%     Y=ones(length(list_mod.fac(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
%     plot(list_mod.fac(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'Color',[0,0,0],'LineStyle','none','Marker','.')
% end
% line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([0 m]);
% xlabel('Time (ms)');
% ylabel('CR trial number');
% xticks([-250 0 250 500 1000]);
% yticks([0 10 20 30 40 50]);
% 
% subplot(2,1,2)
% type='non';
% cell_num=99;
% 
% for m=1:size(list_mod.non(cell_num).all_info.ttt.CR_trial,2)
%     hold on
%     Y=ones(length(list_mod.non(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
%     plot(list_mod.non(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'Color',[0,0,0],'LineStyle','none','Marker','.')
% end
% line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([0 m]);
% xlabel('Time (ms)');
% ylabel('CR trial number');
% xticks([-250 0 250 500 1000]);
% yticks([0 10 20 30 40 50]);

figure;
plot(ff_amp(:,1),ff_amp(:,2),'r.','MarkerSize',10)
hold on
plot(fs_amp(:,1),fs_amp(:,2),'r.','MarkerSize',10)
hold on
plot(sf_amp(:,1),sf_amp(:,2),'b.','MarkerSize',10)
hold on
plot(ss_amp(:,1),ss_amp(:,2),'b.','MarkerSize',10)
hold on
plot(ff_amp(:,1),regression,'Color',[0 0 0],'LineStyle','-','LineWidth',1.0)
hold on
xlim([-100 300]);
ylim([-100 400]);
xlabel('CR facilitation (%)');
ylabel('UR facilitation (%)');
line([0 0],[-100,400],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([-100,300],[0 0],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
text(200,50,['r=' num2str(R(2,1))],'Color','black','FontSize',12);
text(200,25,['p=' num2str(P(2,1))],'Color','black','FontSize',12);


