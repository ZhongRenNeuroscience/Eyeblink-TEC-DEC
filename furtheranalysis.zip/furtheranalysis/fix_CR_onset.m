%%% This code has been added in trace_list_rebuild.m file.



file=file;
t_post=500;
onset_thrd=10;
all_info='all_info_T';
trial_type='CR_trial';


onset_thrd=onset_thrd/100;
for i=134:144
    t_start=file(i).(all_info).ttt.(trial_type)(1).blk_smth(1,1);
    for j=1:size(file(i).(all_info).ttt.(trial_type),2)
        max_CR=max(file(i).(all_info).ttt.(trial_type)(j).blk_smth(-t_start+51:-t_start+t_post,2))>=onset_thrd;
        if max_CR>=onset_thrd
           CR_onset=find(file(i).(all_info).ttt.(trial_type)(j).blk_smth(-t_start+51:-t_start+t_post,2)>=onset_thrd,1,'first')+49;
           file(i).(all_info).ttt.(trial_type)(j).blk_info_new.CR_onset=CR_onset/1000;
        else
           file(i).(all_info).ttt.(trial_type)(j).trial_num=[];
        end       
    end
    file(i).(all_info).ttt.(trial_type)=file(i).(all_info).ttt.(trial_type)(~cellfun(@isempty,{file(i).(all_info).ttt.(trial_type).trial_num}));
end