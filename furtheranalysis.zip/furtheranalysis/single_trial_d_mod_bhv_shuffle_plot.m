trial_mod_list=trial_mod_list_D;
cell_list=delay_list_sim;
t_post=250;
corr_info='fac_corr_info';
corr_data='fac_corr_data';
cell_type='CR_fac';
reg_type='reg_amp';
data_type='fac_onset';
color_1=[1 0.5 0];
% color_1=[0.5 0 1];
color_2=[0.5 0.5 0.5];
ymin=0;
ymax=t_post;
shf_time=10;



mean_list=struct('cell_ID',[],'mod_mean',[],'bhv_mean',[],'d_mean',[],'shf_form',[],'d_form',[],'p_shf',[],...
          'R_1',[],'R_2',[],'R_3',[],'P_1',[],'P_2',[],'P_3',[],'corr_data_1',[],'corr_data_2',[],'corr_data_3',[],...
          'std_mod',[],'std_CR',[],'std_delta',[]);
cell_idx=0;

for i=1:size(trial_mod_list,2)
    if trial_mod_list(i).(cell_type)==1
       cell_idx=cell_idx+1;
       mean_list(cell_idx).cell_ID=trial_mod_list(i).cell_ID;
       mean_list(cell_idx).mod_mean=mean(trial_mod_list(i).(corr_info).(reg_type)(:,1));
       mean_list(cell_idx).bhv_mean=mean(trial_mod_list(i).(corr_info).(reg_type)(:,2));
       mean_list(cell_idx).d_mean=mean_list(cell_idx).bhv_mean-mean_list(cell_idx).mod_mean; 
       shf_form=zeros(size(trial_mod_list(i).(corr_info).(reg_type),1),shf_time+2);
       for j=1:size(trial_mod_list(i).(corr_info).(reg_type),1)
           shf_form(j,1)=trial_mod_list(i).(corr_info).(reg_type)(j,1);
           shf_form(j,2)=trial_mod_list(i).(corr_info).(reg_type)(j,2);
       end
       for m=1:shf_time
           shf_form(:,m+2)=shf_form(randperm(length(shf_form(:,2))),2);           
       end  
       d_form=zeros(size(trial_mod_list(i).(corr_info).(reg_type),1),2);
       for j=1:size(trial_mod_list(i).(corr_info).(reg_type),1)
           d_form(j,1)=shf_form(j,2)-shf_form(j,1);
           d_form(j,2)=mean(shf_form(j,3:end))-shf_form(j,1);          
       end     

       mean_list(cell_idx).shf_form=shf_form;
       mean_list(cell_idx).d_form=d_form;
       mean_list(cell_idx).p_shf=ranksum(d_form(:,1),d_form(:,2));
       
       corr_data_1=zeros(size(trial_mod_list(i).(corr_info).(reg_type),1),3);
       corr_data_1(:,1)=trial_mod_list(i).(corr_info).(reg_type)(:,2);
       corr_data_1(:,2)=d_form(:,1);
       [R_1,P_1]=corrcoef(corr_data_1(:,1),corr_data_1(:,2));
       p_1=polyfit(corr_data_1(:,1),corr_data_1(:,2),1);
       corr_data_1(:,3)=p_1(1)*corr_data_1(:,1)+p_1(2);
       
       corr_data_2=zeros(size(trial_mod_list(i).(corr_info).(reg_type),1),3);
       corr_data_2(:,1)=trial_mod_list(i).(corr_info).(reg_type)(:,1);
       corr_data_2(:,2)=d_form(:,1);
       [R_2,P_2]=corrcoef(corr_data_2(:,1),corr_data_2(:,2));
       p_2=polyfit(corr_data_2(:,1),corr_data_2(:,2),1);
       corr_data_2(:,3)=p_2(1)*corr_data_2(:,1)+p_2(2);    
       
       corr_data_3=zeros(size(trial_mod_list(i).(corr_info).(reg_type),1),3);
       corr_data_3(:,1)=trial_mod_list(i).(corr_info).(reg_type)(:,1);
       corr_data_3(:,2)=trial_mod_list(i).(corr_info).(reg_type)(:,2);
       [R_3,P_3]=corrcoef(corr_data_3(:,1),corr_data_3(:,2));
       p_3=polyfit(corr_data_3(:,1),corr_data_3(:,2),1);
       corr_data_3(:,3)=p_3(1)*corr_data_3(:,1)+p_3(2); 
       
       mean_list(cell_idx).R_1=R_1(2,1);
       mean_list(cell_idx).P_1=P_1(2,1);
       mean_list(cell_idx).R_2=R_2(2,1);
       mean_list(cell_idx).P_2=P_2(2,1);
       mean_list(cell_idx).R_3=R_3(2,1);
       mean_list(cell_idx).P_3=P_3(2,1);
       mean_list(cell_idx).corr_data_1=corr_data_1;
       mean_list(cell_idx).corr_data_2=corr_data_2;
       mean_list(cell_idx).corr_data_3=corr_data_3;
       
       mean_list(cell_idx).std_mod=std(trial_mod_list(i).(corr_info).(reg_type)(:,1));
       mean_list(cell_idx).std_CR=std(trial_mod_list(i).(corr_info).(reg_type)(:,2));
       mean_list(cell_idx).std_delta=std(d_form(:,1));
    end
        
end

figure;
for i=1:size(mean_list,2)
    if mean_list(i).P_3<0.05 %&& mean_list(i).R_3>0
       plot(mean_list(i).corr_data_3(:,1),mean_list(i).corr_data_3(:,3),'-','Color',color_1)
       hold on
    end   
end
% line([0 t_post],[0 t_post],'LineStyle','--');
% xlim([0 t_post]);
% xticks(0:50:t_post);
% ylim([0 t_post]);
% yticks(0:50:t_post);
% xlabel('mod. onset (ms)');
% ylabel('CR onset (ms)');

% line([0 t_post],[0 t_post],'LineStyle','--');
xlim([0 1500]);
xticks(0:500:1500);
ylim([0 100]);
yticks(0:20:100);
xlabel('mod. amp (%)');
ylabel('CR amp (%)');

% cell_ID=118;
% trial_num=6;
% cell_plot_ID=find([mean_list.cell_ID]==cell_ID);
% trial_num_plot=find([trial_mod_list(cell_ID).(corr_data).trial_num]==trial_num);
% figure;
% % subplot(2,2,1)
% % for j=1:size(mean_list(cell_plot_ID).d_form,1)    
% %     plot(mean_list(cell_plot_ID).corr_data_1(j,1),mean_list(cell_plot_ID).corr_data_1(j,2),'.','Color',color_1)
% %     hold on    
% % end
% % plot(mean_list(cell_plot_ID).corr_data_1(:,1),mean_list(cell_plot_ID).corr_data_1(:,3),'-','Color',color_1)
% % hold on
% % % line([1 size(mean_list(cell_plot_ID).d_form,1)],[mean(mean_list(cell_plot_ID).d_form(:,1)) mean(mean_list(cell_plot_ID).d_form(:,1))],'Color',color_1);
% % % hold on
% % % for j=1:size(mean_list(cell_plot_ID).d_form,1)    
% % %     plot(j+size(mean_list(cell_plot_ID).d_form,1),mean_list(cell_plot_ID).d_form(j,2),'.','Color',color_2)
% % %     hold on    
% % % end
% % % hold on
% % 
% % % line([size(mean_list(cell_plot_ID).d_form,1)+0.5 size(mean_list(cell_plot_ID).d_form,1)+0.5],[ymin ymax],'LineStyle','--');
% % xlim([0 t_post]);
% % xticks(0:50:t_post);
% % ylim([ymin ymax]);
% % xlabel('CR onset (ms)');
% % ylabel('d(CR-mod) (ms)');
% 
% % subplot(2,2,2)
% % for j=1:size(mean_list(cell_plot_ID).d_form,1)    
% %     plot(mean_list(cell_plot_ID).corr_data_2(j,1),mean_list(cell_plot_ID).corr_data_2(j,2),'.','Color',color_1)
% %     hold on    
% % end
% % plot(mean_list(cell_plot_ID).corr_data_2(:,1),mean_list(cell_plot_ID).corr_data_2(:,3),'-','Color',color_1)
% % hold on
% % % line([1 size(mean_list(cell_plot_ID).d_form,1)],[mean(mean_list(cell_plot_ID).d_form(:,1)) mean(mean_list(cell_plot_ID).d_form(:,1))],'Color',color_1);
% % % hold on
% % % for j=1:size(mean_list(cell_plot_ID).d_form,1)    
% % %     plot(j+size(mean_list(cell_plot_ID).d_form,1),mean_list(cell_plot_ID).d_form(j,2),'.','Color',color_2)
% % %     hold on    
% % % end
% % % hold on
% % 
% % % line([size(mean_list(cell_plot_ID).d_form,1)+0.5 size(mean_list(cell_plot_ID).d_form,1)+0.5],[ymin ymax],'LineStyle','--');
% % xlim([0 t_post]);
% % xticks(0:50:t_post);
% % ylim([ymin ymax]);
% % xlabel('mod. onset (ms)');
% % ylabel('d(CR-mod) (ms)');
% 
% subplot(2,2,[1 3])
% for j=1:size(mean_list(cell_plot_ID).d_form,1)    
%     plot(mean_list(cell_plot_ID).corr_data_3(j,1),mean_list(cell_plot_ID).corr_data_3(j,2),'.','Color',color_1)
%     hold on    
% end
% plot(mean_list(cell_plot_ID).corr_data_3(:,1),mean_list(cell_plot_ID).corr_data_3(:,3),'-','Color',color_1)
% hold on
% plot(trial_mod_list(cell_ID).(corr_data)(trial_num_plot).(data_type),trial_mod_list(cell_ID).(corr_data)(trial_num_plot).CR_onset,'r.')
% hold on
% line([0 t_post],[0 t_post],'LineStyle','--');
% text(t_post*0.8,t_post*0.3,['R=' num2str(mean_list(cell_plot_ID).R_3)]);
% text(t_post*0.8,t_post*0.1,['P=' num2str(mean_list(cell_plot_ID).P_3)]);
% 
% 
% % line([size(mean_list(cell_plot_ID).d_form,1)+0.5 size(mean_list(cell_plot_ID).d_form,1)+0.5],[ymin ymax],'LineStyle','--');
% xlim([0 t_post]);
% xticks(0:50:t_post);
% ylim([0 t_post]);
% yticks(0:50:t_post);
% xlabel('mod. onset (ms)');
% ylabel('CR onset (ms)');
% 
% % subplot(2,2,4)
% % h1=histogram(mean_list(cell_plot_ID).d_form(:,1));
% % h1.BinWidth=50;
% % h1.BinLimits=[ymin ymax];
% % h1.FaceColor=color_1;
% % h1.Normalization='probability';
% % hold on
% % % h2=histogram(mean_list(cell_plot_ID).d_form(:,2));
% % % h2.BinWidth=50;
% % % h2.BinLimits=[ymin ymax];
% % % h2.FaceColor=color_2;
% % % h2.Normalization='probability';
% % % hold on
% % xlim([ymin ymax]);
% % ylim([0 1]);
% % xticks(ymin:50:ymax);
% 
% subplot(2,2,2)
% h1=histogram(mean_list(cell_plot_ID).corr_data_3(:,1));
% h1.BinWidth=50;
% h1.BinLimits=[ymin ymax];
% h1.FaceColor=color_1;
% h1.Normalization='probability';
% hold on
% % h2=histogram(mean_list(cell_plot_ID).d_form(:,2));
% % h2.BinWidth=50;
% % h2.BinLimits=[ymin ymax];
% % h2.FaceColor=color_2;
% % h2.Normalization='probability';
% % hold on
% xlim([ymin ymax]);
% ylim([0 1]);
% xticks(ymin:50:ymax);
% title('Modulation onset');
% 
% subplot(2,2,4)
% h1=histogram(mean_list(cell_plot_ID).corr_data_3(:,2));
% h1.BinWidth=50;
% h1.BinLimits=[ymin ymax];
% h1.FaceColor=color_1;
% h1.Normalization='probability';
% hold on
% % h2=histogram(mean_list(cell_plot_ID).d_form(:,2));
% % h2.BinWidth=50;
% % h2.BinLimits=[ymin ymax];
% % h2.FaceColor=color_2;
% % h2.Normalization='probability';
% % hold on
% xlim([ymin ymax]);
% ylim([0 1]);
% xticks(ymin:50:ymax);
% title('CR onset');

% figure;
% subplot(2,1,1)
% ifr_plot=smooth_curve(cell_list(cell_ID).all_info.ttt.CR_trial(trial_num_plot).ifr_smooth(:,1),cell_list(cell_ID).all_info.ttt.CR_trial(trial_num_plot).ifr_smooth(:,2),20,10);
% plot(ifr_plot(:,1),ifr_plot(:,2))
% % plot(cell_list(cell_ID).all_info.ttt.CR_trial(trial_num_plot).ifr_smooth(:,1),cell_list(cell_ID).all_info.ttt.CR_trial(trial_num_plot).ifr_smooth(:,2))
% hold on
% t_mk_idx=find(ifr_plot(:,1)>=trial_mod_list(cell_ID).(corr_data)(trial_num_plot).(data_type),1,'first');
% text(ifr_plot(t_mk_idx,1),ifr_plot(t_mk_idx,2),'*','FontSize',10,'HorizontalAlignment','center');
% hold on
% xlim([-250 t_post]);
% xticks(-250:50:t_post);
% title('Firing rate');
% 
% 
% subplot(2,1,2)
% bhv_plot=smooth_curve(cell_list(cell_ID).all_info.ttt.CR_trial(trial_num_plot).blk_smth(:,1),cell_list(cell_ID).all_info.ttt.CR_trial(trial_num_plot).blk_smth(:,2),20,10);
% plot(bhv_plot(:,1),bhv_plot(:,2)*100)
% hold on
% t_mk_idx=find(bhv_plot(:,1)>=trial_mod_list(cell_ID).(corr_data)(trial_num_plot).CR_onset,1,'first');
% text(bhv_plot(t_mk_idx,1),bhv_plot(t_mk_idx,2)*100,'*','FontSize',10,'HorizontalAlignment','center');
% hold on
% xlim([-250 t_post]);
% xticks(-250:50:t_post);
% ylim([-10 100]);
% title('Eyelid closure');
% 
% figure;
% for i=1:size(mean_list,2)
%     plot(-log10(mean_list(i).P_3),mean_list(i).R_3,'k.')
%     hold on  
% end
% plot(-log10(mean_list(cell_plot_ID).P_3),mean_list(cell_plot_ID).R_3,'r.')
% hold on
% line([-log10(0.05) -log10(0.05)],[-1 1],'LineStyle','--');
% ylim([-1 1]);
% yticks(-1:0.5:1);
% xlabel('-lg(p)');
% ylabel('R');





function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=(x((i-1)*step+1)+x(i*step+1))/2;
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end
