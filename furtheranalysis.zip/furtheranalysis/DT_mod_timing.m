mf=1;
ms=1;

for i=1:size(DT_list,2)
    if DT_list(i).CR_fac_D + DT_list(i).CR_sup_D > 0 && DT_list(i).CR_fac_T + DT_list(i).CR_sup_T > 0
       if DT_list(i).CR_fac_D > 0
       DT_mod_249_f(mf,1)=i;
       DT_mod_249_f(mf,2)=DT_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(800,2)/DT_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
       DT_mod_249_f(mf,3)=DT_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(800,2)/DT_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;        
       DT_mod_on_f(mf,1)=i;
       DT_mod_on_f(mf,2)=DT_list(i).mod_info_D.CRf(1).t_onset;
       DT_mod_on_f(mf,3)=DT_list(i).mod_info_T.CRf(1).t_onset;
       DT_mod_peak_f(mf,1)=i;
       [M,I]=max(DT_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       DT_mod_peak_f(mf,2)=M/DT_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
       DT_mod_peak_f(mf,4)=I-1;
       [M,I]=max(DT_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       DT_mod_peak_f(mf,3)=M/DT_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
       DT_mod_peak_f(mf,5)=I-1;
       mf=mf+1;
       elseif DT_list(i).CR_sup_D > 0
       DT_mod_249_s(ms,1)=i;
       DT_mod_249_s(ms,2)=DT_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(800,2)/DT_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
       DT_mod_249_s(ms,3)=DT_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(800,2)/DT_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;        
       DT_mod_on_s(ms,1)=i;
       DT_mod_on_s(ms,2)=DT_list(i).mod_info_D.CRs(1).t_onset;
       DT_mod_on_s(ms,3)=DT_list(i).mod_info_T.CRs(1).t_onset;
       [M,I]=min(DT_list(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       DT_mod_peak_s(ms,2)=M/DT_list(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
       DT_mod_peak_s(ms,4)=I-1;
       [M,I]=min(DT_list(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(551:801,2));
       DT_mod_peak_s(ms,3)=M/DT_list(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
       DT_mod_peak_s(ms,5)=I-1;
       ms=ms+1;           
       end
    end
end