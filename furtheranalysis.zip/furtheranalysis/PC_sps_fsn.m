sps_ff=0;
sps_sf=0;
sps_nf=0;
sps_fs=0;
sps_ss=0;
sps_ns=0;
sps_fn=0;
sps_sn=0;
sps_nn=0;



for i=1:size(list_PC,2)
    if isempty(list_PC(i).CR_fac_cps)
        continue
    end
    if list_PC(i).CR_fac_sps>0 && list_PC(i).UR_fac_sps>0
       sps_ff=sps_ff+1;
    elseif list_PC(i).CR_sup_sps>0 && list_PC(i).UR_fac_sps>0
       sps_sf=sps_sf+1; 
    elseif list_PC(i).CR_fac_sps==0 && list_PC(i).CR_sup_sps==0 && list_PC(i).UR_fac_sps>0
       sps_nf=sps_nf+1; 

    elseif list_PC(i).CR_fac_sps>0 && list_PC(i).UR_sup_sps>0
       sps_fs=sps_fs+1;
    elseif list_PC(i).CR_sup_sps>0 && list_PC(i).UR_sup_sps>0
       sps_ss=sps_ss+1; 
    elseif list_PC(i).CR_fac_sps==0 && list_PC(i).CR_sup_sps==0 && list_PC(i).UR_sup_sps>0
       sps_ns=sps_ns+1; 
    
    elseif list_PC(i).CR_fac_sps>0 && list_PC(i).UR_fac_sps==0 && list_PC(i).UR_sup_sps==0
       sps_fn=sps_fn+1;
    elseif list_PC(i).CR_sup_sps>0 && list_PC(i).UR_fac_sps==0 && list_PC(i).UR_sup_sps==0
       sps_sn=sps_sn+1; 
    elseif list_PC(i).CR_fac_sps==0 && list_PC(i).CR_sup_sps==0 && list_PC(i).UR_fac_sps==0 && list_PC(i).UR_sup_sps==0
       sps_nn=sps_nn+1; 
    end
    
    
end
