% Plot example neurons with three modulation types in TEC-only recordings.
% --Zhong

file=trace_list_sim;

cell_num=424;
trial_num=2;
all_info='all_info';
align_info='align_info';


cell_ID=find([file.cell_ID]==cell_num,1);
CR_trial_num=find([file(cell_ID).(all_info).ttt.CR_trial.trial_num]==trial_num,1);
figure;
subplot(3,1,1)
blk_curve=smooth_curve(file(cell_ID).(all_info).ttt.CR_trial(CR_trial_num).blk_smth(:,1),file(cell_ID).(all_info).ttt.CR_trial(CR_trial_num).blk_smth(:,2)*100,25,5);
plot(blk_curve(:,1),blk_curve(:,2),'Color',[0 0 0],'LineWidth',2)
hold on
line([0 0],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([250 250],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([-10 120]);
xlabel('Time (ms)');
ylabel('Eyelid closure (%)');
xticks([-250 0 250 500 1000]);
yticks([0 100]);

subplot(3,1,2)
hold on

plot_trials=1:size(file(cell_ID).(all_info).ttt.CR_trial,2);
if size(file(cell_ID).(all_info).ttt.CR_trial,2)>=40
   plot_trials=randperm(size(file(cell_ID).(all_info).ttt.CR_trial,2),40);
   plot_trials=sort(plot_trials);
end

for m=1:size(plot_trials,2)
    hold on
    trial_ID=plot_trials(1,m);
    Y=ones(length(file(cell_ID).(all_info).ttt.CR_trial(trial_ID).spk_time),1)*m;
    plot(file(cell_ID).(all_info).ttt.CR_trial(trial_ID).spk_time*1000,Y,'k.')
end
line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([0 m]);
xlabel('Time (ms)');
ylabel('CR trial number');
xticks([-250 0 250 500 1000]);
yticks([0 10 20 30 40 50 60 70 80 90 100]);

subplot(3,1,3)
plot(file(cell_ID).(align_info).psth_ex(:,1),smooth(file(cell_ID).(align_info).psth_ex(:,2),25),'Color',[0 0 0],'LineWidth',2)
hold on

xlabel('Time (ms)');
ylabel('Firing rate (Hz)');
xlim([-250 1000])
ylim([0 120]);
line([0 0],[0,250],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([250 250],[0,250],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[0,250],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xticks([-250 0 250 500 1000]);

function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end