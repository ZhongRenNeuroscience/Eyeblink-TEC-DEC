fac_dot=zeros(size(list_mod.fac,2)-2,4);
k=0;
type='fac';
for i=1:size(list_mod.fac,2)
    if i==33 || i==39
        k=k+1;
        continue    
    end
    j=i-k;
    fac_dot(j,1)=list_mod.(type)(i).mod_info.CRf.t_onset;
    fac_dot(j,2)=list_mod.(type)(i).mod_info.CRf.t_peak;
    avgform=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
    for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
        avgform(m,1)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info_new.CR_onset*1000;
        avgform(m,2)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info_new.CR_peaktime*1000;
    end
    fac_dot(j,3)=nanmean(avgform(:,1));
    fac_dot(j,4)=nanmean(avgform(:,2));
end

sup_dot=zeros(size(list_mod.sup,2),4);
type='sup';
for i=1:size(list_mod.sup,2)
    sup_dot(i,1)=list_mod.(type)(i).mod_info.CRs.t_onset;
    sup_dot(i,2)=list_mod.(type)(i).mod_info.CRs.t_peak;
    avgform=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
    for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
        avgform(m,1)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info_new.CR_onset*1000;
        avgform(m,2)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info_new.CR_peaktime*1000;
    end
    sup_dot(i,3)=nanmean(avgform(:,1));
    sup_dot(i,4)=nanmean(avgform(:,2));
end
figure;
plot(fac_dot(:,1),fac_dot(:,3),'r.')
hold on
plot(sup_dot(:,1),sup_dot(:,3),'b.')
hold on
xlim([0 500]);
ylim([0 500]);
xlabel('Mod onset (ms)');
ylabel('CR onset (ms)');
line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--')
line([250 250],[0,500],'Color',[0 0 0],'LineStyle','--')
line([0,500],[250 250],'Color',[0 0 0],'LineStyle','--')
legend({'Facilitation','Suppression'},'Location','southeast');

figure;
plot(fac_dot(:,2),fac_dot(:,4),'r.')
hold on
plot(sup_dot(:,2),sup_dot(:,4),'b.')
hold on
xlim([0 500]);
ylim([0 500]);
xlabel('Mod peak time (ms)');
ylabel('CR peak time (ms)');
line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--')
line([250 250],[0,500],'Color',[0 0 0],'LineStyle','--')
line([0,500],[250 250],'Color',[0 0 0],'LineStyle','--')
legend({'Facilitation','Suppression'},'Location','southeast');