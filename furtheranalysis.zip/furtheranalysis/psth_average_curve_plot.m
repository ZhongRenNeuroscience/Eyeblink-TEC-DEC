% Plot the average firing rate curve of facilitation, suppression , and
% non-modulation types in TEC-only recordings smoothing into 10 ms bin size.
type='fac';
k=0;
fac_frr=zeros(1510,size(list_mod.fac,2)-2);

for i=1:size(list_mod.fac,2)
    if i==33 || i==39
       k=k+1;
       continue    
    end
    j=i-k;
    fac_frr(:,j)=list_mod.(type)(i).all_info.sss_all.psth.CR_trial.psth_smooth((42:1551),2)/list_mod.(type)(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
end

fac_psthavg=zeros(1510,5);
fac_psthavg(:,1)=mean(fac_frr,2);
fac_psthavg(:,2)=std(fac_frr,0,2);
for k=1:1510
    fac_psthavg(k,3)=fac_psthavg(k,2)/fac_psthavg(k,1)*100;
    fac_psthavg(k,4)=fac_psthavg(k,1)+fac_psthavg(k,3);
    fac_psthavg(k,5)=fac_psthavg(k,1)-fac_psthavg(k,3);
end

type='sup';
sup_frr=zeros(1510,size(list_mod.sup,2)-2);

for i=1:size(list_mod.sup,2)
    j=i;
    sup_frr(:,j)=list_mod.(type)(i).all_info.sss_all.psth.CR_trial.psth_smooth((42:1551),2)/list_mod.(type)(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
end

sup_psthavg=zeros(1510,3);
sup_psthavg(:,1)=mean(sup_frr,2);
sup_psthavg(:,2)=std(sup_frr,0,2);
for k=1:1510
    sup_psthavg(k,3)=sup_psthavg(k,2)/sup_psthavg(k,1)*100;
    sup_psthavg(k,4)=sup_psthavg(k,1)+sup_psthavg(k,3);
    sup_psthavg(k,5)=sup_psthavg(k,1)-sup_psthavg(k,3);
end

type='non';
k=0;
non_frr=zeros(1510,size(list_mod.non,2)-2);

for i=1:size(list_mod.non,2)
    j=i;
    non_frr(:,j)=list_mod.(type)(i).all_info.sss_all.psth.CR_trial.psth_smooth((42:1551),2)/list_mod.(type)(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
end

non_psthavg=zeros(1510,3);
non_psthavg(:,1)=mean(non_frr,2);
non_psthavg(:,2)=std(non_frr,0,2);
for k=1:1510
    non_psthavg(k,3)=non_psthavg(k,2)/non_psthavg(k,1)*100;
    non_psthavg(k,4)=non_psthavg(k,1)+non_psthavg(k,3);
    non_psthavg(k,5)=non_psthavg(k,1)-non_psthavg(k,3);
end

smth=zeros(151,10);
smth(:,1)=-500:10:1000;
for m=1:151
    smth(m,2)=mean(fac_psthavg(10*(m-1)+1:10*m,1));
    smth(m,3)=mean(fac_psthavg(10*(m-1)+1:10*m,4));
    smth(m,4)=mean(fac_psthavg(10*(m-1)+1:10*m,5));
    smth(m,5)=mean(sup_psthavg(10*(m-1)+1:10*m,1));
    smth(m,6)=mean(sup_psthavg(10*(m-1)+1:10*m,4));
    smth(m,7)=mean(sup_psthavg(10*(m-1)+1:10*m,5));
    smth(m,8)=mean(non_psthavg(10*(m-1)+1:10*m,1));
    smth(m,9)=mean(non_psthavg(10*(m-1)+1:10*m,4));
    smth(m,10)=mean(non_psthavg(10*(m-1)+1:10*m,5)); 
end

smth2=zeros(151,10);
smth2(:,1)=smth(:,1);
smth2(:,2)=smooth(smth(:,2),3);
smth2(:,3)=smooth(smth(:,3),3);
smth2(:,4)=smooth(smth(:,4),3);
smth2(:,5)=smooth(smth(:,5),3);
smth2(:,6)=smooth(smth(:,6),3);
smth2(:,7)=smooth(smth(:,7),3);
smth2(:,8)=smooth(smth(:,8),3);
smth2(:,9)=smooth(smth(:,9),3);
smth2(:,10)=smooth(smth(:,10),3);


figure;
subplot(3,1,1)
plot(smth2(:,1),smth2(:,2),'r-','LineWidth',1.5)
hold on
plot(smth2(:,1),smth2(:,3),'Color',[0.5,0.5,0.5])
hold on
plot(smth2(:,1),smth2(:,4),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
ylim([50 250]);
line([0 0],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[50,250],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
text(-400,225,'n=46','Color','red','FontSize',12);
xticks([-500 0 250 500 1000]);

subplot(3,1,2)
plot(smth2(:,1),smth2(:,5),'b-','LineWidth',1.5)
hold on
plot(smth2(:,1),smth2(:,6),'Color',[0.5,0.5,0.5])
hold on
plot(smth2(:,1),smth2(:,7),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
ylim([-50 160]);
line([0 0],[-50,160],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[-50,160],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[-50,160],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
text(-400,135,'n=20','Color','blue','FontSize',12);
xticks([-500 0 250 500 1000]);

subplot(3,1,3)
plot(smth2(:,1),smth2(:,8),'k-','LineWidth',1.5)
hold on
plot(smth2(:,1),smth2(:,9),'Color',[0.5,0.5,0.5])
hold on
plot(smth2(:,1),smth2(:,10),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
ylim([0 200]);
line([0 0],[0,200],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0,200],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[0,200],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
text(-400,175,'n=147','Color','black','FontSize',12);
xticks([-500 0 250 500 1000]);


