% DTTD new list comb

TD_list_align=struct('cell_ID',[],'file_name',[],'Day',[],'cell_num',[],'CR_fac_D',[],'CR_sup_D',[],'UR_fac_D',[],'UR_sup_D',[],'mod_info_D',[],'all_info_D',[],...
              'align_info_D',[],'CR_fac_T',[],'CR_sup_T',[],'UR_fac_T',[],'UR_sup_T',[],'mod_info_T',[],'all_info_T',[],'align_info_T',[]);

for i=1:size(DT_list_comb,2)
    TD_list_align(i).cell_ID=i;
    TD_list_align(i).file_name=DT_list_comb(i).file_name;
    TD_list_align(i).Day=DT_list_comb(i).Day;
    TD_list_align(i).cell_num=DT_list_comb(i).cell_num;
    TD_list_align(i).CR_fac_T=delay_T(i).CR_fac;
    TD_list_align(i).CR_sup_T=delay_T(i).CR_sup;
    TD_list_align(i).UR_fac_T=delay_T(i).UR_fac;
    TD_list_align(i).UR_sup_T=delay_T(i).UR_sup;
    TD_list_align(i).mod_info_T=delay_T(i).mod_info;
    TD_list_align(i).all_info_T=delay_T(i).all_info;
    TD_list_align(i).align_info_T=delay_T(i).align_info;
    TD_list_align(i).CR_fac_D=delay_D(i).CR_fac;
    TD_list_align(i).CR_sup_D=delay_D(i).CR_sup;
    TD_list_align(i).UR_fac_D=delay_D(i).UR_fac;
    TD_list_align(i).UR_sup_D=delay_D(i).UR_sup;
    TD_list_align(i).mod_info_D=delay_D(i).mod_info;
    TD_list_align(i).all_info_D=delay_D(i).all_info;
    TD_list_align(i).align_info_D=delay_D(i).align_info; 
    
        
end