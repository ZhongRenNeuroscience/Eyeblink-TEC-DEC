% To detect the UR modulation type of each single neuron in the list_mod with consideration
% of CR modulation type. The peak and bottom firing frequency value are
% found first. If these values are larger or lower than 3*SD, a modulation
% event will be considered. The UR modulation magnitude and peak time are
% also calculated. The correlation of CR and UR modulation magnitude for
% fac-fac neurons is also calculated. --Zhong

f=1;
s=1;
ff=1;
fs=1;

for i=1:size(list_mod.fac,2)
    bsln=list_mod.fac(i).all_info.sss_all.psth.CR_trial.avg_frq;
    if list_mod.fac(i).UR_fac==1 && list_mod.fac(i).UR_sup==0
       fac_URmod(f,1)=list_mod.fac(i).mod_info.URf.t_peak;
       sss_ID=strfind({blk_sss.session_path},list_mod.fac(i).file_name);
       sss_field=find(~cellfun(@isempty,sss_ID));
       fac_URblk(f,1)=blk_sss(sss_field).UR_pkt;
       fac_URform(:,f)=list_mod.fac(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.fac(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
       fac_UR_ID(f,1)=list_mod.fac(i).cell_ID;
       if list_mod.fac(i).CR_fac > 1
           CR_fac=zeros(1,list_mod.fac(i).CR_fac);
           for k=1:list_mod.fac(i).CR_fac
           CR_fac(1,k)=(list_mod.fac(i).mod_info.CRf(k).peak-bsln)/bsln*100;
           end             
           ff_amp(ff,1)=max(CR_fac);
       else
           ff_amp(ff,1)=(list_mod.fac(i).mod_info.CRf(1).peak-bsln)/bsln*100;
       end
       ff_amp(ff,2)=(list_mod.fac(i).mod_info.URf.peak-bsln)/bsln*100;
       ff=ff+1;
       f=f+1;
    elseif list_mod.fac(i).UR_sup==1 && list_mod.fac(i).UR_fac==0
       sup_URmod(s,1)=list_mod.fac(i).mod_info.URs.t_peak;
       sss_ID=strfind({blk_sss.session_path},list_mod.fac(i).file_name);
       sss_field=find(~cellfun(@isempty,sss_ID));
       sup_URblk(s,1)=blk_sss(sss_field).UR_pkt;
       sup_URform(:,s)=list_mod.fac(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.fac(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
       sup_UR_ID(s,1)=list_mod.fac(i).cell_ID;
       if list_mod.fac(i).CR_fac > 1
           CR_fac=zeros(1,list_mod.fac(i).CR_fac);
           for k=1:list_mod.fac(i).CR_fac
               CR_fac(1,k)=(list_mod.fac(i).mod_info.CRf(k).peak-bsln)/bsln*100;
           end
           fs_amp(fs,1)=max(CR_fac);
       else
           fs_amp(fs,1)=(list_mod.fac(i).mod_info.CRf(1).peak-bsln)/bsln*100;
       end
       fs_amp(fs,2)=(list_mod.fac(i).mod_info.URs.peak-bsln)/bsln*100;
       fs=fs+1;
       s=s+1;
    elseif list_mod.fac(i).UR_fac==1 && list_mod.fac(i).UR_sup==1
       if list_mod.fac(i).mod_info.URf.t_peak < list_mod.fac(i).mod_info.URs.t_peak
          fac_URmod(f,1)=list_mod.fac(i).mod_info.URf.t_peak;
          sss_ID=strfind({blk_sss.session_path},list_mod.fac(i).file_name);
          sss_field=find(~cellfun(@isempty,sss_ID));
          fac_URblk(f,1)=blk_sss(sss_field).UR_pkt;
          fac_URform(:,f)=list_mod.fac(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.fac(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
          fac_UR_ID(f,1)=list_mod.fac(i).cell_ID;
           if list_mod.fac(i).CR_fac > 1
               CR_fac=zeros(1,list_mod.fac(i).CR_fac);
               for k=1:list_mod.fac(i).CR_fac
               CR_fac(1,k)=(list_mod.fac(i).mod_info.CRf(k).peak-bsln)/bsln*100;
               end             
               ff_amp(ff,1)=max(CR_fac);
           else
               ff_amp(ff,1)=(list_mod.fac(i).mod_info.CRf(1).peak-bsln)/bsln*100;
           end
           ff_amp(ff,2)=(list_mod.fac(i).mod_info.URf.peak-bsln)/bsln*100;
           ff=ff+1;
           f=f+1;
       else
          sup_URmod(s,1)=list_mod.fac(i).mod_info.URs.t_peak;
          sss_ID=strfind({blk_sss.session_path},list_mod.fac(i).file_name);
          sss_field=find(~cellfun(@isempty,sss_ID));
          sup_URblk(s,1)=blk_sss(sss_field).UR_pkt;
          sup_URform(:,s)=list_mod.fac(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.fac(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
          sup_UR_ID(s,1)=list_mod.fac(i).cell_ID;
           if list_mod.fac(i).CR_fac > 1
               CR_fac=zeros(1,list_mod.fac(i).CR_fac);
               for k=1:list_mod.fac(i).CR_fac
                   CR_fac(1,k)=(list_mod.fac(i).mod_info.CRf(k).peak-bsln)/bsln*100;
               end
               fs_amp(fs,1)=max(CR_fac);
           else
               fs_amp(fs,1)=(list_mod.fac(i).mod_info.CRf(1).peak-bsln)/bsln*100;
           end
           fs_amp(fs,2)=(list_mod.fac(i).mod_info.URs.peak-bsln)/bsln*100;
           fs=fs+1;
           s=s+1;
       end
    end
end

sf=1;
ss=1;
for i=1:size(list_mod.sup,2)
bsln=list_mod.sup(i).all_info.sss_all.psth.CR_trial.avg_frq;
    if list_mod.sup(i).UR_fac==1 && list_mod.sup(i).UR_sup==0
       fac_URmod(f,1)=list_mod.sup(i).mod_info.URf.t_peak;
       sss_ID=strfind({blk_sss.session_path},list_mod.sup(i).file_name);
       sss_field=find(~cellfun(@isempty,sss_ID));
       fac_URblk(f,1)=blk_sss(sss_field).UR_pkt;
       fac_URform(:,f)=list_mod.sup(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.sup(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
       fac_UR_ID(f,1)=list_mod.sup(i).cell_ID;
       if list_mod.sup(i).CR_sup > 1
           CR_sup=zeros(1,list_mod.sup(i).CR_sup);
           for k=1:list_mod.sup(i).CR_sup
               CR_sup(1,k)=(list_mod.sup(i).mod_info.CRs(k).peak-bsln)/bsln*100;
           end
           sf_amp(sf,1)=min(CR_sup);
       else
           sf_amp(sf,1)=(list_mod.sup(i).mod_info.CRs(1).peak-bsln)/bsln*100;
       end
       sf_amp(sf,2)=(list_mod.sup(i).mod_info.URf.peak-bsln)/bsln*100;
       sf=sf+1;       
       f=f+1;
    elseif list_mod.sup(i).UR_sup==1 && list_mod.sup(i).UR_fac==0
       sup_URmod(s,1)=list_mod.sup(i).mod_info.URs.t_peak;
       sss_ID=strfind({blk_sss.session_path},list_mod.sup(i).file_name);
       sss_field=find(~cellfun(@isempty,sss_ID));
       sup_URblk(s,1)=blk_sss(sss_field).UR_pkt;
       sup_URform(:,s)=list_mod.sup(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.sup(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
       sup_UR_ID(s,1)=list_mod.sup(i).cell_ID;
       if list_mod.sup(i).CR_sup > 1
           CR_sup=zeros(1,list_mod.sup(i).CR_sup);      
           for k=1:list_mod.sup(i).CR_sup
               CR_sup(1,k)=(list_mod.sup(i).mod_info.CRs(k).peak-bsln)/bsln*100;
           end
           ss_amp(ss,1)=min(CR_sup);
       else
           ss_amp(ss,1)=(list_mod.sup(i).mod_info.CRs(1).peak-bsln)/bsln*100;
       end
       ss_amp(ss,2)=(list_mod.sup(i).mod_info.URs.peak-bsln)/bsln*100;
       ss=ss+1;       
       s=s+1;
    elseif list_mod.sup(i).UR_fac==1 && list_mod.sup(i).UR_sup==1
       if list_mod.sup(i).mod_info.URf.t_peak < list_mod.sup(i).mod_info.URs.t_peak
          fac_URmod(f,1)=list_mod.sup(i).mod_info.URf.t_peak;
          sss_ID=strfind({blk_sss.session_path},list_mod.sup(i).file_name);
          sss_field=find(~cellfun(@isempty,sss_ID));
          fac_URblk(f,1)=blk_sss(sss_field).UR_pkt;
          fac_URform(:,f)=list_mod.sup(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.sup(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
          fac_UR_ID(f,1)=list_mod.sup(i).cell_ID;
           if list_mod.sup(i).CR_sup > 1
               CR_sup=zeros(1,list_mod.sup(i).CR_sup);
               for k=1:list_mod.sup(i).CR_sup
                   CR_sup(1,k)=(list_mod.sup(i).mod_info.CRs(k).peak-bsln)/bsln*100;
               end
               sf_amp(sf,1)=min(CR_sup);
           else
               sf_amp(sf,1)=(list_mod.sup(i).mod_info.CRs(1).peak-bsln)/bsln*100;
           end
          sf_amp(sf,2)=(list_mod.sup(i).mod_info.URf.peak-bsln)/bsln*100;
          sf=sf+1;
          f=f+1;
       else
          sup_URmod(s,1)=list_mod.sup(i).mod_info.URs.t_peak;
          sss_ID=strfind({blk_sss.session_path},list_mod.sup(i).file_name);
          sss_field=find(~cellfun(@isempty,sss_ID));
          sup_URblk(s,1)=blk_sss(sss_field).UR_pkt;
          sup_URform(:,s)=list_mod.sup(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.sup(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
          sup_UR_ID(s,1)=list_mod.sup(i).cell_ID;
           if list_mod.sup(i).CR_sup > 1
               CR_sup=zeros(1,list_mod.sup(i).CR_sup);      
               for k=1:list_mod.sup(i).CR_sup
                   CR_sup(1,k)=(list_mod.sup(i).mod_info.CRs(k).peak-bsln)/bsln*100;
               end
               ss_amp(ss,1)=min(CR_sup);
           else
               ss_amp(ss,1)=(list_mod.sup(i).mod_info.CRs(1).peak-bsln)/bsln*100;
           end
          ss_amp(ss,2)=(list_mod.sup(i).mod_info.URs.peak-bsln)/bsln*100;
          ss=ss+1; 
          s=s+1; 
       end
    end
end

for i=1:size(list_mod.non,2)
    if list_mod.non(i).UR_fac==1 && list_mod.non(i).UR_sup==0
       fac_URmod(f,1)=list_mod.non(i).mod_info.URf.t_peak;
       sss_ID=strfind({blk_sss.session_path},list_mod.non(i).file_name);
       sss_field=find(~cellfun(@isempty,sss_ID));
       fac_URblk(f,1)=blk_sss(sss_field).UR_pkt;
       fac_URform(:,f)=list_mod.non(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.non(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
       fac_UR_ID(f,1)=list_mod.non(i).cell_ID;
       f=f+1;
    elseif list_mod.non(i).UR_sup==1 && list_mod.non(i).UR_fac==0
       sup_URmod(s,1)=list_mod.non(i).mod_info.URs.t_peak;
       sss_ID=strfind({blk_sss.session_path},list_mod.non(i).file_name);
       sss_field=find(~cellfun(@isempty,sss_ID));
       sup_URblk(s,1)=blk_sss(sss_field).UR_pkt;
       sup_URform(:,s)=list_mod.non(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.non(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
       sup_UR_ID(s,1)=list_mod.non(i).cell_ID;
       s=s+1;
    elseif list_mod.non(i).UR_fac==1 && list_mod.non(i).UR_sup==1
       if list_mod.non(i).mod_info.URf.t_peak < list_mod.non(i).mod_info.URs.t_peak
          fac_URmod(f,1)=list_mod.non(i).mod_info.URf.t_peak;
          sss_ID=strfind({blk_sss.session_path},list_mod.non(i).file_name);
          sss_field=find(~cellfun(@isempty,sss_ID));
          fac_URblk(f,1)=blk_sss(sss_field).UR_pkt;
          fac_URform(:,f)=list_mod.non(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.non(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
          fac_UR_ID(f,1)=list_mod.non(i).cell_ID;
          f=f+1;
       else
          sup_URmod(s,1)=list_mod.non(i).mod_info.URs.t_peak;
          sss_ID=strfind({blk_sss.session_path},list_mod.non(i).file_name);
          sss_field=find(~cellfun(@isempty,sss_ID));
          sup_URblk(s,1)=blk_sss(sss_field).UR_pkt;
          sup_URform(:,s)=list_mod.non(i).all_info.sss_all.psth.CR_trial.psth_smooth((47:1551),2)/list_mod.non(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
          sup_UR_ID(s,1)=list_mod.non(i).cell_ID;
          s=s+1; 
       end
    end
end

fac_URdata(:,1)=mean(fac_URform,2);
fac_URdata(:,2)=std(fac_URform,0,2);
for j=1:1505
fac_URdata(j,3)=fac_URdata(j,2)/fac_URdata(j,1)*100;
fac_URdata(j,4)=fac_URdata(j,1)+fac_URdata(j,3);
fac_URdata(j,5)=fac_URdata(j,1)-fac_URdata(j,3);
end

sup_URdata(:,1)=mean(sup_URform,2);
sup_URdata(:,2)=std(sup_URform,0,2);
for j=1:1505
sup_URdata(j,3)=sup_URdata(j,2)/sup_URdata(j,1)*100;
sup_URdata(j,4)=sup_URdata(j,1)+sup_URdata(j,3);
sup_URdata(j,5)=sup_URdata(j,1)-sup_URdata(j,3);
end

for m=1:301
fac_URsmth(m,1)=mean(fac_URdata(5*(m-1)+1:5*m,1));
fac_URsmth(m,2)=mean(fac_URdata(5*(m-1)+1:5*m,4));
fac_URsmth(m,3)=mean(fac_URdata(5*(m-1)+1:5*m,5));
sup_URsmth(m,1)=mean(sup_URdata(5*(m-1)+1:5*m,1));
sup_URsmth(m,2)=mean(sup_URdata(5*(m-1)+1:5*m,4));
sup_URsmth(m,3)=mean(sup_URdata(5*(m-1)+1:5*m,5));
end

fac_URsmth(:,4)=smooth(fac_URsmth(:,1),3);
fac_URsmth(:,5)=smooth(fac_URsmth(:,2),3);
fac_URsmth(:,6)=smooth(fac_URsmth(:,3),3);
sup_URsmth(:,4)=smooth(sup_URsmth(:,1),3);
sup_URsmth(:,5)=smooth(sup_URsmth(:,2),3);
sup_URsmth(:,6)=smooth(sup_URsmth(:,3),3);

[R,P]=corrcoef(ff_amp(:,1),ff_amp(:,2));
p=polyfit(ff_amp(:,1),ff_amp(:,2),1);
regression=p(1)*ff_amp(:,1)+p(2);