% plot ifr_peak_shuffle.mat
file=DT_list_align;
all_info='all_info_D';
align_info='align_info_D';
t_post=250;
BinWidth=10;
cd D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\ifr_peak_shuffle_D\new_2

hist_output=struct('cell_ID',[],'fac_CS_align',[],'fac_CR_align',[],'fac_amp_1st',[],'fac_amp_2nd',[],'fac_time_1st',[],'fac_time_2nd',[],'fac_shf_1st',[],'fac_shf_2nd',[],...
                   'sup_CS_align',[],'sup_CR_align',[],'sup_amp_1st',[],'sup_amp_2nd',[],'sup_time_1st',[],'sup_time_2nd',[],'sup_shf_1st',[],'sup_shf_2nd',[]);

for i=1:size(isi_peak_shuffle,2)
    j=isi_peak_shuffle(i).cell_ID;
    hist_output(i).cell_ID=j;
    figure('units','normalized','outerposition',[0 0 1 1])
    subplot(4,4,1)
    CS_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    spk_on=nan(size(isi_peak_shuffle(i).trial_info,2)*2,1);
    k=0;
    [~,index] = sortrows([isi_peak_shuffle(i).trial_info.CR_onset].');
    isi_peak_shuffle(i).trial_info = isi_peak_shuffle(i).trial_info(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).trial_info,2)
        n=find([file(j).(all_info).ttt.CR_trial.trial_num]==isi_peak_shuffle(i).trial_info(m).trial_num);
        hold on
        Y=ones(length(file(j).(all_info).ttt.CR_trial(n).spk_time),1)*m;
        plot(file(j).(all_info).ttt.CR_trial(n).spk_time*1000,Y,'k.')
        hold on
        if ~isempty(isi_peak_shuffle(i).trial_info(m).fac_amp_1st)
           k=k+1;
           spk_on(k,1)=isi_peak_shuffle(i).trial_info(m).fac_amp_1st*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
           k=k+1;
           spk_on(k,1)=isi_peak_shuffle(i).trial_info(m).fac_amp_2nd*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
        end
        plot(0,m,'g.')
        hold on
        plot(file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000,m,'b.')
        hold on
        plot(t_post,m,'r.')     
        CR_on(m,1)=file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000;
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    ylabel('Trial number');
    title('CS onset align');
    
    subplot(4,4,5)
%     h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
%     h1.FaceColor = [0 1 0];
%     hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    spk_on = spk_on(~isnan(spk_on));
    h3=histogram(spk_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
    h3.FaceColor = [1 0 0.5];
    hold on    
    xlim([-250 750]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
%     bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
%     bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
%     bin_CS(2,:)=h1.BinCounts;
%     bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=[];
    CR_hist.bin=bin_CR;
    spk_hist=struct('raw',[],'bin',[]);
    bin_spk=zeros(3,size(h3.BinCounts,2));
    bin_spk(1,:)=h3.BinEdges(1,1:size(h3.BinCounts,2));
    bin_spk(2,:)=h3.BinCounts;
    bin_spk(3,:)=h3.BinCounts/size(h3.Data,1); 
    spk_hist.raw=spk_on;
    spk_hist.bin=bin_spk;
    comb=struct('CS_hist',[],'CR_hist',[],'spk_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    comb.spk_hist=spk_hist;
    hist_output(i).fac_CS_align=comb;
    
    subplot(4,4,2)
    CS_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    spk_on=nan(size(isi_peak_shuffle(i).trial_info,2)*2,1);
    k=0;
    for m=1:size(isi_peak_shuffle(i).trial_info,2)
        n=find([file(j).(all_info).ttt.CR_trial.trial_num]==isi_peak_shuffle(i).trial_info(m).trial_num);
        hold on
        Y=ones(length(file(j).(all_info).ttt.CR_trial(n).spk_time),1)*m;
        plot((file(j).(all_info).ttt.CR_trial(n).spk_time-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset)*1000,Y,'k.')
        hold on
        if ~isempty(isi_peak_shuffle(i).trial_info(m).fac_amp_1st)
           k=k+1;
           spk_on(k,1)=(isi_peak_shuffle(i).trial_info(m).fac_amp_1st-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset)*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
           k=k+1;
           spk_on(k,1)=(isi_peak_shuffle(i).trial_info(m).fac_amp_2nd-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset)*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
        end
        plot(-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000,m,'g.')
        hold on
        plot(0,m,'b.')
        hold on
        plot(t_post-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000,m,'r.')     
        CS_on(m,1)=-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('CR onset align');
    
    subplot(4,4,6)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
%     h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
%     h2.FaceColor = [0 0 1];
%     hold on
    spk_on = spk_on(~isnan(spk_on));
    h3=histogram(spk_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
    h3.FaceColor = [1 0 0.5];
    hold on  
    xlim([-500 500]);
    xticks(-500:250:500); 
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
%     bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
%     bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
%     bin_CR(2,:)=h2.BinCounts;
%     bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=[];
    spk_hist=struct('raw',[],'bin',[]);
    bin_spk=zeros(3,size(h3.BinCounts,2));
    bin_spk(1,:)=h3.BinEdges(1,1:size(h3.BinCounts,2));
    bin_spk(2,:)=h3.BinCounts;
    bin_spk(3,:)=h3.BinCounts/size(h3.Data,1); 
    spk_hist.raw=spk_on;
    spk_hist.bin=bin_spk;
    comb=struct('CS_hist',[],'CR_hist',[],'spk_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    comb.spk_hist=spk_hist;
    hist_output(i).fac_CR_align=comb;

    subplot(4,4,3)
    CS_on=zeros(size(isi_peak_shuffle(i).fac_amp_1st.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).fac_amp_1st.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).fac_amp_1st.Ctas.tss.t_align].');
    isi_peak_shuffle(i).fac_amp_1st.Ctas.tss = isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).fac_amp_1st.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on           
        plot(t_post-isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_align*1000,m,'r.')   
        CS_on(m,1)=-isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_amp_1st.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('1st facilitation peak align');
    
    subplot(4,4,7)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).fac_amp_1st=comb;    
    
    subplot(4,4,4)
    CS_on=zeros(size(isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss.t_align].');
    isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss = isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on           
        plot(t_post-isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_align*1000,m,'r.')   
        CS_on(m,1)=-isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_amp_2nd.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('2nd facilitation peak align');
    
    subplot(4,4,8)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).fac_amp_2nd=comb;    

    subplot(4,4,9)
    CS_on=zeros(size(isi_peak_shuffle(i).fac_time_1st.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).fac_time_1st.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).fac_time_1st.Ctas.tss.t_align].');
    isi_peak_shuffle(i).fac_time_1st.Ctas.tss = isi_peak_shuffle(i).fac_time_1st.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).fac_time_1st.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_time_1st.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('1st facilitation time align');
    
    subplot(4,4,13)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).fac_time_1st=comb;
    
    subplot(4,4,10)
    CS_on=zeros(size(isi_peak_shuffle(i).fac_time_2nd.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).fac_time_2nd.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).fac_time_2nd.Ctas.tss.t_align].');
    isi_peak_shuffle(i).fac_time_2nd.Ctas.tss = isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).fac_time_2nd.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_time_2nd.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('2nd facilitation time align');
    
    subplot(4,4,14)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).fac_time_2nd=comb;
    
    subplot(4,4,11)
    CS_on=zeros(size(isi_peak_shuffle(i).fac_shf_1st.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).fac_shf_1st.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).fac_shf_1st.Ctas.tss.t_align].');
    isi_peak_shuffle(i).fac_shf_1st.Ctas.tss = isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).fac_shf_1st.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_shf_1st.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('1st facilitation shuffle');
    
    subplot(4,4,15)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).fac_shf_1st=comb;
    
    subplot(4,4,12)
    CS_on=zeros(size(isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss.t_align].');
    isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss = isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).fac_shf_2nd.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('2nd facilitation shuffle');
    
    subplot(4,4,16)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).fac_shf_2nd=comb;
    
    saveas(gcf,['DT-fac' num2str(j) '-' num2str(file(j).CR_fac_T) '-' num2str(file(j).CR_sup_T) '.jpg']);  
    close all
    
    figure('units','normalized','outerposition',[0 0 1 1])
    subplot(4,4,1)
    CS_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    spk_on=nan(size(isi_peak_shuffle(i).trial_info,2)*2,1);
    k=0;
    [~,index] = sortrows([isi_peak_shuffle(i).trial_info.CR_onset].');
    isi_peak_shuffle(i).trial_info = isi_peak_shuffle(i).trial_info(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).trial_info,2)
        n=find([file(j).(all_info).ttt.CR_trial.trial_num]==isi_peak_shuffle(i).trial_info(m).trial_num);
        hold on
        Y=ones(length(file(j).(all_info).ttt.CR_trial(n).spk_time),1)*m;
        plot(file(j).(all_info).ttt.CR_trial(n).spk_time*1000,Y,'k.')
        hold on
        if ~isempty(isi_peak_shuffle(i).trial_info(m).sup_amp_1st)
           k=k+1;
           spk_on(k,1)=isi_peak_shuffle(i).trial_info(m).sup_amp_1st*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
           k=k+1;
           spk_on(k,1)=isi_peak_shuffle(i).trial_info(m).sup_amp_2nd*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
        end
        plot(0,m,'g.')
        hold on
        plot(file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000,m,'b.')
        hold on
        plot(t_post,m,'r.')     
        CR_on(m,1)=file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000;
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    ylabel('Trial number');
    title('CS onset align');
    
    subplot(4,4,5)
%     h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
%     h1.FaceColor = [0 1 0];
%     hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    spk_on = spk_on(~isnan(spk_on));
    h3=histogram(spk_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
    h3.FaceColor = [1 0 0.5];
    hold on  
    xlim([-250 750]);
    xticks(-250:250:750);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
%     bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
%     bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
%     bin_CS(2,:)=h1.BinCounts;
%     bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=[];
    CR_hist.bin=bin_CR;
    spk_hist=struct('raw',[],'bin',[]);
    bin_spk=zeros(3,size(h3.BinCounts,2));
    bin_spk(1,:)=h3.BinEdges(1,1:size(h3.BinCounts,2));
    bin_spk(2,:)=h3.BinCounts;
    bin_spk(3,:)=h3.BinCounts/size(h3.Data,1); 
    spk_hist.raw=spk_on;
    spk_hist.bin=bin_spk;
    comb=struct('CS_hist',[],'CR_hist',[],'spk_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    comb.spk_hist=spk_hist;
    hist_output(i).sup_CS_align=comb;
    
    subplot(4,4,2)
    CS_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).trial_info,2),1);
    spk_on=nan(size(isi_peak_shuffle(i).trial_info,2)*2,1);
    k=0;
    for m=1:size(isi_peak_shuffle(i).trial_info,2)
        n=find([file(j).(all_info).ttt.CR_trial.trial_num]==isi_peak_shuffle(i).trial_info(m).trial_num);
        hold on
        Y=ones(length(file(j).(all_info).ttt.CR_trial(n).spk_time),1)*m;
        plot((file(j).(all_info).ttt.CR_trial(n).spk_time-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset)*1000,Y,'k.')
        hold on
        if ~isempty(isi_peak_shuffle(i).trial_info(m).sup_amp_1st)
           k=k+1;
           spk_on(k,1)=(isi_peak_shuffle(i).trial_info(m).sup_amp_1st-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset)*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
           k=k+1;
           spk_on(k,1)=(isi_peak_shuffle(i).trial_info(m).sup_amp_2nd-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset)*1000;
           plot(spk_on(k,1),m,'m.')
           hold on
        end
        plot(-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000,m,'g.')
        hold on
        plot(0,m,'b.')
        hold on
        plot(t_post-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000,m,'r.')     
        CS_on(m,1)=-file(j).(all_info).ttt.CR_trial(n).blk_info_new.CR_onset*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('CR onset align');
    
    subplot(4,4,6)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
%     h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
%     h2.FaceColor = [0 0 1];
%     hold on
    spk_on = spk_on(~isnan(spk_on));
    h3=histogram(spk_on,'BinWidth',BinWidth,'BinLimits',[-250,750],'Normalization','probability');
    h3.FaceColor = [1 0 0.5];
    hold on  
    xlim([-500 500]);
    xticks(-500:250:500);   
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
%     bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
%     bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
%     bin_CR(2,:)=h2.BinCounts;
%     bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=[];
    spk_hist=struct('raw',[],'bin',[]);
    bin_spk=zeros(3,size(h3.BinCounts,2));
    bin_spk(1,:)=h3.BinEdges(1,1:size(h3.BinCounts,2));
    bin_spk(2,:)=h3.BinCounts;
    bin_spk(3,:)=h3.BinCounts/size(h3.Data,1); 
    spk_hist.raw=spk_on;
    spk_hist.bin=bin_spk;
    comb=struct('CS_hist',[],'CR_hist',[],'spk_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    comb.spk_hist=spk_hist;
    hist_output(i).sup_CR_align=comb;

    subplot(4,4,3)
    CS_on=zeros(size(isi_peak_shuffle(i).sup_amp_1st.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).sup_amp_1st.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).sup_amp_1st.Ctas.tss.t_align].');
    isi_peak_shuffle(i).sup_amp_1st.Ctas.tss = isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).sup_amp_1st.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on           
        plot(t_post-isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_align*1000,m,'r.')   
        CS_on(m,1)=-isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_amp_1st.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('1st suppression trough align');
    
    subplot(4,4,7)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).sup_amp_1st=comb;    

    subplot(4,4,4)
    CS_on=zeros(size(isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss.t_align].');
    isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss = isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on           
        plot(t_post-isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_align*1000,m,'r.')   
        CS_on(m,1)=-isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_amp_2nd.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('2nd suppression trough align');
    
    subplot(4,4,8)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).sup_amp_2nd=comb;    
    
    subplot(4,4,9)
    CS_on=zeros(size(isi_peak_shuffle(i).sup_time_1st.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).sup_time_1st.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).sup_time_1st.Ctas.tss.t_align].');
    isi_peak_shuffle(i).sup_time_1st.Ctas.tss = isi_peak_shuffle(i).sup_time_1st.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).sup_time_1st.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_time_1st.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('1st suppresion time align');
    
    subplot(4,4,13)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).sup_time_1st=comb;
    
    subplot(4,4,10)
    CS_on=zeros(size(isi_peak_shuffle(i).sup_time_2nd.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).sup_time_2nd.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).sup_time_2nd.Ctas.tss.t_align].');
    isi_peak_shuffle(i).sup_time_2nd.Ctas.tss = isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).sup_time_2nd.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_time_2nd.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('2nd suppresion time align');
    
    subplot(4,4,14)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).sup_time_2nd=comb;
    
    subplot(4,4,11)
    CS_on=zeros(size(isi_peak_shuffle(i).sup_shf_1st.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).sup_shf_1st.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).sup_shf_1st.Ctas.tss.t_align].');
    isi_peak_shuffle(i).sup_shf_1st.Ctas.tss = isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).sup_shf_1st.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_shf_1st.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('1st suppresion shuffle');    
    
    subplot(4,4,15)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).sup_shf_1st=comb;
    
    subplot(4,4,12)
    CS_on=zeros(size(isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss,2),1);
    CR_on=zeros(size(isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss,2),1);
    [~,index] = sortrows([isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss.t_align].');
    isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss = isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(index);
    clear index;
    for m=1:size(isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss,2)
        hold on
        Y=ones(length(isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t),1)*m;
        plot(isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t*1000,Y,'k.')
        hold on
        plot(-isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_align*1000,m,'g.')
        hold on
        plot((isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_align)*1000,m,'b.')
        hold on  
        plot(t_post-isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_align*1000,m,'r.')          
        CS_on(m,1)=-isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_align*1000;
        CR_on(m,1)=(isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_onset-isi_peak_shuffle(i).sup_shf_2nd.Ctas.tss(m).t_align)*1000;
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    ylabel('Trial number');
    title('2nd suppresion shuffle');      
    
    subplot(4,4,16)
    h1=histogram(CS_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h1.FaceColor = [0 1 0];
    hold on
    h2=histogram(CR_on,'BinWidth',BinWidth,'BinLimits',[-500,500],'Normalization','probability');
    h2.FaceColor = [0 0 1];
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    xlabel('Time(ms)');
    ylabel('Probability');
    CS_hist=struct('raw',[],'bin',[]);
    CR_hist=struct('raw',[],'bin',[]);    
    bin_CS=zeros(3,size(h1.BinCounts,2));
    bin_CR=zeros(3,size(h2.BinCounts,2));
    CS_hist.raw=CS_on;
    CR_hist.raw=CR_on;
    bin_CS(1,:)=h1.BinEdges(1,1:size(h1.BinCounts,2));
    bin_CS(2,:)=h1.BinCounts;
    bin_CS(3,:)=h1.BinCounts/size(h1.Data,1);
    bin_CR(1,:)=h2.BinEdges(1,1:size(h2.BinCounts,2));
    bin_CR(2,:)=h2.BinCounts;
    bin_CR(3,:)=h2.BinCounts/size(h2.Data,1);    
    CS_hist.bin=bin_CS;
    CR_hist.bin=bin_CR;
    comb=struct('CS_hist',[],'CR_hist',[]);
    comb.CS_hist=CS_hist;
    comb.CR_hist=CR_hist;
    hist_output(i).sup_shf_2nd=comb;
    
    saveas(gcf,['DT-sup' num2str(j) '-' num2str(file(j).CR_fac_D) '-' num2str(file(j).CR_sup_D) '.jpg']);  
    close all
    
%     figure('units','normalized','outerposition',[0 0 1 1])
%     subplot(2,1,1)
%     plot(file(j).(align_info).psth_ex(:,1),file(j).(align_info).psth_ex(:,2),'k-')
%     hold on
%     plot(file(j).(align_info).psth_align(:,1),file(j).(align_info).psth_align(:,2),'b-')
%     hold on
%     plot(isi_peak_shuffle(i).fac_amp.psth.Gau_psth_shft(:,1),isi_peak_shuffle(i).fac_amp.psth.Gau_psth_shft(:,2),'r-')
%     hold on
%     plot(isi_peak_shuffle(i).fac_time.psth.Gau_psth_shft(:,1),isi_peak_shuffle(i).fac_time.psth.Gau_psth_shft(:,2),'m-')
%     hold on
%     plot(isi_peak_shuffle(i).fac_shf_1st.psth.Gau_psth_shft(:,1),isi_peak_shuffle(i).fac_shf_1st.psth.Gau_psth_shft(:,2),'y-')
%     hold on
%     plot(isi_peak_shuffle(i).fac_shf_2nd.psth.Gau_psth_shft(:,1),isi_peak_shuffle(i).fac_shf_2nd.psth.Gau_psth_shft(:,2),'Color',[1 0.67 0],'LineStyle','-')
%     hold on    
    
    
end