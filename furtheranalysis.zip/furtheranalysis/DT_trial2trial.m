%Trial to trial analysis

pack=DT_list;
all_info='all_info_T';
t_find=480;
tf=1;
ts=1;
df=1;
ds=1;
amp_thr=2;

ttt_fac_T=struct('cell_ID',[],'ttt',[],'R',[],'P',[]);
% first loop for each cell
for i=1:size(pack,2)
%     for facilitation neurons
    if pack(i).CR_fac_T > 0 && pack(i).CR_fac_D > 0
       ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
       ttt=zeros(ttt_sz,4);
%        second loop for each trial
       for j=1:ttt_sz
           if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > amp_thr
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
              ttt(j,3)=max(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100; 
              if ttt(j,3)==Inf || ttt(j,3)>3000
                 ttt(j,3)=NaN;
              end
           else 
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=NaN;
              ttt(j,3)=NaN;     
           end
       end       
        ttt(any(isnan(ttt),2),:) = [];
        
        tr_num=size(ttt,1);
        md=mod(tr_num,2);
        ttt_new=ttt((tr_num+md)/2:tr_num,:);
        
        [R,P]=corrcoef(ttt_new(:,3),ttt_new(:,2));
        p=polyfit(ttt_new(:,3),ttt_new(:,2),1);
        regression=p(1)*ttt_new(:,3)+p(2);
        ttt_fac_T(tf).R=R(1,2);
        ttt_fac_T(tf).P=P(1,2);
        ttt_new(:,4)=regression;

        ttt_fac_T(tf).cell_ID=pack(i).cell_ID;
        ttt_fac_T(tf).ttt=ttt_new;
        tf=tf+1;
    end
end


ttt_sup_T=struct('cell_ID',[],'ttt',[],'R',[],'P',[]);
% first loop for each cell
for i=1:size(pack,2)
%     for facilitation neurons
    if pack(i).CR_sup_T > 0 && pack(i).CR_sup_D > 0
       ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
       ttt=zeros(ttt_sz,4);
%        second loop for each trial
       for j=1:ttt_sz
           if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > amp_thr
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
              ttt(j,3)=min(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100;   
           else 
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=NaN;
              ttt(j,3)=NaN;     
           end
       end       
        ttt(any(isnan(ttt),2),:) = [];
        
        tr_num=size(ttt,1);
        md=mod(tr_num,2);
        ttt_new=ttt((tr_num+md)/2:tr_num,:);
        
        [R,P]=corrcoef(ttt_new(:,3),ttt_new(:,2));
        p=polyfit(ttt_new(:,3),ttt_new(:,2),1);
        regression=p(1)*ttt_new(:,3)+p(2);
        ttt_sup_T(ts).R=R(1,2);
        ttt_sup_T(ts).P=P(1,2);
        ttt_new(:,4)=regression;

        ttt_sup_T(ts).cell_ID=pack(i).cell_ID;
        ttt_sup_T(ts).ttt=ttt_new;
        ts=ts+1;
    end
end

% for delay part
all_info='all_info_D';
t_find=230;

ttt_fac_D=struct('cell_ID',[],'ttt',[],'R',[],'P',[]);
% first loop for each cell
for i=1:size(pack,2)
%     for facilitation neurons
    if pack(i).CR_fac_T > 0 && pack(i).CR_fac_D > 0
       ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
       ttt=zeros(ttt_sz,4);
%        second loop for each trial
       for j=1:ttt_sz
           if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > amp_thr
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
              ttt(j,3)=max(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100;   
              if ttt(j,3)==Inf || ttt(j,3)>3000
                 ttt(j,3)=NaN;
              end
           else 
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=NaN;
              ttt(j,3)=NaN;     
           end
       end       
        ttt(any(isnan(ttt),2),:) = [];
        [R,P]=corrcoef(ttt(:,3),ttt(:,2));
        p=polyfit(ttt(:,3),ttt(:,2),1);
        regression=p(1)*ttt(:,3)+p(2);
        ttt_fac_D(df).R=R(1,2);
        ttt_fac_D(df).P=P(1,2);
        ttt(:,4)=regression;

        ttt_fac_D(df).cell_ID=pack(i).cell_ID;
        ttt_fac_D(df).ttt=ttt;
        df=df+1;
    end
end


ttt_sup_D=struct('cell_ID',[],'ttt',[],'R',[],'P',[]);
% first loop for each cell
for i=1:size(pack,2)
%     for facilitation neurons
    if pack(i).CR_sup_T > 0 && pack(i).CR_sup_D > 0
       ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
       ttt=zeros(ttt_sz,4);
%        second loop for each trial
       for j=1:ttt_sz
           if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > amp_thr
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
              ttt(j,3)=min(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100;        
           else 
              ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
              ttt(j,2)=NaN;
              ttt(j,3)=NaN;     
           end
       end       
        ttt(any(isnan(ttt),2),:) = [];    
        [R,P]=corrcoef(ttt(:,3),ttt(:,2));
        p=polyfit(ttt(:,3),ttt(:,2),1);
        regression=p(1)*ttt(:,3)+p(2);
        ttt_sup_D(ds).R=R(1,2);
        ttt_sup_D(ds).P=P(1,2);
        ttt(:,4)=regression;

        ttt_sup_D(ds).cell_ID=pack(i).cell_ID;
        ttt_sup_D(ds).ttt=ttt;
        ds=ds+1;
    end
end

clear i j tf ts df ds P R p regression ttt_sz ttt t_find pack all_info


% [R,P]=corrcoef(ttt_fac_D(11).ttt(:,3),ttt_fac_D(11).ttt(:,2));
% p=polyfit(ttt_fac_D(11).ttt(:,3),ttt_fac_D(11).ttt(:,2),1);
% regression=p(1)*ttt_fac_D(11).ttt(:,3)+p(2);
% ttt_fac_D(11).R=R(1,2);
% ttt_fac_D(11).P=P(1,2);
% ttt_fac_D(11).ttt(:,4)=regression;
% ttt_fac_D(11).ttt=ttt_fac_D(11).ttt;