file=DT_list_align;


peak_all=zeros(size(file,2),3);
bottom_all=zeros(size(file,2),3);

for i=1:size(file,2)
    peak_D=max(file(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(801:900,2))/file(i).all_info_D.sss_all.psth.CR_trial.avg_frq*100-100;
    bottom_D=(1-min(file(i).all_info_D.sss_all.psth.CR_trial.psth_smooth(801:900,2))/file(i).all_info_D.sss_all.psth.CR_trial.avg_frq)*100;
    peak_T=max(file(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(1051:1150,2))/file(i).all_info_T.sss_all.psth.CR_trial.avg_frq*100-100;
    bottom_T=(1-min(file(i).all_info_T.sss_all.psth.CR_trial.psth_smooth(1051:1150,2))/file(i).all_info_T.sss_all.psth.CR_trial.avg_frq)*100;    
    
    peak_all(i,1)=peak_D;
    peak_all(i,2)=peak_T;
    bottom_all(i,1)=bottom_D;
    bottom_all(i,2)=bottom_T;
    
    peak_all(i,3)=file(i).UR_fac_D+file(i).UR_fac_T;
    bottom_all(i,3)=file(i).UR_sup_D+file(i).UR_sup_T;
       
end

figure;

subplot(1,2,1)
hold on
for j=1:size(peak_all,1)
   if peak_all(j,3)==2
       plot(peak_all(j,1),peak_all(j,2),'k.')
       hold on
   elseif peak_all(j,3)==1
       plot(peak_all(j,1),peak_all(j,2),'.','Color',[0.5 0.5 0.5])
       hold on
   end
end
xlim([0 300]);
ylim([0 300]);
line([0 300],[0 300],'LineStyle','--');
xlabel('Relative UR facilitation Delay (%)');
ylabel('Relative UR facilitation Trace (%)');

subplot(1,2,2)
for j=1:size(bottom_all,1)
   if bottom_all(j,3)==2
       plot(bottom_all(j,1),bottom_all(j,2),'k.')
       hold on
   elseif bottom_all(j,3)==1
       plot(bottom_all(j,1),bottom_all(j,2),'.','Color',[0.5 0.5 0.5])
       hold on
   end
end
xlim([0 100]);
ylim([0 100]);
line([0 100],[0 100],'LineStyle','--');
xlabel('Relative UR suppression Delay (%)');
ylabel('Relative UR suppression Trace (%)');
    
