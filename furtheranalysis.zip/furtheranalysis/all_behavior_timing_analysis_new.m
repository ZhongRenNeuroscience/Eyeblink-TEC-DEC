% behavior onset peak analysis


% for a=1:size(list_mod.fac,2)
%     pack(a)=list_mod.fac(a);
% end
% for b=1:size(list_mod.sup,2)
%     pack(a+b)=list_mod.sup(b);
% end
% for c=1:size(list_mod.non,2)
%     pack(a+b+c)=list_mod.non(c);
% end

pack=delay_list_2021;
t_post=250;
velocity_curve_bin=10;
slope_cal_range=[0.1 0.9];
CR_onset_v_thrd=0.002;
CR_onset_amp_thrd=0.05;

[d,id]=findgroups({pack.file_name});
all_info='all_info';

blk_sss_delay=struct('session_num',[],'session_path',[],'behavior_info',[],'CR_onset',[],'CR_pkt',[],'UR_pkt',[],'CR_250',[],...
    'CR_num',[],'tr_num',[],'CR_per',[],'CR_amp',[],'CR_slope',[],'CR_velocity',[],'CR_t_pk_v',[],'behavior_curve',[],'velocity_curve',[],...
    'behavior_curve_trial',[],'CR_onset_v',[],'CR_onset_amp',[]);

for i=1:max(d)
    extract=strfind({pack.file_name},id(i));
    file=find(~cellfun(@isempty,extract));
    blk_sss_delay(i).session_num=i;
    blk_sss_delay(i).session_path=char(id(i));
    behavior_info=zeros(size(pack(file(1)).(all_info).ttt.CR_trial,2),11);
    behavior_curve_trial_raw=zeros(1550,size(pack(file(1)).(all_info).ttt.CR_trial,2));
    velocity_curve_trial_raw=zeros(1550/velocity_curve_bin,size(pack(file(1)).(all_info).ttt.CR_trial,2));
    behavior_curve_trial=struct('trial_num',[],'blk_curve',[],'velocity_curve',[]);
    behavior_curve=zeros(1550,2);
    behavior_curve(:,1)=-550:1:999;
    velocity_curve=zeros(1550/velocity_curve_bin,2);
    for j=1:size(pack(file(1)).(all_info).ttt.CR_trial,2)
        behavior_info(j,1)=j;
        if pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset > 0
            behavior_info(j,2)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            behavior_info(j,3)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
            behavior_info(j,4)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.UR_peaktime;
            behavior_info(j,5)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(801,2)*100;
            behavior_info(j,6)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            if isempty(slope_cal_range)
                if behavior_info(j,3)-behavior_info(j,2)>0
                   behavior_info(j,7)=behavior_info(j,6)/(behavior_info(j,3)-behavior_info(j,2));
                else
                   behavior_info(j,7)=NaN;
                end
            else
                if behavior_info(j,3)-behavior_info(j,2)>0
                   amp_idx_1=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*slope_cal_range(1);
                   amp_idx_2=pack(file(1)).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*slope_cal_range(2); 
                   [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2),[0 t_post],[amp_idx_1 amp_idx_1],1);
                   [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,1),pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2),[0 t_post],[amp_idx_2 amp_idx_2],1);
                   if length(inter_t_1)>1
                       [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-behavior_info(j,2)));
                       inter_amp_1=inter_amp_1(inter_t_1_idx);
                   end
                   if isempty(inter_t_1)
                       inter_t_1=NaN;
                       inter_amp_1=NaN;
                   end
                   if length(inter_t_2)>1
                       inter_t_2=inter_t_2(1);
                       inter_amp_2=inter_amp_2(1);
                   end 
                   if isempty(inter_t_2)
                       inter_t_2=NaN;
                       inter_amp_2=NaN;
                   end
                   behavior_info(j,7)=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
                else
                   behavior_info(j,7)=NaN;
                end                                                
            end
            behavior_curve_trial_raw(:,j)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(:,2);
            behavior_curve_trial(j).trial_num=j;
            behavior_curve_trial(j).blk_curve=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth;
            velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
            for k=1:1550/velocity_curve_bin
                k_1=(k-1)*velocity_curve_bin+1;
                k_2=k*velocity_curve_bin;
                velocity_curve_trial(k,1)=pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_1,1)+velocity_curve_bin/2;
                velocity_curve_trial(k,2)=(pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_2,2)-pack(file(1)).(all_info).ttt.CR_trial(j).blk_smth(k_1,2))/velocity_curve_bin;          
            end
            behavior_curve_trial(j).velocity_curve=velocity_curve_trial;
            velocity_curve_trial_raw(:,j)=velocity_curve_trial(:,2);
            if j==1
                t_idx=find(velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<t_post);
                velocity_curve(:,1)=velocity_curve_trial(:,1);
            end
            [behavior_info(j,8),idx_t_max_velocity]=max(velocity_curve_trial(t_idx,2));
            behavior_info(j,9)=velocity_curve_trial(t_idx(1)+idx_t_max_velocity-1,1);
            
            t_50=find(velocity_curve_trial(:,1)<=50,1,'last');
            t_end=find(velocity_curve_trial(:,1)<=t_post,1,'last');
            t_onset_v=find(velocity_curve_trial(t_50+1:t_end,2)>=CR_onset_v_thrd,1,'first');
            if ~isempty(t_onset_v)
                behavior_info(j,10)=velocity_curve_trial(t_50+t_onset_v,1);    
            else
                behavior_info(j,10)=NaN;
            end
            
            t_50=find(behavior_curve_trial(j).blk_curve(:,1)<=50,1,'last');
            t_end=find(behavior_curve_trial(j).blk_curve(:,1)<=t_post,1,'last');
            t_onset_amp=find(behavior_curve_trial(j).blk_curve(t_50+1:t_end,2)>=CR_onset_amp_thrd,1,'first');
            if ~isempty(t_onset_amp)
                behavior_info(j,11)=behavior_curve_trial(j).blk_curve(t_50+t_onset_amp,1);    
            else
                behavior_info(j,11)=NaN;
            end            
            
        else
            behavior_info(j,2)=NaN;
            behavior_info(j,3)=NaN;
            behavior_info(j,4)=NaN;
            behavior_info(j,5)=NaN;
            behavior_info(j,6)=NaN;
            behavior_info(j,7)=NaN;
            behavior_info(j,8)=NaN;
            behavior_info(j,9)=NaN;
            behavior_info(j,10)=NaN;
        end

        
    end
    behavior_curve(:,2)=mean(behavior_curve_trial_raw,2);
    velocity_curve(:,2)=mean(velocity_curve_trial_raw,2);
    blk_sss_delay(i).behavior_info=behavior_info;
    blk_sss_delay(i).CR_onset=nanmean(behavior_info(:,2));
    blk_sss_delay(i).CR_pkt=nanmean(behavior_info(:,3));
    blk_sss_delay(i).UR_pkt=nanmean(behavior_info(:,4));
    blk_sss_delay(i).CR_250=nanmean(behavior_info(:,5));
    blk_sss_delay(i).CR_amp=nanmean(behavior_info(:,6));
    blk_sss_delay(i).CR_num=size(pack(file(1)).(all_info).ttt(1).CR_trial,2);
    blk_sss_delay(i).tr_num=size(pack(file(1)).(all_info).ttt(1).CR_trial,2)+size(pack(file(1)).(all_info).ttt(1).nonCR_trial,2);
    blk_sss_delay(i).CR_per=blk_sss_delay(i).CR_num/blk_sss_delay(i).tr_num*100;
    blk_sss_delay(i).CR_slope=nanmean(behavior_info(:,7));
    blk_sss_delay(i).CR_velocity=nanmean(behavior_info(:,8));
    blk_sss_delay(i).CR_t_pk_v=nanmean(behavior_info(:,9));
    blk_sss_delay(i).CR_onset_v=nanmean(behavior_info(:,10));
    blk_sss_delay(i).CR_onset_amp=nanmean(behavior_info(:,11));
    blk_sss_delay(i).behavior_curve=behavior_curve;
    blk_sss_delay(i).velocity_curve=velocity_curve;
    blk_sss_delay(i).behavior_curve_trial=behavior_curve_trial;
end
clear i j behavior_info package