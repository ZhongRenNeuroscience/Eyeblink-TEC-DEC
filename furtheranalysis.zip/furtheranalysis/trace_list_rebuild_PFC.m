% CR onset alignment and PSTH calculation/plot

file=trace_list_mPFC;
t_post=500;
t_pre=550;
t_psth=1050;
onset_thrd=0.1;
all_info='all_info';
figure_name='Trace';
cd 'D:\Mimo\mPFC_trace\CR_aligned_figure'
Trace_T=struct('cell_ID',[],'file_name',[],'cell_num',[],'channel_info',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[],'align_info',[],'non_info',[]);
ymin_psth_plot=25;
ymax_psth_plot=150;

for i=1:size(file,2)
    mod_info=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
    all_information=struct('sss_all',[],'ttt',[]);
    
    Trace_T(i).cell_ID=file(i).cell_ID;
    Trace_T(i).file_name=file(i).file_name;
    Trace_T(i).cell_num=file(i).cell_num;
    Trace_T(i).channel_info=file(i).channel_info;
    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[]);
    Ctas.cell=1;
    blk_all=NaN(1550,size(file(i).(all_info).ttt.CR_trial,2));
    k=1;
    
    non_idx=size(file(i).(all_info).ttt.nonCR_trial,2);
    exclude_idx=0;
%     file(i).(all_info).ttt.CR_trial = file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.spk_time}));
    for j=1:size(file(i).(all_info).ttt.CR_trial,2)
        if file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp>=0.1 && file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset>0.05
           t_start=file(i).(all_info).ttt.CR_trial(1).blk_smth(1,1);
           CR_onset_fix=find(file(i).(all_info).ttt.CR_trial(j).blk_smth(-t_start+51:-t_start+t_post,2)>=onset_thrd,1,'first')+49;
           file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset=CR_onset_fix/1000;
           tss(k).trial=file(i).(all_info).ttt.CR_trial(j).trial_num;
           tss(k).t=file(i).(all_info).ttt.CR_trial(j).spk_time;
           blk_all(:,k)=file(i).(all_info).ttt.CR_trial(j).blk_smth(:,2);
           k=k+1;
        elseif file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp<=0.05
           non_idx=non_idx+1;
           file(i).(all_info).ttt.nonCR_trial(non_idx).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
           file(i).(all_info).ttt.nonCR_trial(non_idx).cs_lc=file(i).(all_info).ttt.CR_trial(j).cs_lc;
           file(i).(all_info).ttt.nonCR_trial(non_idx).blk_info=file(i).(all_info).ttt.CR_trial(j).blk_info;
           file(i).(all_info).ttt.nonCR_trial(non_idx).spk_time=file(i).(all_info).ttt.CR_trial(j).spk_time;
           file(i).(all_info).ttt.nonCR_trial(non_idx).ifr_smooth=file(i).(all_info).ttt.CR_trial(j).ifr_smooth;
           file(i).(all_info).ttt.nonCR_trial(non_idx).blk_smth=file(i).(all_info).ttt.CR_trial(j).blk_smth;
           file(i).(all_info).ttt.nonCR_trial(non_idx).blk_info_new=file(i).(all_info).ttt.CR_trial(j).blk_info_new;    
           file(i).(all_info).ttt.CR_trial(j).trial_num=[];
        else
           exclude_idx=exclude_idx+1;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).cs_lc=file(i).(all_info).ttt.CR_trial(j).cs_lc;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).blk_info=file(i).(all_info).ttt.CR_trial(j).blk_info;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).spk_time=file(i).(all_info).ttt.CR_trial(j).spk_time;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).ifr_smooth=file(i).(all_info).ttt.CR_trial(j).ifr_smooth;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).blk_smth=file(i).(all_info).ttt.CR_trial(j).blk_smth;
           file(i).(all_info).ttt.exclude_trial(exclude_idx).blk_info_new=file(i).(all_info).ttt.CR_trial(j).blk_info_new;                
           file(i).(all_info).ttt.CR_trial(j).trial_num=[];
        end
    end
    Ctas.tss=tss;  
%     file(i).(all_info).ttt.CR_trial=file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.trial_num}));
    [~,index] = sortrows([file(i).(all_info).ttt.nonCR_trial.trial_num].'); 
    file(i).(all_info).ttt.nonCR_trial = file(i).(all_info).ttt.nonCR_trial(index); 
    clear index
    
    ttt=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[],'exclude_trial',[]);
    ttt.CR_trial=file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.trial_num}));
    ttt.nonCR_trial=file(i).(all_info).ttt.nonCR_trial;
    ttt.probe_trial=file(i).(all_info).ttt.probe_trial;
    if isfield(file(i).(all_info).ttt,'exclude_trial')
       ttt.exclude_trial=file(i).(all_info).ttt.exclude_trial;
    end
    spk_CR_Gau=spk_Gaussian(Ctas,t_pre,t_psth,20,6);
    psth_CR_Gau=Gau_psth_cal(spk_CR_Gau,t_pre,t_psth,0);
    mod_CR=modulation_type(t_pre-50,t_post,psth_CR_Gau,3,10);
    
    Ctas_ex=struct('cell',[],'tss',[]);
    Ctas_align=struct('cell',[],'tss',[]);
    Ctas_ex.tss=struct('trial',[],'t',[],'onset',[]);
    Ctas_align.tss=struct('trial',[],'t',[]);
    tttCR_ex=ttt.CR_trial;
    Ctas_ex.cell=1; 
    Ctas_align.cell=1;
    n=1;
    for m=1:size(tttCR_ex,2)
        if tttCR_ex(m).blk_info_new.CR_onset<=t_post/1000*0.9
           Ctas_ex.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_align.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_ex.tss(n).t=tttCR_ex(m).spk_time;
           Ctas_align.tss(n).t=tttCR_ex(m).spk_time-tttCR_ex(m).blk_info_new.CR_onset;
           Ctas_ex.tss(n).onset=tttCR_ex(m).blk_info_new.CR_onset;
           n=n+1;
        else
           tttCR_ex(m).trial_num=[]; 
        end        
    end
    tttCR_ex=tttCR_ex(~cellfun(@isempty,{tttCR_ex.trial_num}));
%     if size(tttCR_ex,2)<20
%        tttCR_ex=[];
%     end

    Ntas=struct('cell',[],'tss',[]);
    Ntas.tss=struct('trial',[],'t',[],'onset',[]);
    ttt_nonCR=ttt.nonCR_trial;
    Ntas.cell=1; 
    n=1;
    for m=1:size(ttt_nonCR,2)
        Ntas.tss(n).trial=ttt_nonCR(m).trial_num;
        Ntas.tss(n).t=ttt_nonCR(m).spk_time;
        Ntas.tss(n).onset=0;
        n=n+1;     
    end


    spk_CR_Gau_ex=spk_Gaussian(Ctas_ex,t_pre,t_psth,20,6);
    psth_CR_Gau_ex=Gau_psth_cal(spk_CR_Gau_ex,t_pre,t_psth,0);
    mod_CR_ex=modulation_type(t_pre-50,t_post,psth_CR_Gau_ex,3,10);    
    spk_CR_Gau_align=spk_Gaussian(Ctas_align,550,550,20,6);
    psth_CR_Gau_align=Gau_psth_cal(spk_CR_Gau_align,550,550,0);
    spk_nonCR_Gau=spk_Gaussian(Ntas,t_pre,t_psth,20,6);
    psth_nonCR_Gau=Gau_psth_cal(spk_nonCR_Gau,t_pre,t_psth,0);
    mod_nonCR=modulation_type(t_pre-50,t_post,psth_nonCR_Gau,3,10);    
    
    align_info=struct('bsl_frq_ex',[],'SD_ex',[],'psth_ex',[],'psth_align',[],'CR_fac',[],'CR_sup',[],'t_start',[],'t_end',[]);
    align_info.bsl_frq_ex=mod_CR_ex.bsl_frq;
    align_info.SD_ex=mod_CR_ex.SD;
    align_info.psth_ex=psth_CR_Gau_ex.Gau_psth_shft;
    align_info.psth_align=psth_CR_Gau_align.Gau_psth_shft;
    if isempty(mod_CR_ex.fac_mginfo(1).t_onset)
       align_info.CR_fac=[];
    else
       align_info.CR_fac=mod_CR_ex.fac_mginfo;
    end
    if isempty(mod_CR_ex.sup_mginfo(1).t_onset)
       align_info.CR_sup=[];
    else
       align_info.CR_sup=mod_CR_ex.sup_mginfo;
    end    
    align_info.t_start=min([Ctas_ex.tss.onset])*1000;
    align_info.t_end=max([Ctas_ex.tss.onset])*1000;
%     align_info.ttt_ex=tttCR_ex;
    Trace_T(i).align_info=align_info;
    
    non_info=struct('bsl_frq',[],'SD',[],'psth',[],'CR_fac',[],'CR_sup',[]);
    non_info.bsl_frq=mod_nonCR.bsl_frq;
    non_info.SD=mod_nonCR.SD;
    non_info.psth=psth_nonCR_Gau.Gau_psth_shft;
    if isempty(mod_nonCR.fac_mginfo(1).t_onset)
       non_info.CR_fac=[];
    else
       non_info.CR_fac=mod_nonCR.fac_mginfo;
    end
    if isempty(mod_nonCR.sup_mginfo(1).t_onset)
       non_info.CR_sup=[];
    else
       non_info.CR_sup=mod_nonCR.sup_mginfo;
    end    
    Trace_T(i).non_info=non_info;
    
    Trace_T(i).CR_fac=mod_CR.fac_merge;
    Trace_T(i).CR_sup=mod_CR.sup_merge;
    if mod_CR.fac_merge>0
       mod_info.CRf=mod_CR.fac_mginfo;
    end
    if mod_CR.sup_merge>0
       mod_info.CRs=mod_CR.sup_mginfo; 
    end
    if mod_CR.ur_fac==0
       Trace_T(i).UR_fac=0;
       Trace_T(i).mod_info.URf=[];
    else
       Trace_T(i).UR_fac=1;
       mod_info.URf.t_peak=mod_CR.ur_fpkt;
       mod_info.URf.peak=mod_CR.ur_fac;
    end
    if mod_CR.ur_sup==0
       Trace_T(i).UR_sup=0;
       mod_info.URs=[];
    else
       Trace_T(i).UR_sup=1;
       mod_info.URs.t_peak=mod_CR.ur_spkt;
       mod_info.URs.peak=mod_CR.ur_sup;
    end
    Trace_T(i).mod_info=mod_info;
    
    blk_sss_CR=zeros(1550,2);
    blk_sss_CR(:,1)=-550:1:999;
    blk_sss_CR(:,2)=nanmean(blk_all,2);
    file(i).(all_info).sss_all.blk.CR_trial_new=blk_sss_CR;
    psth_sss_CR=struct('avg_frq',[],'test_frq',[],'SD',[],'psth_raw',[],'psth_smooth',[]);
    psth_sss_CR.avg_frq=mod_CR.bsl_frq;
    psth_sss_CR.test_frq=mod_CR.test_frq;
    psth_sss_CR.SD=mod_CR.SD;
    psth_sss_CR.psth_raw=psth_CR_Gau.Gau_psth_org;
    psth_sss_CR.psth_smooth=psth_CR_Gau.Gau_psth_shft;
    file(i).(all_info).sss_all.psth.CR_trial=psth_sss_CR;
    sss_all=struct('blk',[],'behavior',[],'psth',[]);
    sss_all.blk=file(i).(all_info).sss_all.blk;
    sss_all.behavior=file(i).(all_info).sss_all.behavior;
    sss_all.psth=file(i).(all_info).sss_all.psth;
    all_information.sss_all=sss_all;
    all_information.ttt=ttt;
    
    Trace_T(i).all_info=all_information;
end

% raster_psth_plot(Trace_T,figure_name,t_post,ymin_psth_plot,ymax_psth_plot);