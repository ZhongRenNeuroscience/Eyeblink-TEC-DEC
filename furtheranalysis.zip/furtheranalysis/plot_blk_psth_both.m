% Plot the analysis results of seperating trials in one recording session
% into early and late CR onset from 'early_late_onset_sep_new'. --Zhong

figure;    
    for m=1:20
    subplot(4,5,m)
    plot(sps_trial(m).early_blk(51:1550,1),sps_trial(m).early_blk(51:1550,2)*100,'c-')
    hold on
    plot(sps_trial(m).late_blk(51:1550,1),sps_trial(m).late_blk(51:1550,2)*100,'m-')
    hold on
    plot(sps_trial(m).early_psth(51:1550,1),sps_trial(m).early_psth(51:1550,2),'c-')
    hold on
    plot(sps_trial(m).late_psth(51:1550,1),sps_trial(m).late_psth(51:1550,2),'m-')
    hold on 
    xlim([-500 1000]);
    ylim([-10 300]);
    xlabel('Time (ms)');
    ylabel({'Firing rate (%)';'Eyelid (%)'});
    title(['PC-' num2str(m) ' ' num2str(sps_form(m).t)]);
    line([0 0],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[-10, 300],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    
    figure;    
    for m=21:40
    subplot(4,5,m-20)
    plot(sps_trial(m).early_blk(51:1550,1),sps_trial(m).early_blk(51:1550,2)*100,'c-')
    hold on
    plot(sps_trial(m).late_blk(51:1550,1),sps_trial(m).late_blk(51:1550,2)*100,'m-')
    hold on
    plot(sps_trial(m).early_psth(51:1550,1),sps_trial(m).early_psth(51:1550,2),'c-')
    hold on
    plot(sps_trial(m).late_psth(51:1550,1),sps_trial(m).late_psth(51:1550,2),'m-')
    hold on 
    xlim([-500 1000]);
    ylim([-10 250]);
    xlabel('Time (ms)');
    ylabel({'Firing rate (%)';'Eyelid (%)'});
    title(['PC-' num2str(m) ' ' num2str(sps_form(m).t)]);
    line([0 0],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[-10, 300],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    
    figure;
    for m=41:57
    subplot(4,5,m-40)
    plot(sps_trial(m).early_blk(51:1550,1),sps_trial(m).early_blk(51:1550,2)*100,'c-')
    hold on
    plot(sps_trial(m).late_blk(51:1550,1),sps_trial(m).late_blk(51:1550,2)*100,'m-')
    hold on
    plot(sps_trial(m).early_psth(51:1550,1),sps_trial(m).early_psth(51:1550,2),'c-')
    hold on
    plot(sps_trial(m).late_psth(51:1550,1),sps_trial(m).late_psth(51:1550,2),'m-')
    hold on 
    xlim([-500 1000]);
    ylim([-10 250]);
    xlabel('Time (ms)');
    ylabel({'Firing rate (%)';'Eyelid (%)'});
    title(['PC-' num2str(m) ' ' num2str(sps_form(m).t)]);
    line([0 0],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[-10, 300],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    
%     figure;    
%     for m=1:20
%     subplot(5,5,m)
%     plot(sup_trial(m).early_blk(1001:31000,1),sup_trial(m).early_blk(1001:31000,2)*100,'c-')
%     hold on
%     plot(sup_trial(m).late_blk(1001:31000,1),sup_trial(m).late_blk(1001:31000,2)*100,'m-')
%     hold on
%     plot(sup_trial(m).early_psth(1001:31000,1),sup_trial(m).early_psth(1001:31000,3),'c-')
%     hold on
%     plot(sup_trial(m).late_psth(1001:31000,1),sup_trial(m).late_psth(1001:31000,3),'m-')
%     hold on 
%     xlim([-500 1000]);
%     ylim([-10 250]);
%     xlabel('Time (ms)');
%     ylabel({'Firing rate (%)';'Eyelid (%)'});
%     title(['Sup-' num2str(m)]);
%     line([0 0],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
%     line([250 250],[-10, 300],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
%     line([500 500],[-10, 300],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
%     end
%     

%     num=33;
%     type='Fac';
%     smth_form=zeros(61,9);
%     for i=1:61
%         smth_form(i,1)=(i-1)*10-100;
%         smth_form(i,2)=mean(fac_trial(num).early_psth(441+10*i-9:441+10*i,2));
%         smth_form(i,3)=mean(fac_trial(num).late_psth(441+10*i-9:441+10*i,2));
%         smth_form(i,4)=mean(fac_trial(num).early_blk(441+10*i-9:441+10*i,2))*100;
%         smth_form(i,5)=mean(fac_trial(num).late_blk(441+10*i-9:441+10*i,2))*100;
%     end
%     
%     smth_form(:,6)=smooth(smth_form(:,2),3);
%     smth_form(:,7)=smooth(smth_form(:,3),3);
%     smth_form(:,8)=smooth(smth_form(:,4),3);
%     smth_form(:,9)=smooth(smth_form(:,5),3);
%     
%     figure;
%     subplot(2,1,1)
%     plot(smth_form(:,1),smth_form(:,8),'c-')
%     hold on
%     plot(smth_form(:,1),smth_form(:,9),'m-')
%     hold on
%     ylabel('Eyelid closure (%)');
%     xticks([0 250 500]);
%     title([type '-' num2str(num)]);
%     
%     subplot(2,1,2)
%     stairs(smth_form(:,1),smth_form(:,6),'c-')
%     hold on
%     stairs(smth_form(:,1),smth_form(:,7),'m-')
%     hold on
%     xlabel('Time (ms)');
%     ylabel('Relative firing rate (%)');
%     legend({'Early onset','Late onset'},'Location','southeast');
%     xticks([0 250 500]);
%     
%     num=11;
%     type='Sup';
%     smth_form=zeros(61,9);
%     for i=1:61
%         smth_form(i,1)=(i-1)*10-100;
%         smth_form(i,2)=mean(sup_trial(num).early_psth(441+10*i-9:441+10*i,2));
%         smth_form(i,3)=mean(sup_trial(num).late_psth(441+10*i-9:441+10*i,2));
%         smth_form(i,4)=mean(sup_trial(num).early_blk(441+10*i-9:441+10*i,2))*100;
%         smth_form(i,5)=mean(sup_trial(num).late_blk(441+10*i-9:441+10*i,2))*100;
%     end
%     
%     smth_form(:,6)=smooth(smth_form(:,2),3);
%     smth_form(:,7)=smooth(smth_form(:,3),3);
%     smth_form(:,8)=smooth(smth_form(:,4),3);
%     smth_form(:,9)=smooth(smth_form(:,5),3);
%     
%     figure;
%     subplot(2,1,1)
%     plot(smth_form(:,1),smth_form(:,8),'c-')
%     hold on
%     plot(smth_form(:,1),smth_form(:,9),'m-')
%     hold on
%     ylabel('Eyelid closure (%)');
%     xticks([0 250 500]);
%     title([type '-' num2str(num)]);
%     
%     subplot(2,1,2)
%     stairs(smth_form(:,1),smth_form(:,6),'c-')
%     hold on
%     stairs(smth_form(:,1),smth_form(:,7),'m-')
%     hold on
%     xlabel('Time (ms)');
%     ylabel('Relative firing rate (%)');
%     legend({'Early onset','Late onset'},'Location','southeast');
%     xticks([0 250 500]);
%     
