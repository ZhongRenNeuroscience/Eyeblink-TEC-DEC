file_name_1='_delay_probe.mat';
file_name_2='_trace500_probe.mat';
form_name='behavior_form_prb';
legend_name_1='DEC';
% legend_name_2={'TEC750'};
legend_name_2={'1st 25%','2nd 25%','3rd 25%','4th 25%'};

color_1=[1 0.5 0];
color_2=[0 0 0];
trial_num_split=4;

listing=dir(['*' file_name_1]);

for i=1:size(listing,1)
    form_1=load(listing(i).name);
    name_match=extractBefore(listing(i).name,file_name_1);
    form_2=load([name_match file_name_2]);
    
    figure;
    
    for j=1:size(form_1.(form_name),2)
        smth_curve=smooth_curve(form_1.(form_name)(j).blk_trace(:,1),form_1.(form_name)(j).blk_trace(:,2)*100,20,5);
        if j==size(form_1.(form_name),2)
            plot(smth_curve(:,1),smth_curve(:,2),'Color',color_1,'LineWidth',2,'DisplayName',legend_name_1)
            hold on        
%         else
%             plot(smth_curve(:,1),smth_curve(:,2),'Color',color_1,'LineWidth',0.3)
%             hold on              
        end
    end
    
    
    trial_group=quantile(1:size(form_2.(form_name),2)-1,trial_num_split-1);
    trial_group=[0 floor(trial_group(1:trial_num_split-1)) size(form_2.(form_name),2)-1];
 
    for k=1:length(trial_group)-1
        color=color_2+[0.25 0.25 0.25]*(k-1);
        curve_all=zeros(size(form_2.(form_name)(1).blk_trace,1),trial_group(k+1)-trial_group(k));
        for j=trial_group(k)+1:trial_group(k+1)
            curve_all(:,j-trial_group(k))=form_2.(form_name)(j).blk_trace(:,2);
            smth_curve=smooth_curve(form_2.(form_name)(j).blk_trace(:,1),form_2.(form_name)(j).blk_trace(:,2)*100,20,5);            
%             plot(smth_curve(:,1),smth_curve(:,2),'Color',color,'LineWidth',0.3)
%             hold on              
        end    
        smth_curve=smooth_curve(form_2.(form_name)(1).blk_trace(:,1),mean(curve_all,2)*100,20,5);            
        plot(smth_curve(:,1),smth_curve(:,2),'Color',color,'LineWidth',2,'DisplayName',legend_name_2{1,k})
        hold on               
    end
    xlim([-250 1000]);
    xticks(-250:250:1000);
    ylim([-10 100]);
    yticks(0:25:100);
    ylabel('Time (ms)');
    ylabel('Eyelid closure (%)');
%     legend
    
    title(name_match,'Interpreter','none');
%     saveas(gcf,[name_match '_eyelid closure curve.pdf']);
%     close all
end




function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end