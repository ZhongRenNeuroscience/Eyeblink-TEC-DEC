% plot trial to trial analysis results of 'trial2trial' code. Red,
% facilitation; blue suppression; solid, with significance; light, no
% significance.  --Zhong

j=0;
figure;

for i=1:size(ttt_fac,2)
    if ttt_fac(i).P < 0.05
       plot (ttt_fac(i).ttt(:,3),ttt_fac(i).ttt(:,4),'r-')
       hold on
       j=j+1;
    else
       plot (ttt_fac(i).ttt(:,3),ttt_fac(i).ttt(:,4),'Color',[1 0.75 0.75],'LineStyle','-')
       hold on
    end
end

xlim([0 1500]);
ylim([0 50]);
xticks(0:250:1500);
yticks(0:10:50);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');



% figure;
% 
% for i=1:size(ttt_fac,2)
%     if ttt_fac(i).R < 0
%         if ttt_fac(i).P < 0.05
%            plot (ttt_fac(i).ttt(:,3),ttt_fac(i).ttt(:,4),'r-')
%            hold on
%         else
%            plot (ttt_fac(i).ttt(:,3),ttt_fac(i).ttt(:,4),'Color',[1 0.75 0.75],'LineStyle','-')
%            hold on
%         end
%     end
% end
% 
% xlim([0 1500]);
% ylim([0 60]);
% xticks(0:250:1500);
% yticks(0:10:60);
% xlabel('Mod change (%)');
% ylabel('CR amplitude (%)');
% 
figure;

for i=1:size(ttt_sup,2)
    if ttt_sup(i).P < 0.05
       plot (-ttt_sup(i).ttt(:,3),ttt_sup(i).ttt(:,4),'b-')
       hold on
    else
       plot (-ttt_sup(i).ttt(:,3),ttt_sup(i).ttt(:,4),'Color',[0.75 0.75 1],'LineStyle','-')
       hold on
    end
end

xlim([20 100]);
ylim([0 50]);
xticks(20:10:100);
yticks(0:10:50);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');

% num=1;
% plot(ttt_fac(num).ttt(:,3),ttt_fac(num).ttt(:,2),'r.')
% hold on
% plot(ttt_fac(num).ttt(:,3),ttt_fac(num).ttt(:,4),'r-')
% % 
% num=1;
% plot(ttt_sup(num).ttt(:,3),ttt_sup(num).ttt(:,2),'b.')
% hold on
% plot(ttt_sup(num).ttt(:,3),ttt_sup(num).ttt(:,4),'b-')
