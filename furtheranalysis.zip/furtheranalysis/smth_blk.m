% A patch for previous code to smooth the eyelid behavior curve into 1 ms temporal resolusion.
% --Zhong
pack=pack;
all_info='all_info_T';
t_isi=500;

for i=1:size(pack,2)
    for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
        blk_smooth=zeros(1550,2);
        blk_smooth(:,1)=-550:1:999;
        for k=1:1550
            blk_smooth(k,2)=mean(pack(i).(all_info).ttt.CR_trial(j).blk_trace((20*k-19):20*k,4));
        end
        pack(i).(all_info).ttt.CR_trial(j).blk_smth=blk_smooth;
        
        bsl=mean(blk_smooth(51:550,2));
        sd=std(blk_smooth(51:550,2));
        thr=bsl+6*sd;
        [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi,2));
        CR_pkt=CR_pkt+49;
        if CR_amp > thr
           CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
           CR_on=CR_on+49;
        else
           CR_on=0;
           CR_amp=0;
           CR_pkt=0;
        end
        [UR_amp,UR_pkt]=max(blk_smooth(551+t_isi:700+t_isi,2));
        UR_pkt=UR_pkt+t_isi-1;
        
        blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
        blk_info_new.CR_onset=CR_on/1000;
        blk_info_new.CR_amp=CR_amp;
        blk_info_new.CR_peaktime=CR_pkt/1000;
        blk_info_new.UR_peaktime=UR_pkt;
        pack(i).(all_info).ttt.CR_trial(j).blk_info_new=blk_info_new;
    end

    for j=1:size(pack(i).(all_info).ttt.nonCR_trial,2)
        blk_smooth=zeros(1550,2);
        blk_smooth(:,1)=-550:1:999;
        for k=1:1550
            blk_smooth(k,2)=mean(pack(i).(all_info).ttt.nonCR_trial(j).blk_trace((20*k-19):20*k,4));
        end
        pack(i).(all_info).ttt.nonCR_trial(j).blk_smth=blk_smooth;
        
        bsl=mean(blk_smooth(51:550,2));
        sd=std(blk_smooth(51:550,2));
        thr=bsl+6*sd;
        [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi,2));
        CR_pkt=CR_pkt+49;
        if CR_amp > thr
           CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
           CR_on=CR_on+49;
        else
           CR_on=0;
           CR_amp=0;
           CR_pkt=0;
        end
        [UR_amp,UR_pkt]=max(blk_smooth(551+t_isi:700+t_isi,2));
        UR_pkt=UR_pkt+t_isi-1;
        
        blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
        blk_info_new.CR_onset=CR_on/1000;
        blk_info_new.CR_amp=CR_amp;
        blk_info_new.CR_peaktime=CR_pkt/1000;
        blk_info_new.UR_peaktime=UR_pkt;
        pack(i).(all_info).ttt.nonCR_trial(j).blk_info_new=blk_info_new;
    end
    
%     for j=1:size(pack(i).(all_info).ttt.CH_trial,2)
%         blk_smooth=zeros(1550,2);
%         blk_smooth(:,1)=-550:1:999;
%         for k=1:1550
%             blk_smooth(k,2)=mean(pack(i).(all_info).ttt.CH_trial(j).blk_trace((20*k-19):20*k,4));
%         end
%         pack(i).(all_info).ttt.CH_trial(j).blk_smth=blk_smooth;
%         
%         bsl=mean(blk_smooth(51:550,2));
%         sd=std(blk_smooth(51:550,2));
%         thr=bsl+6*sd;
%         [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi,2));
%         CR_pkt=CR_pkt+49;
%         if CR_amp > thr
%            CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
%            CR_on=CR_on+49;
%         else
%            CR_on=0;
%            CR_amp=0;
%            CR_pkt=0;
%         end
%         [UR_amp,UR_pkt]=max(blk_smooth(551+t_isi:700+t_isi,2));
%         UR_pkt=UR_pkt+t_isi-1;
%         
%         blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
%         blk_info_new.CR_onset=CR_on/1000;
%         blk_info_new.CR_amp=CR_amp;
%         blk_info_new.CR_peaktime=CR_pkt/1000;
%         blk_info_new.UR_peaktime=UR_pkt;
%         pack(i).(all_info).ttt.CH_trial(j).blk_info_new=blk_info_new;
%     end    
% 
%     for j=1:size(pack(i).(all_info).ttt.CL_trial,2)
%         blk_smooth=zeros(1550,2);
%         blk_smooth(:,1)=-550:1:999;
%         for k=1:1550
%             blk_smooth(k,2)=mean(pack(i).(all_info).ttt.CL_trial(j).blk_trace((20*k-19):20*k,4));
%         end
%         pack(i).(all_info).ttt.CL_trial(j).blk_smth=blk_smooth;
%         
%         bsl=mean(blk_smooth(51:550,2));
%         sd=std(blk_smooth(51:550,2));
%         thr=bsl+6*sd;
%         [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi,2));
%         CR_pkt=CR_pkt+49;
%         if CR_amp > thr
%            CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
%            CR_on=CR_on+49;
%         else
%            CR_on=0;
%            CR_amp=0;
%            CR_pkt=0;
%         end
%         [UR_amp,UR_pkt]=max(blk_smooth(551+t_isi:700+t_isi,2));
%         UR_pkt=UR_pkt+t_isi-1;
%         
%         blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
%         blk_info_new.CR_onset=CR_on/1000;
%         blk_info_new.CR_amp=CR_amp;
%         blk_info_new.CR_peaktime=CR_pkt/1000;
%         blk_info_new.UR_peaktime=UR_pkt;
%         pack(i).(all_info).ttt.CL_trial(j).blk_info_new=blk_info_new;
%     end      
    
    for j=1:size(pack(i).(all_info).ttt.probe_trial,2)
        blk_smooth=zeros(1550,2);
        blk_smooth(:,1)=-550:1:999;
        for k=1:1550
            blk_smooth(k,2)=mean(pack(i).(all_info).ttt.probe_trial(j).blk_trace((20*k-19):20*k,4));
        end
        pack(i).(all_info).ttt.probe_trial(j).blk_smth=blk_smooth;
        
        bsl=mean(blk_smooth(51:550,2));
        sd=std(blk_smooth(51:550,2));
        thr=bsl+6*sd;
        [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi+250,2));
        CR_pkt=CR_pkt+49;
        if CR_amp > thr
           CR_on=find(blk_smooth(601:550+t_isi+250,2) >= thr,1,'first');
           CR_on=CR_on+49;
           if CR_on >= t_isi+250
              CR_on=0;
              CR_amp=0;
              CR_pkt=0;
           end
        else
           CR_on=0;
           CR_amp=0;
           CR_pkt=0;
        end
        UR_pkt=0;
        
        blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
        blk_info_new.CR_onset=CR_on/1000;
        blk_info_new.CR_amp=CR_amp;
        blk_info_new.CR_peaktime=CR_pkt/1000;
        blk_info_new.UR_peaktime=UR_pkt;
        pack(i).(all_info).ttt.probe_trial(j).blk_info_new=blk_info_new;
    end
    
end

% all_info='all_info_D';
% t_isi=250;
% 
% for i=1:size(pack,2)
%     if isempty(pack(i).(all_info))
%         continue
%     end
%     for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
%         blk_smooth=zeros(1550,2);
%         blk_smooth(:,1)=-550:1:999;
%         for k=1:1550
%             blk_smooth(k,2)=mean(pack(i).(all_info).ttt.CR_trial(j).blk_trace((20*k-19):20*k,4));
%         end
%         pack(i).(all_info).ttt.CR_trial(j).blk_smth=blk_smooth;
%         
%         bsl=mean(blk_smooth(51:550,2));
%         sd=std(blk_smooth(51:550,2));
%         thr=bsl+6*sd;
%         [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi,2));
%         CR_pkt=CR_pkt+49;
%         if CR_amp > thr
%            CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
%            CR_on=CR_on+49;           
%         else
%            CR_on=0;
%            CR_amp=0;
%            CR_pkt=0;
%         end
%         [UR_amp,UR_pkt]=max(blk_smooth(551+t_isi:700+t_isi,2));
%         UR_pkt=UR_pkt+t_isi-1;
%         
%         blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
%         blk_info_new.CR_onset=CR_on/1000;
%         blk_info_new.CR_amp=CR_amp;
%         blk_info_new.CR_peaktime=CR_pkt/1000;
%         blk_info_new.UR_peaktime=UR_pkt;
%         pack(i).(all_info).ttt.CR_trial(j).blk_info_new=blk_info_new;
%     end
%     
%     for j=1:size(pack(i).(all_info).ttt.probe_trial,2)
%         blk_smooth=zeros(1550,2);
%         blk_smooth(:,1)=-550:1:999;
%         for k=1:1550
%             blk_smooth(k,2)=mean(pack(i).(all_info).ttt.probe_trial(j).blk_trace((20*k-19):20*k,4));
%         end
%         pack(i).(all_info).ttt.probe_trial(j).blk_smth=blk_smooth;
%         
%         bsl=mean(blk_smooth(51:550,2));
%         sd=std(blk_smooth(51:550,2));
%         thr=bsl+6*sd;
%         [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi+250,2));
%         CR_pkt=CR_pkt+49;
%         if CR_amp > thr
%            CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
%            CR_on=CR_on+49;
%            if CR_on >= t_isi+250
%               CR_on=0;
%               CR_amp=0;
%               CR_pkt=0;
%            end
%         else
%            CR_on=0;
%            CR_amp=0;
%            CR_pkt=0;
%         end
%         UR_pkt=0;
%         
%         blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
%         blk_info_new.CR_onset=CR_on/1000;
%         blk_info_new.CR_amp=CR_amp;
%         blk_info_new.CR_peaktime=CR_pkt/1000;
%         blk_info_new.UR_peaktime=UR_pkt;
%         pack(i).(all_info).ttt.probe_trial(j).blk_info_new=blk_info_new;
%     end
% end
    
% all_info='all_info_D2';
% t_isi=250;
% 
% for i=1:size(pack,2)
%     if isempty(pack(i).(all_info))
%         continue
%     end
%     for j=1:size(pack(i).(all_info).ttt.CR_trial,2)
%         blk_smooth=zeros(1550,2);
%         blk_smooth(:,1)=-550:1:999;
%         for k=1:1550
%             blk_smooth(k,2)=mean(pack(i).(all_info).ttt.CR_trial(j).blk_trace((20*k-19):20*k,4));
%         end
%         pack(i).(all_info).ttt.CR_trial(j).blk_smth=blk_smooth;
%         
%         bsl=mean(blk_smooth(51:550,2));
%         sd=std(blk_smooth(51:550,2));
%         thr=bsl+6*sd;
%         [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi,2));
%         CR_pkt=CR_pkt+49;
%         if CR_amp > thr
%            CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
%            CR_on=CR_on+49;           
%         else
%            CR_on=0;
%            CR_amp=0;
%            CR_pkt=0;
%         end
%         [UR_amp,UR_pkt]=max(blk_smooth(551+t_isi:700+t_isi,2));
%         UR_pkt=UR_pkt+t_isi-1;
%         
%         blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
%         blk_info_new.CR_onset=CR_on/1000;
%         blk_info_new.CR_amp=CR_amp;
%         blk_info_new.CR_peaktime=CR_pkt/1000;
%         blk_info_new.UR_peaktime=UR_pkt;
%         pack(i).(all_info).ttt.CR_trial(j).blk_info_new=blk_info_new;
%     end
%     
%     for j=1:size(pack(i).(all_info).ttt.probe_trial,2)
%         blk_smooth=zeros(1550,2);
%         blk_smooth(:,1)=-550:1:999;
%         for k=1:1550
%             blk_smooth(k,2)=mean(pack(i).(all_info).ttt.probe_trial(j).blk_trace((20*k-19):20*k,4));
%         end
%         pack(i).(all_info).ttt.probe_trial(j).blk_smth=blk_smooth;
%         
%         bsl=mean(blk_smooth(51:550,2));
%         sd=std(blk_smooth(51:550,2));
%         thr=bsl+6*sd;
%         [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_isi+250,2));
%         CR_pkt=CR_pkt+49;
%         if CR_amp > thr
%            CR_on=find(blk_smooth(601:550+t_isi,2) >= thr,1,'first');
%            CR_on=CR_on+49;
%            if CR_on >= t_isi+250
%               CR_on=0;
%               CR_amp=0;
%               CR_pkt=0;
%            end
%         else
%            CR_on=0;
%            CR_amp=0;
%            CR_pkt=0;
%         end
%         UR_pkt=0;
%         
%         blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[]);
%         blk_info_new.CR_onset=CR_on/1000;
%         blk_info_new.CR_amp=CR_amp;
%         blk_info_new.CR_peaktime=CR_pkt/1000;
%         blk_info_new.UR_peaktime=UR_pkt;
%         pack(i).(all_info).ttt.probe_trial(j).blk_info_new=blk_info_new;
%     end
%     
% end