file=pack;

loco_session=struct('session_ID',[],'mouse_ID',[],'loco_per',[],'avg_loco',[]);

for i=1:size(file,2)
    
    loco_session(i).session_ID=file(i).file_name; 
    loco_session(i).loco_per=size(file(i).all_info.ttt(1).CH_trial,2)/size(file(i).all_info.ttt(1).CR_trial,2)*100;
    loco_session(i).avg_loco=mean([file(i).all_info.ttt(1).CH_trial.avg_velo]);
    
end