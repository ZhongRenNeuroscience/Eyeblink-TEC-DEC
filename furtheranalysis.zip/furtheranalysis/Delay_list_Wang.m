% Delay list rebuild for Xiaolu's data
t_interval=250;
t_pre=500;
t_psth=1050;
figure_name='Delay';
file_name='blkpack';
Delay_Wang=struct('cell_ID',[],'file_name',[],'cell_num',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[],'align_info',[]);
ymin_psth_plot=25;
ymax_psth_plot=150;

LIST = dir(['D:\Intan_data\package\' '*' file_name '*']);
for i=1:size(LIST,1)
    load(['D:\Intan_data\package\' LIST(i).name]);
    Delay_Wang(i).cell_ID=i;
    Delay_Wang(i).file_name=LIST(i).name;
    Delay_Wang(i).cell_num=1;
    
    mod_info=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
    all_info=struct('sss_all',[],'ttt',[]);    
    align_info=struct('bsl_frq_ex',[],'SD_ex',[],'psth_ex',[],'psth_align',[],'CR_fac',[],'CR_sup',[],'t_start',[],'t_end',[]);
    sss_all=struct('blk',[],'behavior',[],'psth',[]);
    sss_all.psth=struct('CR_trial',[],'nonCR_trial',[]);
    ttt=struct('CR_trial',[],'nonCR_trial',[]);
    Ctas=struct('cell',[],'tss',[]);
    Ctas.cell=1;
    blk_all=NaN(1550,size(blk_pack.TTT.tss_CR,2));
    k=1;    
    ttt.CR_trial=struct('trial_num',[],'blk_smth',[],'blk_info_new',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    ttt.nonCR_trial=struct('trial_num',[],'blk_smth',[],'blk_info_new',[],'spk_time',[],'ifr_org_Gau',[],'ifr_smooth',[]);
    UR_amp_list=struct('UR_amp_value',[]);
    UR_idx=0;
    for j=1:size(blk_pack.TTT.tss_CR,2)
        blk_smooth_pre=zeros(1550,2);
        blk_smooth_pre(:,1)=-550:1:999;
        for k=1:1500
            blk_smooth_pre(k+50,2)=mean(blk_pack.TTT.tss_CR(j).blk((20*k-19):20*k,1));
        end       
        bsl=mean(blk_smooth_pre(51:550,2));
        sd=std(blk_smooth_pre(51:550,2));
        thr=bsl+6*sd;
        CR_amp=max(blk_smooth_pre(601:550+t_interval,2));
        if CR_amp > thr
           UR_amp=max(blk_smooth_pre(551+t_interval:700+t_interval,2));
           UR_idx=UR_idx+1;
           UR_amp_list(UR_idx).UR_amp_value=UR_amp;
        else
           blk_pack.TTT.tss_CR(j).trial = [];
        end              
    end
    blk_pack.TTT.tss_CR=blk_pack.TTT.tss_CR(~cellfun(@isempty,{blk_pack.TTT.tss_CR.trial}));
    for j=1:size(blk_pack.TTT.tss_NO_CR,2)
        blk_smooth_NOpre=zeros(1550,2);
        blk_smooth_NOpre(:,1)=-550:1:999;
        for k=1:1500
            blk_smooth_NOpre(k+50,2)=mean(blk_pack.TTT.tss_NO_CR(j).blk((20*k-19):20*k,1));
        end 
        UR_idx=UR_idx+1;
        UR_amp=max(blk_smooth_NOpre(551+t_interval:700+t_interval,2));
    end
    UR_mean=mean([UR_amp_list.UR_amp_value]);
    tss=struct('trial',[],'t',[]);
    for j=1:size(blk_pack.TTT.tss_CR,2)
        ttt.CR_trial(j).trial_num=blk_pack.TTT.tss_CR(j).trial;         
        blk_smooth=zeros(1550,3);
        blk_smooth(:,1)=-550:1:999;
        for k=1:1500
            blk_smooth(k+50,2)=mean(blk_pack.TTT.tss_CR(j).blk((20*k-19):20*k,1));
        end
        blk_smooth(:,3)=blk_smooth(:,2)/UR_mean;
        ttt.CR_trial(j).blk_smth=blk_smooth;
        
        bsl=mean(blk_smooth(51:550,3));
        sd=std(blk_smooth(51:550,3));
        thr=bsl+6*sd;
        [CR_amp,CR_pkt]=max(blk_smooth(601:550+t_interval,3));
        CR_pkt=CR_pkt+49;
        CR_on=find(blk_smooth(601:550+t_interval,3) >= thr,1,'first');
        CR_on=CR_on+49;
        [UR_amp,UR_pkt]=max(blk_smooth(551+t_interval:700+t_interval,3));
        UR_pkt=UR_pkt+t_interval-1;
        
        blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[],'UR_amp',[]);
        blk_info_new.CR_onset=CR_on/1000;
        blk_info_new.CR_amp=CR_amp;
        blk_info_new.CR_peaktime=CR_pkt/1000;
        blk_info_new.UR_peaktime=UR_pkt;
        blk_info_new.UR_amp=UR_amp;
        ttt.CR_trial(j).blk_info_new=blk_info_new;

        tss(j).trial=blk_pack.TTT.tss_CR(j).trial;
        tss(j).t=blk_pack.TTT.tss_CR(j).t;
        ttt.CR_trial(j).spk_time=tss(j).t;
    end
    Ctas.tss=tss;     
    spk_CR_Gau=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_CR_Gau=Gau_psth_cal(spk_CR_Gau,t_pre,t_psth,0);
    mod_CR=modulation_type(t_pre,t_interval,psth_CR_Gau,3,10); 
    ttt_CR_Gau=ifr_Gau_trial(spk_CR_Gau,10,1);
    for j=1:size(blk_pack.TTT.tss_CR,2)
        ttt.CR_trial(j).ifr_org_Gau=ttt_CR_Gau(1).ifr_Gau_cell(j).ifr_Gau_org;
        ttt.CR_trial(j).ifr_smooth=ttt_CR_Gau(1).ifr_Gau_cell(j).ifr_Gau_bin;
    end    
   
    sss_all.psth.CR_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    sss_all.psth.CR_trial.avg_frq=mod_CR(1).bsl_frq;
    sss_all.psth.CR_trial.psth_raw=psth_CR_Gau(1).Gau_psth_org;
    sss_all.psth.CR_trial.psth_smooth=psth_CR_Gau(1).Gau_psth_shft;
    
    Delay_Wang(i).CR_fac=mod_CR.fac_merge;
    Delay_Wang(i).CR_sup=mod_CR.sup_merge;
    if mod_CR.fac_merge>0
       mod_info.CRf=mod_CR.fac_mginfo;
    end
    if mod_CR.sup_merge>0
       mod_info.CRs=mod_CR.sup_mginfo; 
    end
    if mod_CR.ur_fac==0
       Delay_Wang(i).UR_fac=0;
       Delay_Wang(i).mod_info.URf=[];
    else
       Delay_Wang(i).UR_fac=1;
       mod_info.URf.t_peak=mod_CR.ur_fpkt;
       mod_info.URf.peak=mod_CR.ur_fac;
    end
    if mod_CR.ur_sup==0
       Delay_Wang(i).UR_sup=0;
       mod_info.URs=[];
    else
       Delay_Wang(i).UR_sup=1;
       mod_info.URs.t_peak=mod_CR.ur_spkt;
       mod_info.URs.peak=mod_CR.ur_sup;
    end
    Delay_Wang(i).mod_info=mod_info;    

    Ctas_ex=struct('cell',[],'tss',[]);
    Ctas_align=struct('cell',[],'tss',[]);
    Ctas_ex.tss=struct('trial',[],'t',[],'onset',[]);
    Ctas_align.tss=struct('trial',[],'t',[]);
    tttCR_ex=ttt.CR_trial;
    Ctas_ex.cell=1; 
    Ctas_align.cell=1;
    n=1;
    for m=1:size(tttCR_ex,2)
        if tttCR_ex(m).blk_info_new.CR_onset<=t_interval/1000*0.9
           Ctas_ex.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_align.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_ex.tss(n).t=tttCR_ex(m).spk_time;
           Ctas_align.tss(n).t=tttCR_ex(m).spk_time-tttCR_ex(m).blk_info_new.CR_onset;
           Ctas_ex.tss(n).onset=tttCR_ex(m).blk_info_new.CR_onset;
           n=n+1;
        else
           tttCR_ex(m).trial_num=[]; 
        end        
    end
    tttCR_ex=tttCR_ex(~cellfun(@isempty,{tttCR_ex.trial_num}));
%     if size(tttCR_ex,2)<20
%        tttCR_ex=[];
%     end
    
    spk_CR_Gau_ex=spk_Gaussian(Ctas_ex,t_pre,t_psth,10,3);
    psth_CR_Gau_ex=Gau_psth_cal(spk_CR_Gau_ex,t_pre,t_psth,0);
    mod_CR_ex=modulation_type(t_pre-50,t_interval,psth_CR_Gau_ex,3,10);    
    spk_CR_Gau_align=spk_Gaussian(Ctas_align,550,550,10,3);
    psth_CR_Gau_align=Gau_psth_cal(spk_CR_Gau_align,550,550,0);
    
    align_info.bsl_frq_ex=mod_CR_ex.bsl_frq;
    align_info.SD_ex=mod_CR_ex.SD;
    align_info.psth_ex=psth_CR_Gau_ex.Gau_psth_shft;
    align_info.psth_align=psth_CR_Gau_align.Gau_psth_shft;
    if isempty(mod_CR_ex.fac_mginfo(1).t_onset)
       align_info.CR_fac=[];
    else
       align_info.CR_fac=mod_CR_ex.fac_mginfo;
    end
    if isempty(mod_CR_ex.sup_mginfo(1).t_onset)
       align_info.CR_sup=[];
    else
       align_info.CR_sup=mod_CR_ex.sup_mginfo;
    end    
    align_info.t_start=min([Ctas_ex.tss.onset])*1000;
    align_info.t_end=max([Ctas_ex.tss.onset])*1000;
%     align_info.ttt_ex=tttCR_ex;
    Delay_Wang(i).align_info=align_info;

    tss=struct('trial',[],'t',[]);
    for j=1:size(blk_pack.TTT.tss_NO_CR,2)
        ttt.nonCR_trial(j).trial_num=blk_pack.TTT.tss_NO_CR(j).trial;         
        blk_smooth=zeros(1550,3);
        blk_smooth(:,1)=-550:1:999;
        for k=1:1500
            blk_smooth(k+50,2)=mean(blk_pack.TTT.tss_NO_CR(j).blk((20*k-19):20*k,1));
        end
        blk_smooth(:,3)=blk_smooth(:,2)/UR_mean;
        ttt.nonCR_trial(j).blk_smth=blk_smooth;
        
        [UR_amp,UR_pkt]=max(blk_smooth(551+t_interval:700+t_interval,3));
        UR_pkt=UR_pkt+t_interval-1;
        
        blk_info_new=struct('CR_onset',[],'CR_amp',[],'CR_peaktime',[],'UR_peaktime',[],'UR_amp',[]);
        blk_info_new.CR_onset=0;
        blk_info_new.CR_amp=0;
        blk_info_new.CR_peaktime=0;
        blk_info_new.UR_peaktime=UR_pkt;
        blk_info_new.UR_amp=UR_amp;
        ttt.nonCR_trial(j).blk_info_new=blk_info_new;

        tss(j).trial=blk_pack.TTT.tss_NO_CR(j).trial;
        tss(j).t=blk_pack.TTT.tss_NO_CR(j).t;
        ttt.nonCR_trial(j).spk_time=tss(j).t;
    end
    Ntas.tss=tss;     
    spk_nonCR_Gau=spk_Gaussian(Ntas,t_pre,t_psth,10,3);
    psth_nonCR_Gau=Gau_psth_cal(spk_nonCR_Gau,t_pre,t_psth,0);
    mod_nonCR=modulation_type(t_pre,t_interval,psth_nonCR_Gau,3,10); 
    ttt_nonCR_Gau=ifr_Gau_trial(spk_nonCR_Gau,10,1);
    for j=1:size(blk_pack.TTT.tss_NO_CR,2)
        ttt.nonCR_trial(j).ifr_org_Gau=ttt_nonCR_Gau(1).ifr_Gau_cell(j).ifr_Gau_org;
        ttt.nonCR_trial(j).ifr_smooth=ttt_nonCR_Gau(1).ifr_Gau_cell(j).ifr_Gau_bin;
    end    
   
    sss_all.psth.nonCR_trial=struct('avg_frq',[],'psth_raw',[],'psth_smooth',[]);
    sss_all.psth.nonCR_trial.avg_frq=mod_nonCR(1).bsl_frq;
    sss_all.psth.nonCR_trial.psth_raw=psth_nonCR_Gau(1).Gau_psth_org;
    sss_all.psth.nonCR_trial.psth_smooth=psth_nonCR_Gau(1).Gau_psth_shft;
    
    all_info.sss_all=sss_all;
    all_info.ttt=ttt;
    Delay_Wang(i).all_info=all_info;
    
    Gau_psth_plot_Wang(psth_CR_Gau,ttt.CR_trial,Ctas,t_interval,'CR',num2str(i));
end


function Gau_psth_plot_Wang(Gau_psth_all,blk_ttt,Ctas,t_post,trial_tp,cell_ID)

% outpath='D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Trace-trained-mice\DCN_mat_output\loco_data\normal_PSTH\';

cell_number=size(Gau_psth_all,2);
CR_number=size(blk_ttt,2);
blk_data=zeros(size(blk_ttt(1).blk_smth,1),size(blk_ttt,2));   

for n=1:size(blk_ttt,2)
%     t_trialon=Clocs(n).t;
%     t_norm=(blk(trial_num).t-t_trialon)*1000;
%         blk(trial_num).tr;
    blk_data(:,n)=blk_ttt(n).blk_smth(:,3);
end

mean_blk=mean(blk_data,2);
% std_blk=std(blk_data,0,2);
% std_up=mean_blk+std_blk;
% std_down=mean_blk-std_blk;
ymax=max(max(blk_data))+0.1;
ymin=min(min(blk_data))-0.1;
    
for k=1:cell_number
    cell_nr=k;
    fig_name = strcat('Gau_PSTH Cell No.',num2str(cell_ID,'%03d'),trial_tp);
    figure('Name',fig_name,'NumberTitle','off','units','normalized','outerposition',[0 0 1 1])

    %   plot behavior data
    subplot(3,1,1)
    hold on
    for i=1:size(blk_data,2)
        plot(-550:1:999,blk_data(:,i),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    plot(-550:1:999,mean_blk,'Color',[0 0 0],'LineWidth',2)
    hold on
%     plot(t_norm,std_up,'c-')
%     hold on
%     plot(t_norm,std_down,'c-')
%     hold on
    if t_post==500
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[ymin, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    xlim([-250 1000]);
    ylim([ymin ymax]);
    xlabel('time(ms)');
    ylabel('Normalized eyelid trace')

    %   plot raster data
    subplot(3,1,2)
    hold on

    for m=1:CR_number
        hold on
        Y=ones(length(Ctas(cell_nr).tss(m).t),1)*m;
        plot(Ctas(cell_nr).tss(m).t*1000,Y,'k.')
    end
    hold on
    if t_post==500
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, m+1],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, m+1],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);    
    end
    xlim([-250 1000]);
    ylim([0 m+1]);
    xlabel('time(ms)');
    ylabel('CR trial number');


    % plot PSTH    
    subplot(3,1,3)
    hold on
    h = histogram(Gau_psth_all(k).Gau_psth_shft(:,1));
        h.BinEdges = (min(Gau_psth_all(k).Gau_psth_shft(:,1))):(max(Gau_psth_all(k).Gau_psth_shft(:,1)) + 1);
        h.NumBins = size(Gau_psth_all(k).Gau_psth_shft,1);
        h.BinCounts = Gau_psth_all(k).Gau_psth_shft(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    % Draw 0 point reference line
    yh = max(Gau_psth_all(k).Gau_psth_shft(:,2)) * 1.01;
    hold on
    if t_post==500
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([500 500],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    elseif t_post==250
    line([0 0],[0, yh],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
    line([250 250],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
    end
    % Set labels
    xlabel('Bin No.');
    %   xlim([(min([psth(cell_nr).bar.bin]) - 1) (max([psth(cell_nr).bar.bin]) + 2)]);
    xlim([-250 1000]);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    saveas(gcf,[fig_name '.jpg']);
    hold on
%     cd(outpath);
%     saveas(gcf,[csv_name fig_name '.jpg']);
end
% close all
end