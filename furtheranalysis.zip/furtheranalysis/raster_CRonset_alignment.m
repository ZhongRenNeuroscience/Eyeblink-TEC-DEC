file=trace_list;
t_interval=500;
all_info='all_info';
figure_name='trace';
cd 'D:\Zhong\Trace-trained-mice\DCN_mat_output\RasterFigures\new_all'

raster_info=struct('cell_ID',[],'trial_info',[]);

for i=1:1
    raster_info(i).cell_ID=file(i).cell_ID;
    trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'CRonset_rank',[],'spk',[]);
    for j=1:size(file(i).(all_info).ttt.CR_trial,2)
        trial_info(j).field=j;
        trial_info(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
        trial_info(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
        trial_info(j).CRonset_rank=file(i).(all_info).ttt.CR_trial(j).blk_info.CRonset_rank;
        trial_info(j).spk=file(i).(all_info).ttt.CR_trial(j).spk_time;
    end
    
    trial_info = trial_info(all(~cellfun(@isempty,struct2cell(trial_info))));
    
    raster_info(i).trial_info=trial_info;  
    
    figure('Name',[figure_name num2str(i)],'NumberTitle','off','units','normalized','outerposition',[0 0 1 1]);   
    
    subplot(4,1,1)
    hold on
    
    behavior_mean=zeros(1550,size(trial_info,2));
    for m=1:size(trial_info,2)
        behavior_mean(:,m)=file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
        plot(file(i).(all_info).ttt.CR_trial(m).blk_smth(:,1),file(i).(all_info).ttt.CR_trial(m).blk_smth(:,2),'linewidth',0.5,'color',[0.9 0.9 0.9])
        hold on
    end
    ymax=max(max(behavior_mean))+0.1;
    ymin=min(min(behavior_mean))-0.1;
    plot(file(i).(all_info).ttt.CR_trial(1).blk_smth(:,1),mean(behavior_mean,2),'Color',[0 0 0],'LineWidth',2)
    hold on

    line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    line([t_interval t_interval],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);

    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([ymin ymax]);
    xlabel('Time(ms)');
    ylabel('Normalized eyelid trace')    
    
    
    subplot(4,1,2)
    hold on
    
    for m=1:size(trial_info,2)
        hold on
        Y=ones(length(trial_info(m).spk),1)*m;
        plot(trial_info(m).spk*1000,Y,'k.')
        hold on
        plot(0,Y,'g.')
        hold on
        plot(trial_info(m).CR_onset*1000,Y,'b.')
        hold on
        plot(t_interval,Y,'r.')        
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    xlabel('Time(ms)');
    ylabel('Trial number');
    
    [~,index] = sortrows([trial_info.CR_onset].'); 
    trial_info = trial_info(index);
    
    subplot(4,1,3)
    hold on
    
    for m=1:size(trial_info,2)
        hold on
        Y=ones(length(trial_info(m).spk),1)*m;
        plot(trial_info(m).spk*1000,Y,'k.')
        hold on
        plot(0,Y,'g.')
        hold on
        plot(trial_info(m).CR_onset*1000,Y,'b.')
        hold on
        plot(t_interval,Y,'r.')         
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    xlabel('Time(ms)');
    ylabel('Trial number');
    
    subplot(4,1,4)
    hold on
    
    for m=1:size(trial_info,2)
        hold on
        Y=ones(length(trial_info(m).spk),1)*m;
        hold on
        plot((trial_info(m).spk-trial_info(m).CR_onset)*1000,Y,'k.')
        hold on
        plot(-trial_info(m).CR_onset*1000,Y,'g.')
        hold on
        plot(0,Y,'b.')
        hold on
        plot(t_interval-trial_info(m).CR_onset*1000,Y,'r.')        
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    xlabel('CR onset aligned time(ms)');
    ylabel('Trial number');
    hold on
    
    saveas(gcf,[figure_name num2str(i) '-' num2str(file(i).CR_fac_T) '-' num2str(file(i).CR_sup_T) '.jpg']);
        
end
