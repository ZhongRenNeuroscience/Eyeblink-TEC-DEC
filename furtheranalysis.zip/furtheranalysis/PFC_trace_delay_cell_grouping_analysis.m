% PFC trace or delay cell type definition

list=trace_list_mPFC_ready;
mod_list=PFC_mod_list_T;
t_post=500;
thrd_hww=t_post/5;
all_info='all_info';
% align_info='align_info';
CR_trial='CR_trial_T';
nonCR_trial='nonCR_trial_T';

PFC_fac_list_T=struct('cell_ID',[],'mod_pkt',[],'mod_amp',[],'hww',[],'hww_1',[],'hww_2',[],'hw_amp',[],'p_NCR',[],'mean_mod_pkt',[],'pkt_sd',[]);
mod_type='mod_type_T';
mod_info='mod_info_T';
fac_idx=0;

% include_cell_D=[25 43 47 48 316 333 341];

for i=1:size(mod_list,2)
    if mod_list(i).(mod_type)==1
       fac_idx=fac_idx+1;
       PFC_fac_list_T(fac_idx).cell_ID=mod_list(i).cell_ID;
       PFC_fac_list_T(fac_idx).mod_pkt=mod_list(i).(mod_info).mod_pkt;
       PFC_fac_list_T(fac_idx).mod_amp=mod_list(i).(mod_info).mod_amp;
       PFC_fac_list_T(fac_idx).hww=mod_list(i).(mod_info).hww;
       PFC_fac_list_T(fac_idx).hww_1=mod_list(i).(mod_info).hww_1;
       PFC_fac_list_T(fac_idx).hww_2=mod_list(i).(mod_info).hww_2;
       PFC_fac_list_T(fac_idx).hw_amp=mod_list(i).(mod_info).hw_amp;
%        if size(mod_list(i).(CR_trial),2)/size(mod_list(i).(nonCR_trial),2)>2
%           for j=size(mod_list(i).(nonCR_trial),2)+1:20
%               rand_idx=randi(size(mod_list(i).(nonCR_trial),2),1,1);
%               mod_list(i).(nonCR_trial)(j).trial_num=mod_list(i).(nonCR_trial)(rand_idx).trial_num;
%               mod_list(i).(nonCR_trial)(j).bsl_all=mod_list(i).(nonCR_trial)(rand_idx).bsl_all;
%               mod_list(i).(nonCR_trial)(j).CR_epoch_all=mod_list(i).(nonCR_trial)(rand_idx).CR_epoch_all;
%           end
%        end
       p_NCR=ranksum([mod_list(i).(CR_trial).CR_epoch_all]-[mod_list(i).(CR_trial).bsl_all],[mod_list(i).(nonCR_trial).CR_epoch_all]-[mod_list(i).(nonCR_trial).bsl_all]);
       PFC_fac_list_T(fac_idx).p_NCR=p_NCR;
       PFC_fac_list_T(fac_idx).mean_mod_pkt=mean([mod_list(i).(CR_trial).ifr_pkt]);
       PFC_fac_list_T(fac_idx).pkt_sd=std([mod_list(i).(CR_trial).ifr_pkt]);
    end
end

%%
% % For CR specific activity cells
% cell_number=sum([PFC_fac_list_T.p_NCR]<0.05);
% t_slot=size(list(1).(all_info).sss_all.psth.CR_trial.psth_smooth,1);
% CR_raw_form=zeros(t_slot,cell_number);
% nonCR_raw_form=zeros(t_slot,cell_number);
% cell_idx=0;
% 
% for i=1:size(PFC_fac_list_T,2)
%     if PFC_fac_list_T(i).p_NCR<0.05 %|| any(include_cell_T == PFC_fac_list_T(i).cell_ID)
%        cell_idx=cell_idx+1;
%        cell_ID=PFC_fac_list_T(i).cell_ID;
%        t_bsl_idx=find(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1)==0,1,'first');
%        CR_bsl=mean(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(1:t_bsl_idx-1,2));
%        nonCR_bsl=mean(list(cell_ID).(all_info).sss_all.psth.nonCR_trial.psth_smooth(1:t_bsl_idx-1,2));      
%        if abs(CR_bsl-nonCR_bsl)/CR_bsl+nonCR_bsl>0.5
%           CR_bsl=(CR_bsl+nonCR_bsl)/2;
%           nonCR_bsl=(CR_bsl+nonCR_bsl)/2;
%        end
%        if abs(CR_bsl-nonCR_bsl)/CR_bsl+nonCR_bsl>0.5
%           nonCR_bsl=CR_bsl;
%        end
%        CR_raw_form(:,cell_idx)=list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2)/CR_bsl*100;
%        nonCR_raw_form(:,cell_idx)=list(cell_ID).(all_info).sss_all.psth.nonCR_trial.psth_smooth(:,2)/nonCR_bsl*100;
%     end
% end
% 
% CR_ready_form=zeros(t_slot,5);
% nonCR_ready_form=zeros(t_slot,5);
% 
% CR_ready_form(:,1)=list(1).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1);
% CR_ready_form(:,2)=mean(CR_raw_form,2);
% CR_ready_form(:,3)=std(CR_raw_form,0,2);
% CR_ready_form(:,4)=CR_ready_form(:,2)+CR_ready_form(:,3)/sqrt(size(CR_raw_form,2));
% CR_ready_form(:,5)=CR_ready_form(:,2)-CR_ready_form(:,3)/sqrt(size(CR_raw_form,2));
% 
% nonCR_ready_form(:,1)=list(1).(all_info).sss_all.psth.nonCR_trial.psth_smooth(:,1);
% nonCR_ready_form(:,2)=mean(nonCR_raw_form,2);
% nonCR_ready_form(:,3)=std(nonCR_raw_form,0,2);
% nonCR_ready_form(:,4)=nonCR_ready_form(:,2)+nonCR_ready_form(:,3)/sqrt(size(CR_raw_form,2));
% nonCR_ready_form(:,5)=nonCR_ready_form(:,2)-nonCR_ready_form(:,3)/sqrt(size(CR_raw_form,2));
% 
% figure;
% plot(CR_ready_form(:,1),smooth(CR_ready_form(:,2),20),'r-','LineWidth',2)
% hold on
% plot(CR_ready_form(:,1),smooth(CR_ready_form(:,4),20),'r-','LineWidth',1)
% hold on
% plot(CR_ready_form(:,1),smooth(CR_ready_form(:,5),20),'r-','LineWidth',1)
% hold on
% plot(nonCR_ready_form(:,1),smooth(nonCR_ready_form(:,2),20),'k-','LineWidth',2)
% hold on
% plot(nonCR_ready_form(:,1),smooth(nonCR_ready_form(:,4),20),'k-','LineWidth',1)
% hold on
% plot(nonCR_ready_form(:,1),smooth(nonCR_ready_form(:,5),20),'k-','LineWidth',1)
% hold on
% xlim([-250 1000]);
% xticks(-250:250:1000);
% xlabel('Time (ms)');
% ylim([0 500]);
% yticks(0:100:500);
% ylabel('Rel. firing rate');
% title([num2str(size(CR_raw_form,2)) ' cells']);


%%

% % For CR sharp modulation cells
% cell_number=sum([PFC_fac_list_T.hww]<thrd_hww);
% t_slot=size(list(1).(all_info).sss_all.psth.CR_trial.psth_smooth,1);
% sharp_raw_form=zeros(t_slot,cell_number);
% cell_idx=0;
% 
% for i=1:size(PFC_fac_list_T,2)
%     if PFC_fac_list_T(i).hww<thrd_hww && PFC_fac_list_T(i).mod_pkt<200
%        cell_idx=cell_idx+1;
%        cell_ID=PFC_fac_list_T(i).cell_ID;
%        t_bsl_idx=find(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1)==0,1,'first');
%        sharp_bsl=mean(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(1:t_bsl_idx-1,2));       
%        sharp_raw_form(:,cell_idx)=list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2)/sharp_bsl*100;       
%     end
% end
% 
% sharp_ready_form=zeros(t_slot,5);
% sharp_ready_form(:,1)=list(1).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1);
% sharp_ready_form(:,2)=mean(sharp_raw_form,2);
% sharp_ready_form(:,3)=std(sharp_raw_form,0,2);
% sharp_ready_form(:,4)=sharp_ready_form(:,2)+sharp_ready_form(:,3)/sqrt(cell_number);
% sharp_ready_form(:,5)=sharp_ready_form(:,2)-sharp_ready_form(:,3)/sqrt(cell_number);
% 
% figure;
% plot(sharp_ready_form(:,1),smooth(sharp_ready_form(:,2),20),'k-','LineWidth',2)
% hold on
% plot(sharp_ready_form(:,1),smooth(sharp_ready_form(:,4),20),'k-','LineWidth',1)
% hold on
% plot(sharp_ready_form(:,1),smooth(sharp_ready_form(:,5),20),'k-','LineWidth',1)
% hold on
% 
% xlim([-250 1000]);
% xticks(-250:250:1000);
% xlabel('Time (ms)');
% ylim([50 400]);
% ylabel('Rel. firing rate');
% title([num2str(cell_number) ' cells']);

%%
% % For other modulation cells
% cell_number=size(PFC_fac_list_T,2)-(sum([PFC_fac_list_T.hww]<thrd_hww));
% t_slot=size(list(1).(all_info).sss_all.psth.CR_trial.psth_smooth,1);
% blund_raw_form=zeros(t_slot,cell_number);
% cell_idx=0;
% 
% for i=1:size(PFC_fac_list_T,2)
%     if PFC_fac_list_T(i).hww>thrd_hww || PFC_fac_list_T(i).mod_pkt>200
%        cell_idx=cell_idx+1;
%        cell_ID=PFC_fac_list_T(i).cell_ID;
%        t_bsl_idx=find(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1)==0,1,'first');
%        blund_bsl=mean(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(1:t_bsl_idx-1,2));       
%        blund_raw_form(:,cell_idx)=list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2)/blund_bsl*100;       
%     end
% end
% 
% blund_ready_form=zeros(t_slot,5);
% blund_ready_form(:,1)=list(1).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1);
% blund_ready_form(:,2)=mean(blund_raw_form,2);
% blund_ready_form(:,3)=std(blund_raw_form,0,2);
% blund_ready_form(:,4)=blund_ready_form(:,2)+blund_ready_form(:,3)/sqrt(cell_number);
% blund_ready_form(:,5)=blund_ready_form(:,2)-blund_ready_form(:,3)/sqrt(cell_number);
% 
% figure;
% plot(blund_ready_form(:,1),smooth(blund_ready_form(:,2),20),'k-','LineWidth',2)
% hold on
% plot(blund_ready_form(:,1),smooth(blund_ready_form(:,4),20),'k-','LineWidth',1)
% hold on
% plot(blund_ready_form(:,1),smooth(blund_ready_form(:,5),20),'k-','LineWidth',1)
% hold on
% 
% xlim([-250 1000]);
% xticks(-250:250:1000);
% xlabel('Time (ms)');
% ylim([50 400]);
% ylabel('Rel. firing rate');
% title([num2str(cell_number) ' cells']);

%%
% For all cells

cell_number=size(PFC_fac_list_T,2);
t_slot=size(list(1).(all_info).sss_all.psth.CR_trial.psth_smooth,1);
all_raw_form=zeros(t_slot,cell_number);
cell_idx=0;

for i=1:size(PFC_fac_list_T,2)
    cell_idx=cell_idx+1;
    cell_ID=PFC_fac_list_T(i).cell_ID;
    t_bsl_idx=find(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1)==0,1,'first');
    all_bsl=mean(list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(1:t_bsl_idx-1,2));       
    all_raw_form(:,cell_idx)=list(cell_ID).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2)/all_bsl*100;       

end

all_ready_form=zeros(t_slot,5);
all_ready_form(:,1)=list(1).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1);
all_ready_form(:,2)=mean(all_raw_form,2);
all_ready_form(:,3)=std(all_raw_form,0,2);
all_ready_form(:,4)=all_ready_form(:,2)+all_ready_form(:,3)/sqrt(cell_number);
all_ready_form(:,5)=all_ready_form(:,2)-all_ready_form(:,3)/sqrt(cell_number);

figure;
plot(all_ready_form(:,1),smooth(all_ready_form(:,2),20),'k-','LineWidth',2)
hold on
plot(all_ready_form(:,1),smooth(all_ready_form(:,4),20),'k-','LineWidth',1)
hold on
plot(all_ready_form(:,1),smooth(all_ready_form(:,5),20),'k-','LineWidth',1)
hold on

xlim([-250 1000]);
xticks(-250:250:1000);
xlabel('Time (ms)');
ylim([50 500]);
ylabel('Rel. firing rate');
title([num2str(cell_number) ' cells']);




