file=delay_list_2021;
align_info_1='align_info';
all_info_1='all_info';
t_pre=-250;
t_post=500;
bin=10;
d_curve_range=300;

fac_idx=0;
sup_idx=0;
raw_data_size=(t_post-t_pre+250)/bin+1;

raw_data_fac=struct('cell_ID',[],'raw_data',[]);
raw_data_sup=struct('cell_ID',[],'raw_data',[]);

for i=1:size(file,2)  
    if ~isempty(file(i).(align_info_1).CR_fac)
        fac_idx=fac_idx+1;
        raw_data_fac(fac_idx).cell_ID=file(i).cell_ID;
        trial_data=struct('trial_ID',[],'blk_bin',[],'spk_bin',[]);
        for j=1:size(file(i).(all_info_1).ttt.CR_trial,2)
            trial_data(j).trial_ID=file(i).(all_info_1).ttt.CR_trial(j).trial_num;
            blk_bin=zeros(raw_data_size,2);
            spk_bin=zeros(raw_data_size,2);
            blk_bin(:,1)=t_pre:bin:t_post+250;
            spk_bin(:,1)=t_pre:bin:t_post+250;
            t_1_blk=find(file(i).(all_info_1).ttt.CR_trial(1).blk_smth(:,1)==t_pre);
            t_1_spk=find(file(i).(all_info_1).ttt.CR_trial(1).ifr_smooth(:,1)==t_pre);
            for k=1:raw_data_size
                tdx_blk=t_1_blk+(k-1)*bin-bin/2:1:t_1_blk+k*bin-bin/2-1;
                tdx_spk=t_1_spk+(k-1)*bin-bin/2:1:t_1_spk+k*bin-bin/2-1;
                blk_bin(k,2)=mean(file(i).(all_info_1).ttt.CR_trial(j).blk_smth(tdx_blk,2));
                spk_bin(k,2)=mean(file(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(tdx_spk,2));           
            end
            trial_data(j).blk_bin=blk_bin;
            trial_data(j).spk_bin=spk_bin;
        end
        raw_data_fac(fac_idx).raw_data=trial_data;
    end
        
    if ~isempty(file(i).(align_info_1).CR_sup)
        sup_idx=sup_idx+1;
        raw_data_sup(sup_idx).cell_ID=file(i).cell_ID;
        trial_data=struct('trial_ID',[],'blk_bin',[],'spk_bin',[]);
        for j=1:size(file(i).(all_info_1).ttt.CR_trial,2)
            trial_data(j).trial_ID=file(i).(all_info_1).ttt.CR_trial(j).trial_num;
            blk_bin=zeros(raw_data_size,2);
            spk_bin=zeros(raw_data_size,2);
            blk_bin(:,1)=t_pre:bin:t_post+250;
            spk_bin(:,1)=t_pre:bin:t_post+250;
            t_1_blk=find(file(i).(all_info_1).ttt.CR_trial(1).blk_smth(:,1)==t_pre);
            t_1_spk=find(file(i).(all_info_1).ttt.CR_trial(1).ifr_smooth(:,1)==t_pre);
            for k=1:raw_data_size
                tdx_blk=t_1_blk+(k-1)*bin-bin/2:1:t_1_blk+k*bin-bin/2-1;
                tdx_spk=t_1_spk+(k-1)*bin-bin/2:1:t_1_spk+k*bin-bin/2-1;
                blk_bin(k,2)=mean(file(i).(all_info_1).ttt.CR_trial(j).blk_smth(tdx_blk,2));
                spk_bin(k,2)=mean(file(i).(all_info_1).ttt.CR_trial(j).ifr_smooth(tdx_spk,2));           
            end
            trial_data(j).blk_bin=blk_bin;
            trial_data(j).spk_bin=spk_bin;
        end
        raw_data_sup(sup_idx).raw_data=trial_data;                
    end      
end

% for facilitation cells
htmap_fac=struct('cell_ID',[],'cell_htmap',[]);
for i=1:size(raw_data_fac,2)
    cell_htmap_fac=zeros(raw_data_size,raw_data_size);
    htmap_fac(i).cell_ID=raw_data_fac(i).cell_ID;
    for m=1:raw_data_size
        for n=1:raw_data_size
            spk_trial=zeros(size(raw_data_fac(i).raw_data,2),1);
            blk_trial=zeros(size(raw_data_fac(i).raw_data,2),1);
            for j=1:size(raw_data_fac(i).raw_data,2)
                spk_trial(j)=raw_data_fac(i).raw_data(j).spk_bin(m,2);
                blk_trial(j)=raw_data_fac(i).raw_data(j).blk_bin(n,2);        
            end
            reg = fitlm(spk_trial,blk_trial);
            reg_r = reg.Rsquared.Adjusted;
            cell_htmap_fac(n,m) = reg_r;      
        end        
    end
    htmap_fac(i).cell_htmap=cell_htmap_fac;
end


htmap_avg_fac=zeros(raw_data_size-1,raw_data_size-1);
for m=1:raw_data_size-1
    for n=1:raw_data_size-1
        r_cell=zeros(size(raw_data_fac,2),1);
        for i=1:size(raw_data_fac,2)
            r_cell(i,1)=htmap_fac(i).cell_htmap(n,m);
        end   
        htmap_avg_fac(raw_data_size-n,m)=nanmean(r_cell);
    end
end

figure;
h=heatmap(htmap_avg_fac,'GridVisible','off','Colormap',hot);
h.ColorLimits = [0.01 0.05];


dt_blk_spk_fac=struct('cell_ID',[],'curve',[],'r_peak',[],'t_peak',[]);
dt_blk_spk_all_fac=zeros(d_curve_range/bin+1,size(raw_data_fac,2));
figure;
for i=1:size(raw_data_fac,2)
    dt_blk_spk_fac(i).cell_ID=raw_data_fac(i).cell_ID;
    dt_blk_spk_curve=zeros(d_curve_range/bin+1,2);
    dt_blk_spk_curve(:,1)=-d_curve_range/2:bin:d_curve_range/2;
    for j=1:d_curve_range/bin+1
        dt=dt_blk_spk_curve(j,1)/bin;
        dt_blk_spk_raw=nan(raw_data_size-1,1);
        for n=1:raw_data_size-1
            if n-dt>0 && n-dt<raw_data_size
                dt_blk_spk_raw(n,1)=htmap_fac(i).cell_htmap(n,n-dt);
            end                
        end   
        dt_blk_spk_curve(j,2)=nanmean(dt_blk_spk_raw);
    end
    dt_blk_spk_fac(i).curve=dt_blk_spk_curve;
    dt_blk_spk_all_fac(:,i)=dt_blk_spk_curve(:,2);
    [dt_blk_spk_fac(i).r_peak,tdx_max]=max(dt_blk_spk_curve(:,2));
    dt_blk_spk_fac(i).t_peak=dt_blk_spk_curve(tdx_max,1);
    plot(dt_blk_spk_curve(:,1),dt_blk_spk_curve(:,2),'-','Color',[0.8 0.8 0.8])
    hold on
end
dt_blk_spk_all_avg_fac=zeros(d_curve_range/bin+1,2);
dt_blk_spk_all_avg_fac(:,1)=-d_curve_range/2:bin:d_curve_range/2;
dt_blk_spk_all_avg_fac(:,2)=mean(dt_blk_spk_all_fac,2);
dt_blk_spk_fac(size(raw_data_fac,2)+1).cell_ID='all_mean';
dt_blk_spk_fac(size(raw_data_fac,2)+1).curve=dt_blk_spk_all_avg_fac;

plot(dt_blk_spk_all_avg_fac(:,1),dt_blk_spk_all_avg_fac(:,2),'r-')
hold on
xlim([-d_curve_range/2 d_curve_range/2]);
ylim([-0.02 0.06]);
xticks(-d_curve_range/2:25:d_curve_range/2);
yticks(-0.02:0.02:0.06);
xlabel('t(eyelid)-t(spike)');
ylabel('R value');

%% for suppression cells
sup_color_map=[0,0,0
0,0,0.025
0,0,0.05
0,0,0.075
0,0,0.1
0,0,0.125
0,0,0.15
0,0,0.175
0,0,0.2
0,0,0.225
0,0,0.25
0,0,0.275
0,0,0.3
0,0,0.325
0,0,0.35
0,0,0.375
0,0,0.4
0,0,0.425
0,0,0.45
0,0,0.475
0,0,0.5
0,0,0.525
0,0,0.55
0,0,0.575
0,0,0.6
0,0,0.625
0,0,0.65
0,0,0.675
0,0,0.7
0,0,0.725
0,0,0.75
0,0,0.775
0,0,0.8
0,0,0.825
0,0,0.85
0,0,0.875
0,0,0.9
0,0,0.925
0,0,0.95
0,0,0.975
0,0,1
0.025,0.025,1
0.05,0.05,1
0.075,0.075,1
0.1,0.1,1
0.125,0.125,1
0.15,0.15,1
0.175,0.175,1
0.2,0.2,1
0.225,0.225,1
0.25,0.25,1
0.275,0.275,1
0.3,0.3,1
0.325,0.325,1
0.35,0.35,1
0.375,0.375,1
0.4,0.4,1
0.425,0.425,1
0.45,0.45,1
0.475,0.475,1
0.5,0.5,1
0.525,0.525,1
0.55,0.55,1
0.575,0.575,1
0.6,0.6,1
0.625,0.625,1
0.65,0.65,1
0.675,0.675,1
0.7,0.7,1
0.725,0.725,1
0.75,0.75,1
0.775,0.775,1
0.8,0.8,1
0.825,0.825,1
0.85,0.85,1
0.875,0.875,1
0.9,0.9,1 
0.925,0.925,1
0.95,0.95,1
0.975,0.975,1
1,1,1];

htmap_sup=struct('cell_ID',[],'cell_htmap',[]);
for i=1:size(raw_data_sup,2)
    cell_htmap_sup=zeros(raw_data_size,raw_data_size);
    htmap_sup(i).cell_ID=raw_data_sup(i).cell_ID;
    for m=1:raw_data_size
        for n=1:raw_data_size
            spk_trial=zeros(size(raw_data_sup(i).raw_data,2),1);
            blk_trial=zeros(size(raw_data_sup(i).raw_data,2),1);
            for j=1:size(raw_data_sup(i).raw_data,2)
                spk_trial(j)=raw_data_sup(i).raw_data(j).spk_bin(m,2);
                blk_trial(j)=raw_data_sup(i).raw_data(j).blk_bin(n,2);        
            end
            reg = fitlm(spk_trial,blk_trial);
            reg_r = reg.Rsquared.Adjusted;
            cell_htmap_sup(n,m) = reg_r;      
        end        
    end
    htmap_sup(i).cell_htmap=cell_htmap_sup;
end

htmap_avg_sup=zeros(raw_data_size-1,raw_data_size-1);
for m=1:raw_data_size-1
    for n=1:raw_data_size-1
        r_cell=zeros(size(raw_data_sup,2),1);
        for i=1:size(raw_data_sup,2)
            r_cell(i,1)=htmap_sup(i).cell_htmap(n,m);
        end   
        htmap_avg_sup(raw_data_size-n,m)=nanmean(r_cell);
    end
end

figure;
h=heatmap(htmap_avg_sup,'GridVisible','off','Colormap',sup_color_map);
h.ColorLimits = [0.02 0.06];


dt_blk_spk_sup=struct('cell_ID',[],'curve',[],'r_peak',[],'t_peak',[]);
dt_blk_spk_all_sup=zeros(d_curve_range/bin+1,size(raw_data_sup,2));
figure;
for i=1:size(raw_data_sup,2)
    dt_blk_spk_sup(i).cell_ID=raw_data_sup(i).cell_ID;
    dt_blk_spk_curve=zeros(d_curve_range/bin+1,2);
    dt_blk_spk_curve(:,1)=-d_curve_range/2:bin:d_curve_range/2;
    for j=1:d_curve_range/bin+1
        dt=dt_blk_spk_curve(j,1)/bin;
        dt_blk_spk_raw=nan(raw_data_size-1,1);
        for n=1:raw_data_size-1
            if n-dt>0 && n-dt<raw_data_size
                dt_blk_spk_raw(n,1)=htmap_sup(i).cell_htmap(n,n-dt);
            end                
        end   
        dt_blk_spk_curve(j,2)=nanmean(dt_blk_spk_raw);
    end
    dt_blk_spk_sup(i).curve=dt_blk_spk_curve;
    dt_blk_spk_all_sup(:,i)=dt_blk_spk_curve(:,2);
    [dt_blk_spk_sup(i).r_peak,tdx_peak]=min(dt_blk_spk_curve(:,2));
    dt_blk_spk_sup(i).t_peak=dt_blk_spk_curve(tdx_peak,1);
    plot(dt_blk_spk_curve(:,1),dt_blk_spk_curve(:,2),'-','Color',[0.8 0.8 0.8])
    hold on
end
dt_blk_spk_all_avg_sup=zeros(d_curve_range/bin+1,2);
dt_blk_spk_all_avg_sup(:,1)=-d_curve_range/2:bin:d_curve_range/2;
dt_blk_spk_all_avg_sup(:,2)=mean(dt_blk_spk_all_sup,2);
dt_blk_spk_sup(size(raw_data_sup,2)+1).cell_ID='all_mean';
dt_blk_spk_sup(size(raw_data_sup,2)+1).curve=dt_blk_spk_all_avg_sup;

plot(dt_blk_spk_all_avg_sup(:,1),dt_blk_spk_all_avg_sup(:,2),'b-')
hold on
xlim([-d_curve_range/2 d_curve_range/2]);
ylim([-0.02 0.06]);
xticks(-d_curve_range/2:25:d_curve_range/2);
yticks(-0.02:0.02:0.06);
xlabel('t(eyelid)-t(spike)');
ylabel('R value');
