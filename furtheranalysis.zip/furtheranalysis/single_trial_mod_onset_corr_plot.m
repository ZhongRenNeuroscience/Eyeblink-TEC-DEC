file=file;
blk_sss_file=blk_sss_delay;
mod_list=mod_list_delay;
all_info='all_info';
align_info='align_info';
behavior_info='behavior_info';
bin=50;
step=10;
t_pre=500;
t_post=250;
velocity_curve_bin=10;
slope_cal_range=[0.1 0.9];
mod_event_type='mod_event_ifr';
bin_type='bin_ifr';
bsl_mean_type='bsl_mean_ifr';
min_corr_tr_num=10;
other_corr_data_11='fac_corr_data';
other_item_mod_11='fac_pkt';
other_item_bhv_11='CR_t_pk_v';
other_corr_data_12='sup_corr_data';
other_item_mod_12='sup_pkt';
other_item_bhv_12='CR_t_pk_v';
other_corr_data_21='fac_corr_data';
other_item_mod_21='fac_pkt';
other_item_bhv_21='CR_t_pk_v';
other_corr_data_22='sup_corr_data';
other_item_mod_22='sup_pkt';
other_item_bhv_22='CR_t_pk_v';

% [d,id]=findgroups({blk_sss_file.session_path});

trial_mod_list_D=struct('cell_ID',[],'CR_fac',[],'CR_sup',[],'fac_onset_corr',[],'fac_pkt_corr',[],'fac_amp_corr',[],'sup_onset_corr',[],'sup_pkt_corr',[],'sup_amp_corr',[],'fac_corr_data',[],'fac_corr_info',[],'sup_corr_data',[],'sup_corr_info',[]);
for i=1:size(file,2)
    
%     blk_sss_id=strcmp(file(i).file_name,{blk_sss_file.session_path});
%     blk_sss_id=find(blk_sss_id,1);
    
    trial_mod_list_D(i).cell_ID=i; %file(i).cell_ID;
    if ~isempty(mod_list(i).(align_info).CR_fac)
       trial_mod_list_D(i).CR_fac=1;
    else
       trial_mod_list_D(i).CR_fac=0;
    end
    if ~isempty(mod_list(i).(align_info).CR_sup) 
       trial_mod_list_D(i).CR_sup=1;
    else
       trial_mod_list_D(i).CR_sup=0;
    end
    
    fac_corr_data=struct('trial_num',[],'CR_onset',[],'CR_amp',[],'CR_pkt',[],'CR_slope',[],'CR_velocity',[],'CR_t_pk_v',[],'fac_onset',[],'fac_offset',[],'fac_pkt',[],'fac_amp',[],'fac_spk',[]);
    sup_corr_data=struct('trial_num',[],'CR_onset',[],'CR_amp',[],'CR_pkt',[],'CR_slope',[],'CR_velocity',[],'CR_t_pk_v',[],'sup_onset',[],'sup_offset',[],'sup_pkt',[],'sup_amp',[],'sup_spk',[]);
    
    for j=1:size(file(i).(all_info).ttt.CR_trial,2)
        if ~isempty(file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type)(1).onset)           
            [~,index] = sortrows([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type).type].'); 
            file(i).all_info.ttt.CR_trial(j).mod_trial.(mod_event_type) = file(i).all_info.ttt.CR_trial(j).mod_trial.(mod_event_type)(index); 
            clear index
            
            fac_event=find(ismember([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type).type],1));
            sup_event=find(ismember([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type).type],2));
        else
            fac_event=[];
            sup_event=[];
        end
        if ~isempty(fac_event)
            fac_corr_data(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
            fac_corr_data(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            fac_corr_data(j).CR_amp=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            fac_corr_data(j).CR_pkt=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
%             [CR_slope,CR_velocity,CR_t_pk_v]=CR_slope_v_cal(file,i,j,all_info,'CR_trial',slope_cal_range,velocity_curve_bin,t_post);
%             fac_corr_data(j).CR_slope=CR_slope;
%             fac_corr_data(j).CR_velocity=CR_velocity;
%             fac_corr_data(j).CR_t_pk_v=CR_t_pk_v;
            fac_corr_data(j).fac_onset=min([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type)(fac_event).onset]);
            fac_corr_data(j).fac_offset=max([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type)(fac_event).offset]);
            [fac_amp,fac_pkt_idx]=max(file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post-bin)/step+1),2));
            fac_corr_data(j).fac_amp=fac_amp/file(i).(all_info).ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100;
            fac_corr_data(j).fac_pkt=file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+fac_pkt_idx,1);
            fac_corr_data(j).fac_spk=file(i).(all_info).ttt.CR_trial(j).mod_trial.bsl_mod_spk_diff;
        else
            fac_corr_data(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
            fac_corr_data(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            fac_corr_data(j).CR_amp=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            fac_corr_data(j).CR_pkt=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
%             [CR_slope,CR_velocity,CR_t_pk_v]=CR_slope_v_cal(file,i,j,all_info,'CR_trial',slope_cal_range,velocity_curve_bin,t_post);
%             fac_corr_data(j).CR_slope=CR_slope;
%             fac_corr_data(j).CR_velocity=CR_velocity;
%             fac_corr_data(j).CR_t_pk_v=CR_t_pk_v;
            fac_corr_data(j).fac_onset=[];
            fac_corr_data(j).fac_offset=[];
            [fac_amp,fac_pkt_idx]=max(file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post-bin)/step+1),2));
            fac_corr_data(j).fac_amp=fac_amp/file(i).(all_info).ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100;
            fac_corr_data(j).fac_pkt=file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+fac_pkt_idx,1);    
            fac_corr_data(j).fac_spk=file(i).(all_info).ttt.CR_trial(j).mod_trial.bsl_mod_spk_diff;
        end

        if ~isempty(sup_event)
            sup_corr_data(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
            sup_corr_data(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            sup_corr_data(j).CR_amp=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            sup_corr_data(j).CR_pkt=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
%             [CR_slope,CR_velocity,CR_t_pk_v]=CR_slope_v_cal(file,i,j,all_info,'CR_trial',slope_cal_range,velocity_curve_bin,t_post);
%             sup_corr_data(j).CR_slope=CR_slope;
%             sup_corr_data(j).CR_velocity=CR_velocity;
%             sup_corr_data(j).CR_t_pk_v=CR_t_pk_v;
            sup_corr_data(j).sup_onset=min([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type)(sup_event).onset]);
            sup_corr_data(j).sup_offset=max([file(i).(all_info).ttt.CR_trial(j).mod_trial.(mod_event_type)(sup_event).offset]);
            [sup_amp,sup_pkt_idx]=min(file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post-bin)/step+1),2));
            sup_corr_data(j).sup_amp=-(sup_amp/file(i).(all_info).ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100);
            sup_corr_data(j).sup_pkt=file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+sup_pkt_idx,1);
            sup_corr_data(j).sup_spk=file(i).(all_info).ttt.CR_trial(j).mod_trial.bsl_mod_spk_diff;
        else
            sup_corr_data(j).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
            sup_corr_data(j).CR_onset=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset*1000;
            sup_corr_data(j).CR_amp=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
            sup_corr_data(j).CR_pkt=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_peaktime*1000;
%             [CR_slope,CR_velocity,CR_t_pk_v]=CR_slope_v_cal(file,i,j,all_info,'CR_trial',slope_cal_range,velocity_curve_bin,t_post);
%             sup_corr_data(j).CR_slope=CR_slope;
%             sup_corr_data(j).CR_velocity=CR_velocity;
%             sup_corr_data(j).CR_t_pk_v=CR_t_pk_v;
            sup_corr_data(j).sup_onset=[];
            sup_corr_data(j).sup_offset=[];
            [sup_amp,sup_pkt_idx]=min(file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)((t_pre/step+1):((t_pre+t_post-bin)/step+1),2));
            sup_corr_data(j).sup_amp=-(sup_amp/file(i).(all_info).ttt.CR_trial(j).mod_trial.(bsl_mean_type)*100-100);
            sup_corr_data(j).sup_pkt=file(i).(all_info).ttt.CR_trial(j).mod_trial.(bin_type)(t_pre/step+sup_pkt_idx,1);     
            sup_corr_data(j).sup_spk=file(i).(all_info).ttt.CR_trial(j).mod_trial.bsl_mod_spk_diff;
        end                          
    end   
    trial_mod_list_D(i).fac_corr_data=fac_corr_data;
    trial_mod_list_D(i).sup_corr_data=sup_corr_data;
    
    fac_corr_info=struct('R_onset',[],'P_onset',[],'pdx_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'pdx_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[],'pdx_amp',[]);
    sup_corr_info=struct('R_onset',[],'P_onset',[],'pdx_onset',[],'reg_onset',[],'R_pkt',[],'P_pkt',[],'reg_pkt',[],'pdx_pkt',[],'R_amp',[],'P_amp',[],'reg_amp',[],'pdx_amp',[]);

    fac_onset_form=nan(size(fac_corr_data,2),3);
    for k=1:size(fac_corr_data,2)
        if ~isempty(fac_corr_data(k).fac_onset)
            fac_onset_form(k,1)=fac_corr_data(k).fac_onset;
            fac_onset_form(k,2)=fac_corr_data(k).CR_onset;
        end
    end  
    fac_onset_form=fac_onset_form(all(~isnan(fac_onset_form(:,1)),2),:);
    fac_onset_form=fac_onset_form(all(~isinf(fac_onset_form(:,1)),2),:);
    if size(fac_onset_form,1)>=min_corr_tr_num
        [fac_R_onset,fac_P_onset]=corrcoef(fac_onset_form(:,1),fac_onset_form(:,2));
        p_fac_onset=polyfit(fac_onset_form(:,1),fac_onset_form(:,2),1);
        fac_onset_form(:,3)=p_fac_onset(1)*fac_onset_form(:,1)+p_fac_onset(2);
        fac_corr_info.R_onset=fac_R_onset(2,1);
        fac_corr_info.P_onset=fac_P_onset(2,1);
        fac_corr_info.reg_onset=fac_onset_form;   
        fac_corr_info.pdx_onset=p_fac_onset;
        if fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)>0
           trial_mod_list_D(i).fac_onset_corr=1;
        elseif fac_P_onset(2,1)<0.05 && fac_R_onset(2,1)<=0
           trial_mod_list_D(i).fac_onset_corr=-1;
        else
           trial_mod_list_D(i).fac_onset_corr=0;
        end
    else
        fac_corr_info.R_onset=[];
        fac_corr_info.P_onset=[];
        fac_corr_info.reg_onset=fac_onset_form; 
        fac_corr_info.pdx_onset=[];
        trial_mod_list_D(i).fac_onset_corr=[];
    end

    fac_pkt_form=nan(size(fac_corr_data,2),3);
    for k=1:size(fac_corr_data,2)
        if ~isempty(fac_corr_data(k).fac_pkt)
            fac_pkt_form(k,1)=fac_corr_data(k).fac_pkt;
            fac_pkt_form(k,2)=fac_corr_data(k).CR_pkt;
        end
    end  
    fac_pkt_form=fac_pkt_form(all(~isnan(fac_pkt_form(:,1)),2),:);
    fac_pkt_form=fac_pkt_form(all(~isinf(fac_pkt_form(:,1)),2),:);
    if size(fac_pkt_form,1)>=min_corr_tr_num
        [fac_R_pkt,fac_P_pkt]=corrcoef(fac_pkt_form(:,1),fac_pkt_form(:,2));
        p_fac_pkt=polyfit(fac_pkt_form(:,1),fac_pkt_form(:,2),1);
        fac_pkt_form(:,3)=p_fac_pkt(1)*fac_pkt_form(:,1)+p_fac_pkt(2);
        fac_corr_info.R_pkt=fac_R_pkt(2,1);
        fac_corr_info.P_pkt=fac_P_pkt(2,1);
        fac_corr_info.reg_pkt=fac_pkt_form;
        fac_corr_info.pdx_pkt=p_fac_pkt;
        if fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)>0
           trial_mod_list_D(i).fac_pkt_corr=1;
        elseif fac_P_pkt(2,1)<0.05 && fac_R_pkt(2,1)<=0
           trial_mod_list_D(i).fac_pkt_corr=-1;
        else
           trial_mod_list_D(i).fac_pkt_corr=0;
        end
    else
        fac_corr_info.R_pkt=[];
        fac_corr_info.P_pkt=[];
        fac_corr_info.reg_pkt=fac_pkt_form; 
        fac_corr_info.pdx_pkt=[];
        trial_mod_list_D(i).fac_pkt_corr=[];
    end
    
    fac_amp_form=nan(size(fac_corr_data,2),3);
    for k=1:size(fac_corr_data,2)
        if ~isempty(fac_corr_data(k).fac_amp)
            fac_amp_form(k,1)=fac_corr_data(k).fac_amp;
            fac_amp_form(k,2)=fac_corr_data(k).CR_amp;
        end
    end  
    fac_amp_form=fac_amp_form(all(~isnan(fac_amp_form(:,1)),2),:);
    fac_amp_form=fac_amp_form(all(~isinf(fac_amp_form(:,1)),2),:);
    if size(fac_amp_form,1)>=min_corr_tr_num
        [fac_R_amp,fac_P_amp]=corrcoef(fac_amp_form(:,1),fac_amp_form(:,2));
        p_fac_amp=polyfit(fac_amp_form(:,1),fac_amp_form(:,2),1);
        fac_amp_form(:,3)=p_fac_amp(1)*fac_amp_form(:,1)+p_fac_amp(2);
        fac_corr_info.R_amp=fac_R_amp(2,1);
        fac_corr_info.P_amp=fac_P_amp(2,1);
        fac_corr_info.reg_amp=fac_amp_form;   
        fac_corr_info.pdx_amp=p_fac_amp;
        if fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)>0
           trial_mod_list_D(i).fac_amp_corr=1;
        elseif fac_P_amp(2,1)<0.05 && fac_R_amp(2,1)<=0
           trial_mod_list_D(i).fac_amp_corr=-1;
        else
           trial_mod_list_D(i).fac_amp_corr=0;
        end
    else
        fac_corr_info.R_amp=[];
        fac_corr_info.P_amp=[];
        fac_corr_info.reg_amp=fac_amp_form;
        fac_corr_info.pdx_amp=[];
        trial_mod_list_D(i).fac_amp_corr=[];
    end
    
    sup_onset_form=nan(size(sup_corr_data,2),3);
    for k=1:size(sup_corr_data,2)
        if ~isempty(sup_corr_data(k).sup_onset)
            sup_onset_form(k,1)=sup_corr_data(k).sup_onset;
            sup_onset_form(k,2)=sup_corr_data(k).CR_onset;
        end
    end  
    sup_onset_form=sup_onset_form(all(~isnan(sup_onset_form(:,1)),2),:);
    sup_onset_form=sup_onset_form(all(~isinf(sup_onset_form(:,1)),2),:);
    if size(sup_onset_form,1)>=min_corr_tr_num
        [sup_R_onset,sup_P_onset]=corrcoef(sup_onset_form(:,1),sup_onset_form(:,2));
        p_sup_onset=polyfit(sup_onset_form(:,1),sup_onset_form(:,2),1);
        sup_onset_form(:,3)=p_sup_onset(1)*sup_onset_form(:,1)+p_sup_onset(2);
        sup_corr_info.R_onset=sup_R_onset(2,1);
        sup_corr_info.P_onset=sup_P_onset(2,1);
        sup_corr_info.reg_onset=sup_onset_form; 
        sup_corr_info.pdx_onset=p_sup_onset;
        if sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)>0
           trial_mod_list_D(i).sup_onset_corr=1;
        elseif sup_P_onset(2,1)<0.05 && sup_R_onset(2,1)<=0
           trial_mod_list_D(i).sup_onset_corr=-1;
        else
           trial_mod_list_D(i).sup_onset_corr=0;
        end
    else
        sup_corr_info.R_onset=[];
        sup_corr_info.P_onset=[];
        sup_corr_info.reg_onset=sup_onset_form; 
        sup_corr_info.pdx_onset=[];
        trial_mod_list_D(i).sup_onset_corr=[];
    end

    sup_pkt_form=nan(size(sup_corr_data,2),3);
    for k=1:size(sup_corr_data,2)
        if ~isempty(sup_corr_data(k).sup_pkt)
            sup_pkt_form(k,1)=sup_corr_data(k).sup_pkt;
            sup_pkt_form(k,2)=sup_corr_data(k).CR_pkt;
        end
    end  
    sup_pkt_form=sup_pkt_form(all(~isnan(sup_pkt_form(:,1)),2),:);
    sup_pkt_form=sup_pkt_form(all(~isinf(sup_pkt_form(:,1)),2),:);
    if size(sup_pkt_form,1)>=min_corr_tr_num
        [sup_R_pkt,sup_P_pkt]=corrcoef(sup_pkt_form(:,1),sup_pkt_form(:,2));
        p_sup_pkt=polyfit(sup_pkt_form(:,1),sup_pkt_form(:,2),1);
        sup_pkt_form(:,3)=p_sup_pkt(1)*sup_pkt_form(:,1)+p_sup_pkt(2);
        sup_corr_info.R_pkt=sup_R_pkt(2,1);
        sup_corr_info.P_pkt=sup_P_pkt(2,1);
        sup_corr_info.reg_pkt=sup_pkt_form;
        sup_corr_info.pdx_pkt=p_sup_pkt;
        if sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)>0
           trial_mod_list_D(i).sup_pkt_corr=1;
        elseif sup_P_pkt(2,1)<0.05 && sup_R_pkt(2,1)<=0
           trial_mod_list_D(i).sup_pkt_corr=-1;
        else
           trial_mod_list_D(i).sup_pkt_corr=0;
        end
    else
        sup_corr_info.R_pkt=[];
        sup_corr_info.P_pkt=[];
        sup_corr_info.reg_pkt=sup_pkt_form; 
        sup_corr_info.pdx_pkt=[];
        trial_mod_list_D(i).sup_pkt_corr=[];
    end
    
    sup_amp_form=nan(size(sup_corr_data,2),3);
    for k=1:size(sup_corr_data,2)
        if ~isempty(sup_corr_data(k).sup_amp)
            sup_amp_form(k,1)=sup_corr_data(k).sup_amp;
            sup_amp_form(k,2)=sup_corr_data(k).CR_amp;
        end
    end  
    sup_amp_form=sup_amp_form(all(~isnan(sup_amp_form(:,1)),2),:);
    sup_amp_form=sup_amp_form(all(~isinf(sup_amp_form(:,1)),2),:);
    if size(sup_amp_form,1)>=min_corr_tr_num
        [sup_R_amp,sup_P_amp]=corrcoef(sup_amp_form(:,1),sup_amp_form(:,2));
        p_sup_amp=polyfit(sup_amp_form(:,1),sup_amp_form(:,2),1);
        sup_amp_form(:,3)=p_sup_amp(1)*sup_amp_form(:,1)+p_sup_amp(2);
        sup_corr_info.R_amp=sup_R_amp(2,1);
        sup_corr_info.P_amp=sup_P_amp(2,1);
        sup_corr_info.reg_amp=sup_amp_form; 
        sup_corr_info.pdx_amp=p_sup_amp;
        if sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)>0
           trial_mod_list_D(i).sup_amp_corr=1;
        elseif sup_P_amp(2,1)<0.05 && sup_R_amp(2,1)<=0
           trial_mod_list_D(i).sup_amp_corr=-1;
        else
           trial_mod_list_D(i).sup_amp_corr=0;
        end
    else
        sup_corr_info.R_amp=[];
        sup_corr_info.P_amp=[];
        sup_corr_info.reg_amp=sup_amp_form; 
        sup_corr_info.pdx_amp=[];
        trial_mod_list_D(i).sup_amp_corr=[];
    end
   
    trial_mod_list_D(i).fac_corr_info=fac_corr_info;
    trial_mod_list_D(i).sup_corr_info=sup_corr_info;     
    
%     other_corr_info_11=other_corr(trial_mod_list_T(i).(other_corr_data_11),other_item_mod_11,other_item_bhv_11,min_corr_tr_num);
%     trial_mod_list_T(i).other_corr_info_11=other_corr_info_11;
%     
%     other_corr_info_12=other_corr(trial_mod_list_T(i).(other_corr_data_12),other_item_mod_12,other_item_bhv_12,min_corr_tr_num);
%     trial_mod_list_T(i).other_corr_info_12=other_corr_info_12;
%     
%     other_corr_info_21=other_corr(trial_mod_list_T(i).(other_corr_data_21),other_item_mod_21,other_item_bhv_21,min_corr_tr_num);
%     trial_mod_list_T(i).other_corr_info_21=other_corr_info_21;
%     
%     other_corr_info_22=other_corr(trial_mod_list_T(i).(other_corr_data_22),other_item_mod_22,other_item_bhv_22,min_corr_tr_num);
%     trial_mod_list_T(i).other_corr_info_22=other_corr_info_22;
end

function corr_info=other_corr(corr_data,item_mod,item_bhv,min_corr_tr_num)
    corr_info=struct('R',[],'P',[],'reg',[],'pdx',[]);
    corr_form=nan(size(corr_data,2),3);
    for k=1:size(corr_data,2)
        if ~isempty(corr_data(k).(item_mod))
            corr_form(k,1)=corr_data(k).(item_mod);
            corr_form(k,2)=corr_data(k).(item_bhv);
        end
    end  
    corr_form=corr_form(all(~isnan(corr_form(:,1)),2),:);
    corr_form=corr_form(all(~isinf(corr_form(:,1)),2),:);
    if size(corr_form,1)>=min_corr_tr_num
        [R,P]=corrcoef(corr_form(:,1),corr_form(:,2));
        p_sup_pkt=polyfit(corr_form(:,1),corr_form(:,2),1);
        corr_form(:,3)=p_sup_pkt(1)*corr_form(:,1)+p_sup_pkt(2);
        corr_info.R=R(2,1);
        corr_info.P=P(2,1);
        corr_info.reg=corr_form;
        corr_info.pdx=p_sup_pkt;
    else
        corr_info.R=[];
        corr_info.P=[];
        corr_info.reg=corr_form; 
        corr_info.pdx=[];
    end
end

function [CR_slope,CR_velocity,CR_t_pk_v]=CR_slope_v_cal(cell_list,session_id,trial_id,all_info,trial_type,slope_cal_range,velocity_curve_bin,t_post)


            if cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_info_new.CR_peaktime-cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_info_new.CR_onset>0
               amp_idx_1=cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_info_new.CR_amp*slope_cal_range(1);
               amp_idx_2=cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_info_new.CR_amp*slope_cal_range(2); 
               [inter_t_1,inter_amp_1,iout_1,jout_1] = intersections(cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(:,1),cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(:,2),[0 t_post],[amp_idx_1 amp_idx_1],1);
               [inter_t_2,inter_amp_2,iout_2,jout_2] = intersections(cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(:,1),cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(:,2),[0 t_post],[amp_idx_2 amp_idx_2],1);
               if length(inter_t_1)>1
                   [inter_t_1,inter_t_1_idx]=min(abs(inter_t_1-cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_info_new.CR_onset*1000));
                   inter_amp_1=inter_amp_1(inter_t_1_idx);
               end
               if isempty(inter_t_1)
                   inter_t_1=NaN;
                   inter_amp_1=NaN;
               end
               if length(inter_t_2)>1
                   inter_t_2=inter_t_2(1);
                   inter_amp_2=inter_amp_2(1);
               end 
               if isempty(inter_t_2)
                   inter_t_2=NaN;
                   inter_amp_2=NaN;
               end
               CR_slope=(inter_amp_2-inter_amp_1)/(inter_t_2-inter_t_1)*100;
            else
               CR_slope=NaN;
            end                                                

            velocity_curve_trial=zeros(1550/velocity_curve_bin,2);
            for k=1:1550/velocity_curve_bin
                k_1=(k-1)*velocity_curve_bin+1;
                k_2=k*velocity_curve_bin;
                velocity_curve_trial(k,1)=cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(k_1,1)+velocity_curve_bin/2;
                velocity_curve_trial(k,2)=(cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(k_2,2)-cell_list(session_id).(all_info).ttt.(trial_type)(trial_id).blk_smth(k_1,2))/velocity_curve_bin;          
            end
            t_idx= velocity_curve_trial(:,1)>=0 & velocity_curve_trial(:,1)<t_post;
            [CR_velocity,idx_t_max_velocity]=max(velocity_curve_trial(t_idx,2));
            CR_t_pk_v=velocity_curve_trial(find(t_idx,1,'first')+idx_t_max_velocity-1,1);
end


