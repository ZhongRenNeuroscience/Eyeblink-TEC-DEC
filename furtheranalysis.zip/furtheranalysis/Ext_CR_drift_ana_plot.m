% Plot CR amplitude and CR onset against trial number during DEC extinction

item_1='CR_amp';
item_2='CR_on';
unit_1='(%)';
unit_2='(ms)';
matfile_name='behavior_form_prb';
ylim_1=[0 100];
ylim_2=[0 500];
bin=10;
step=2;
trial_num_split=4;

listing=dir('*_ext_probe.mat');

all_session_form=struct('session_ID',[],'data',[],'curve_1',[],'curve_2',[]);
for i=1:size(listing,1)

    session_form=load(listing(i).name);
    file_ID=extractBefore(listing(i).name,'_ext_probe.mat');
    data=struct('trial_num',[],item_1,[],item_2,[]);
    jdx=0;
    
    figure;
    for j=1:size(session_form.(matfile_name),2)-1
        if ~isnan(session_form.(matfile_name)(j).(item_1)) && ~isnan(session_form.(matfile_name)(j).(item_2))
            jdx=jdx+1;
            data(jdx).trial_num=jdx;
            data(jdx).(item_1)=session_form.(matfile_name)(j).(item_1);
            data(jdx).(item_2)=session_form.(matfile_name)(j).(item_2);
%             yyaxis left
%             plot(data(jdx).trial_num,data(jdx).(item_1),'b.')
%             hold on
%             yyaxis right
            plot(data(jdx).trial_num,data(jdx).(item_2),'r.')
            hold on
        end
    end

    trial_group=quantile(1:size(data,2),trial_num_split-1);
    trial_group=[0 floor(trial_group(1:trial_num_split-1)) size(data,2)];
    
    curve_plot_1=smooth_curve([data.trial_num],[data.(item_1)],bin,step);
    curve_plot_2=smooth_curve([data.trial_num],[data.(item_2)],bin,step);

    all_session_form(i).session_ID=file_ID;
    all_session_form(i).data=data;
    all_session_form(i).curve_1=curve_plot_1;
    all_session_form(i).curve_2=curve_plot_2;
    for k=1:trial_num_split
        field_name=[item_1 '_mean_' num2str(k)];
        data_include=trial_group(k)+1:trial_group(k+1);
        all_session_form(i).(field_name)=nanmean([data(data_include).(item_1)]);       
    end
    for k=1:trial_num_split
        field_name=[item_2 '_mean_' num2str(k)];
        data_include=trial_group(k)+1:trial_group(k+1);
        all_session_form(i).(field_name)=nanmean([data(data_include).(item_2)]); 
    end    
    
%     yyaxis left
%     plot(curve_plot_1(:,1),curve_plot_1(:,2),'-')
%     hold on
%     xlabel('Trial')
%     ylabel([item_1 ' ' unit_1],'Interpreter','none')
    xlim([0 jdx+1]);
%     ylim(ylim_1);
    
%     yyaxis right
    plot(curve_plot_2(:,1),curve_plot_2(:,2),'-')
    hold on    
    ylabel([item_2 ' ' unit_2],'Interpreter','none')
    ylim(ylim_2);
    
    title(file_ID,'Interpreter','none');
    
    
    saveas(gcf,[file_ID '_' item_2 '.pdf']);
%     close all

end


function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros(floor((length(x)-bin)/step)+1,2);
    for i=1:floor((length(x)-bin)/step)+1
        smth_curve(i,1)=median(x((i-1)*step+1:(i-1)*step+bin));
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end