
sps_form=struct('cell_ID',[],'early_CR_on',[],'late_CR_on',[],'early_fac_on',[],'late_fac_on',[],'early_sup_on',[],'late_sup_on',[],'bsl_frq',[],'mod_f',[],'mod_s',[],'t',[]);
sps_trial=struct('cell_ID',[],'on_info',[],'early_info',[],'early_psth',[],'early_blk',[],'late_info',[],'late_psth',[],'late_blk',[],'t_smth',[]);
% first loop for each cell
j=1;
for i=1:size(list_PC,2)
    if isempty(list_PC(i).CR_fac_cps)
        continue
    end
    sps_trial(j).cell_ID=list_PC(i).cell_ID;
% second loop for each trial 
    sps_trial(j).on_info=zeros(size(list_PC(i).all_info_sps.ttt.CR_trial,2),2);
    for m=1:size(list_PC(i).all_info_sps.ttt.CR_trial,2)
        sps_trial(j).on_info(m,1)=m;
        sps_trial(j).on_info(m,2)=list_PC(i).all_info_sps.ttt.CR_trial(m).blk_info_new.CR_onset*1000;
    end
    sps_trial(j).on_info(any(isnan(sps_trial(j).on_info),2),:) = [];
    [rank,idx]=sort(sps_trial(j).on_info(:,2));
%     if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 30
%        early=0;
%        late=0;
    if length(rank) < 40
       early=idx(find(idx,20,'first'),1);
       late=idx(find(idx,20,'last'),1);
    else
        sz_mod=mod(length(rank),2);
        sz_group=(length(rank)-sz_mod)/2;
        early=idx(find(idx,sz_group+sz_mod,'first'),1);
        late=idx(find(idx,sz_group,'last'),1);
    end
    sps_trial(j).early_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
    early_ifr_form=zeros(32001,size(early,1));
    early_blk_form=zeros(1550,size(early,1));
    sps_trial(j).late_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
    late_ifr_form=zeros(32001,size(late,1));
    late_blk_form=zeros(1550,size(late,1));
    for n=1:size(early,1)
        sps_trial(j).early_info(n).trial_num=sps_trial(j).on_info(early(n,1),1);
        sps_trial(j).early_info(n).cr_onset=list_PC(i).all_info_sps.ttt.CR_trial(sps_trial(j).on_info(early(n,1),1)).blk_info_new.CR_onset*1000;
        sps_trial(j).early_info(n).ifr=list_PC(i).all_info_sps.ttt.CR_trial(sps_trial(j).on_info(early(n,1),1)).ifr_org_Gau(:,2);
        sps_trial(j).early_info(n).blk=list_PC(i).all_info_sps.ttt.CR_trial(sps_trial(j).on_info(early(n,1),1)).blk_smth(:,2);
        early_ifr_form(:,n)=sps_trial(j).early_info(n).ifr;
        early_blk_form(:,n)=sps_trial(j).early_info(n).blk;
    end
    for n=1:size(late,1)
        sps_trial(j).late_info(n).trial_num=sps_trial(j).on_info(late(n,1),1);
        sps_trial(j).late_info(n).cr_onset=list_PC(i).all_info_sps.ttt.CR_trial(sps_trial(j).on_info(late(n,1),1)).blk_info_new.CR_onset*1000;
        sps_trial(j).late_info(n).ifr=list_PC(i).all_info_sps.ttt.CR_trial(sps_trial(j).on_info(late(n,1),1)).ifr_org_Gau(:,2);
        sps_trial(j).late_info(n).blk=list_PC(i).all_info_sps.ttt.CR_trial(sps_trial(j).on_info(late(n,1),1)).blk_smth(:,2);
        late_ifr_form(:,n)=sps_trial(j).late_info(n).ifr;
        late_blk_form(:,n)=sps_trial(j).late_info(n).blk;
    end
    sps_form(j).cell_ID=i;
    sps_form(j).early_CR_on=nanmean([sps_trial(j).early_info.cr_onset]);
    sps_form(j).late_CR_on=nanmean([sps_trial(j).late_info.cr_onset]);
   
    early_psth2=mean(early_ifr_form,2);
    late_psth2=mean(late_ifr_form,2);  
    early_psth=zeros(1600,2);
    late_psth=zeros(1600,2);
    early_psth(:,1)=-550:1:1049;
    late_psth(:,1)=-550:1:1049;    

    for k=1:1600            
        early_psth(k,2)=mean(early_psth2(20*k-19:20*k,1))*1000/list_PC(i).all_info_sps.sss_all.psth.CR_trial.bsl_frq*100;
        late_psth(k,2)=mean(late_psth2(20*k-19:20*k,1))*1000/list_PC(i).all_info_sps.sss_all.psth.CR_trial.bsl_frq*100;          
    end
    
    ear_bsl=mean(early_psth(early_psth(:,1) < 0 & early_psth(:,1) >= -500,2));
    ear_sd=std(early_psth(early_psth(:,1) < 0 & early_psth(:,1) >= -500,2));
    ear_shrld_up=ear_bsl+3*ear_sd;
    ear_shrld_dn=ear_bsl-3*ear_sd;
    for t=551:1050
        tt=t-551;
        if early_psth(t,2)>=ear_shrld_up
            break
        end
    end
    if tt==499
       tt=NaN;
    end
    sps_form(j).early_fac_on=tt;
    
    for t=551:1050
        tt=t-551;
        if early_psth(t,2)<=ear_shrld_dn
            break
        end
    end
    if tt==499
       tt=NaN;
    end
    sps_form(j).early_sup_on=tt;    
    
    late_bsl=mean(late_psth(late_psth(:,1)<0 & late_psth(:,1) >= -500,2));
    late_sd=std(late_psth(late_psth(:,1)<0 & late_psth(:,1) >= -500,2));
    late_shrld_up=late_bsl+3*late_sd;
    late_shrld_dn=late_bsl-3*late_sd;
    
    for t=551:1050
        tt=t-551;
        if late_psth(t,2)>=late_shrld_up
            break
        end
    end
    if tt==499
       tt=NaN;
    end
    sps_form(j).late_fac_on=tt;
    
    for t=551:1050
        tt=t-551;
        if late_psth(t,2)<=late_shrld_dn
            break
        end
    end
    if tt==499
       tt=NaN;
    end
    sps_form(j).late_sup_on=tt;
    
    sps_form(j).bsl_frq=list_PC(i).all_info_sps.sss_all.psth.CR_trial.bsl_frq;
    sps_form(j).mod_f=list_PC(i).CR_fac_sps;
    sps_form(j).mod_s=list_PC(i).CR_sup_sps;
    
    t_smth=zeros(60,2);
    for k=1:60
        idx=451+(k-1)*10;
        t_smth(k,1)=mean(early_psth(idx:idx+9,2));
        t_smth(k,2)=mean(late_psth(idx:idx+9,2));
    end
    [p,h,stats] = signrank(t_smth(11:60,1),t_smth(11:60,2));
    sps_form(j).t=p;
    sps_trial(j).t_smth=t_smth;
    
    early_blk=zeros(1550,2);
    late_blk=zeros(1550,2);
    early_blk(:,1)=list_PC(1).all_info_sps.ttt.CR_trial(1).blk_smth(:,1);
    early_blk(:,2)=mean(early_blk_form,2);
    sps_trial(j).early_blk=early_blk;
    late_blk(:,1)=list_PC(1).all_info_sps.ttt.CR_trial(1).blk_smth(:,1);
    late_blk(:,2)=mean(late_blk_form,2);
    sps_trial(j).late_blk=late_blk;
    
    sps_trial(j).early_psth=early_psth;
    sps_trial(j).late_psth=late_psth;
    
    j=j+1;
    
%     clear early late idx rank sz_group sz_mod early_ifr_form early_psth late_ifr_form late_psth 
end
% clear i j k m n t tt type

% type='sup';
% sup_form=zeros(size(list_mod.sup,2),5);
% sup_trial=struct('sup_num',[],'cell_ID',[],'on_info',[],'early_info',[],'early_psth',[],'early_blk',[],'late_info',[],'late_psth',[],'late_blk',[]);
% % first loop for each cell
% for i=1:size(list_mod.sup,2)
%     j=i;
%     sup_trial(j).sup_num=i;
%     sup_trial(j).cell_ID=list_mod.(type)(i).cell_ID;
% % second loop for each trial 
%     sup_trial(j).on_info=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
%     for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
%         sup_trial(j).on_info(m,1)=m;
%         sup_trial(j).on_info(m,2)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info_new.CR_onset*1000;
%     end
%     sup_trial(j).on_info(any(isnan(sup_trial(j).on_info),2),:) = [];
%     [rank,idx]=sort(sup_trial(j).on_info(:,2));
% %     if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 30
% %        early=0;
% %        late=0;
%     if length(rank) < 40
%        early=idx(find(idx,20,'first'),1);
%        late=idx(find(idx,20,'last'),1);
%     else
%         sz_mod=mod(length(rank),2);
%         sz_group=(length(rank)-sz_mod)/2;
%         early=idx(find(idx,sz_group+sz_mod,'first'),1);
%         late=idx(find(idx,sz_group,'last'),1);
%     end
%     sup_trial(j).early_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
%     early_ifr_form=zeros(32001,size(early,1));
%     early_blk_form=zeros(1550,size(early,1));
%     sup_trial(j).late_info=struct('trial_num',[],'cr_onset',[],'ifr',[],'blk',[]);
%     late_ifr_form=zeros(32001,size(late,1));
%     late_blk_form=zeros(1550,size(late,1));
%     for n=1:size(early,1)
%         sup_trial(j).early_info(n).trial_num=sup_trial(j).on_info(early(n,1),1);
%         sup_trial(j).early_info(n).cr_onset=list_mod.(type)(i).all_info.ttt.CR_trial(sup_trial(j).on_info(early(n,1),1)).blk_info_new.CR_onset*1000;
%         sup_trial(j).early_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(sup_trial(j).on_info(early(n,1),1)).ifr_org_Gau(:,2);
%         sup_trial(j).early_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(sup_trial(j).on_info(early(n,1),1)).blk_smth(:,2);
%         early_ifr_form(:,n)=sup_trial(j).early_info(n).ifr;
%         early_blk_form(:,n)=sup_trial(j).early_info(n).blk;
%     end
%     for n=1:size(late,1)
%         sup_trial(j).late_info(n).trial_num=sup_trial(j).on_info(late(n,1),1);
%         sup_trial(j).late_info(n).cr_onset=list_mod.(type)(i).all_info.ttt.CR_trial(sup_trial(j).on_info(late(n,1),1)).blk_info_new.CR_onset*1000;
%         sup_trial(j).late_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(sup_trial(j).on_info(late(n,1),1)).ifr_org_Gau(:,2);
%         sup_trial(j).late_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(sup_trial(j).on_info(late(n,1),1)).blk_smth(:,2);
%         late_ifr_form(:,n)=sup_trial(j).late_info(n).ifr;
%         late_blk_form(:,n)=sup_trial(j).late_info(n).blk;
%     end
%     sup_form(j,1)=i;
%     sup_form(j,2)=nanmean([sup_trial(j).early_info.cr_onset]);
%     sup_form(j,3)=nanmean([sup_trial(j).late_info.cr_onset]);
%     early_psth2=mean(early_ifr_form,2);
%     late_psth2=mean(late_ifr_form,2);  
%     early_psth=zeros(1600,2);
%     late_psth=zeros(1600,2);
%     early_psth(:,1)=-550:1:1049;
%     late_psth(:,1)=-550:1:1049;    
% 
%     for k=1:1600            
%         early_psth(k,2)=mean(early_psth2(20*k-19:20*k,1))*1000/list_mod.(type)(i).all_info.sss_all.psth.CR_trial.avg_frq*100;
%         late_psth(k,2)=mean(late_psth2(20*k-19:20*k,1))*1000/list_mod.(type)(i).all_info.sss_all.psth.CR_trial.avg_frq*100;          
%     end
%     
%     ear_bsl=mean(early_psth(early_psth(:,1) < 0 & early_psth(:,1) >= -500,2));
%     ear_sd=std(early_psth(early_psth(:,1) < 0 & early_psth(:,1) >= -500,2));
%     ear_shrld=ear_bsl-3*ear_sd;
%     for t=551:1050
%         tt=t-551;
%         if early_psth(t,2)<=ear_shrld
%             break
%         end
%     end
%     if tt==499
%        tt=NaN;
%     end
%     sup_form(j,4)=tt;
%     
%     late_bsl=mean(late_psth(late_psth(:,1)<0 & late_psth(:,1) >= -500,2));
%     late_sd=std(late_psth(late_psth(:,1)<0 & late_psth(:,1) >= -500,2));
%     late_shrld=late_bsl-3*late_sd;
%     for t=551:1050
%         tt=t-551;
%         if late_psth(t,2)<=late_shrld
%             break
%         end
%     end
%     if tt==499
%        tt=NaN;
%     end
%     sup_form(j,5)=tt;
%     
%     early_blk=zeros(1550,2);
%     late_blk=zeros(1550,2);
%     early_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_smth(:,1);
%     early_blk(:,2)=mean(early_blk_form,2);
%     sup_trial(j).early_blk=early_blk;
%     late_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_smth(:,1);
%     late_blk(:,2)=mean(late_blk_form,2);
%     sup_trial(j).late_blk=late_blk;
%     
%     sup_trial(j).early_psth=early_psth;
%     sup_trial(j).late_psth=late_psth;
%     
%     clear eearly late idx rank sz_group sz_mod early_ifr_form early_psth late_ifr_form late_psth 
% end
% clear i j k m n t tt type ear_bsl ear_sd ear_shrld early late_bsl late_sd late_shrld early 


% figure;
% plot(fac_form(:,5)-fac_form(:,4),fac_form(:,3)-fac_form(:,2),'r.')
% hold on
% plot(sup_form(:,5)-sup_form(:,4),sup_form(:,3)-sup_form(:,2),'b.')
% hold on
% xlabel('Mod onset late-early (ms)');
% ylabel('CR onset late-early (ms)');
% % xlim([-200 500]);
% % ylim([0 500]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--');
% line([0 0],[0,500],'Color',[0 0 0],'LineStyle','--');
% % legend({'Facilitation','Suppression'},'Location','northwest');
% % line([-300,500],[0 0],'Color',[0 0 0],'LineStyle','--');

% figure;
% plot(sps_form(:,4),sps_form(:,5),'r.')
% hold on
% % plot(sup_form(:,4),sup_form(:,5),'b.')
% % hold on 
% xlabel('Mod. onset of early CR onset trials');
% ylabel('Mod. onset of late CR onset trials');
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--');