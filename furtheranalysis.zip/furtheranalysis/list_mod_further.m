cell_list=struct('session_ID',[],'cell_ID',[],'bsl_frq',[],'CRmod_type',[],'mod_amp',[],'mod_pkt',[],'ttt_r',[],'ttt_p',[],...
    'URmod_type',[],'UR_amp',[],'UR_pkt',[]);

for i=1:size(list_mod.fac,2)
    cell_list(i).session_ID=list_mod.fac(i).file_name;
    cell_list(i).cell_ID=list_mod.fac(i).cell_ID;
    cell_list(i).bsl_frq=list_mod.fac(i).all_info.sss_all.psth.CR_trial.avg_frq;
    cell_list(i).CRmod_type='Facilitation';
    if list_mod.fac(i).CR_fac > 1
       CR_fac=zeros(1,list_mod.fac(i).CR_fac);
       for k=1:list_mod.fac(i).CR_fac
           CR_fac(1,k)=(list_mod.fac(i).mod_info.CRf(k).peak-cell_list(i).bsl_frq)/cell_list(i).bsl_frq*100;
       end             
       [cell_list(i).mod_amp,I]=max(CR_fac);
       cell_list(i).mod_pkt=list_mod.fac(i).mod_info.CRf(I).t_peak;
    else
       cell_list(i).mod_amp=(list_mod.fac(i).mod_info.CRf(1).peak-cell_list(i).bsl_frq)/cell_list(i).bsl_frq*100;
       cell_list(i).mod_pkt=list_mod.fac(i).mod_info.CRf(1).t_peak;
    end
    cell_list(i).ttt_r=ttt_fac(i).R;
    cell_list(i).ttt_p=ttt_fac(i).P;
    if list_mod.fac(i).UR_fac==1 && list_mod.fac(i).UR_sup==0
       cell_list(i).URmod_type='Facilitation';
       cell_list(i).UR_amp=(list_mod.fac(i).mod_info.URf.peak-cell_list(i).bsl_frq)/cell_list(i).bsl_frq*100;
       cell_list(i).UR_pkt=list_mod.fac(i).mod_info.URf.t_peak-500;
    elseif list_mod.fac(i).UR_fac==0 && list_mod.fac(i).UR_sup==1
       cell_list(i).URmod_type='Suppression';
       cell_list(i).UR_amp=(list_mod.fac(i).mod_info.URs.peak-cell_list(i).bsl_frq)/cell_list(i).bsl_frq*100;
       cell_list(i).UR_pkt=list_mod.fac(i).mod_info.URs.t_peak-500;
    elseif list_mod.fac(i).UR_fac==1 && list_mod.fac(i).UR_sup==1
           if list_mod.fac(i).mod_info.URf.t_peak < list_mod.fac(i).mod_info.URs.t_peak
              cell_list(i).URmod_type='Facilitation';
              cell_list(i).UR_amp=(list_mod.fac(i).mod_info.URf.peak-cell_list(i).bsl_frq)/cell_list(i).bsl_frq*100;
              cell_list(i).UR_pkt=list_mod.fac(i).mod_info.URf.t_peak-500;
           elseif list_mod.fac(i).mod_info.URf.t_peak > list_mod.fac(i).mod_info.URs.t_peak
              cell_list(i).URmod_type='Suppression';
              cell_list(i).UR_amp=(list_mod.fac(i).mod_info.URs.peak-cell_list(i).bsl_frq)/cell_list(i).bsl_frq*100;
              cell_list(i).UR_pkt=list_mod.fac(i).mod_info.URs.t_peak-500;
           end
    end
end

j=i;

for i=1:size(list_mod.sup,2)
    cell_list(i+j).session_ID=list_mod.sup(i).file_name;
    cell_list(i+j).cell_ID=list_mod.sup(i).cell_ID;
    cell_list(i+j).bsl_frq=list_mod.sup(i).all_info.sss_all.psth.CR_trial.avg_frq;
    cell_list(i+j).CRmod_type='Suppression';
    if list_mod.sup(i).CR_sup > 1
       CR_sup=zeros(1,list_mod.sup(i).CR_sup);
       for k=1:list_mod.sup(i).CR_sup
           CR_sup(1,k)=(list_mod.sup(i).mod_info.CRs(k).peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
       end             
       [cell_list(i+j).mod_amp,I]=min(CR_sup);
       cell_list(i+j).mod_pkt=list_mod.sup(i).mod_info.CRs(I).t_peak;
    else
       cell_list(i+j).mod_amp=(list_mod.sup(i).mod_info.CRs(1).peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
       cell_list(i+j).mod_pkt=list_mod.sup(i).mod_info.CRs(1).t_peak;
    end
    cell_list(i+j).ttt_r=ttt_sup(i).R;
    cell_list(i+j).ttt_p=ttt_sup(i).P;
    if list_mod.sup(i).UR_fac==1 && list_mod.sup(i).UR_sup==0
       cell_list(i+j).URmod_type='Facilitation';
       cell_list(i+j).UR_amp=(list_mod.sup(i).mod_info.URf.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
       cell_list(i+j).UR_pkt=list_mod.sup(i).mod_info.URf.t_peak-500;
    elseif list_mod.sup(i).UR_fac==0 && list_mod.sup(i).UR_sup==1
       cell_list(i+j).URmod_type='Suppression';
       cell_list(i+j).UR_amp=(list_mod.sup(i).mod_info.URs.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
       cell_list(i+j).UR_pkt=list_mod.sup(i).mod_info.URs.t_peak-500;
    elseif list_mod.sup(i).UR_fac==1 && list_mod.sup(i).UR_sup==1
           if list_mod.sup(i).mod_info.URf.t_peak < list_mod.sup(i).mod_info.URs.t_peak
              cell_list(i+j).URmod_type='Facilitation';
              cell_list(i+j).UR_amp=(list_mod.sup(i).mod_info.URf.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
              cell_list(i+j).UR_pkt=list_mod.sup(i).mod_info.URf.t_peak-500;
           elseif list_mod.sup(i).mod_info.URf.t_peak > list_mod.sup(i).mod_info.URs.t_peak
              cell_list(i+j).URmod_type='Suppression';
              cell_list(i+j).UR_amp=(list_mod.sup(i).mod_info.URs.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
              cell_list(i+j).UR_pkt=list_mod.sup(i).mod_info.URs.t_peak-500;
           end
    end
end

j=i+j;

for i=1:size(list_mod.non,2)
    cell_list(i+j).session_ID=list_mod.non(i).file_name;
    cell_list(i+j).cell_ID=list_mod.non(i).cell_ID;
    cell_list(i+j).bsl_frq=list_mod.non(i).all_info.sss_all.psth.CR_trial.avg_frq;
    cell_list(i+j).CRmod_type='Non-modulation';
    cell_list(i+j).mod_amp='-';
    cell_list(i+j).mod_pkt='-';
    cell_list(i+j).ttt_r='-';
    cell_list(i+j).ttt_p='-';
    if list_mod.non(i).UR_fac==1 && list_mod.non(i).UR_sup==0
       cell_list(i+j).URmod_type='Facilitation';
       cell_list(i+j).UR_amp=(list_mod.non(i).mod_info.URf.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
       cell_list(i+j).UR_pkt=list_mod.non(i).mod_info.URf.t_peak-500;
    elseif list_mod.non(i).UR_fac==0 && list_mod.non(i).UR_sup==1
       cell_list(i+j).URmod_type='Suppression';
       cell_list(i+j).UR_amp=(list_mod.non(i).mod_info.URs.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
       cell_list(i+j).UR_pkt=list_mod.non(i).mod_info.URs.t_peak-500;
    elseif list_mod.non(i).UR_fac==1 && list_mod.non(i).UR_sup==1
           if list_mod.non(i).mod_info.URf.t_peak < list_mod.non(i).mod_info.URs.t_peak
              cell_list(i+j).URmod_type='Facilitation';
              cell_list(i+j).UR_amp=(list_mod.non(i).mod_info.URf.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
              cell_list(i+j).UR_pkt=list_mod.non(i).mod_info.URf.t_peak-500;
           elseif list_mod.non(i).mod_info.URf.t_peak > list_mod.non(i).mod_info.URs.t_peak
              cell_list(i+j).URmod_type='Suppression';
              cell_list(i+j).UR_amp=(list_mod.non(i).mod_info.URs.peak-cell_list(i+j).bsl_frq)/cell_list(i+j).bsl_frq*100;
              cell_list(i+j).UR_pkt=list_mod.non(i).mod_info.URs.t_peak-500;
           end
    elseif list_mod.non(i).UR_fac==0 && list_mod.non(i).UR_sup==0
           cell_list(i+j).URmod_type='Non-modulation';
           cell_list(i+j).UR_amp='-';
           cell_list(i+j).UR_pkt='-';
    end
end