
cell_list=DT_list_sim;
align_info_1='align_info_T';
align_info_2='align_info_D';
cell_validation_list=DT_cell_validation_list;
p_value_list=DT_p_value_all;
bin_width = 100; 
step_size = 50;  
t_start=-500;
t_end=500;

%% Calculate the diff_list
% trace_diff_list=struct('cell_ID',[],'mod_fac',[],'mod_sup',[],'sig_CR',[],'sig_bsl',[],'p_t_sig',[],'fac_info',[],'sup_info',[],'bsl_1',[],'bsl_2',[],'d_bsl',[]);
% for i=1:size(cell_list,2)
%     trace_diff_list(i).cell_ID=cell_list(i).cell_ID;
%     fac_info=struct('pkt_1',[],'pkt_2',[],'d_pkt',[],'amp_1',[],'amp_2',[],'d_amp',[]);
%     sup_info=struct('pkt_1',[],'pkt_2',[],'d_pkt',[],'amp_1',[],'amp_2',[],'d_amp',[]);
%     if ~isempty(cell_list(i).(align_info_1).CR_fac) && ~isempty(cell_list(i).(align_info_2).CR_fac)
%        trace_diff_list(i).mod_fac=1;
%     else
%        trace_diff_list(i).mod_fac=0;         
%     end
%     if ~isempty(cell_list(i).(align_info_1).CR_sup) && ~isempty(cell_list(i).(align_info_2).CR_sup)
%        trace_diff_list(i).mod_sup=1;
%     else
%        trace_diff_list(i).mod_sup=0;         
%     end
%     
%     trace_diff_list(i).p_t_sig=cell_validation_list(i).sig_decoding;
%     
%     if ~isempty(cell_validation_list(i).sig_decoding(1).t)
%        bsl_sig_idx=find([cell_validation_list(i).sig_decoding.t]<0);
%        CR_sig_idx=find([cell_validation_list(i).sig_decoding.t]>0);
%        if ~isempty(bsl_sig_idx)
%           trace_diff_list(i).sig_bsl=1;
%        else
%           trace_diff_list(i).sig_bsl=0;            
%        end
%        if ~isempty(CR_sig_idx)
%           trace_diff_list(i).sig_CR=1;
%        else
%           trace_diff_list(i).sig_CR=0;            
%        end    
%     else
%        trace_diff_list(i).sig_bsl=0;
%        trace_diff_list(i).sig_CR=0;
%     end
%         
%         
%     t_CR_idx_1=find(cell_validation_list(i).frq_1(1,:)>0,1,'first');
%     t_CR_idx_2=find(cell_validation_list(i).frq_2(1,:)>0,1,'first');
%     
%     [fac_amp_1,fac_idx_1]=max(cell_validation_list(i).frq_1(2,t_CR_idx_1:end));
%     [fac_amp_2,fac_idx_2]=max(cell_validation_list(i).frq_2(2,t_CR_idx_1:end));  
%     [sup_amp_1,sup_idx_1]=min(cell_validation_list(i).frq_1(2,t_CR_idx_1:end));
%     [sup_amp_2,sup_idx_2]=min(cell_validation_list(i).frq_2(2,t_CR_idx_1:end));  
%     
%     fac_pkt_1=cell_validation_list(i).frq_1(1,t_CR_idx_1+fac_idx_1-1);
%     fac_pkt_2=cell_validation_list(i).frq_2(1,t_CR_idx_2+fac_idx_2-1); 
%     sup_pkt_1=cell_validation_list(i).frq_1(1,t_CR_idx_1+sup_idx_1-1);
%     sup_pkt_2=cell_validation_list(i).frq_2(1,t_CR_idx_2+sup_idx_2-1);   
% 
%     trace_diff_list(i).bsl_1=mean(cell_validation_list(i).frq_1(2,1:t_CR_idx_1));
%     trace_diff_list(i).bsl_2=mean(cell_validation_list(i).frq_2(2,1:t_CR_idx_2));
%     trace_diff_list(i).d_bsl=trace_diff_list(i).bsl_2-trace_diff_list(i).bsl_1;
%     
%     fac_info.pkt_1=fac_pkt_1;
%     fac_info.pkt_2=fac_pkt_2;
%     fac_info.d_pkt=fac_pkt_2-fac_pkt_1;
%     fac_info.amp_1=fac_amp_1/trace_diff_list(i).bsl_1*100;
%     fac_info.amp_2=fac_amp_2/trace_diff_list(i).bsl_2*100;    
%     fac_info.d_amp=fac_info.amp_2-fac_info.amp_1;  
% 
%     sup_info.pkt_1=sup_pkt_1;
%     sup_info.pkt_2=sup_pkt_2;
%     sup_info.d_pkt=sup_pkt_2-sup_pkt_1;
%     sup_info.amp_1=sup_amp_1/trace_diff_list(i).bsl_1*100;
%     sup_info.amp_2=sup_amp_2/trace_diff_list(i).bsl_2*100;    
%     sup_info.d_amp=sup_info.amp_2-sup_info.amp_1;  
%     
%     trace_diff_list(i).fac_info=fac_info;
%     trace_diff_list(i).sup_info=sup_info;
% end

%% Calculate and plot the population d_pkt vs. d_amp

% diff_list=DT_diff_list;
% 
% figure;
% 
% xmax=300;
% ymax=40;
% x_thrd=50;
% y_thrd=20;
% 
% mod_tp='mod_fac';
% mod_info='fac_info';
% fac_d_list=struct('cell_ID',[],'sig_CR',[],'d_pkt',[],'d_amp',[],'group',[]);
% fac_idx=0;
% for i=1:size(diff_list,2)  
%     if diff_list(i).(mod_tp)>0 && diff_list(i).sig_CR>0
%        fac_idx=fac_idx+1;
%        fac_d_list(fac_idx).cell_ID=diff_list(i).cell_ID;
%        fac_d_list(fac_idx).sig_CR=diff_list(i).sig_CR;
%        fac_d_list(fac_idx).d_pkt=diff_list(i).(mod_info).d_pkt;
%        fac_d_list(fac_idx).d_amp=diff_list(i).(mod_info).d_amp;  
%        plot(diff_list(i).(mod_info).d_pkt,diff_list(i).(mod_info).d_amp,'r.')      
%        hold on   
%        if diff_list(i).(mod_info).d_amp>=y_thrd
%           fac_d_list(fac_idx).group=11;
%        elseif diff_list(i).(mod_info).d_amp<=-y_thrd
%           fac_d_list(fac_idx).group=12;
%        elseif diff_list(i).(mod_info).d_pkt>=x_thrd
%           fac_d_list(fac_idx).group=2; 
%        else
%           fac_d_list(fac_idx).group=3; 
%        end
%     elseif diff_list(i).(mod_tp)>0 && diff_list(i).sig_CR==0
%        fac_idx=fac_idx+1; 
%        fac_d_list(fac_idx).cell_ID=diff_list(i).cell_ID;
%        fac_d_list(fac_idx).sig_CR=diff_list(i).sig_CR;
%        fac_d_list(fac_idx).d_pkt=diff_list(i).(mod_info).d_pkt;
%        fac_d_list(fac_idx).d_amp=diff_list(i).(mod_info).d_amp;  
%        fac_d_list(fac_idx).group=0; 
%        plot(diff_list(i).(mod_info).d_pkt,diff_list(i).(mod_info).d_amp,'.','Color',[1 0.8 0.8])      
%        hold on         
%     end   
% end
% x_mean=mean([fac_d_list.d_pkt]);
% x_std=std([fac_d_list.d_pkt]);
% y_mean=mean([fac_d_list.d_amp]);
% y_std=std([fac_d_list.d_amp]);
% 
% plot(x_mean,y_mean,'rs')
% hold on
% errorbar(x_mean,y_mean,y_std/sqrt(size(fac_d_list,2)),y_std/sqrt(size(fac_d_list,2)),x_std/sqrt(size(fac_d_list,2)),x_std/sqrt(size(fac_d_list,2)),...
%     'Color',[1 0 0]);
% hold on
% 
% line([x_thrd x_thrd],[-ymax ymax],'LineStyle','--','Color','k');
% hold on
% line([-xmax xmax],[y_thrd y_thrd],'LineStyle','--','Color','k');
% hold on
% line([-xmax xmax],[-y_thrd -y_thrd],'LineStyle','--','Color','k');
% hold on
% xlabel('d mod pkt');
% ylabel('d mod amp');
% xlim([-xmax xmax]);
% ylim([-ymax ymax]);
% xticks(-xmax:50:xmax);
% yticks(-ymax:20:ymax);
% 
% figure;
% 
% xmax=200;
% ymax=30;
% x_thrd=50;
% y_thrd=10;
% 
% mod_tp='mod_sup';
% mod_info='sup_info';
% sup_d_list=struct('cell_ID',[],'sig_CR',[],'d_pkt',[],'d_amp',[],'group',[]);
% sup_idx=0;
% for i=1:size(diff_list,2)
%     if diff_list(i).(mod_tp)>0 && diff_list(i).sig_CR>0
%        sup_idx=sup_idx+1;
%        sup_d_list(sup_idx).cell_ID=diff_list(i).cell_ID;
%        sup_d_list(sup_idx).sig_CR=diff_list(i).sig_CR;
%        sup_d_list(sup_idx).d_pkt=diff_list(i).(mod_info).d_pkt;
%        sup_d_list(sup_idx).d_amp=diff_list(i).(mod_info).d_amp;                  
%        plot(diff_list(i).(mod_info).d_pkt,diff_list(i).(mod_info).d_amp,'b.')
%        hold on 
%        if diff_list(i).(mod_info).d_amp<=-y_thrd
%           sup_d_list(sup_idx).group=11;
%        elseif diff_list(i).(mod_info).d_amp>=y_thrd
%           sup_d_list(sup_idx).group=12;
%        elseif diff_list(i).(mod_info).d_pkt>=x_thrd
%           sup_d_list(sup_idx).group=2; 
%        else
%           sup_d_list(sup_idx).group=3; 
%        end  
%     elseif diff_list(i).(mod_tp)>0 && diff_list(i).sig_CR==0
%        sup_idx=sup_idx+1; 
%        sup_d_list(sup_idx).cell_ID=diff_list(i).cell_ID;
%        sup_d_list(sup_idx).sig_CR=diff_list(i).sig_CR;
%        sup_d_list(sup_idx).d_pkt=diff_list(i).(mod_info).d_pkt;
%        sup_d_list(sup_idx).d_amp=diff_list(i).(mod_info).d_amp;  
%        sup_d_list(sup_idx).group=0; 
%        plot(diff_list(i).(mod_info).d_pkt,diff_list(i).(mod_info).d_amp,'.','Color',[0.8 0.8 1])      
%        hold on  
%     end  
% end
% 
% x_mean=mean([sup_d_list.d_pkt]);
% x_std=std([sup_d_list.d_pkt]);
% y_mean=mean([sup_d_list.d_amp]);
% y_std=std([sup_d_list.d_amp]);
% 
% plot(x_mean,y_mean,'bs')
% hold on
% errorbar(x_mean,y_mean,y_std/sqrt(size(sup_d_list,2)),y_std/sqrt(size(sup_d_list,2)),x_std/sqrt(size(sup_d_list,2)),x_std/sqrt(size(sup_d_list,2)),...
%     'Color',[0 0 1]);
% hold on
% 
% line([x_thrd x_thrd],[-ymax ymax],'LineStyle','--','Color','k');
% hold on
% line([-xmax xmax],[y_thrd y_thrd],'LineStyle','--','Color','k');
% hold on
% line([-xmax xmax],[-y_thrd -y_thrd],'LineStyle','--','Color','k');
% hold on
% 
% xlabel('d mod pkt');
% ylabel('d mod amp');
% xlim([-xmax xmax]);
% ylim([-ymax ymax]);
% xticks(-xmax:50:xmax);
% yticks(-ymax:10:ymax);

%% Calculate the average curve of each group of neuron with modulation
t_bin_num=19;
ymin=90;
ymax=150;

fac_amp_sig_0=avg_se_cal(cell_validation_list,diff_list,fac_d_list,0,t_bin_num,1);
figure;
plot(fac_amp_sig_0.plot_form_1(1,:),fac_amp_sig_0.plot_form_1(2,:),'r-')
hold on
plot(fac_amp_sig_0.plot_form_1(1,:),fac_amp_sig_0.plot_form_1(4,:),'-','Color',[1 0.8 0.8])
hold on
plot(fac_amp_sig_0.plot_form_1(1,:),fac_amp_sig_0.plot_form_1(5,:),'-','Color',[1 0.8 0.8])
hold on
plot(fac_amp_sig_0.plot_form_2(1,:),fac_amp_sig_0.plot_form_2(2,:),'k-')
hold on
plot(fac_amp_sig_0.plot_form_2(1,:),fac_amp_sig_0.plot_form_2(4,:),'-','Color',[0.8 0.8 0.8])
hold on
plot(fac_amp_sig_0.plot_form_2(1,:),fac_amp_sig_0.plot_form_2(5,:),'-','Color',[0.8 0.8 0.8])
hold on

xlabel('Time (ms)');
ylabel('Rel. firing rate (%)');
xlim([-500 500]);
ylim([ymin ymax]);
xticks(-500:100:500);
yticks(ymin:10:ymax);
title([num2str(size(fac_amp_sig_0.raw_form_1,1)) ' cells']);



%% baseline decoding significance

% diff_list=DT_diff_list;
% cell_validation_list=DT_cell_validation_list;
% 
% figure;
% 
% ymax=30;
% 
% bsl_d_list=struct('cell_ID',[],'bsl_1',[],'bsl_2',[],'d_bsl',[],'group',[],'bsl_sig_frq',[]);
% bsl_idx=0;
% for i=1:size(diff_list,2)  
%     if diff_list(i).sig_bsl>0
%        bsl_idx=bsl_idx+1;
%        bsl_d_list(bsl_idx).cell_ID=diff_list(i).cell_ID;
%        bsl_sig_frq=struct('t',[],'frq_1',[],'frq_2',[]);
%        for j=1:sum([diff_list(i).p_t_sig.t]<0)
%            t_idx=find(cell_validation_list(i).frq_1(1,:)==diff_list(i).p_t_sig(j).t);
%            bsl_sig_frq(j).t=diff_list(i).p_t_sig(j).t;
%            bsl_sig_frq(j).frq_1=cell_validation_list(i).frq_1(2,t_idx);
%            bsl_sig_frq(j).frq_2=cell_validation_list(i).frq_2(2,t_idx);
%        end     
%        bsl_d_list(bsl_idx).bsl_1=mean([bsl_sig_frq.frq_1]);
%        bsl_d_list(bsl_idx).bsl_2=mean([bsl_sig_frq.frq_2]);  
%        bsl_d_list(bsl_idx).d_bsl=bsl_d_list(bsl_idx).bsl_2-bsl_d_list(bsl_idx).bsl_1;
%        bsl_d_list(bsl_idx).bsl_sig_frq=bsl_sig_frq;
%        plot(1,diff_list(i).d_bsl,'k.')      
%        hold on   
%        if diff_list(i).d_bsl>0
%           bsl_d_list(bsl_idx).group=1;
%        elseif diff_list(i).d_bsl<0
%           bsl_d_list(bsl_idx).group=2;
%        end         
%     end   
% end
% y_mean=mean([bsl_d_list.d_bsl]);
% y_std=std([bsl_d_list.d_bsl]);
% 
% plot(1,y_mean,'ks')
% hold on
% errorbar(y_mean,y_std/sqrt(size(bsl_d_list,2)),'Color',[0 0 0]);
% hold on
% 
% ylabel('d bsl frq');
% xlim([0 2]);
% ylim([-ymax ymax]);
% yticks(-ymax:20:ymax);
% 
% 
% t_bin_num=19;
% ymin=60;
% ymax=100;
% 
% bsl_sig_2=avg_se_cal(cell_validation_list,diff_list,bsl_d_list,2,t_bin_num,0);
% figure;
% plot(bsl_sig_2.plot_form_1(1,:),bsl_sig_2.plot_form_1(2,:),'r-')
% hold on
% plot(bsl_sig_2.plot_form_1(1,:),bsl_sig_2.plot_form_1(4,:),'-','Color',[1 0.8 0.8])
% hold on
% plot(bsl_sig_2.plot_form_1(1,:),bsl_sig_2.plot_form_1(5,:),'-','Color',[1 0.8 0.8])
% hold on
% plot(bsl_sig_2.plot_form_2(1,:),bsl_sig_2.plot_form_2(2,:),'k-')
% hold on
% plot(bsl_sig_2.plot_form_2(1,:),bsl_sig_2.plot_form_2(4,:),'-','Color',[0.8 0.8 0.8])
% hold on
% plot(bsl_sig_2.plot_form_2(1,:),bsl_sig_2.plot_form_2(5,:),'-','Color',[0.8 0.8 0.8])
% hold on
% 
% xlabel('Time (ms)');
% ylabel('Firing frequency (Hz)');
% xlim([-500 500]);
% ylim([ymin ymax]);
% xticks(-500:100:500);
% yticks(ymin:10:ymax);
% title([num2str(size(bsl_sig_2.raw_form_1,1)) ' cells']);






%%
function plot_curve=avg_se_cal(cell_validation_list,diff_list,mod_d_list,group_type,t_bin_num,bsl_norm)

plot_curve=struct('raw_form_1',[],'raw_form_2',[],'plot_form_1',[],'plot_form_2',[]);
raw_form_1=zeros(sum([mod_d_list.group]==group_type),t_bin_num);
raw_form_2=zeros(sum([mod_d_list.group]==group_type),t_bin_num);
plot_form_1=zeros(5,t_bin_num);
plot_form_2=zeros(5,t_bin_num);
cell_idx=0;
for i=1:size(mod_d_list,2)
    if mod_d_list(i).group==group_type
       cell_idx=cell_idx+1;
       if bsl_norm==1
           raw_form_1(cell_idx,:)=cell_validation_list(mod_d_list(i).cell_ID).frq_1(2,:)/diff_list(mod_d_list(i).cell_ID).bsl_1*100;
           raw_form_2(cell_idx,:)=cell_validation_list(mod_d_list(i).cell_ID).frq_2(2,:)/diff_list(mod_d_list(i).cell_ID).bsl_2*100;  
       elseif bsl_norm==0
           raw_form_1(cell_idx,:)=cell_validation_list(mod_d_list(i).cell_ID).frq_1(2,:);
           raw_form_2(cell_idx,:)=cell_validation_list(mod_d_list(i).cell_ID).frq_2(2,:);             
       end
    end   
end

plot_form_1(1,:)=-450:50:450;
plot_form_1(2,:)=mean(raw_form_1,1);
plot_form_1(3,:)=std(raw_form_1,0,1)/sqrt(size(raw_form_1,1));
plot_form_1(4,:)=plot_form_1(2,:)+plot_form_1(3,:);
plot_form_1(5,:)=plot_form_1(2,:)-plot_form_1(3,:);

plot_form_2(1,:)=-450:50:450;
plot_form_2(2,:)=mean(raw_form_2,1);
plot_form_2(3,:)=std(raw_form_2,0,1)/sqrt(size(raw_form_2,1));
plot_form_2(4,:)=plot_form_2(2,:)+plot_form_2(3,:);
plot_form_2(5,:)=plot_form_2(2,:)-plot_form_2(3,:);

plot_curve.raw_form_1=raw_form_1;
plot_curve.raw_form_2=raw_form_2;
plot_curve.plot_form_1=plot_form_1;
plot_curve.plot_form_2=plot_form_2;

end
    
