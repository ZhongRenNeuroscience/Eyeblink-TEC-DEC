% CV2_temp_prb=struct('irg_D',[],'reg_D',[],'irg_T',[],'reg_T',[]);
% idx_irg_D=0;
% idx_reg_D=0;
% idx_irg_T=0;
% idx_reg_T=0;
% 
% for i=1:size(file_hist,2)    
%     for m=1:10
%         if file_hist(i).hist_info_D.CV2_temp(m+20).p_value<0.05
%            if file_hist(i).hist_info_D.CV2_temp(m+20).mean>mean([file_hist(i).hist_info_D.CV2_temp(1:20).mean])
%               idx_irg_D=idx_irg_D+1;
%               CV2_temp_prb(idx_irg_D).irg_D=25*m-12.5;
%            elseif file_hist(i).(hist_info).CV2_temp(m+20).mean<mean([file_hist(i).hist_info_D.CV2_temp(1:20).mean])
%               idx_reg_D=idx_reg_D+1;
%               CV2_temp_prb(idx_reg_D).reg_D=25*m-12.5;               
%            end
%         end                
%     end        
%     for m=1:20
%         if file_hist(i).hist_info_T.CV2_temp(m+20).p_value<0.05
%            if file_hist(i).hist_info_T.CV2_temp(m+20).mean>mean([file_hist(i).hist_info_T.CV2_temp(1:20).mean])
%               idx_irg_T=idx_irg_T+1;
%               CV2_temp_prb(idx_irg_T).irg_T=25*m-12.5;
%            elseif file_hist(i).hist_info_T.CV2_temp(m+20).mean<mean([file_hist(i).hist_info_T.CV2_temp(1:20).mean])
%               idx_reg_T=idx_reg_T+1;
%               CV2_temp_prb(idx_reg_T).reg_T=25*m-12.5;               
%            end
%         end                
%     end         
%     
% end
% 
% figure('units','normalized','outerposition',[0 0 1 1]);  
% 
% subplot(2,2,1)
% h1=histogram([CV2_temp_prb.irg_D],'BinWidth',25,'BinLimits',[0,250],'Normalization','probability');
% h1.FaceColor = [1 0 0];
% xlabel('Time (ms)');
% ylabel('Probability of increased irregularity');  
% title('Delay sessions');
% 
% subplot(2,2,3)
% h1=histogram([CV2_temp_prb.reg_D],'BinWidth',25,'BinLimits',[0,250],'Normalization','probability');
% h1.FaceColor = [0 0 1];
% xlabel('Time (ms)');
% ylabel('Probability of decreased irregularity');  
% 
% subplot(2,2,2)
% h1=histogram([CV2_temp_prb.irg_T],'BinWidth',25,'BinLimits',[0,500],'Normalization','probability');
% h1.FaceColor = [1 0 0];
% xlabel('Time (ms)');
% ylabel('Probability of increased irregularity');  
% title('Trace sessions');
% 
% subplot(2,2,4)
% h1=histogram([CV2_temp_prb.reg_T],'BinWidth',25,'BinLimits',[0,500],'Normalization','probability');
% h1.FaceColor = [0 0 1];
% xlabel('Time (ms)');
% ylabel('Probability of decreased irregularity'); 

% bsl_comp=zeros(size(session_output,2),2);
% for i=1:size(session_output,2)
%     bsl_comp(i,1)=(session_output(i).pmean_T.bsl_mean/session_output(i).pmean_D.bsl_mean-1)*100;
%     bsl_comp(i,2)=(session_output(i).CV2_T.bsl_mean/session_output(i).CV2_D.bsl_mean-1)*100;
% end
% figure;
% subplot(1,2,1)
% plot(1,bsl_comp(:,1),'k.','MarkerSize',10)
% subplot(1,2,2)
% plot(1,bsl_comp(:,2),'k.','MarkerSize',10)