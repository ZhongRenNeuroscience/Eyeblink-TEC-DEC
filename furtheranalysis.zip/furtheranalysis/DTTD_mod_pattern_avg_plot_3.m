file=DT_list_align;
mod_file=mod_format;

fac_thrd=5;
sup_thrd=3;

mod_pattern=struct('fac_D_CS',[],'fac_D_CR',[],'sup_D_CS',[],'sup_D_CR',[],'fac_T_CS',[],'fac_T_CR',[],'sup_T_CS',[],'sup_T_CR',[]);
fac_D_CS=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
fac_D_CR=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
sup_D_CS=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
sup_D_CR=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
fac_T_CS=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
fac_T_CR=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
sup_T_CS=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
sup_T_CR=struct('cell_ID',[],'bsl_frq',[],'psth_CS',[],'psth_CR',[],'CS_peak',[],'CR_peak',[]);
fac_D_CS_idx=0;
fac_D_CR_idx=0;
sup_D_CS_idx=0;
sup_D_CR_idx=0;
fac_T_CS_idx=0;
fac_T_CR_idx=0;
sup_T_CS_idx=0;
sup_T_CR_idx=0;

for i=1:size(file,2)
    if mod_file(i).fac_D+mod_file(i).fac_T+mod_file(i).sup_D+mod_file(i).sup_T>0
       CS_peak_D=max(file(i).align_info_D.psth_ex(551:800,2)/file(i).align_info_D.bsl_frq_ex)*100-100;
       CR_peak_D=max(file(i).align_info_D.psth_align(551-file(i).align_info_D.t_start:801-file(i).align_info_D.t_end,2)/file(i).align_info_D.bsl_frq_ex)*100-100;
       CS_peak_T=max(file(i).align_info_T.psth_ex(551:1050,2)/file(i).align_info_T.bsl_frq_ex)*100-100;
       CR_peak_T=max(file(i).align_info_T.psth_align(551-file(i).align_info_T.t_start:1051-file(i).align_info_T.t_end,2)/file(i).align_info_T.bsl_frq_ex)*100-100;
       if mod_file(i).motor_relevant_fac_D==1 && CR_peak_D-CS_peak_D>=fac_thrd
          fac_D_CR_idx=fac_D_CR_idx+1;
          fac_D_CR(fac_D_CR_idx).cell_ID=mod_file(i).cell_ID;
          fac_D_CR(fac_D_CR_idx).bsl_frq=file(i).align_info_D.bsl_frq_ex;
          fac_D_CR(fac_D_CR_idx).psth_CS=file(i).align_info_D.psth_ex;
          fac_D_CR(fac_D_CR_idx).psth_CR=file(i).align_info_D.psth_align;
          fac_D_CR(fac_D_CR_idx).CS_peak=CS_peak_D;
          fac_D_CR(fac_D_CR_idx).CR_peak=CR_peak_D;
       elseif mod_file(i).motor_relevant_fac_D==1 && mod_file(i).fac_D>0 && CR_peak_D-CS_peak_D<fac_thrd
          fac_D_CS_idx=fac_D_CS_idx+1;
          fac_D_CS(fac_D_CS_idx).cell_ID=mod_file(i).cell_ID;
          fac_D_CS(fac_D_CS_idx).bsl_frq=file(i).align_info_D.bsl_frq_ex;
          fac_D_CS(fac_D_CS_idx).psth_CS=file(i).align_info_D.psth_ex;
          fac_D_CS(fac_D_CS_idx).psth_CR=file(i).align_info_D.psth_align;
          fac_D_CS(fac_D_CS_idx).CS_peak=CS_peak_D;
          fac_D_CS(fac_D_CS_idx).CR_peak=CR_peak_D;              
       elseif mod_file(i).motor_relevant_fac_D==0 && mod_file(i).fac_D>0
          fac_D_CS_idx=fac_D_CS_idx+1;
          fac_D_CS(fac_D_CS_idx).cell_ID=mod_file(i).cell_ID;
          fac_D_CS(fac_D_CS_idx).bsl_frq=file(i).align_info_D.bsl_frq_ex;
          fac_D_CS(fac_D_CS_idx).psth_CS=file(i).align_info_D.psth_ex;
          fac_D_CS(fac_D_CS_idx).psth_CR=file(i).align_info_D.psth_align;
          fac_D_CS(fac_D_CS_idx).CS_peak=CS_peak_D;
          fac_D_CS(fac_D_CS_idx).CR_peak=CR_peak_D;          
       end
       if mod_file(i).motor_relevant_fac_T==1 && CR_peak_T-CS_peak_T>=fac_thrd
          fac_T_CR_idx=fac_T_CR_idx+1;
          fac_T_CR(fac_T_CR_idx).cell_ID=mod_file(i).cell_ID;
          fac_T_CR(fac_T_CR_idx).bsl_frq=file(i).align_info_T.bsl_frq_ex;
          fac_T_CR(fac_T_CR_idx).psth_CS=file(i).align_info_T.psth_ex;
          fac_T_CR(fac_T_CR_idx).psth_CR=file(i).align_info_T.psth_align;
          fac_T_CR(fac_T_CR_idx).CS_peak=CS_peak_T;
          fac_T_CR(fac_T_CR_idx).CR_peak=CR_peak_T;     
       elseif mod_file(i).motor_relevant_fac_T==1 && mod_file(i).fac_T>0 && CR_peak_T-CS_peak_T<fac_thrd
          fac_T_CS_idx=fac_T_CS_idx+1;
          fac_T_CS(fac_T_CS_idx).cell_ID=mod_file(i).cell_ID;
          fac_T_CS(fac_T_CS_idx).bsl_frq=file(i).align_info_T.bsl_frq_ex;
          fac_T_CS(fac_T_CS_idx).psth_CS=file(i).align_info_T.psth_ex;
          fac_T_CS(fac_T_CS_idx).psth_CR=file(i).align_info_T.psth_align;
          fac_T_CS(fac_T_CS_idx).CS_peak=CS_peak_T;
          fac_T_CS(fac_T_CS_idx).CR_peak=CR_peak_T;              
       elseif mod_file(i).motor_relevant_fac_T==0 && mod_file(i).fac_T>0
          fac_T_CS_idx=fac_T_CS_idx+1;
          fac_T_CS(fac_T_CS_idx).cell_ID=mod_file(i).cell_ID;
          fac_T_CS(fac_T_CS_idx).bsl_frq=file(i).align_info_T.bsl_frq_ex;
          fac_T_CS(fac_T_CS_idx).psth_CS=file(i).align_info_T.psth_ex;
          fac_T_CS(fac_T_CS_idx).psth_CR=file(i).align_info_T.psth_align;
          fac_T_CS(fac_T_CS_idx).CS_peak=CS_peak_T;
          fac_T_CS(fac_T_CS_idx).CR_peak=CR_peak_T;          
       end           
    
%     elseif ~isempty(mod_file(i).motor_relevant_sup_D) && mod_file(i).fac_D+mod_file(i).fac_T==0
       CS_peak_D=min(file(i).align_info_D.psth_ex(551:800,2)/file(i).align_info_D.bsl_frq_ex)*100-100;
       CR_peak_D=min(file(i).align_info_D.psth_align(551-file(i).align_info_D.t_start:801-file(i).align_info_D.t_end,2)/file(i).align_info_D.bsl_frq_ex)*100-100;
       CS_peak_T=min(file(i).align_info_T.psth_ex(551:1050,2)/file(i).align_info_T.bsl_frq_ex)*100-100;
       CR_peak_T=min(file(i).align_info_T.psth_align(551-file(i).align_info_T.t_start:1051-file(i).align_info_T.t_end,2)/file(i).align_info_T.bsl_frq_ex)*100-100;       
       if mod_file(i).motor_relevant_sup_D==1 && CS_peak_D-CR_peak_D>=sup_thrd
          sup_D_CR_idx=sup_D_CR_idx+1;
          sup_D_CR(sup_D_CR_idx).cell_ID=mod_file(i).cell_ID;
          sup_D_CR(sup_D_CR_idx).bsl_frq=file(i).align_info_D.bsl_frq_ex;
          sup_D_CR(sup_D_CR_idx).psth_CS=file(i).align_info_D.psth_ex;
          sup_D_CR(sup_D_CR_idx).psth_CR=file(i).align_info_D.psth_align;
          sup_D_CR(sup_D_CR_idx).CS_peak=CS_peak_D;
          sup_D_CR(sup_D_CR_idx).CR_peak=CR_peak_D;          
       elseif mod_file(i).motor_relevant_sup_D==1 && mod_file(i).sup_D>0 && CS_peak_D-CR_peak_D<sup_thrd
          sup_D_CS_idx=sup_D_CS_idx+1;
          sup_D_CS(sup_D_CS_idx).cell_ID=mod_file(i).cell_ID;
          sup_D_CS(sup_D_CS_idx).bsl_frq=file(i).align_info_D.bsl_frq_ex;
          sup_D_CS(sup_D_CS_idx).psth_CS=file(i).align_info_D.psth_ex;
          sup_D_CS(sup_D_CS_idx).psth_CR=file(i).align_info_D.psth_align;
          sup_D_CS(sup_D_CS_idx).CS_peak=CS_peak_D;
          sup_D_CS(sup_D_CS_idx).CR_peak=CR_peak_D;    
       elseif mod_file(i).motor_relevant_sup_D==0 && mod_file(i).sup_D>0
          sup_D_CS_idx=sup_D_CS_idx+1;
          sup_D_CS(sup_D_CS_idx).cell_ID=mod_file(i).cell_ID;
          sup_D_CS(sup_D_CS_idx).bsl_frq=file(i).align_info_D.bsl_frq_ex;
          sup_D_CS(sup_D_CS_idx).psth_CS=file(i).align_info_D.psth_ex;
          sup_D_CS(sup_D_CS_idx).psth_CR=file(i).align_info_D.psth_align;
          sup_D_CS(sup_D_CS_idx).CS_peak=CS_peak_D;
          sup_D_CS(sup_D_CS_idx).CR_peak=CR_peak_D;           
       end
       if mod_file(i).motor_relevant_sup_T==1 && CS_peak_T-CR_peak_T>=sup_thrd
          sup_T_CR_idx=sup_T_CR_idx+1;
          sup_T_CR(sup_T_CR_idx).cell_ID=mod_file(i).cell_ID;
          sup_T_CR(sup_T_CR_idx).bsl_frq=file(i).align_info_T.bsl_frq_ex;
          sup_T_CR(sup_T_CR_idx).psth_CS=file(i).align_info_T.psth_ex;
          sup_T_CR(sup_T_CR_idx).psth_CR=file(i).align_info_T.psth_align;
          sup_T_CR(sup_T_CR_idx).CS_peak=CS_peak_T;
          sup_T_CR(sup_T_CR_idx).CR_peak=CR_peak_T;      
       elseif mod_file(i).motor_relevant_sup_T==1 && mod_file(i).sup_T>0 && CS_peak_T-CR_peak_T<sup_thrd
          sup_T_CS_idx=sup_T_CS_idx+1;
          sup_T_CS(sup_T_CS_idx).cell_ID=mod_file(i).cell_ID;
          sup_T_CS(sup_T_CS_idx).bsl_frq=file(i).align_info_T.bsl_frq_ex;
          sup_T_CS(sup_T_CS_idx).psth_CS=file(i).align_info_T.psth_ex;
          sup_T_CS(sup_T_CS_idx).psth_CR=file(i).align_info_T.psth_align;
          sup_T_CS(sup_T_CS_idx).CS_peak=CS_peak_T;
          sup_T_CS(sup_T_CS_idx).CR_peak=CR_peak_T;                  
       elseif mod_file(i).motor_relevant_sup_T==0 && mod_file(i).sup_T>0
          sup_T_CS_idx=sup_T_CS_idx+1;
          sup_T_CS(sup_T_CS_idx).cell_ID=mod_file(i).cell_ID;
          sup_T_CS(sup_T_CS_idx).bsl_frq=file(i).align_info_T.bsl_frq_ex;
          sup_T_CS(sup_T_CS_idx).psth_CS=file(i).align_info_T.psth_ex;
          sup_T_CS(sup_T_CS_idx).psth_CR=file(i).align_info_T.psth_align;
          sup_T_CS(sup_T_CS_idx).CS_peak=CS_peak_T;
          sup_T_CS(sup_T_CS_idx).CR_peak=CR_peak_T;          
       end         
    end
end
mod_pattern.fac_D_CS=fac_D_CS;
mod_pattern.fac_D_CR=fac_D_CR;
mod_pattern.fac_T_CS=fac_T_CS;
mod_pattern.fac_T_CR=fac_T_CR;
mod_pattern.sup_D_CS=sup_D_CS;
mod_pattern.sup_D_CR=sup_D_CR;
mod_pattern.sup_T_CS=sup_T_CS;
mod_pattern.sup_T_CR=sup_T_CR;

fac_D_CS_CS_data=zeros(1600,size(mod_pattern.fac_D_CS,2));
fac_D_CS_CR_data=zeros(1100,size(mod_pattern.fac_D_CS,2));
fac_D_CR_CS_data=zeros(1600,size(mod_pattern.fac_D_CR,2));
fac_D_CR_CR_data=zeros(1100,size(mod_pattern.fac_D_CR,2));
fac_T_CS_CS_data=zeros(1600,size(mod_pattern.fac_T_CS,2));
fac_T_CS_CR_data=zeros(1100,size(mod_pattern.fac_T_CS,2));
fac_T_CR_CS_data=zeros(1600,size(mod_pattern.fac_T_CR,2));
fac_T_CR_CR_data=zeros(1100,size(mod_pattern.fac_T_CR,2));
sup_D_CS_CS_data=zeros(1600,size(mod_pattern.sup_D_CS,2));
sup_D_CS_CR_data=zeros(1100,size(mod_pattern.sup_D_CS,2));
sup_D_CR_CS_data=zeros(1600,size(mod_pattern.sup_D_CR,2));
sup_D_CR_CR_data=zeros(1100,size(mod_pattern.sup_D_CR,2));
sup_T_CS_CS_data=zeros(1600,size(mod_pattern.sup_T_CS,2));
sup_T_CS_CR_data=zeros(1100,size(mod_pattern.sup_T_CS,2));
sup_T_CR_CS_data=zeros(1600,size(mod_pattern.sup_T_CR,2));
sup_T_CR_CR_data=zeros(1100,size(mod_pattern.sup_T_CR,2));

for i=1:size(mod_pattern.fac_D_CS,2)
    fac_D_CS_CS_data(:,i)=(mod_pattern.fac_D_CS(i).psth_CS(:,2)/mod_pattern.fac_D_CS(i).bsl_frq)*100;
    fac_D_CS_CR_data(:,i)=(mod_pattern.fac_D_CS(i).psth_CR(:,2)/mod_pattern.fac_D_CS(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.fac_D_CR,2)
    fac_D_CR_CS_data(:,i)=(mod_pattern.fac_D_CR(i).psth_CS(:,2)/mod_pattern.fac_D_CR(i).bsl_frq)*100;
    fac_D_CR_CR_data(:,i)=(mod_pattern.fac_D_CR(i).psth_CR(:,2)/mod_pattern.fac_D_CR(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.fac_T_CS,2)
    fac_T_CS_CS_data(:,i)=(mod_pattern.fac_T_CS(i).psth_CS(:,2)/mod_pattern.fac_T_CS(i).bsl_frq)*100;
    fac_T_CS_CR_data(:,i)=(mod_pattern.fac_T_CS(i).psth_CR(:,2)/mod_pattern.fac_T_CS(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.fac_T_CR,2)
    fac_T_CR_CS_data(:,i)=(mod_pattern.fac_T_CR(i).psth_CS(:,2)/mod_pattern.fac_T_CR(i).bsl_frq)*100;
    fac_T_CR_CR_data(:,i)=(mod_pattern.fac_T_CR(i).psth_CR(:,2)/mod_pattern.fac_T_CR(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.sup_D_CS,2)
    sup_D_CS_CS_data(:,i)=(mod_pattern.sup_D_CS(i).psth_CS(:,2)/mod_pattern.sup_D_CS(i).bsl_frq)*100;
    sup_D_CS_CR_data(:,i)=(mod_pattern.sup_D_CS(i).psth_CR(:,2)/mod_pattern.sup_D_CS(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.sup_D_CR,2)
    sup_D_CR_CS_data(:,i)=(mod_pattern.sup_D_CR(i).psth_CS(:,2)/mod_pattern.sup_D_CR(i).bsl_frq)*100;
    sup_D_CR_CR_data(:,i)=(mod_pattern.sup_D_CR(i).psth_CR(:,2)/mod_pattern.sup_D_CR(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.sup_T_CS,2)
    sup_T_CS_CS_data(:,i)=(mod_pattern.sup_T_CS(i).psth_CS(:,2)/mod_pattern.sup_T_CS(i).bsl_frq)*100;
    sup_T_CS_CR_data(:,i)=(mod_pattern.sup_T_CS(i).psth_CR(:,2)/mod_pattern.sup_T_CS(i).bsl_frq)*100;
end
for i=1:size(mod_pattern.sup_T_CR,2)
    sup_T_CR_CS_data(:,i)=(mod_pattern.sup_T_CR(i).psth_CS(:,2)/mod_pattern.sup_T_CR(i).bsl_frq)*100;
    sup_T_CR_CR_data(:,i)=(mod_pattern.sup_T_CR(i).psth_CR(:,2)/mod_pattern.sup_T_CR(i).bsl_frq)*100;
end

fac_D_CS_CS_plot=data_smooth_plot(fac_D_CS_CS_data,1600);
fac_D_CS_CR_plot=data_smooth_plot(fac_D_CS_CR_data,1100);
fac_D_CR_CS_plot=data_smooth_plot(fac_D_CR_CS_data,1600);
fac_D_CR_CR_plot=data_smooth_plot(fac_D_CR_CR_data,1100);
fac_T_CS_CS_plot=data_smooth_plot(fac_T_CS_CS_data,1600);
fac_T_CS_CR_plot=data_smooth_plot(fac_T_CS_CR_data,1100);
fac_T_CR_CS_plot=data_smooth_plot(fac_T_CR_CS_data,1600);
fac_T_CR_CR_plot=data_smooth_plot(fac_T_CR_CR_data,1100);
sup_D_CS_CS_plot=data_smooth_plot(sup_D_CS_CS_data,1600);
sup_D_CS_CR_plot=data_smooth_plot(sup_D_CS_CR_data,1100);
sup_D_CR_CS_plot=data_smooth_plot(sup_D_CR_CS_data,1600);
sup_D_CR_CR_plot=data_smooth_plot(sup_D_CR_CR_data,1100);
sup_T_CS_CS_plot=data_smooth_plot(sup_T_CS_CS_data,1600);
sup_T_CS_CR_plot=data_smooth_plot(sup_T_CS_CR_data,1100);
sup_T_CR_CS_plot=data_smooth_plot(sup_T_CR_CS_data,1600);
sup_T_CR_CR_plot=data_smooth_plot(sup_T_CR_CR_data,1100);

figure('units','normalized','outerposition',[0 0 1 1]);
subplot(2,2,1)
for i=1:size(fac_D_CS,2)
    plot(fac_D_CS(i).CS_peak,fac_D_CS(i).CR_peak,'r.','MarkerSize',15)
    hold on    
end
for i=1:size(fac_D_CR,2)
    plot(fac_D_CR(i).CS_peak,fac_D_CR(i).CR_peak,'r*')
    hold on    
end
xlim([0 300]);
ylim([0 300]);
line([0,300],[0,300],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xlabel('CS-align rel. mod. change (%)')
ylabel('CR-align rel. mod. change (%)')

subplot(2,2,2)
for i=1:size(fac_T_CS,2)
    plot(fac_T_CS(i).CS_peak,fac_T_CS(i).CR_peak,'r.','MarkerSize',15)
    hold on    
end
for i=1:size(fac_T_CR,2)
    plot(fac_T_CR(i).CS_peak,fac_T_CR(i).CR_peak,'r*')
    hold on    
end
xlim([0 400]);
ylim([0 400]);
line([0,400],[0,400],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xlabel('CS-align rel. mod. change (%)')
ylabel('CR-align rel. mod. change (%)')

subplot(2,2,3)
for i=1:size(sup_D_CS,2)
    plot(-sup_D_CS(i).CS_peak,-sup_D_CS(i).CR_peak,'b.','MarkerSize',15)
    hold on    
end
for i=1:size(sup_D_CR,2)
    plot(-sup_D_CR(i).CS_peak,-sup_D_CR(i).CR_peak,'b*')
    hold on    
end
xlim([0 100]);
ylim([0 100]);
line([0,100],[0,100],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xlabel('CS-align rel. mod. change (%)')
ylabel('CR-align rel. mod. change (%)')

subplot(2,2,4)
for i=1:size(sup_T_CS,2)
    plot(-sup_T_CS(i).CS_peak,-sup_T_CS(i).CR_peak,'b.','MarkerSize',15)
    hold on    
end
for i=1:size(sup_T_CR,2)
    plot(-sup_T_CR(i).CS_peak,-sup_T_CR(i).CR_peak,'b*')
    hold on    
end
xlim([0 100]);
ylim([0 100]);
line([0,100],[0,100],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xlabel('CS-align rel. mod. change (%)')
ylabel('CR-align rel. mod. change (%)')

t_plot_CS=-550:10:1040;
t_plot_CR=-550:10:540;

figure('units','normalized','outerposition',[0 0 1 1]);  
subplot(2,2,1)
plot(t_plot_CS,fac_D_CS_CS_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CS,fac_D_CS_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,fac_D_CS_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[50,250],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['Non CR wrapping facilitation neurons - ' num2str(size(fac_D_CS,2)) ' cells']);

subplot(2,2,2)
plot(t_plot_CR,fac_D_CS_CR_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CR,fac_D_CS_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,fac_D_CS_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[max(fac_D_CS_CS_plot(56:75,1)),max(fac_D_CS_CS_plot(56:75,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['Non CR wrapping facilitation neurons - ' num2str(size(fac_D_CS,2)) ' cells']);

subplot(2,2,3)
plot(t_plot_CS,fac_D_CR_CS_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CS,fac_D_CR_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,fac_D_CR_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[50,250],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['CR wrapping facilitation neurons - ' num2str(size(fac_D_CR,2)) ' cells']);

subplot(2,2,4)
plot(t_plot_CR,fac_D_CR_CR_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CR,fac_D_CR_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,fac_D_CR_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[max(fac_D_CR_CS_plot(56:75,1)),max(fac_D_CR_CS_plot(56:75,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['CR wrapping facilitation neurons - ' num2str(size(fac_D_CR,2)) ' cells']);

figure('units','normalized','outerposition',[0 0 1 1]);  
subplot(2,2,1)
plot(t_plot_CS,fac_T_CS_CS_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CS,fac_T_CS_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,fac_T_CS_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[50,250],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['Non CR wrapping facilitation neurons - ' num2str(size(fac_T_CS,2)) ' cells']);

subplot(2,2,2)
plot(t_plot_CR,fac_T_CS_CR_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CR,fac_T_CS_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,fac_T_CS_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[max(fac_T_CS_CS_plot(56:100,1)),max(fac_T_CS_CS_plot(56:100,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['Non CR wrapping facilitation neurons - ' num2str(size(fac_T_CS,2)) ' cells']);

subplot(2,2,3)
plot(t_plot_CS,fac_T_CR_CS_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CS,fac_T_CR_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,fac_T_CR_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[50,250],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['CR wrapping facilitation neurons - ' num2str(size(fac_T_CR,2)) ' cells']);

subplot(2,2,4)
plot(t_plot_CR,fac_T_CR_CR_plot(:,1),'r-','LineWidth',1.5)
hold on
plot(t_plot_CR,fac_T_CR_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,fac_T_CR_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([50 250]);
line([0 0],[50,250],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[max(fac_T_CR_CS_plot(56:100,1)),max(fac_T_CR_CS_plot(56:100,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['CR wrapping facilitation neurons - ' num2str(size(fac_T_CR,2)) ' cells']);

figure('units','normalized','outerposition',[0 0 1 1]);  
subplot(2,2,1)
plot(t_plot_CS,sup_D_CS_CS_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CS,sup_D_CS_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,sup_D_CS_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0 150],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['Non CR wrapping suppression neurons - ' num2str(size(sup_D_CS,2)) ' cells']);

subplot(2,2,2)
plot(t_plot_CR,sup_D_CS_CR_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CR,sup_D_CS_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,sup_D_CS_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[min(sup_D_CS_CS_plot(56:75,1)),min(sup_D_CS_CS_plot(56:75,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['Non CR wrapping suppression neurons - ' num2str(size(sup_D_CS,2)) ' cells']);

subplot(2,2,3)
plot(t_plot_CS,sup_D_CR_CS_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CS,sup_D_CR_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,sup_D_CR_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0 150],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['CR wrapping suppression neurons - ' num2str(size(sup_D_CR,2)) ' cells']);

subplot(2,2,4)
plot(t_plot_CR,sup_D_CR_CR_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CR,sup_D_CR_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,sup_D_CR_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[min(sup_D_CR_CS_plot(56:75,1)),min(sup_D_CR_CS_plot(56:75,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['CR wrapping suppression neurons - ' num2str(size(sup_D_CR,2)) ' cells']);

figure('units','normalized','outerposition',[0 0 1 1]);  
subplot(2,2,1)
plot(t_plot_CS,sup_T_CS_CS_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CS,sup_T_CS_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,sup_T_CS_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0 150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[0 150],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['Non CR wrapping suppression neurons - ' num2str(size(sup_T_CS,2)) ' cells']);

subplot(2,2,2)
plot(t_plot_CR,sup_T_CS_CR_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CR,sup_T_CS_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,sup_T_CS_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[min(sup_T_CS_CS_plot(56:100,1)),min(sup_T_CS_CS_plot(56:100,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['Non CR wrapping suppression neurons - ' num2str(size(sup_T_CS,2)) ' cells']);

subplot(2,2,3)
plot(t_plot_CS,sup_T_CR_CS_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CS,sup_T_CR_CS_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CS,sup_T_CR_CS_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 750]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0 150],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[0 150],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xticks(-250:250:750);
title(['CR wrapping suppression neurons - ' num2str(size(sup_T_CR,2)) ' cells']);

subplot(2,2,4)
plot(t_plot_CR,sup_T_CR_CR_plot(:,1),'b-','LineWidth',1.5)
hold on
plot(t_plot_CR,sup_T_CR_CR_plot(:,2),'Color',[0.5,0.5,0.5])
hold on
plot(t_plot_CR,sup_T_CR_CR_plot(:,3),'Color',[0.5,0.5,0.5])
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-500 500]);
ylim([0 150]);
line([0 0],[0 150],'Color',[0 0 1],'LineStyle','--','LineWidth',1.0);
line([-500 500],[min(sup_T_CR_CS_plot(56:100,1)),min(sup_T_CR_CS_plot(56:100,1))],'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',1.0);
xticks(-500:250:500);
title(['CR wrapping suppression neurons - ' num2str(size(sup_T_CR,2)) ' cells']);

function data_smooth=data_smooth_plot(mod_raw_data,t_length)
    wd=10;
    
    data_smoothing=zeros(t_length,5);
    data_smoothing(:,1)=mean(mod_raw_data,2);
    data_smoothing(:,2)=std(mod_raw_data,0,2);
    for i=1:t_length
        data_smoothing(i,3)=data_smoothing(i,2)/data_smoothing(i,1)*100;
        data_smoothing(i,4)=data_smoothing(i,1)+data_smoothing(i,3);
        data_smoothing(i,5)=data_smoothing(i,1)-data_smoothing(i,3);
    end
    
    data_smth=zeros(t_length/wd,3);
    for i=1:t_length/10
        data_smth(i,1)=mean(data_smoothing(wd*(i-1)+1:wd*i,1));
        data_smth(i,2)=mean(data_smoothing(wd*(i-1)+1:wd*i,4));
        data_smth(i,3)=mean(data_smoothing(wd*(i-1)+1:wd*i,5));
    end

    data_smooth=zeros(t_length/wd,3);
    data_smooth(:,1)=smooth(data_smth(:,1),3);
    data_smooth(:,2)=smooth(data_smth(:,2),3);
    data_smooth(:,3)=smooth(data_smth(:,3),3);
end