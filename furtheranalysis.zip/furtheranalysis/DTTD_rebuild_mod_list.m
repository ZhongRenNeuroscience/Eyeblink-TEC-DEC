
% !!!!!!!!!!!!! just make the modulation detection criteria the same
% between delay and trace and CR aligned PSTH with 3*SD, change that before
% use!!!!!!!!!!!!!!!!

list=DT_list_sim;
align_info_1='align_info_D';
align_info_2='align_info_T';
all_info_1='all_info_D';
all_info_2='all_info_T';
t_pre=550;
t_pre_extra=50;
std_idx=5;
pct_idx=40;
mod_find_start=30;

mod_list_DT=struct('cell_ID',[],'CR_fac_D',[],'CR_sup_D',[],'align_info_D',[],'CR_fac_T',[],'CR_sup_T',[],'align_info_T',[],'norm_info_DT',[]);

for i=1:size(list,2)
    mod_list_DT(i).cell_ID=list(i).cell_ID;
    mod_list_DT(i).CR_fac_D=0;
    mod_list_DT(i).CR_sup_D=0;
    mod_list_DT(i).CR_fac_T=0;
    mod_list_DT(i).CR_sup_T=0;
    align_info_D=struct('bsl_frq_ex',[],'SD_ex',[],'psth_ex',[],'psth_align',[],'psth_prb',[],'CR_fac',[],'CR_sup',[],'CR_fac_align',[],'CR_sup_align',[],'t_start',[],'t_end',[]);
    align_info_T=struct('bsl_frq_ex',[],'SD_ex',[],'psth_ex',[],'psth_align',[],'psth_prb',[],'CR_fac',[],'CR_sup',[],'CR_fac_align',[],'CR_sup_align',[],'t_start',[],'t_end',[]);
    norm_info_DT=struct('bsl_psth',[],'bsl_frq',[],'bsl_SD',[],'thrd_D',[],'thrd_T',[]);
    
    bsl_psth=zeros(t_pre-t_pre_extra,7);
    bsl_psth(:,1)=-t_pre+t_pre_extra:-1;
    bsl_psth(:,2)=list(i).(align_info_1).psth_ex(1+t_pre_extra:t_pre,2)/list(i).(align_info_1).bsl_frq_ex*100;
    bsl_psth(:,3)=list(i).(align_info_2).psth_ex(1+t_pre_extra:t_pre,2)/list(i).(align_info_2).bsl_frq_ex*100;
    bsl_psth(:,4)=list(i).(align_info_1).psth_ex(1+t_pre_extra:t_pre,2);
    bsl_psth(:,5)=list(i).(align_info_2).psth_ex(1+t_pre_extra:t_pre,2);
    for j=1:t_pre-t_pre_extra
        bsl_psth(j,6)=(bsl_psth(j,2)*size(list(i).(all_info_1).ttt.CR_trial,2)+bsl_psth(j,3)*size(list(i).(all_info_2).ttt.CR_trial,2))/...
            (size(list(i).(all_info_1).ttt.CR_trial,2)+size(list(i).(all_info_2).ttt.CR_trial,2));      
        bsl_psth(j,7)=(bsl_psth(j,4)*size(list(i).(all_info_1).ttt.CR_trial,2)+bsl_psth(j,5)*size(list(i).(all_info_2).ttt.CR_trial,2))/...
            (size(list(i).(all_info_1).ttt.CR_trial,2)+size(list(i).(all_info_2).ttt.CR_trial,2));           
    end
    bsl_frq=mean(bsl_psth(1+t_pre_extra:end,7));
    bsl_SD=std(bsl_psth(1+t_pre_extra:end,7));
    bsl_frq_norm=mean(bsl_psth(1+t_pre_extra:end,6));
    bsl_SD_norm=std(bsl_psth(1+t_pre_extra:end,6)); 
    mod_thrd_D=std_idx*bsl_SD_norm;
    mod_thrd_T=std_idx*bsl_SD_norm;
    
%     bsl_wv_D=max(abs(bsl_psth(:,2)-100));
%     bsl_wv_T=max(abs(bsl_psth(:,3)-100));
%     mod_thrd_D=max([std_idx*bsl_SD pct_idx bsl_wv_D+10]);
%     mod_thrd_T=max([std_idx*bsl_SD pct_idx bsl_wv_T+10]);
%     mod_thrd_D=min([6*bsl_SD mod_thrd_D]);
%     mod_thrd_T=min([6*bsl_SD mod_thrd_T]);
    
    norm_info_DT.bsl_psth=bsl_psth;
    norm_info_DT.bsl_frq=bsl_frq;
    norm_info_DT.bsl_SD=bsl_SD;
    norm_info_DT.thrd_D=mod_thrd_D;
    norm_info_DT.thrd_T=mod_thrd_T;
    mod_list_DT(i).norm_info_DT=norm_info_DT;
    
    align_info_D.bsl_frq_ex=list(i).align_info_D.bsl_frq_ex;
    align_info_D.SD_ex=list(i).align_info_D.SD_ex;
    psth_ex=zeros(size(list(i).align_info_D.psth_ex,1),3);
    psth_ex(:,1)=list(i).align_info_D.psth_ex(:,1);
    psth_ex(:,2)=list(i).align_info_D.psth_ex(:,2);
    psth_ex(:,3)=list(i).align_info_D.psth_ex(:,2)/list(i).align_info_D.bsl_frq_ex*100;
    CR_fac=struct('t_onset_1',[],'t_onset',[],'t_peak',[],'peak',[]);
    CR_sup=struct('t_onset_1',[],'t_onset',[],'t_peak',[],'peak',[]); 
    
    [CR_fac.peak,CR_fac.t_peak]=max(psth_ex(t_pre+1:t_pre+249,3));
    [fac_pk,fac_pk_idx]=findpeaks(psth_ex(t_pre+1:t_pre+249,3),'MinPeakHeight',mod_thrd_D+100);
    if ~isempty(fac_pk)
        for j=1:length(fac_pk)
           fac_onset=find(psth_ex(t_pre+1:t_pre+fac_pk_idx(j,1),3)<=100+mod_thrd_D,1,'last');
           if ~isempty(fac_onset) && fac_pk_idx(j,1)-fac_onset>=4 && fac_onset>mod_find_start
              CR_fac.t_onset=fac_onset;
              CR_fac.t_onset_1=find(psth_ex(t_pre+1:t_pre+fac_pk_idx(j,1),3)<=100+mod_thrd_D,1,'first');
              [CR_fac.peak,I]=max(fac_pk);
              CR_fac.t_peak=fac_pk_idx(I);
              mod_list_DT(i).CR_fac_D=1;
              break              
           end
        end 
    end
    [CR_sup.peak,CR_sup.t_peak]=min(psth_ex(t_pre+1:t_pre+249,3));
    [sup_pk,sup_pk_idx]=findpeaks((psth_ex(t_pre+1:t_pre+249,3)*-1),'MinPeakHeight',-100+mod_thrd_D);
    if ~isempty(sup_pk)
        for j=1:length(sup_pk)
           sup_onset=find((psth_ex(t_pre+1:t_pre+sup_pk_idx(j,1),3)*-1)<=-100+mod_thrd_D,1,'last');
           if ~isempty(sup_onset) && sup_pk_idx(j,1)-sup_onset>=4 && sup_onset>mod_find_start
              CR_sup.t_onset=sup_onset;
              CR_sup.t_onset_1=find(psth_ex(t_pre+1:t_pre+sup_pk_idx(j,1),3)<=-100+mod_thrd_D,1,'first');
              [CR_sup.peak,I]=max(sup_pk);
              CR_sup.peak=CR_sup.peak*-1;
              CR_sup.t_peak=sup_pk_idx(I);
              mod_list_DT(i).CR_sup_D=1;
              break
           end
        end          
    end
    
    psth_align=zeros(size(list(i).align_info_D.psth_align,1),3);
    psth_align(:,1)=list(i).align_info_D.psth_align(:,1);
    psth_align(:,2)=list(i).align_info_D.psth_align(:,2);
    psth_align(:,3)=list(i).align_info_D.psth_align(:,2)/list(i).align_info_D.bsl_frq_ex*100;
    CR_fac_align=struct('t_peak',[],'peak',[]);
    CR_sup_align=struct('t_peak',[],'peak',[]);
    [fac_pk,fac_pk_idx]=max(psth_align(t_pre+1-list(i).align_info_D.t_start:t_pre+250-list(i).align_info_D.t_end,3));
    CR_fac_align.peak=fac_pk; 
    if fac_pk>=100+mod_thrd_D
       if psth_align(t_pre+fac_pk_idx-list(i).align_info_D.t_start-4,3)>=100+mod_thrd_D
          CR_fac_align.t_peak=-list(i).align_info_D.t_start+fac_pk_idx-1;   
       end
    end    
    [sup_pk,sup_pk_idx]=min(psth_align(t_pre+1-list(i).align_info_D.t_start:t_pre+250-list(i).align_info_D.t_end,3));
    CR_sup_align.peak=sup_pk;
    if sup_pk<=100-mod_thrd_D
       if psth_align(t_pre+sup_pk_idx-list(i).align_info_D.t_start-4,3)<=100-mod_thrd_D
          CR_sup_align.t_peak=-list(i).align_info_D.t_start+sup_pk_idx-1;          
       end 
    end     

    align_info_D.psth_ex=psth_ex;
    align_info_D.psth_align=psth_align;
    align_info_D.CR_fac=CR_fac;
    align_info_D.CR_sup=CR_sup;
    align_info_D.CR_fac_align=CR_fac_align;
    align_info_D.CR_sup_align=CR_sup_align;    
    align_info_D.t_start=list(i).align_info_D.t_start;
    align_info_D.t_end=list(i).align_info_D.t_end;
    mod_list_DT(i).align_info_D=align_info_D;
    
    align_info_T.bsl_frq_ex=list(i).align_info_T.bsl_frq_ex;
    align_info_T.SD_ex=list(i).align_info_T.SD_ex;
    psth_ex=zeros(size(list(i).align_info_T.psth_ex,1),3);
    psth_ex(:,1)=list(i).align_info_T.psth_ex(:,1);
    psth_ex(:,2)=list(i).align_info_T.psth_ex(:,2);
    psth_ex(:,3)=list(i).align_info_T.psth_ex(:,2)/list(i).align_info_T.bsl_frq_ex*100;
    CR_fac=struct('t_onset_1',[],'t_onset',[],'t_peak',[],'peak',[],'t_peak_250',[],'peak_250',[]);
    CR_sup=struct('t_onset_1',[],'t_onset',[],'t_peak',[],'peak',[],'t_peak_250',[],'peak_250',[]); 
    [CR_fac.peak,CR_fac.t_peak]=max(psth_ex(t_pre+1:t_pre+499,3));
    [CR_fac.peak_250,CR_fac.t_peak_250]=max(psth_ex(t_pre+1:t_pre+249,3));
    [fac_pk,fac_pk_idx]=findpeaks(psth_ex(t_pre+1:t_pre+499,3),'MinPeakHeight',mod_thrd_T+100);
    if ~isempty(fac_pk)
        for j=1:length(fac_pk)
           fac_onset=find(psth_ex(t_pre+1:t_pre+fac_pk_idx(j,1),3)<=100+mod_thrd_T,1,'last');
           if ~isempty(fac_onset) && fac_pk_idx(j,1)-fac_onset>=4 && fac_onset>mod_find_start
              CR_fac.t_onset=fac_onset;
              CR_fac.t_onset_1=find(psth_ex(t_pre+1:t_pre+fac_pk_idx(j,1),3)<=100+mod_thrd_T,1,'first');
              [CR_fac.peak,I]=max(fac_pk);
              CR_fac.t_peak=fac_pk_idx(I);
              mod_list_DT(i).CR_fac_T=1;
              break
           end
        end
        
    end
    [CR_sup.peak,CR_sup.t_peak]=min(psth_ex(t_pre+1:t_pre+499,3));
    [CR_sup.peak_250,CR_sup.t_peak_250]=min(psth_ex(t_pre+1:t_pre+249,3));
    [sup_pk,sup_pk_idx]=findpeaks((psth_ex(t_pre+1:t_pre+499,3)*-1),'MinPeakHeight',-100+mod_thrd_T);
    if ~isempty(sup_pk)
        for j=1:length(sup_pk)
           sup_onset=find((psth_ex(t_pre+1:t_pre+sup_pk_idx(j,1),3)*-1)<=-100+mod_thrd_T,1,'last');
           if ~isempty(sup_onset) && sup_pk_idx(j,1)-sup_onset>=4 && sup_onset>mod_find_start
              CR_sup.t_onset=sup_onset;
              CR_sup.t_onset_1=find(psth_ex(t_pre+1:t_pre+sup_pk_idx(j,1),3)<=-100+mod_thrd_T,1,'first');
              [CR_sup.peak,I]=max(sup_pk);
              CR_sup.peak=CR_sup.peak*-1;
              CR_sup.t_peak=sup_pk_idx(I);
              mod_list_DT(i).CR_sup_T=1;
              break
           end
        end        
    end
    
    psth_align=zeros(size(list(i).align_info_T.psth_align,1),3);
    psth_align(:,1)=list(i).align_info_T.psth_align(:,1);
    psth_align(:,2)=list(i).align_info_T.psth_align(:,2);
    psth_align(:,3)=list(i).align_info_T.psth_align(:,2)/list(i).align_info_T.bsl_frq_ex*100;
    CR_fac_align=struct('t_peak',[],'peak',[]);
    CR_sup_align=struct('t_peak',[],'peak',[]); 
    [fac_pk,fac_pk_idx]=max(psth_align(t_pre+1-list(i).align_info_T.t_start:t_pre+500-list(i).align_info_T.t_end,3));
    CR_fac_align.peak=fac_pk; 
    if fac_pk>=100+mod_thrd_T
       if psth_align(t_pre+fac_pk_idx-list(i).align_info_T.t_start-4,3)>=100+mod_thrd_T
          CR_fac_align.t_peak=-list(i).align_info_T.t_start+fac_pk_idx-1;                
       end
    end    
    [sup_pk,sup_pk_idx]=min(psth_align(t_pre+1-list(i).align_info_T.t_start:t_pre+500-list(i).align_info_T.t_end,3));
    CR_sup_align.peak=sup_pk;
    if sup_pk<=100-mod_thrd_T
       if psth_align(t_pre+sup_pk_idx-list(i).align_info_T.t_start-4,3)<=100-mod_thrd_T
          CR_sup_align.t_peak=-list(i).align_info_T.t_start+sup_pk_idx-1;          
       end
    end      
    
    align_info_T.psth_ex=psth_ex;
    align_info_T.psth_align=psth_align;
    align_info_T.CR_fac=CR_fac;
    align_info_T.CR_sup=CR_sup;
    align_info_T.CR_fac_align=CR_fac_align;
    align_info_T.CR_sup_align=CR_sup_align;    
    align_info_T.t_start=list(i).align_info_T.t_start;
    align_info_T.t_end=list(i).align_info_T.t_end;
    mod_list_DT(i).align_info_T=align_info_T;    
    
end