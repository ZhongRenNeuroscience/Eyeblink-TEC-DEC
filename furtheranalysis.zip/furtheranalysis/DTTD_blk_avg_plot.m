cell_num=101;
all_info='all_info_D';
pack=DT_list_sim;

blk_data1=zeros(31000,size(pack(cell_num).(all_info).ttt.CR_trial,2));

for n=1:size(pack(cell_num).(all_info).ttt.CR_trial,2)
    blk_data1(:,n)=pack(cell_num).(all_info).ttt.CR_trial(n).blk_trace(:,4)*100;
end

blk_data2=zeros(1250,size(blk_data1,2));
blk_form2=zeros(1250,5);
blk_form2(:,1)=-250:1:999;

for k=1:1250
t_idx=6001+20*(k-1);
blk_data2(k,:)=mean(blk_data1(t_idx-19:t_idx,:),1);  
end

blk_form2(:,2)=mean(blk_data2,2);
blk_form2(:,3)=std(blk_data2,0,2);

for k=1:1250
blk_form2(k,4)=blk_form2(k,2)+blk_form2(k,3);
blk_form2(k,5)=blk_form2(k,2)-blk_form2(k,3);
end

figure;
% subplot(2,1,1)
hold on
for i=1:44
    plot(blk_form2(:,1),smooth(blk_data2(:,i),5),'linewidth',0.5,'Color',[0.9 0.9 0.9],'LineWidth',0.5)
    hold on
end
plot(blk_form2(:,1),smooth(blk_form2(:,2),5),'Color',[0 0 0],'LineWidth',2)
hold on
plot(blk_form2(:,1),smooth(blk_form2(:,4),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
hold on
plot(blk_form2(:,1),smooth(blk_form2(:,5),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
hold on
line([0 0],[-10, 125],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[-10, 120],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[-10, 125],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([-10 125]);
xlabel('Time (ms)');
ylabel('Eyelid closure (%)');
xticks([-250 0 250 500 1000]);
yticks([0 100]);

all_info='all_info_T';

blk_data1=zeros(31000,size(pack(cell_num).(all_info).ttt.CR_trial,2));

for n=1:size(pack(cell_num).(all_info).ttt.CR_trial,2)
    blk_data1(:,n)=pack(cell_num).(all_info).ttt.CR_trial(n).blk_trace(:,4)*100;
end

blk_data2=zeros(1250,size(blk_data1,2));
blk_form2=zeros(1250,5);
blk_form2(:,1)=-250:1:999;

for k=1:1250
t_idx=6001+20*(k-1);
blk_data2(k,:)=mean(blk_data1(t_idx-19:t_idx,:),1);  
end

blk_form2(:,2)=mean(blk_data2,2);
blk_form2(:,3)=std(blk_data2,0,2);

for k=1:1250
blk_form2(k,4)=blk_form2(k,2)+blk_form2(k,3);
blk_form2(k,5)=blk_form2(k,2)-blk_form2(k,3);
end

figure;
% subplot(2,1,2)
hold on
for i=1:58
    plot(blk_form2(:,1),smooth(blk_data2(:,i),5),'linewidth',0.5,'Color',[0.9 0.9 0.9],'LineWidth',0.5)
    hold on
end
plot(blk_form2(:,1),smooth(blk_form2(:,2),5),'Color',[0 0 0],'LineWidth',2)
hold on
plot(blk_form2(:,1),smooth(blk_form2(:,4),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
hold on
plot(blk_form2(:,1),smooth(blk_form2(:,5),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
hold on
line([0 0],[-10, 125],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[-10, 125],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[-10, 125],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([-10 125]);
xlabel('Time (ms)');
ylabel('Eyelid closure (%)');
xticks([-250 0 250 500 1000]);
yticks([0 100]);



