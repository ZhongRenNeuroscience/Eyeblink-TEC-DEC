file=DT_list_align;
ID='cell_ID';
all_info_1='all_info_D';
all_info_2='all_info_T';
t_start=-500;
sample_size=30;
corr_test_type='Pearson';%'Spearman'; 
cd D:\Zhong\Delay-trained-mice\CTD\DT_sep

bsl_tr_corr=struct('cell_ID',[],'row_data',[],'corr_p',[],'corr_r',[],'test_p',[],'test_info',[],'count_result',[]);

for i=1:size(file,2)
    row_data=struct('row_data_1',[],'row_data_2',[],'row_data_all',[]);
    corr_p=struct('p_1',[],'p_2',[],'p_all',[]);
    corr_r=struct('r_1',[],'r_2',[],'r_all',[]);
    test_p=struct('p_12',[],'p_13',[],'p_23',[],'p_DTTD',[]);
    test_info=struct('mean',[],'std',[]);
    row_data_1=zeros(size(file(i).(all_info_1).ttt.CR_trial,2),3);
    row_data_2=zeros(size(file(i).(all_info_2).ttt.CR_trial,2),3);
    row_data_all=zeros(size(file(i).(all_info_1).ttt.CR_trial,2)+size(file(i).(all_info_2).ttt.CR_trial,2),3);
    
    for j=1:size(file(i).(all_info_1).ttt.CR_trial,2)
        row_data_1(j,1)=j;
        row_data_1(j,2)=length(find([file(i).(all_info_1).ttt.CR_trial(j).spk_time]>=-0.5 & [file(i).(all_info_1).ttt.CR_trial(j).spk_time]<0))/(-t_start)*1000;
        row_data_all(j,1)=j;
        row_data_all(j,2)=row_data_1(j,2);
    end
    for k=1:size(file(i).(all_info_2).ttt.CR_trial,2)
        row_data_2(k,1)=k;
        row_data_2(k,2)=length(find([file(i).(all_info_2).ttt.CR_trial(k).spk_time]>=-0.5 & [file(i).(all_info_2).ttt.CR_trial(k).spk_time]<0))/(-t_start)*1000;
        row_data_all(j+k,1)=j+k;
        row_data_all(j+k,2)=row_data_2(k,2);
    end    
    
    [R_1,P_1]=corr(row_data_1(:,1),row_data_1(:,2),'Type',corr_test_type);
    p_1=polyfit(row_data_1(:,1),row_data_1(:,2),1);
    regression_1=p_1(1)*row_data_1(:,1)+p_1(2);
    row_data_1(:,3)=regression_1;
        
    [R_2,P_2]=corr(row_data_2(:,1),row_data_2(:,2),'Type',corr_test_type);
    p_2=polyfit(row_data_2(:,1),row_data_2(:,2),1);
    regression_2=p_2(1)*row_data_2(:,1)+p_2(2);
    row_data_2(:,3)=regression_2;    
    
    [R_all,P_all]=corr(row_data_all(:,1),row_data_all(:,2),'Type',corr_test_type);
    p_all=polyfit(row_data_all(:,1),row_data_all(:,2),1);
    regression_all=p_all(1)*row_data_all(:,1)+p_all(2);
    row_data_all(:,3)=regression_all;
    
    p_12=ranksum(row_data_1(:,2),row_data_2(1:sample_size,2));
    p_13=ranksum(row_data_1(:,2),row_data_2(size(file(i).(all_info_2).ttt.CR_trial,2)-sample_size:end,2));
    p_23=ranksum(row_data_2(1:sample_size,2),row_data_2(size(file(i).(all_info_2).ttt.CR_trial,2)-sample_size:end,2));
    p_DTTD=ranksum(row_data_1(:,2),row_data_2(:,2));
    
    row_data.row_data_1=row_data_1;
    row_data.row_data_2=row_data_2;
    row_data.row_data_all=row_data_all;   
    corr_p.p_1=P_1;
    corr_p.p_2=P_2;
    corr_p.p_all=P_all;
    corr_r.r_1=R_1;
    corr_r.r_2=R_2;
    corr_r.r_all=R_all;
    test_p.p_12=p_12;
    test_p.p_23=p_23;
    test_p.p_13=p_13;
    test_p.p_DTTD=p_DTTD;
    test_info(1).mean=mean(row_data_1(:,2));
    test_info(1).std=std(row_data_1(:,2));
    test_info(2).mean=mean(row_data_2(1:sample_size,2));
    test_info(2).std=std(row_data_2(1:sample_size,2));
    test_info(3).mean=mean(row_data_2(size(file(i).(all_info_2).ttt.CR_trial,2)-sample_size:end,2));
    test_info(3).std=std(row_data_2(size(file(i).(all_info_2).ttt.CR_trial,2)-sample_size:end,2));
    
    bsl_tr_corr(i).cell_ID=file(i).(ID);
    bsl_tr_corr(i).row_data=row_data;
    bsl_tr_corr(i).corr_p=corr_p;
    bsl_tr_corr(i).corr_r=corr_r;
    bsl_tr_corr(i).test_p=test_p;
    bsl_tr_corr(i).test_info=test_info;
end

count_result=struct('no_change',[],'direct_change',[],'non_direct_change',[]);
no_change=0;
direct_change=0;
non_direct_change=0;

for i=1:size(bsl_tr_corr,2)
    if bsl_tr_corr(i).test_p.p_DTTD>=0.05
       no_change=no_change+1;
       count_result(no_change).no_change=bsl_tr_corr(i).cell_ID;
    elseif bsl_tr_corr(i).test_p.p_DTTD<0.05
        if bsl_tr_corr(i).test_p.p_12<0.05
           direct_change=direct_change+1;
           count_result(direct_change).direct_change=bsl_tr_corr(i).cell_ID;
        elseif bsl_tr_corr(i).test_p.p_12>=0.05
           non_direct_change=non_direct_change+1;
           count_result(non_direct_change).non_direct_change=bsl_tr_corr(i).cell_ID;
        end       
    end   
end
bsl_tr_corr(1).count_result=count_result;

fac_idx=0;
sup_idx=0;
non_idx=0;
multi_idx=0;
for i=1:no_change
    cell_idx=count_result(i).no_change;
    fac_num=file(cell_idx).CR_fac_D+file(cell_idx).CR_fac_T;
    sup_num=file(cell_idx).CR_sup_D+file(cell_idx).CR_sup_T;
    if fac_num>0 && sup_num==0
       fac_idx=fac_idx+1;
    elseif fac_num==0 && sup_num>0
       sup_idx=sup_idx+1;
    elseif fac_num>0 && sup_num>0
       multi_idx=multi_idx+1;
    elseif fac_num==0 && sup_num==0
       non_idx=non_idx+1; 
    end    
end
no_change=struct('fac',[],'sup',[],'non',[],'multi',[]);
no_change_count.fac=fac_idx;
no_change_count.sup=sup_idx;
no_change_count.non=non_idx;
no_change_count.multi=multi_idx;
bsl_tr_corr(2).count_result=no_change_count;

fac_idx=0;
sup_idx=0;
non_idx=0;
multi_idx=0;
for i=1:direct_change
    cell_idx=count_result(i).direct_change;
    fac_num=file(cell_idx).CR_fac_D+file(cell_idx).CR_fac_T;
    sup_num=file(cell_idx).CR_sup_D+file(cell_idx).CR_sup_T;
    if fac_num>0 && sup_num==0
       fac_idx=fac_idx+1;
    elseif fac_num==0 && sup_num>0
       sup_idx=sup_idx+1;
    elseif fac_num>0 && sup_num>0
       multi_idx=multi_idx+1;
    elseif fac_num==0 && sup_num==0
       non_idx=non_idx+1; 
    end    
end
direct_change=struct('fac',[],'sup',[],'non',[],'multi',[]);
direct_change_count.fac=fac_idx;
direct_change_count.sup=sup_idx;
direct_change_count.non=non_idx;
direct_change_count.multi=multi_idx;
bsl_tr_corr(3).count_result=direct_change_count;

fac_idx=0;
sup_idx=0;
non_idx=0;
multi_idx=0;
for i=1:non_direct_change
    cell_idx=count_result(i).non_direct_change;
    fac_num=file(cell_idx).CR_fac_D+file(cell_idx).CR_fac_T;
    sup_num=file(cell_idx).CR_sup_D+file(cell_idx).CR_sup_T;
    if fac_num>0 && sup_num==0
       fac_idx=fac_idx+1;
    elseif fac_num==0 && sup_num>0
       sup_idx=sup_idx+1;
    elseif fac_num>0 && sup_num>0
       multi_idx=multi_idx+1;
    elseif fac_num==0 && sup_num==0
       non_idx=non_idx+1; 
    end    
end
non_direct_change_count=struct('fac',[],'sup',[],'non',[],'multi',[]);
non_direct_change_count.fac=fac_idx;
non_direct_change_count.sup=sup_idx;
non_direct_change_count.non=non_idx;
non_direct_change_count.multi=multi_idx;
bsl_tr_corr(4).count_result=non_direct_change_count;

% for i=1:size(file,2)
%     figure('units','normalized','outerposition',[0.2 0.2 0.6 0.6]) ;
%     subplot('Position',[0.1 0.1 0.55 0.8])
%     plot(bsl_tr_corr(i).row_data.row_data_all(:,1),bsl_tr_corr(i).row_data.row_data_all(:,2),'k.','MarkerSize',10)
%     hold on
%     ymin=min(bsl_tr_corr(i).row_data.row_data_all(:,2))*0.8;
%     ymax=max(bsl_tr_corr(i).row_data.row_data_all(:,2))*1.2;
%     line([size(bsl_tr_corr(i).row_data.row_data_1,1)+0.5 size(bsl_tr_corr(i).row_data.row_data_1+0.5,1)],[ymin ymax],'Color',[0 0 0],'LineStyle','--');
%     if bsl_tr_corr(i).corr_p.p_1<0.05
%        plot(bsl_tr_corr(i).row_data.row_data_1(:,1),bsl_tr_corr(i).row_data.row_data_1(:,3),'r-','LineWidth',3)
%        hold on
%     else   
%        plot(bsl_tr_corr(i).row_data.row_data_1(:,1),bsl_tr_corr(i).row_data.row_data_1(:,3),'k-','LineWidth',2) 
%        hold on
%     end
%     if bsl_tr_corr(i).corr_p.p_2<0.05
%        plot(bsl_tr_corr(i).row_data.row_data_2(:,1)+size(bsl_tr_corr(i).row_data.row_data_1,1),bsl_tr_corr(i).row_data.row_data_2(:,3),'r-','LineWidth',3)
%        hold on
%     else   
%        plot(bsl_tr_corr(i).row_data.row_data_2(:,1)+size(bsl_tr_corr(i).row_data.row_data_1,1),bsl_tr_corr(i).row_data.row_data_2(:,3),'k-','LineWidth',2) 
%        hold on
%     end   
%     text_word={['r1= ' num2str(bsl_tr_corr(i).corr_r.r_1)];['p1= ' num2str(bsl_tr_corr(i).corr_p.p_1)];['r2= ' num2str(bsl_tr_corr(i).corr_r.r_2)];['p2= ' num2str(bsl_tr_corr(i).corr_p.p_2)]};
%     text(size(bsl_tr_corr(i).row_data.row_data_all,1)*0.97,ymax*0.9,text_word,'HorizontalAlignment','right');
%     xlim([0 size(bsl_tr_corr(i).row_data.row_data_all,1)+1]);
%     ylim([ymin ymax]);
%     xlabel('Trial number');
%     ylabel('Frequency (Hz)'); 
%     title(['DT cell ' num2str(bsl_tr_corr(i).cell_ID)]);
%     
%     subplot('Position',[0.7 0.1 0.2 0.8])
%     
%     plot(1,bsl_tr_corr(i).row_data.row_data_1(:,2),'.','Color',[0.5 0.5 0.5])
%     hold on
%     plot(2,bsl_tr_corr(i).row_data.row_data_2(1:sample_size,2),'.','Color',[0.5 0.5 0.5])
%     hold on
%     plot(3,bsl_tr_corr(i).row_data.row_data_2(size(file(i).(all_info_2).ttt.CR_trial,2)-sample_size:end,2),'.','Color',[0.5 0.5 0.5])
%     hold on
%     line([0.7 1.3],[bsl_tr_corr(i).test_info(1).mean bsl_tr_corr(i).test_info(1).mean],'Color',[0 0 0],'LineStyle','-','LineWidth',2);
%     errorbar(1,bsl_tr_corr(i).test_info(1).mean,bsl_tr_corr(i).test_info(1).std,'Color',[0 0 0]);
%     line([1.7 2.3],[bsl_tr_corr(i).test_info(2).mean bsl_tr_corr(i).test_info(2).mean],'Color',[0 0 0],'LineStyle','-','LineWidth',2);
%     errorbar(2,bsl_tr_corr(i).test_info(2).mean,bsl_tr_corr(i).test_info(2).std,'Color',[0 0 0]);    
%     line([2.7 3.3],[bsl_tr_corr(i).test_info(3).mean bsl_tr_corr(i).test_info(3).mean],'Color',[0 0 0],'LineStyle','-','LineWidth',2);
%     errorbar(3,bsl_tr_corr(i).test_info(3).mean,bsl_tr_corr(i).test_info(3).std,'Color',[0 0 0]);
%     
%     if bsl_tr_corr(i).test_p.p_12<0.05
%        line([1.05 1.95],[ymax*0.9 ymax*0.9],'Color',[0 0 0],'LineStyle','-');
%        text(1.5,ymax*0.91,'*','Color','r','FontSize',12,'HorizontalAlignment','center');
%     end
%     if bsl_tr_corr(i).test_p.p_23<0.05
%        line([2.05 2.95],[ymax*0.9 ymax*0.9],'Color',[0 0 0],'LineStyle','-');
%        text(2.5,ymax*0.91,'*','Color','r','FontSize',12,'HorizontalAlignment','center');
%     end   
%     if bsl_tr_corr(i).test_p.p_13<0.05
%        line([1.05 2.95],[ymax*0.95 ymax*0.95],'Color',[0 0 0],'LineStyle','-');
%        text(2,ymax*0.96,'*','Color','r','FontSize',12,'HorizontalAlignment','center');
%     end
%     
%     xlim([0 4]);
%     ylim([ymin ymax]);
%     xticks([1 2 3]);
%     xticklabels({'D all','T start','T end'});
%     
%     saveas(gcf,['Baseline test Cell ' num2str(file(i).(ID)) '.tif']);
%     close all
% end