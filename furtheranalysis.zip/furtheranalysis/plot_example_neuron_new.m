% plot example cells with everything

file=trace_list_sim;
val_file=cell_validation_list_trace_2;
p_value_file=trace_p_value_all;
cell_ID=424;
all_info='all_info';
align_info='align_info';
sort_method='CR_onset';
neuron_name='trace_neuron';
t_post=500;
dur=1000;
bin_htmp=50;
step_htmp=25;
trial_max=60;
ht_range_low=80;
ht_range_high=100;

t_end=dur-500;

trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'CRonset_rank',[],'spk',[],'blk_smth',[],'ifr_smth',[],...
    'bsl_frq',[],'CR_frq',[],'ifr_plot',[]);
for j=1:size(file(cell_ID).(all_info).ttt.CR_trial,2)
    trial_info(j).field=j;
    trial_info(j).trial_num=file(cell_ID).(all_info).ttt.CR_trial(j).trial_num;
    trial_info(j).CR_onset=file(cell_ID).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
%     trial_info(j).CRonset_rank=file(cell_ID).(all_info).ttt.CR_trial(j).blk_info.CRonset_rank;
    trial_info(j).spk=file(cell_ID).(all_info).ttt.CR_trial(j).spk_time;
    trial_info(j).blk_smth=file(cell_ID).(all_info).ttt.CR_trial(j).blk_smth;
    trial_info(j).ifr_smth=file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth;
    trial_info(j).bsl_frq=length(find([file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]>=-0.5 & [file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]<0))/500*1000;
    trial_info(j).CR_frq=length(find([file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]>=0 & [file(cell_ID).(all_info).ttt.CR_trial(j).spk_time]<t_post/1000))/t_post*1000;
    t_ifr_start=find(file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth(:,1)==-500);
    ifr_plot=smooth_curve(file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,1),file(cell_ID).(all_info).ttt.CR_trial(j).ifr_smooth(t_ifr_start:t_ifr_start+dur-1,2),bin_htmp,step_htmp);
    trial_info(j).ifr_plot=ifr_plot;
%     [mod_amp,mod_pkt]=max(ifr_plot(250/step+1:(250+t_post)/step,2));
%     trial_info(j).mod_amp=mod_amp;
%     trial_info(j).mod_pkt=mod_pkt*(2*step-1)/2;
end

% trial_info = trial_info(all(~cellfun(@isempty,struct2cell(trial_info))));
[~,index] = sortrows([trial_info.(sort_method)].'); 
trial_info = trial_info(index);
% for n=1:size(trial_info,2)
%     if trial_info(n).CR_onset<0.05 || trial_info(n).CR_onset>t_post/1000*0.9
%        trial_info(n).trial_num=[]; 
%     end
% end
% trial_info=trial_info(~cellfun(@isempty,{trial_info.trial_num}));

plot_trials=1:size(trial_info,2);
if size(trial_info,2)>=trial_max
   plot_trials=randperm(size(trial_info,2),trial_max);
   plot_trials=sort(plot_trials);
end

figure;
subplot(4,2,1)
behavior_mean=zeros((1550-25)/5+1,size(trial_info,2));
for m=1:size(trial_info,2)
    blk_curve=smooth_curve(trial_info(m).blk_smth(:,1),trial_info(m).blk_smth(:,2)*100,25,5);
    behavior_mean(:,m)=blk_curve(:,2);  
end
for m=1:ceil(length(plot_trials)/2)
    plot(blk_curve(:,1),behavior_mean(:,plot_trials(1,m)),'Color',[1 0.75 0.75],'LineWidth',0.25)
    hold on
end
for m=ceil(length(plot_trials)/2)+1:length(plot_trials)
    plot(blk_curve(:,1),behavior_mean(:,plot_trials(1,m)),'Color',[0.8 0.8 0.8],'LineWidth',0.25)
    hold on
end
early_idx=ceil(size(trial_info,2)/2);
behavior_mean_plot=zeros(size(blk_curve,1),5);
behavior_mean_plot(:,1)=blk_curve(:,1);
behavior_mean_plot(:,2)=mean(behavior_mean,2);
behavior_mean_plot(:,3)=std(behavior_mean,1,2);
behavior_mean_plot(:,4)=mean(behavior_mean(:,1:early_idx),2);
behavior_mean_plot(:,5)=mean(behavior_mean(:,early_idx+1:end),2);
early_onset_avg=mean([trial_info(1:1:early_idx).CR_onset])*1000;
late_onset_avg=mean([trial_info(:,early_idx+1:end).CR_onset])*1000;
ymax=max(max(behavior_mean))+0.1;
ymin=min(min(behavior_mean))-0.1;
%     line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
% rectangle('Position',[0,ymin*0.95,250,ymax-ymin],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')
line([t_post t_post],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
plot(behavior_mean_plot(:,1),behavior_mean_plot(:,4),'Color',[1 0 0],'LineWidth',2)
hold on
plot(behavior_mean_plot(:,1),behavior_mean_plot(:,5),'Color',[0 0 0],'LineWidth',2)
hold on
text(early_onset_avg,ymax-5,1,'*','HorizontalAlignment','left','Color','r');
text(late_onset_avg,ymax-5,1,'*','HorizontalAlignment','left','Color','k');
xlim([-500 t_end]);
xticks(-500:250:t_end);
ylim([ymin ymax]);
xlabel('Time(ms)');
ylabel('Normalized eyelid trace')    

subplot(4,2,3)
ymin=min(min(file(cell_ID).(align_info).psth_ex(51:1500,2)),min(file(cell_ID).(align_info).psth_align(51:1000,2)))*0.9;   
ymax=max(max(file(cell_ID).(align_info).psth_ex(51:1500,2)),max(file(cell_ID).(align_info).psth_align(51:1000,2)))*1.1;   
%     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
%     hold on
%     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
%     hold on  
plot(file(cell_ID).(align_info).psth_ex(:,1),smooth(file(cell_ID).(align_info).psth_ex(:,2),25),'k-','LineWidth',2.0)
hold on
% plot(file(cell_ID).(align_info).psth_align(:,1),smooth(file(cell_ID).(align_info).psth_align(:,2),25),'b-','LineWidth',2.0)
% hold on

% line([-file(cell_ID).(align_info).t_start -file(cell_ID).(align_info).t_start],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
% line([t_post-file(cell_ID).(align_info).t_end t_post-file(cell_ID).(align_info).t_end],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
line([250 250],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
line([t_post t_post],[0,ymax],'LineStyle','--','Color',[1 0 0],'LineWidth',1.0);
hold on
xlim([-500 1000]);
ylim([ymin ymax]); 
xticks(-500:250:1000);
xlabel('Time(ms)');
ylabel('Est. Spike Freq. (Hz)');

subplot(4,2,5)
% ymin=min(min(file(cell_ID).(align_info).psth_ex(51:1500,2)),min(file(cell_ID).(align_info).psth_align(51:1000,2)))*0.9;   
% ymax=max(max(file(cell_ID).(align_info).psth_ex(51:1500,2)),max(file(cell_ID).(align_info).psth_align(51:1000,2)))*1.1;   
%     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
%     hold on
%     rectangle('Position',[-package(i).align_info.t_start,ymin_psth_plot+0.5,t_interval-package(i).align_info.t_end+package(i).align_info.t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
%     hold on  
% plot(file(cell_ID).(align_info).psth_ex(:,1),smooth(file(cell_ID).(align_info).psth_ex(:,2),25),'k-','LineWidth',2.0)
% hold on
plot(file(cell_ID).(align_info).psth_align(:,1),smooth(file(cell_ID).(align_info).psth_align(:,2),25),'b-','LineWidth',2.0)
hold on

line([-file(cell_ID).(align_info).t_start -file(cell_ID).(align_info).t_start],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
line([t_post-file(cell_ID).(align_info).t_end t_post-file(cell_ID).(align_info).t_end],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
hold on
xlim([-500 500]);
ylim([ymin ymax]); 
xticks(-500:250:500);
xlabel('Time(ms)');
ylabel('Est. Spike Freq. (Hz)');

subplot(4,2,7)
plot(val_file(cell_ID).frq_1(1,:),val_file(cell_ID).frq_1(2,:),'r-')
hold on
plot(val_file(cell_ID).frq_2(1,:),val_file(cell_ID).frq_2(2,:),'k-')
hold on
% errorbar(val_file(cell_ID).frq_1(1,:),val_file(cell_ID).frq_1(2,:),val_file(cell_ID).frq_1(3,:),'Color','r')
% hold on
% errorbar(val_file(cell_ID).frq_2(1,:),val_file(cell_ID).frq_2(2,:),val_file(cell_ID).frq_2(3,:),'Color','k')
% hold on  
% if ~isempty(val_file(cell_ID).sig_validation(1).t)
%    for k=1:size(val_file(cell_ID).sig_validation,2)  
%        t_lc=(val_file(cell_ID).sig_validation(k).t+450)/50+1;
%        y_lc=max([val_file(cell_ID).frq_1(2,t_lc) val_file(cell_ID).frq_2(2,t_lc)])+max([val_file(cell_ID).frq_1(3,t_lc) val_file(cell_ID).frq_2(3,t_lc)])+5;
%        text(val_file(cell_ID).sig_validation(k).t,y_lc,'*','Color','r','FontSize',20,'HorizontalAlignment','center');
%        
%    end    
% end

ymin_1=min(val_file(cell_ID).frq_1(2,:));
ymin_2=min(val_file(cell_ID).frq_2(2,:));
ymin=min([ymin_1 ymin_2])-5;

p_value_list_ID = extractAfter({p_value_file.ID},neuron_name);
cell_ID_p=find(strcmp(p_value_list_ID,num2str(cell_ID)));
for m=1:19
    if p_value_file(cell_ID_p).final_result(2,m)>0
       line([-475+(m-1)*50,-425+(m-1)*50],[ymin ymin],'LineStyle','-','LineWidth',3,'Color','b');
    end
end
xlabel('Time (ms)');
ylabel('Frequency (Hz)');
xlim([-500 t_post]);

subplot (4,2,4)

plot(p_value_file(cell_ID_p).final_curve(1,:),p_value_file(cell_ID_p).final_curve(2,:)*100,'k-')
hold on
xlabel('Time (ms)');
ylabel('Decoding accuracy (%)');
xlim([-500 t_post]);
line([-500 t_post],[50 50],'LineStyle','--');
yticks(0:10:100);

subplot(4,2,2)
rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
hold on
ifr_list=zeros(length(plot_trials),(dur-bin_htmp)/step_htmp+1);
for m=1:length(plot_trials)
    hold on        
    Y=ones(length(trial_info(plot_trials(1,m)).spk),1)*m;
    plot(trial_info(plot_trials(1,m)).spk*1000,Y,'.','Color',[0.3 0.3 0.3],'MarkerSize',1)
    hold on
%         plot(0,m,'g.')
%         hold on
    plot(trial_info(plot_trials(1,m)).CR_onset*1000,m,'b*')
    hold on
%         plot(t_interval,m,'r.')   
    ifr_list(length(plot_trials)-m+1,:)=trial_info(plot_trials(1,m)).ifr_plot(:,2)';
end
hold on
xlim([-500 t_end]);
xticks(-500:250:t_end);
ylim([0 m]);
line([t_post t_post],[0 m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
xlabel('Time(ms)');
ylabel('Trial number');

subplot (4,2,[6 8])
h=heatmap(ifr_list,'GridVisible','off','Colormap',parula);
h.ColorLimits = [ht_range_low ht_range_high];

% line([11 11],[1 size(ifr_list,1)],'Color',[0 0 0],'LineStyle','--','LineWidth',2.0);
% line([21 21],[1 size(ifr_list,1)],'Color',[0 0 0],'LineStyle','--','LineWidth',2.0);
% line([31 31],[1 size(ifr_list,1)],'Color',[0 0 0],'LineStyle','--','LineWidth',2.0);
    
function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end

