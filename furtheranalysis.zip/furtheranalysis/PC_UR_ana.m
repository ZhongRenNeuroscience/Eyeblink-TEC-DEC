PC_UR=struct('cell_ID',[],'UR_blk',[],'UR_mod',[],'UR_sps',[],'UR_cps',[]);

n=1;
for i=1:size(list_PC,2)
    if isempty(list_PC(i).CR_fac_cps)
       continue
    end
    
    UR_blk_trial=zeros(size(list_PC(i).all_info_sps.ttt.CR_trial,2),1);
    for j=1:size(list_PC(i).all_info_sps.ttt.CR_trial,2)
        UR_blk_trial(j,1)=list_PC(i).all_info_sps.ttt.CR_trial(j).blk_info_new.UR_peaktime;               
    end
    PC_UR(n).cell_ID=i;
    PC_UR(n).UR_blk=mean(UR_blk_trial(:,1));
    if list_PC(i).UR_fac_sps+list_PC(i).UR_sup_sps>0
       if list_PC(i).UR_fac_sps>0
          PC_UR(n).UR_mod=1;
          PC_UR(n).UR_sps=list_PC(i).mod_info_sps.URf.t_peak;
       elseif list_PC(i).UR_sup_sps>0
          PC_UR(n).UR_mod=2;
          PC_UR(n).UR_sps=list_PC(i).mod_info_sps.URs.t_peak;           
       end       
    else
       PC_UR(n).UR_mod=0;
       PC_UR(n).UR_sps=[];        
    end
    
    if list_PC(i).UR_fac_cps>0
       PC_UR(n).UR_cps=list_PC(i).mod_info_cps.URf.t_peak;
    else
       PC_UR(n).UR_cps=[]; 
    end
    
    n=n+1;
end