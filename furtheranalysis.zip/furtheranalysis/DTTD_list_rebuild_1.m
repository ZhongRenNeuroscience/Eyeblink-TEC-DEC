file=pack;
t_pre=550;
t_psth=1050;
figure_name='TD_new';
cd 'D:\Zhong\TheGaoLab Dropbox\Ren Zhong\Trace-trained-mice\DCN_mat_output\loco_data\CR_aligned_figures'
TD_2=struct('cell_ID',[],'file_name',[],'cell_num',[],'CR_fac_T',[],'CR_sup_T',[],'UR_fac_T',[],'UR_sup_T',[],'mod_info_T',[],'all_info_T',[],'align_info_T',[],...
    'CR_fac_D',[],'CR_sup_D',[],'UR_fac_D',[],'UR_sup_D',[],'mod_info_D',[],'all_info_D',[],'align_info_D',[]);
ymin_psth_plot=25;
ymax_psth_plot=150;

for i=1:29
%     mod_info_T=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
%     all_information_T=struct('sss_all',[],'ttt',[]);
    
    TD_2(i).cell_ID=file(i).cell_ID;
    TD_2(i).file_name=file(i).file_name;
    TD_2(i).cell_num=file(i).cell_num;
    
    t_interval=500;
    all_info='all_info_T';
    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[]);
    Ctas.cell=1;
    blk_all=NaN(1550,size(file(i).(all_info).ttt.CR_trial,2));
    k=1;
    
    file(i).(all_info).ttt.CR_trial = file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.spk_time}));
    for j=1:size(file(i).(all_info).ttt.CR_trial,2)
        if file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp>0.05 && file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset>0.05
           tss(k).trial=file(i).(all_info).ttt.CR_trial(j).trial_num;
           tss(k).t=file(i).(all_info).ttt.CR_trial(j).spk_time;
           blk_all(:,k)=file(i).(all_info).ttt.CR_trial(j).blk_smth(:,2);
           k=k+1;
        else
           file(i).(all_info).ttt.CR_trial(j).trial_num=[];
        end
        Ctas.tss=tss;     
        
    end
    
    ttt=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
    ttt.CR_trial=file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.trial_num}));
    ttt.nonCR_trial=file(i).(all_info).ttt.nonCR_trial;
    ttt.probe_trial=file(i).(all_info).ttt.probe_trial;
    spk_CR_Gau=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_CR_Gau=Gau_psth_cal(spk_CR_Gau,t_pre,t_psth,0);
    mod_CR=modulation_type(t_pre-50,t_interval,psth_CR_Gau,3,10);
    
    Ctas_ex=struct('cell',[],'tss',[]);
    Ctas_align=struct('cell',[],'tss',[]);
    Ctas_ex.tss=struct('trial',[],'t',[],'onset',[]);
    Ctas_align.tss=struct('trial',[],'t',[]);
    tttCR_ex=ttt.CR_trial;
    Ctas_ex.cell=1; 
    Ctas_align.cell=1;
    n=1;
    for m=1:size(tttCR_ex,2)
        if tttCR_ex(m).blk_info_new.CR_onset<=t_interval/1000*0.9
           Ctas_ex.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_align.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_ex.tss(n).t=tttCR_ex(m).spk_time;
           Ctas_align.tss(n).t=tttCR_ex(m).spk_time-tttCR_ex(m).blk_info_new.CR_onset;
           Ctas_ex.tss(n).onset=tttCR_ex(m).blk_info_new.CR_onset;
           n=n+1;
        else
           tttCR_ex(m).trial_num=[]; 
        end        
    end
%     tttCR_ex=tttCR_ex(~cellfun(@isempty,{tttCR_ex.trial_num}));
%     if size(tttCR_ex,2)<20
%        tttCR_ex=[];
%     end
    
    spk_CR_Gau_ex=spk_Gaussian(Ctas_ex,t_pre,t_psth,10,3);
    psth_CR_Gau_ex=Gau_psth_cal(spk_CR_Gau_ex,t_pre,t_psth,0);
    mod_CR_ex=modulation_type(t_pre-50,t_interval,psth_CR_Gau_ex,3,10);    
    spk_CR_Gau_align=spk_Gaussian(Ctas_align,550,550,10,3);
    psth_CR_Gau_align=Gau_psth_cal(spk_CR_Gau_align,550,550,0);
    
    align_info_T=struct('bsl_frq_ex',[],'SD_ex',[],'psth_ex',[],'psth_align',[],'CR_fac',[],'CR_sup',[],'t_start',[],'t_end',[]);
    align_info_T.bsl_frq_ex=mod_CR_ex.bsl_frq;
    align_info_T.SD_ex=mod_CR_ex.SD;
    align_info_T.psth_ex=psth_CR_Gau_ex.Gau_psth_shft;
    align_info_T.psth_align=psth_CR_Gau_align.Gau_psth_shft;
    if isempty(mod_CR_ex.fac_mginfo(1).t_onset)
       align_info_T.CR_fac=[];
    else
       align_info_T.CR_fac=mod_CR_ex.fac_mginfo;
    end
    if isempty(mod_CR_ex.sup_mginfo(1).t_onset)
       align_info_T.CR_sup=[];
    else
       align_info_T.CR_sup=mod_CR_ex.sup_mginfo;
    end    
    align_info_T.t_start=min([Ctas_ex.tss.onset])*1000;
    align_info_T.t_end=max([Ctas_ex.tss.onset])*1000;
%     align_info.ttt_ex=tttCR_ex;
    TD_2(i).align_info_T=align_info_T;
    
    TD_2(i).CR_fac_T=mod_CR.fac_merge;
    TD_2(i).CR_sup_T=mod_CR.sup_merge;
    if mod_CR.fac_merge>0
       mod_info_T.CRf=mod_CR.fac_mginfo;
    end
    if mod_CR.sup_merge>0
       mod_info_T.CRs=mod_CR.sup_mginfo; 
    end
    if mod_CR.ur_fac==0
       TD_2(i).UR_fac_T=0;
       TD_2(i).mod_info_T.URf=[];
    else
       TD_2(i).UR_fac_T=1;
       mod_info_T.URf.t_peak=mod_CR.ur_fpkt;
       mod_info_T.URf.peak=mod_CR.ur_fac;
    end
    if mod_CR.ur_sup==0
       TD_2(i).UR_sup_T=0;
       mod_info_T.URs=[];
    else
       TD_2(i).UR_sup_T=1;
       mod_info_T.URs.t_peak=mod_CR.ur_spkt;
       mod_info_T.URs.peak=mod_CR.ur_sup;
    end
    TD_2(i).mod_info_T=mod_info_T;
    
    blk_sss_CR=zeros(1550,2);
    blk_sss_CR(:,1)=-550:1:999;
    blk_sss_CR(:,2)=nanmean(blk_all,2);
    TD_2(i).(all_info).sss_all.blk.CR_trial_new=blk_sss_CR;
    psth_sss_CR=struct('avg_frq',[],'test_frq',[],'SD',[],'psth_raw',[],'psth_smooth',[]);
    psth_sss_CR.avg_frq=mod_CR.bsl_frq;
    psth_sss_CR.test_frq=mod_CR.test_frq;
    psth_sss_CR.SD=mod_CR.SD;
    psth_sss_CR.psth_raw=psth_CR_Gau.Gau_psth_org;
    psth_sss_CR.psth_smooth=psth_CR_Gau.Gau_psth_shft;
    TD_2(i).(all_info).sss_all.psth.CR_trial=psth_sss_CR;
    sss_all=struct('blk',[],'behavior',[],'psth',[]);
    sss_all.blk=file(i).(all_info).sss_all.blk;
    sss_all.behavior=file(i).(all_info).sss_all.behavior;
    sss_all.psth=file(i).(all_info).sss_all.psth;
    all_information_T.sss_all=sss_all;
    all_information_T.ttt=ttt;
    
    TD_2(i).all_info_T=all_information_T;

    t_interval=250;
    all_info='all_info_D';
    
    mod_info_D=struct('CRf',[],'CRs',[],'URf',[],'URs',[]);
    all_information_D=struct('sss_all',[],'ttt',[]);
    
    Ctas=struct('cell',[],'tss',[]);
    tss=struct('trial',[],'t',[]);
    Ctas.cell=1;
    blk_all=NaN(1550,size(file(i).(all_info).ttt.CR_trial,2));
    k=1;
    
    file(i).(all_info).ttt.CR_trial = file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.spk_time}));
    for j=1:size(file(i).(all_info).ttt.CR_trial,2)
        if file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp>0.05 && file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset>0.05
           tss(k).trial=file(i).(all_info).ttt.CR_trial(j).trial_num;
           tss(k).t=file(i).(all_info).ttt.CR_trial(j).spk_time;
           blk_all(:,k)=file(i).(all_info).ttt.CR_trial(j).blk_smth(:,2);
           k=k+1;
        else
           file(i).(all_info).ttt.CR_trial(j).trial_num=[];
        end
        Ctas.tss=tss;     
        
    end
    
    ttt=struct('CR_trial',[],'nonCR_trial',[],'probe_trial',[]);
    ttt.CR_trial=file(i).(all_info).ttt.CR_trial(~cellfun(@isempty,{file(i).(all_info).ttt.CR_trial.trial_num}));
    ttt.nonCR_trial=file(i).(all_info).ttt.nonCR_trial;
    ttt.probe_trial=file(i).(all_info).ttt.probe_trial;
    spk_CR_Gau=spk_Gaussian(Ctas,t_pre,t_psth,10,3);
    psth_CR_Gau=Gau_psth_cal(spk_CR_Gau,t_pre,t_psth,0);
    mod_CR=modulation_type(t_pre-50,t_interval,psth_CR_Gau,3,10);
    
    Ctas_ex=struct('cell',[],'tss',[]);
    Ctas_align=struct('cell',[],'tss',[]);
    Ctas_ex.tss=struct('trial',[],'t',[],'onset',[]);
    Ctas_align.tss=struct('trial',[],'t',[]);
    tttCR_ex=ttt.CR_trial;
    Ctas_ex.cell=1; 
    Ctas_align.cell=1;
    n=1;
    for m=1:size(tttCR_ex,2)
        if tttCR_ex(m).blk_info_new.CR_onset<=t_interval/1000*0.9
           Ctas_ex.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_align.tss(n).trial=tttCR_ex(m).trial_num;
           Ctas_ex.tss(n).t=tttCR_ex(m).spk_time;
           Ctas_align.tss(n).t=tttCR_ex(m).spk_time-tttCR_ex(m).blk_info_new.CR_onset;
           Ctas_ex.tss(n).onset=tttCR_ex(m).blk_info_new.CR_onset;
           n=n+1;
        else
           tttCR_ex(m).trial_num=[]; 
        end        
    end
%     tttCR_ex=tttCR_ex(~cellfun(@isempty,{tttCR_ex.trial_num}));
%     if size(tttCR_ex,2)<20
%        tttCR_ex=[];
%     end
    
    spk_CR_Gau_ex=spk_Gaussian(Ctas_ex,t_pre,t_psth,10,3);
    psth_CR_Gau_ex=Gau_psth_cal(spk_CR_Gau_ex,t_pre,t_psth,0);
    mod_CR_ex=modulation_type(t_pre-50,t_interval,psth_CR_Gau_ex,3,10);    
    spk_CR_Gau_align=spk_Gaussian(Ctas_align,550,550,10,3);
    psth_CR_Gau_align=Gau_psth_cal(spk_CR_Gau_align,550,550,0);
    
    align_info_D=struct('bsl_frq_ex',[],'SD_ex',[],'psth_ex',[],'psth_align',[],'CR_fac',[],'CR_sup',[],'t_start',[],'t_end',[]);
    align_info_D.bsl_frq_ex=mod_CR_ex.bsl_frq;
    align_info_D.SD_ex=mod_CR_ex.SD;
    align_info_D.psth_ex=psth_CR_Gau_ex.Gau_psth_shft;
    align_info_D.psth_align=psth_CR_Gau_align.Gau_psth_shft;
    if isempty(mod_CR_ex.fac_mginfo(1).t_onset)
       align_info_D.CR_fac=[];
    else
       align_info_D.CR_fac=mod_CR_ex.fac_mginfo;
    end
    if isempty(mod_CR_ex.sup_mginfo(1).t_onset)
       align_info_D.CR_sup=[];
    else
       align_info_D.CR_sup=mod_CR_ex.sup_mginfo;
    end    
    align_info_D.t_start=min([Ctas_ex.tss.onset])*1000;
    align_info_D.t_end=max([Ctas_ex.tss.onset])*1000;
%     align_info.ttt_ex=tttCR_ex;
    TD_2(i).align_info_D=align_info_D;
    
    TD_2(i).CR_fac_D=mod_CR.fac_merge;
    TD_2(i).CR_sup_D=mod_CR.sup_merge;
    if mod_CR.fac_merge>0
       mod_info_D.CRf=mod_CR.fac_mginfo;
    end
    if mod_CR.sup_merge>0
       mod_info_D.CRs=mod_CR.sup_mginfo; 
    end
    if mod_CR.ur_fac==0
       TD_2(i).UR_fac_D=0;
       TD_2(i).mod_info_D.URf=[];
    else
       TD_2(i).UR_fac_D=1;
       mod_info_D.URf.t_peak=mod_CR.ur_fpkt;
       mod_info_D.URf.peak=mod_CR.ur_fac;
    end
    if mod_CR.ur_sup==0
       TD_2(i).UR_sup_D=0;
       mod_info_D.URs=[];
    else
       TD_2(i).UR_sup_D=1;
       mod_info_D.URs.t_peak=mod_CR.ur_spkt;
       mod_info_D.URs.peak=mod_CR.ur_sup;
    end
    TD_2(i).mod_info_D=mod_info_D;
    
    blk_sss_CR=zeros(1550,2);
    blk_sss_CR(:,1)=-550:1:999;
    blk_sss_CR(:,2)=nanmean(blk_all,2);
    TD_2(i).(all_info).sss_all.blk.CR_trial_new=blk_sss_CR;
    psth_sss_CR=struct('avg_frq',[],'test_frq',[],'SD',[],'psth_raw',[],'psth_smooth',[]);
    psth_sss_CR.avg_frq=mod_CR.bsl_frq;
    psth_sss_CR.test_frq=mod_CR.test_frq;
    psth_sss_CR.SD=mod_CR.SD;
    psth_sss_CR.psth_raw=psth_CR_Gau.Gau_psth_org;
    psth_sss_CR.psth_smooth=psth_CR_Gau.Gau_psth_shft;
    TD_2(i).(all_info).sss_all.psth.CR_trial=psth_sss_CR;
    sss_all=struct('blk',[],'behavior',[],'psth',[]);
    sss_all.blk=file(i).(all_info).sss_all.blk;
    sss_all.behavior=file(i).(all_info).sss_all.behavior;
    sss_all.psth=file(i).(all_info).sss_all.psth;
    all_information_D.sss_all=sss_all;
    all_information_D.ttt=ttt;
    
    TD_2(i).all_info_D=all_information_D;
end

% raster_psth_plot(trace_T,figure_name,t_interval,ymin_psth_plot,ymax_psth_plot);