pack=mod_format;

fsn=struct('ff',[],'ff_info',[],'fn',[],'fn_info',[],'nf',[],'nf_info',[],...
           'ss',[],'ss_info',[],'sn',[],'sn_info',[],'ns',[],'ns_info',[],'multi',[],'multi_info',[],'nn',[]);
ff_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);
fn_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);
nf_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);       
ss_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);       
sn_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);     
ns_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);
multi_info=struct('motor_pp',[],'motor_pn',[],'motor_np',[],'motor_nn',[],'paradigm_diff',[],'timing_diff',[]);

ff=0;
fn=0;
ss=0;
sn=0;
nf=0;
ns=0;
nn=0;
multi=0;

multi_motor_pp=0;
ff_motor_pp=0;
fn_motor_pp=0;
nf_motor_pp=0;
ss_motor_pp=0;
sn_motor_pp=0;
ns_motor_pp=0;
multi_motor_pn=0;
ff_motor_pn=0;
fn_motor_pn=0;
nf_motor_pn=0;
ss_motor_pn=0;
sn_motor_pn=0;
ns_motor_pn=0;
multi_motor_np=0;
ff_motor_np=0;
fn_motor_np=0;
nf_motor_np=0;
ss_motor_np=0;
sn_motor_np=0;
ns_motor_np=0;
multi_motor_nn=0;
ff_motor_nn=0;
fn_motor_nn=0;
nf_motor_nn=0;
ss_motor_nn=0;
sn_motor_nn=0;
ns_motor_nn=0;
multi_paradigm_diff=0;
ff_paradigm_diff=0;
fn_paradigm_diff=0;
nf_paradigm_diff=0;
ss_paradigm_diff=0;
sn_paradigm_diff=0;
ns_paradigm_diff=0;
multi_timing_diff=0;
ff_timing_diff=0;
fn_timing_diff=0;
nf_timing_diff=0;
ss_timing_diff=0;
sn_timing_diff=0;
ns_timing_diff=0;

for i=1:size(pack,2)
%     if pack(i).fac_D+pack(i).fac_T>0 && pack(i).sup_D+pack(i).sup_T>0
%        multi=multi+1; 
%        if pack(i).motor_relevant_fac_D+pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_fac_T+pack(i).motor_relevant_sup_T>0
%           multi_motor_pp=multi_motor_pp+1; 
%        elseif pack(i).motor_relevant_fac_D+pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_fac_T+pack(i).motor_relevant_sup_T==0
%           multi_motor_pn=multi_motor_pn+1; 
%        elseif pack(i).motor_relevant_fac_D+pack(i).motor_relevant_sup_D==0 && pack(i).motor_relevant_fac_T+pack(i).motor_relevant_sup_T>0
%           multi_motor_np=multi_motor_np+1; 
%        else
%           multi_motor_nn=multi_motor_nn+1; 
%        end
%        if pack(i).paradigm_relevant>0
%           multi_paradigm_diff=multi_paradigm_diff+1; 
%        end
%        if pack(i).timing_relevant>0
%           multi_timing_diff=multi_timing_diff+1; 
%        end
    if pack(i).fac_D > 0 &&  pack(i).fac_T > 0
       ff=ff+1;
       if pack(i).motor_relevant_fac_D>0 && pack(i).motor_relevant_fac_T>0
          ff_motor_pp=ff_motor_pp+1; 
       elseif pack(i).motor_relevant_fac_D>0 && pack(i).motor_relevant_fac_T==0
          ff_motor_pn=ff_motor_pn+1; 
       elseif pack(i).motor_relevant_fac_D==0 && pack(i).motor_relevant_fac_T>0
          ff_motor_np=ff_motor_np+1; 
       else
          ff_motor_nn=ff_motor_nn+1; 
       end
       if pack(i).paradigm_relevant>0
          ff_paradigm_diff=ff_paradigm_diff+1; 
       end   
       if pack(i).timing_relevant>0
          ff_timing_diff=ff_timing_diff+1; 
       end          
    elseif pack(i).sup_D > 0 &&  pack(i).sup_T > 0
       ss=ss+1;
       if pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_sup_T>0
          ss_motor_pp=ss_motor_pp+1; 
       elseif pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_sup_T==0
          ss_motor_pn=ss_motor_pn+1; 
       elseif pack(i).motor_relevant_sup_D==0 && pack(i).motor_relevant_sup_T>0
          ss_motor_np=ss_motor_np+1; 
       else
          ss_motor_nn=ss_motor_nn+1; 
       end
       if pack(i).paradigm_relevant>0
          ss_paradigm_diff=ss_paradigm_diff+1; 
       end  
       if pack(i).timing_relevant>0
          ff_timing_diff=ff_timing_diff+1; 
       end          
    elseif pack(i).fac_D == 0 &&  pack(i).fac_T > 0
       nf=nf+1;
       if pack(i).motor_relevant_fac_D>0 && pack(i).motor_relevant_fac_T>0
          nf_motor_pp=nf_motor_pp+1; 
       elseif pack(i).motor_relevant_fac_D>0 && pack(i).motor_relevant_fac_T==0
          nf_motor_pn=nf_motor_pn+1; 
       elseif pack(i).motor_relevant_fac_D==0 && pack(i).motor_relevant_fac_T>0
          nf_motor_np=nf_motor_np+1; 
       else
          nf_motor_nn=nf_motor_nn+1; 
       end
       if pack(i).paradigm_relevant>0
          nf_paradigm_diff=nf_paradigm_diff+1; 
       end  
       if pack(i).timing_relevant>0
          ff_timing_diff=ff_timing_diff+1; 
       end          
    elseif pack(i).fac_D > 0 &&  pack(i).fac_T == 0
       fn=fn+1;
       if pack(i).motor_relevant_fac_D>0 && pack(i).motor_relevant_fac_T>0
          fn_motor_pp=fn_motor_pp+1; 
       elseif pack(i).motor_relevant_fac_D>0 && pack(i).motor_relevant_fac_T==0
          fn_motor_pn=fn_motor_pn+1; 
       elseif pack(i).motor_relevant_fac_D==0 && pack(i).motor_relevant_fac_T>0
          fn_motor_np=fn_motor_np+1; 
       else
          fn_motor_nn=fn_motor_nn+1; 
       end 
       if pack(i).paradigm_relevant>0
          fn_paradigm_diff=fn_paradigm_diff+1; 
       end 
       if pack(i).timing_relevant>0
          ff_timing_diff=ff_timing_diff+1; 
       end          
    elseif pack(i).sup_D == 0 &&  pack(i).sup_T > 0
       ns=ns+1;
       if pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_sup_T>0
          ns_motor_pp=ns_motor_pp+1; 
       elseif pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_sup_T==0
          ns_motor_pn=ns_motor_pn+1; 
       elseif pack(i).motor_relevant_sup_D==0 && pack(i).motor_relevant_sup_T>0
          ns_motor_np=ns_motor_np+1; 
       else
          ns_motor_nn=ns_motor_nn+1; 
       end
       if pack(i).paradigm_relevant>0
          ns_paradigm_diff=ns_paradigm_diff+1; 
       end 
       if pack(i).timing_relevant>0
          ff_timing_diff=ff_timing_diff+1; 
       end          
    elseif pack(i).sup_D > 0 &&  pack(i).sup_T == 0
       sn=sn+1;
       if pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_sup_T>0
          sn_motor_pp=sn_motor_pp+1; 
       elseif pack(i).motor_relevant_sup_D>0 && pack(i).motor_relevant_sup_T==0
          sn_motor_pn=sn_motor_pn+1; 
       elseif pack(i).motor_relevant_sup_D==0 && pack(i).motor_relevant_sup_T>0
          sn_motor_np=sn_motor_np+1; 
       else
          sn_motor_nn=sn_motor_nn+1; 
       end
       if pack(i).paradigm_relevant>0
          sn_paradigm_diff=sn_paradigm_diff+1; 
       end     
       if pack(i).timing_relevant>0
          ff_timing_diff=ff_timing_diff+1; 
       end          
    elseif pack(i).fac_D+pack(i).fac_T+pack(i).sup_D+pack(i).sup_T == 0
        nn=nn+1;
    end   
end

fsn.ff=ff;
ff_info.motor_pp=ff_motor_pp;
ff_info.motor_pn=ff_motor_pn;
ff_info.motor_np=ff_motor_np;
ff_info.motor_nn=ff_motor_nn;
ff_info.paradigm_diff=ff_paradigm_diff;
ff_info.timing_diff=ff_timing_diff;
fsn.ff_info=ff_info;
fsn.fn=fn;
fn_info.motor_pp=fn_motor_pp;
fn_info.motor_pn=fn_motor_pn;
fn_info.motor_np=fn_motor_np;
fn_info.motor_nn=fn_motor_nn;
fn_info.paradigm_diff=fn_paradigm_diff;
fn_info.timing_diff=fn_timing_diff;
fsn.fn_info=fn_info;
fsn.nf=nf;
nf_info.motor_pp=nf_motor_pp;
nf_info.motor_pn=nf_motor_pn;
nf_info.motor_np=nf_motor_np;
nf_info.motor_nn=nf_motor_nn;
nf_info.paradigm_diff=nf_paradigm_diff;
nf_info.timing_diff=nf_timing_diff;
fsn.nf_info=nf_info;
fsn.ss=ss;
ss_info.motor_pp=ss_motor_pp;
ss_info.motor_pn=ss_motor_pn;
ss_info.motor_np=ss_motor_np;
ss_info.motor_nn=ss_motor_nn;
ss_info.paradigm_diff=ss_paradigm_diff;
ss_info.timing_diff=ss_timing_diff;
fsn.ss_info=ss_info;
fsn.sn=sn;
sn_info.motor_pp=sn_motor_pp;
sn_info.motor_pn=sn_motor_pn;
sn_info.motor_np=sn_motor_np;
sn_info.motor_nn=sn_motor_nn;
sn_info.paradigm_diff=sn_paradigm_diff;
sn_info.timing_diff=sn_timing_diff;
fsn.sn_info=sn_info;
fsn.ns=ns;
ns_info.motor_pp=ns_motor_pp;
ns_info.motor_pn=ns_motor_pn;
ns_info.motor_np=ns_motor_np;
ns_info.motor_nn=ns_motor_nn;
ns_info.paradigm_diff=ns_paradigm_diff;
ns_info.timing_diff=ns_timing_diff;
fsn.ns_info=ns_info;
fsn.multi=multi;
multi_info.motor_pp=multi_motor_pp;
multi_info.motor_pn=multi_motor_pn;
multi_info.motor_np=multi_motor_np;
multi_info.motor_nn=multi_motor_nn;
multi_info.paradigm_diff=multi_paradigm_diff;
multi_info.timing_diff=multi_timing_diff;
fsn.multi_info=multi_info;
fsn.nn=nn;