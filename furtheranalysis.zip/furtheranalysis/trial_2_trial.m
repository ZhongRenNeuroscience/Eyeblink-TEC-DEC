%Trial to trial analysis: The correlation test (and the significance of the correlation) to each single neuron of the magnitude of
%modulation and behavior in trial basis. 

pack=list_mod.fac;
all_info='all_info';
t_find=500;
t_find=t_find-20;

ttt_fac=struct('cell_ID',[],'ttt',[],'R',[],'P',[]);
% first loop for each cell
for i=1:size(pack,2)
%     for facilitation neurons
    if pack(i).CR_fac > 0
       ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
%        second loop for each trial
       k=1;
       ttt=zeros(ttt_sz,4);
       for j=1:ttt_sz
           if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > 2
           ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
           ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
           ttt(j,3)=max(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100;    
           else 
           ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
           ttt(j,2)=NaN;
           ttt(j,3)=NaN;              
           end
       end  
       ttt(any(isnan(ttt),2),:) = [];
    end
    
    [R,P]=corrcoef(ttt(:,3),ttt(:,2));
    p=polyfit(ttt(:,3),ttt(:,2),1);
    regression=p(1)*ttt(:,3)+p(2);
    ttt_fac(i).R=R(1,2);
    ttt_fac(i).P=P(1,2);
    ttt(:,4)=regression;
    
    ttt_fac(i).cell_ID=pack(i).cell_ID;
    ttt_fac(i).ttt=ttt;

end

pack=list_mod.sup;
all_info='all_info';
t_find=500;
t_find=t_find-20;

ttt_sup=struct('cell_ID',[],'ttt',[],'R',[],'P',[]);
% first loop for each cell
for i=1:size(pack,2)
%     for facilitation neurons
    if pack(i).CR_sup > 0
       ttt_sz=size(pack(i).(all_info).ttt.CR_trial,2);
       ttt=zeros(ttt_sz,4);
%        second loop for each trial
       k=1;
       for j=1:ttt_sz
           if pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100 > 2
           ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
           ttt(j,2)=pack(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp*100;
           ttt(j,3)=min(pack(i).(all_info).ttt.CR_trial(j).ifr_smooth(541:541+t_find,3))*100-100;   
           else
           ttt(j,1)=pack(i).(all_info).ttt.CR_trial(j).trial_num;
           ttt(j,2)=NaN;
           ttt(j,3)=NaN;    
           end
       end 
       ttt(any(isnan(ttt),2),:) = [];
    end
    
    [R,P]=corrcoef(ttt(:,3),ttt(:,2));
    p=polyfit(ttt(:,3),ttt(:,2),1);
    regression=p(1)*ttt(:,3)+p(2);
    ttt_sup(i).R=R(1,2);
    ttt_sup(i).P=P(1,2);
    ttt(:,4)=regression;
    
    ttt_sup(i).cell_ID=pack(i).cell_ID;
    ttt_sup(i).ttt=ttt;

end
