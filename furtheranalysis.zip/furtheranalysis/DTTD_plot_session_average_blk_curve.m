sss_list_1=DT_blk_sss;
sss_list_2=DT_blk_sss_PFC;
session_1='D';
session_2='T';


blk_session_1=['behavior_curve_session_' session_1];
blk_session_2=['behavior_curve_session_' session_2];
trial_type='prb_trial';

color_1=[1 0.5 0];
color_2=[0.5 0 1];

figure;

for i=1:size(sss_list_1,2)
    smth_curve=smooth_curve(sss_list_1(i).(blk_session_1).(trial_type).blk_curve(:,1),sss_list_1(i).(blk_session_1).(trial_type).blk_curve(:,2)*100,20,5);
    plot(smth_curve(:,1),smth_curve(:,2),'Color',color_1,'LineWidth',1)
    hold on

    smth_curve=smooth_curve(sss_list_1(i).(blk_session_2).(trial_type).blk_curve(:,1),sss_list_1(i).(blk_session_2).(trial_type).blk_curve(:,2)*100,20,5);
    plot(smth_curve(:,1),smth_curve(:,2),'Color',color_2,'LineWidth',1)
    hold on   
end

if ~isempty(sss_list_2)
    for i=1:size(sss_list_2,2)
        smth_curve=smooth_curve(sss_list_2(i).(blk_session_1).(trial_type).blk_curve(:,1),sss_list_2(i).(blk_session_1).(trial_type).blk_curve(:,2)*100,20,5);
        plot(smth_curve(:,1),smth_curve(:,2),'Color',color_1,'LineWidth',1)
        hold on

        smth_curve=smooth_curve(sss_list_2(i).(blk_session_2).(trial_type).blk_curve(:,1),sss_list_2(i).(blk_session_2).(trial_type).blk_curve(:,2)*100,20,5);
        plot(smth_curve(:,1),smth_curve(:,2),'Color',color_2,'LineWidth',1)
        hold on   
    end       
end

xlim([-250 1000]);
ylim([-10 110]);
xticks(-250:250:1000);

function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end