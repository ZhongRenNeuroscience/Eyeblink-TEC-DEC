t2t_list=trial_mod_list_D;
file=file;
mod_type='CR_fac';
corr_info='fac_corr_info';
P_type='P_amp';
R_type='R_amp';
reg_type='reg_amp';
pdx_type='pdx_amp';
xmin=0;
xmax=250;
ymin=0;
ymax=250;

pos_sig_cell_list=struct('cell_ID',[],'R',[],'P',[],'pdx_1',[],'pdx_2',[],'FitLine',[]);
nosig_cell_list=struct('cell_ID',[]);
pos_sig_cell_idx=0;
nosig_cell_idx=0;

figure;
for i=1:size(t2t_list,2)
    if t2t_list(i).(mod_type)==1 && ~isempty(t2t_list(i).(corr_info).(P_type))
       if t2t_list(i).(corr_info).(P_type)<0.05 && t2t_list(i).(corr_info).(R_type)>0
           pos_sig_cell_idx=pos_sig_cell_idx+1;
           pos_sig_cell_list(pos_sig_cell_idx).cell_ID=t2t_list(i).cell_ID;
           pos_sig_cell_list(pos_sig_cell_idx).R=t2t_list(i).(corr_info).(R_type);
           pos_sig_cell_list(pos_sig_cell_idx).P=t2t_list(i).(corr_info).(P_type);
           pos_sig_cell_list(pos_sig_cell_idx).pdx_1=t2t_list(i).(corr_info).(pdx_type)(1);
           pos_sig_cell_list(pos_sig_cell_idx).pdx_2=t2t_list(i).(corr_info).(pdx_type)(2);
           pos_sig_cell_list(pos_sig_cell_idx).FitLine=t2t_list(i).(corr_info).(reg_type);
           plot(t2t_list(i).(corr_info).(reg_type)(:,1),t2t_list(i).(corr_info).(reg_type)(:,3),'b-')
           hold on
       end
    end
end
xlim([xmin xmax]);
ylim([ymin ymax]);



figure;
for i=1:size(t2t_list,2)
    if t2t_list(i).(mod_type)==1 && ~isempty(t2t_list(i).(corr_info).(P_type))
       if t2t_list(i).(corr_info).(P_type)>=0.05
           nosig_cell_idx=nosig_cell_idx+1;
           nosig_cell_list(nosig_cell_idx).cell_ID=t2t_list(i).cell_ID;
           plot(t2t_list(i).(corr_info).(reg_type)(:,1),t2t_list(i).(corr_info).(reg_type)(:,3),'b-')
           hold on
       elseif t2t_list(i).(corr_info).(P_type)<0.05 && t2t_list(i).(corr_info).(R_type)<=0
           nosig_cell_idx=nosig_cell_idx+1;
           nosig_cell_list(nosig_cell_idx).cell_ID=t2t_list(i).cell_ID;
           plot(t2t_list(i).(corr_info).(reg_type)(:,1),t2t_list(i).(corr_info).(reg_type)(:,3),'b-')
           hold on           
       end
    end
end
xlim([xmin xmax]);
ylim([ymin ymax]);

neg_sig_cell_list=struct('cell_ID',[]);
neg_sig_cell_idx=0;
figure;
for i=1:size(t2t_list,2)
    if t2t_list(i).(mod_type)==1 && ~isempty(t2t_list(i).(corr_info).(P_type))
       if t2t_list(i).(corr_info).(P_type)<0.05 && t2t_list(i).(corr_info).(R_type)<0
           neg_sig_cell_idx=neg_sig_cell_idx+1;
           neg_sig_cell_list(neg_sig_cell_idx).cell_ID=t2t_list(i).cell_ID;
           plot(t2t_list(i).(corr_info).(reg_type)(:,1),t2t_list(i).(corr_info).(reg_type)(:,3),'b-')
           hold on
       end
    end
end
xlim([xmin xmax]);
ylim([ymin ymax]);