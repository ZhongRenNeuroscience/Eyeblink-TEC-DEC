file=DT_list_align;
paradigm='DT';
session_pre=[];
cd='D:\Zhong\Delay-trained-mice\D_T_data_output\new_data\RasterFigure\onset_amp';


for i=1:size(file,2)
    if strcmp(session_pre,file(i).file_name)
       continue
    else
       figure;
       session_pre=file(i).file_name;
       onset_amp_D=zeros(size(file(i).all_info_D.ttt.CR_trial,2),3);
       m=0;
       for j=1:size(file(i).all_info_D.ttt.CR_trial,2)
           if file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000<=240
              m=m+1;
              onset_amp_D(m,1)=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
              onset_amp_D(m,2)=file(i).all_info_D.ttt.CR_trial(j).blk_info_new.CR_amp*100;

               if onset_amp_D(m,2)>100
                  onset_amp_D(m,2)=100; 
               end
           end
       end
       [R_D,P_D]=corrcoef(onset_amp_D(1:m,1),onset_amp_D(1:m,2),'rows','complete');
       p_D=polyfit(onset_amp_D(1:m,1),onset_amp_D(1:m,2),1);
       regression=p_D(1)*onset_amp_D(1:m,1)+p_D(2);
       onset_amp_D(1:m,3)=regression;
       
       if strcmp(paradigm,'DT')
          subplot(1,2,1)
       elseif strcmp(paradigm,'TD')
          subplot(1,2,2)
       end
       hold on       
       plot(onset_amp_D(1:m,1),onset_amp_D(1:m,2),'k.')
       hold on
       plot(onset_amp_D(1:m,1),onset_amp_D(1:m,3),'k-')
       hold on
       text(150,90,['r=' num2str(R_D(2,1))],'Color','black','FontSize',12);
       text(150,80,['p=' num2str(P_D(2))],'Color','black','FontSize',12);
       xlim([0 250]);
       ylim([0 100]);
       xticks(0:50:250);
       yticks(0:10:100);
       xlabel('CR onset(ms)');
       ylabel('CR amplitude(%)');
       title('Delay');
  
       onset_amp_T=zeros(size(file(i).all_info_T.ttt.CR_trial,2),3);
       m=0;
       for j=1:size(file(i).all_info_T.ttt.CR_trial,2)
           if file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_peaktime*1000<=490
              m=m+1;
              onset_amp_T(m,1)=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_onset*1000;
              onset_amp_T(m,2)=file(i).all_info_T.ttt.CR_trial(j).blk_info_new.CR_amp*100;
               if onset_amp_T(j,2)>100
                  onset_amp_T(j,2)=100; 
               end
           end      
       [R_T,P_T]=corrcoef(onset_amp_T(1:m,1),onset_amp_T(1:m,2),'rows','complete');
       p_T=polyfit(onset_amp_T(1:m,1),onset_amp_T(1:m,2),1);
       regression=p_T(1)*onset_amp_T(1:m,1)+p_T(2);
       onset_amp_T(1:m,3)=regression;           
       end  
      
       
       if strcmp(paradigm,'DT')
          subplot(1,2,2)
       elseif strcmp(paradigm,'TD')
          subplot(1,2,1)
       end
       hold on       
       plot(onset_amp_T(1:m,1),onset_amp_T(1:m,2),'k.')
       hold on
       plot(onset_amp_T(1:m,1),onset_amp_T(1:m,3),'k-')
       hold on
       text(350,90,['r=' num2str(R_T(2,1))],'Color','black','FontSize',12);
       text(350,80,['p=' num2str(P_T(2))],'Color','black','FontSize',12);
       xlim([0 500]);
       ylim([0 100]);
       xticks(0:50:500);
       yticks(0:10:100);
       xlabel('CR onset(ms)');
       ylabel('CR amplitude(%)');       
       title('Trace');
       
       set(gcf,'position',[100 100 1200 750]);
       saveas(gcf,[paradigm session_pre '.jpg']);
    end
    
    
    
    
end