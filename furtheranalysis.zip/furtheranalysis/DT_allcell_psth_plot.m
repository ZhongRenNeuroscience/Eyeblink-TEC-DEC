% plot all facilitation neurons
figure;

for k=1:42
subplot(7,6,k)
if DT_list(k).CR_fac_D > 0
    h=area(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[1 0 0];
    h.FaceAlpha=0.3;
    hold on
elseif DT_list(k).CR_sup_D > 0
    h=area(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 1];
    h.FaceAlpha=0.3;
    hold on
elseif DT_list(k).CR_fac_D == 0 && DT_list(k).CR_sup_D == 0
    h=area(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 0];
    h.FaceAlpha=0.3;
    hold on   
end

if DT_list(k).CR_fac_T > 0
    plot(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'r-');
    hold on
elseif DT_list(k).CR_sup_T > 0
    plot(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'b-');
    hold on
elseif DT_list(k).CR_fac_T == 0 && DT_list(k).CR_sup_T == 0
    plot(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'k-');
    hold on   
end

plot(DT_list(k).all_info_D.sss_all.blk.CR_trial(:,1),DT_list(k).all_info_D.sss_all.blk.CR_trial(:,2)*100,'k--')
plot(DT_list(k).all_info_T.sss_all.blk.CR_trial(:,1),DT_list(k).all_info_T.sss_all.blk.CR_trial(:,2)*100,'k-.')

ymax1=max(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax2=max(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax=max(ymax1,ymax2)*1.05;
ymin1=min(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin2=min(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin=min(ymin1,ymin2)*0.95;
xlim([-250 750]);
ylim([0 ymax]);
xticks([-250 0 250 500 750]);
line([0 0],[0, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
line([250 250],[0, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
title(['Cell',num2str(DT_list(k).cell_ID),' ','D:',num2str(DT_list(k).CR_fac_D),'-',num2str(DT_list(k).CR_sup_D),'-',num2str(DT_list(k).UR_fac_D),'-',...
      num2str(DT_list(k).UR_sup_D),' ','T:',num2str(DT_list(k).CR_fac_T),'-',num2str(DT_list(k).CR_sup_T),'-',num2str(DT_list(k).UR_fac_T),'-',...
      num2str(DT_list(k).UR_sup_T),' Day',num2str(DT_list(k).Day)]);
end


figure;
for k=43:83
subplot(7,6,k-42)
if DT_list(k).CR_fac_D > 0
    h=area(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[1 0 0];
    h.FaceAlpha=0.3;
    hold on
elseif DT_list(k).CR_sup_D > 0
    h=area(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 1];
    h.FaceAlpha=0.3;
    hold on
elseif DT_list(k).CR_fac_D == 0 && DT_list(k).CR_sup_D == 0
    h=area(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 0];
    h.FaceAlpha=0.3;
    hold on   
end

if DT_list(k).CR_fac_T > 0
    plot(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'r-');
    hold on
elseif DT_list(k).CR_sup_T > 0
    plot(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'b-');
    hold on
elseif DT_list(k).CR_fac_T == 0 && DT_list(k).CR_sup_T == 0
    plot(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'k-');
    hold on   
end

plot(DT_list(k).all_info_D.sss_all.blk.CR_trial(:,1),DT_list(k).all_info_D.sss_all.blk.CR_trial(:,2)*100,'k--')
plot(DT_list(k).all_info_T.sss_all.blk.CR_trial(:,1),DT_list(k).all_info_T.sss_all.blk.CR_trial(:,2)*100,'k-.')

ymax1=max(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax2=max(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax=max(ymax1,ymax2)*1.05;
ymin1=min(DT_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin2=min(DT_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin=min(ymin1,ymin2)*0.95;
xlim([-250 750]);
ylim([0 ymax]);
xticks([-250 0 250 500 750]);
line([0 0],[0, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
line([250 250],[0, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
title(['Cell',num2str(DT_list(k).cell_ID),' ','D:',num2str(DT_list(k).CR_fac_D),'-',num2str(DT_list(k).CR_sup_D),'-',num2str(DT_list(k).UR_fac_D),'-',...
      num2str(DT_list(k).UR_sup_D),' ','T:',num2str(DT_list(k).CR_fac_T),'-',num2str(DT_list(k).CR_sup_T),'-',num2str(DT_list(k).UR_fac_T),'-',...
      num2str(DT_list(k).UR_sup_T),' Day',num2str(DT_list(k).Day)]);
end


