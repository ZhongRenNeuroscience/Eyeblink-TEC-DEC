file=trace_list_sim;
all_info_1='all_info';
all_info_2='all_info';
trial_type='CR_trial';
cell_ID=424;
mod_num=1;
rest_num=0;

color_21=[1 0.5 0];
color_22=[1 0.8 0.6];
color_11=[0.5 0 1];
color_12=[0.8 0.6 1];

splt_num=4;

%% 
figure;
i=cell_ID;
splt_idx=quantile(1:size(file(i).(all_info_2).ttt.(trial_type),2),splt_num-1);
raw_curve_1=nan(size(file(i).(all_info_1).ttt.(trial_type)(1).blk_smth,1),size(file(i).(all_info_1).ttt.(trial_type),2));
raw_curve_21=nan(size(file(i).(all_info_2).ttt.(trial_type)(1).blk_smth,1),floor(splt_idx(1)));
raw_curve_22=nan(size(file(i).(all_info_2).ttt.(trial_type)(1).blk_smth,1),size(file(i).(all_info_2).ttt.(trial_type),2)-ceil(splt_idx(end))+1);

CR_amp_1=nan(size(file(i).(all_info_1).ttt.(trial_type),2),1);
CR_amp_21=nan(floor(splt_idx(1)),1);
CR_amp_22=nan(size(file(i).(all_info_2).ttt.(trial_type),2)-ceil(splt_idx(end))+1,1);

for j=1:size(file(i).(all_info_1).ttt.(trial_type),2)
    if file(i).(all_info_1).ttt.(trial_type)(j).blk_info_new.CR_onset>0
       raw_curve_1(:,j)=file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,2);
       raw_curve_1(1:800,j)=raw_curve_1(1:800,j)*0.4;
       CR_amp_1(j,1)=file(i).(all_info_1).ttt.(trial_type)(j).blk_info_new.CR_amp*100;
       curve_plot=smooth_curve(file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,1),raw_curve_1(:,j),20,5);
       plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',[0.5 0.5 0.5],'LineWidth',1)
       hold on
    end   
end
raw_curve_1=raw_curve_1(:,all(~isnan(raw_curve_1))); 
avg_curve_1=zeros(size(file(i).(all_info_1).ttt.(trial_type)(1).blk_smth,1),5);
avg_curve_1(:,1)=file(i).(all_info_1).ttt.(trial_type)(1).blk_smth(:,1);
avg_curve_1(:,2)=mean(raw_curve_1,2);
avg_curve_1(:,3)=std(raw_curve_1,0,2);
avg_curve_1(:,4)=avg_curve_1(:,2)+avg_curve_1(:,3);%/sqrt(size(raw_curve_1,2));
avg_curve_1(:,5)=avg_curve_1(:,2)-avg_curve_1(:,3);%/sqrt(size(raw_curve_1,2));
curve_plot=smooth_curve(avg_curve_1(:,1),avg_curve_1(:,2),20,5);
plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_11,'LineWidth',2)
hold on
curve_plot=smooth_curve(avg_curve_1(:,1),avg_curve_1(:,4),20,5);
plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_11,'LineWidth',1)
hold on
curve_plot=smooth_curve(avg_curve_1(:,1),avg_curve_1(:,5),20,5);
plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_11,'LineWidth',1)
hold on


% for j=1:floor(splt_idx(1))
%     if file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_onset>0
%        raw_curve_21(:,j)=file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,2);
%        CR_amp_21(j,1)=file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_amp*100;
%     end   
% end
% raw_curve_21=raw_curve_21(:,all(~isnan(raw_curve_21))); 
% avg_curve_21=zeros(size(file(i).(all_info_2).ttt.(trial_type)(1).blk_smth,1),5);
% avg_curve_21(:,1)=file(i).(all_info_2).ttt.(trial_type)(1).blk_smth(:,1);
% avg_curve_21(:,2)=mean(raw_curve_21,2);
% avg_curve_21(:,3)=std(raw_curve_21,0,2);
% avg_curve_21(:,4)=avg_curve_21(:,2)+avg_curve_21(:,3);%/sqrt(size(raw_curve_21,2));
% avg_curve_21(:,5)=avg_curve_21(:,2)-avg_curve_21(:,3);%/sqrt(size(raw_curve_21,2));
% curve_plot=smooth_curve(avg_curve_21(:,1),avg_curve_21(:,2),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_21,'LineWidth',2)
% hold on
% curve_plot=smooth_curve(avg_curve_21(:,1),avg_curve_21(:,4),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_21,'LineWidth',1)
% hold on
% curve_plot=smooth_curve(avg_curve_21(:,1),avg_curve_21(:,5),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_21,'LineWidth',1)
% hold on
% 
% for j=ceil(splt_idx(end)):size(file(i).(all_info_2).ttt.(trial_type),2)
%     if file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_onset>0
%        raw_curve_22(:,j-ceil(splt_idx(end))+1)=file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,2);
%        CR_amp_22(j-ceil(splt_idx(end))+1,1)=file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_amp*100;
%     end   
% end
% raw_curve_22=raw_curve_22(:,all(~isnan(raw_curve_22))); 
% avg_curve_22=zeros(size(file(i).(all_info_2).ttt.(trial_type)(1).blk_smth,1),5);
% avg_curve_22(:,1)=file(i).(all_info_2).ttt.(trial_type)(1).blk_smth(:,1);
% avg_curve_22(:,2)=mean(raw_curve_22,2);
% avg_curve_22(:,3)=std(raw_curve_22,0,2);
% avg_curve_22(:,4)=avg_curve_22(:,2)+avg_curve_22(:,3);%/sqrt(size(raw_curve_22,2));
% avg_curve_22(:,5)=avg_curve_22(:,2)-avg_curve_22(:,3);%/sqrt(size(raw_curve_22,2));
% curve_plot=smooth_curve(avg_curve_22(:,1),avg_curve_22(:,2),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_22,'LineWidth',2)
% hold on
% curve_plot=smooth_curve(avg_curve_22(:,1),avg_curve_22(:,4),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_22,'LineWidth',1)
% hold on
% curve_plot=smooth_curve(avg_curve_22(:,1),avg_curve_22(:,5),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_22,'LineWidth',1)
% hold on
xlim([-250 1000]);
ylim([-10 110]);
xticks(-250:250:1000);
yticks(0:50:100);
xlabel('Time (ms)');
ylabel('Eyelid (%)');

%%
% i=cell_ID;
% % wtf_form=zeros(floor(size(raw_curve_1,2)/mod_num)+floor(size(raw_curve_2,2)/mod_num),307,2);
% wtf_form=zeros(22,307,2);
% idx=0;
% for j=1:size(file(i).(all_info_1).ttt.(trial_type),2)
%     if file(i).(all_info_1).ttt.(trial_type)(j).blk_info_new.CR_onset>0 %&& mod(j,mod_num)==rest_num
%        idx=idx+1;
%        wtf_form(idx,:,:)=smooth_curve(file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,1),file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,2)*100,20,5);
%     end   
% end
% 
% for j=1:size(file(i).(all_info_2).ttt.(trial_type),2)
%     if file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_onset>0 %&& mod(j,mod_num)==rest_num
%        idx=idx+1; 
%        wtf_form(idx,:,:)=smooth_curve(file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,1),file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,2)*100,20,5);
%     end   
% end
% 
% 
% figure;
% y=1:1:size(wtf_form,1);
% x=-550:5:980;
% [X,Y]=meshgrid(x,y);
% p1=waterfall(X,Y,wtf_form(:,:,2));
% p1.EdgeColor='b';
% hold on
% p2=waterfall(X,Y,wtf_form(:,:,2));
% 
% xlim([-250 1000]);
% zlim([-10 110]);
% zticks(0:50:100);
% xticks(-250:250:1000);
% rotate3d on

%%
% i=cell_ID;
% figure;
% raw_curve_1=nan(size(file(i).(all_info_1).ttt.(trial_type)(1).blk_smth,1),size(file(i).(all_info_1).ttt.(trial_type),2));
% raw_curve_2=nan(size(file(i).(all_info_2).ttt.(trial_type)(1).blk_smth,1),size(file(i).(all_info_2).ttt.(trial_type),2));
% onset_1=nan(size(file(i).(all_info_1).ttt.(trial_type),2),1);
% onset_2=nan(size(file(i).(all_info_2).ttt.(trial_type),2),1);
% amp_1=nan(size(file(i).(all_info_1).ttt.(trial_type),2),1);
% amp_2=nan(size(file(i).(all_info_2).ttt.(trial_type),2),1);
% 
% for j=1:size(file(i).(all_info_1).ttt.(trial_type),2)
%     if file(i).(all_info_1).ttt.(trial_type)(j).blk_info_new.CR_onset>0
%        curve_plot=smooth_curve(file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,1),file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,2),20,5);
%        plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_12,'LineWidth',0.5)
%        hold on 
%        raw_curve_1(:,j)=file(i).(all_info_1).ttt.(trial_type)(j).blk_smth(:,2);
%        onset_1(j,1)=file(i).(all_info_1).ttt.(trial_type)(j).blk_info_new.CR_onset*1000;
%        amp_1(j,1)=file(i).(all_info_1).ttt.(trial_type)(j).blk_info_new.CR_amp*100;
%     end   
% end
% raw_curve_1=raw_curve_1(:,all(~isnan(raw_curve_1))); 
% avg_curve_1=zeros(size(file(i).(all_info_1).ttt.(trial_type)(1).blk_smth,1),2);
% avg_curve_1(:,1)=file(i).(all_info_1).ttt.(trial_type)(1).blk_smth(:,1);
% avg_curve_1(:,2)=mean(raw_curve_1,2);
% curve_plot=smooth_curve(avg_curve_1(:,1),avg_curve_1(:,2),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_11,'LineWidth',2)
% hold on
% text(nanmean(onset_1(:,1)),100,'*','HorizontalAlignment','center');
% % xlim([-250 1000]);
% % ylim([-10 110]);
% % xticks(-250:250:1000);
% % yticks(0:50:100);
% % xlabel('Time (ms)');
% % ylabel('Eyelid (%)');
% % 
% % figure;
% for j=1:size(file(i).(all_info_2).ttt.(trial_type),2)
%     if file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_onset>0
%        curve_plot=smooth_curve(file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,1),file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,2),20,5);
%        plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_22,'LineWidth',0.5)
%        hold on 
%        raw_curve_2(:,j)=file(i).(all_info_2).ttt.(trial_type)(j).blk_smth(:,2);
%        onset_2(j,1)=file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_onset*1000;
%        amp_2(j,1)=file(i).(all_info_2).ttt.(trial_type)(j).blk_info_new.CR_amp*100;
%     end   
% end
% raw_curve_2=raw_curve_2(:,all(~isnan(raw_curve_2))); 
% avg_curve_2=zeros(size(file(i).(all_info_2).ttt.(trial_type)(1).blk_smth,1),2);
% avg_curve_2(:,1)=file(i).(all_info_2).ttt.(trial_type)(1).blk_smth(:,1);
% avg_curve_2(:,2)=mean(raw_curve_2,2);
% curve_plot=smooth_curve(avg_curve_2(:,1),avg_curve_2(:,2),20,5);
% plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_21,'LineWidth',2)
% hold on
% text(nanmean(onset_2(:,1)),100,'*','HorizontalAlignment','center');
% xlim([-250 1000]);
% ylim([-10 110]);
% xticks(-250:250:1000);
% yticks(0:50:100);
% xlabel('Time (ms)');
% ylabel('Eyelid (%)');

%%
function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end