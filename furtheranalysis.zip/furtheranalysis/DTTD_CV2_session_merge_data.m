% file_CV2=CV2_cal_2;
% file_hist=CV2_hist_list;
% 
% session_output=struct('cell_ID',[],'pmean_D',[],'pmean_T',[],'CV2_D',[],'CV2_T',[]);
% for i=1:151
%     pmean_D=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[]);
%     pmean_T=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[],'p_bsl',[],'p_test',[]);
%     CV2_D=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[]);
%     CV2_T=struct('bsl_mean',[],'bsl_SE',[],'test_mean',[],'test_SE',[],'p_value',[],'p_bsl',[],'p_test',[]);
%     
%     pmean_D.bsl_mean=mean([file_hist(i).hist_info_D.CV2_mean_bsl.mean]);
%     pmean_D.test_mean=mean([file_hist(i).hist_info_D.CV2_mean_test.mean]);
%     pmean_T.bsl_mean=mean([file_hist(i).hist_info_T.CV2_mean_bsl.mean]);
%     pmean_T.test_mean=mean([file_hist(i).hist_info_T.CV2_mean_test.mean]);
%     pmean_D.bsl_SE=std([file_hist(i).hist_info_D.CV2_mean_bsl.mean])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_bsl.mean]));
%     pmean_D.test_SE=std([file_hist(i).hist_info_D.CV2_mean_test.mean])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_test.mean]));
%     pmean_T.bsl_SE=std([file_hist(i).hist_info_T.CV2_mean_bsl.mean])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_bsl.mean]));
%     pmean_T.test_SE=std([file_hist(i).hist_info_T.CV2_mean_test.mean])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_test.mean])); 
%     p_1= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.mean],[file_hist(i).hist_info_D.CV2_mean_test.mean]);
%     p_2= ranksum([file_hist(i).hist_info_T.CV2_mean_bsl.mean],[file_hist(i).hist_info_T.CV2_mean_test.mean]);
%     p_3= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.mean],[file_hist(i).hist_info_T.CV2_mean_bsl.mean]);
%     p_4= ranksum([file_hist(i).hist_info_D.CV2_mean_test.mean],[file_hist(i).hist_info_T.CV2_mean_test.mean]);
%     pmean_D.p_value=p_1;
%     pmean_T.p_value=p_2;  
%     pmean_T.p_bsl=p_3;
%     pmean_T.p_test=p_4;
%     
%     CV2_D.bsl_mean=mean([file_hist(i).hist_info_D.CV2_mean_bsl.CV2]);
%     CV2_D.test_mean=mean([file_hist(i).hist_info_D.CV2_mean_test.CV2]);
%     CV2_T.bsl_mean=mean([file_hist(i).hist_info_T.CV2_mean_bsl.CV2]);
%     CV2_T.test_mean=mean([file_hist(i).hist_info_T.CV2_mean_test.CV2]);
%     CV2_D.bsl_SE=std([file_hist(i).hist_info_D.CV2_mean_bsl.CV2])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_bsl.CV2]));
%     CV2_D.test_SE=std([file_hist(i).hist_info_D.CV2_mean_test.CV2])/sqrt(length([file_hist(i).hist_info_D.CV2_mean_test.CV2]));
%     CV2_T.bsl_SE=std([file_hist(i).hist_info_T.CV2_mean_bsl.CV2])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_bsl.CV2]));
%     CV2_T.test_SE=std([file_hist(i).hist_info_T.CV2_mean_test.CV2])/sqrt(length([file_hist(i).hist_info_T.CV2_mean_test.CV2])); 
%     p_1= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.CV2],[file_hist(i).hist_info_D.CV2_mean_test.CV2]);
%     p_2= ranksum([file_hist(i).hist_info_T.CV2_mean_bsl.CV2],[file_hist(i).hist_info_T.CV2_mean_test.CV2]);
%     p_3= ranksum([file_hist(i).hist_info_D.CV2_mean_bsl.CV2],[file_hist(i).hist_info_T.CV2_mean_bsl.CV2]);
%     p_4= ranksum([file_hist(i).hist_info_D.CV2_mean_test.CV2],[file_hist(i).hist_info_T.CV2_mean_test.CV2]);
%     CV2_D.p_value=p_1;
%     CV2_T.p_value=p_2;    
%     CV2_T.p_bsl=p_3;
%     CV2_T.p_test=p_4;    
%     
%     session_output(i).cell_ID=file_hist(i).cell_ID;
%     session_output(i).pmean_D=pmean_D;
%     session_output(i).pmean_T=pmean_T;
%     session_output(i).CV2_D=CV2_D;
%     session_output(i).CV2_T=CV2_T;    
%     
% end

group_info_D=struct('cell_ID',[],'d_pmean',[],'d_CV2',[],'p_pmean',[],'p_CV2',[],'type',[]);
fac_irg=0;
fac_reg=0;
sup_irg=0;
sup_reg=0;
non_irg=0;
non_reg=0;
figure('units','normalized','outerposition',[0 0.1 1 0.8]);  
subplot(1,2,1)
for i=1:size(session_output,2)
    group_info_D(i).cell_ID=session_output(i).cell_ID;
    group_info_D(i).p_pmean=session_output(i).pmean_D.p_value;
    group_info_D(i).p_CV2=session_output(i).CV2_D.p_value;
    group_info_D(i).d_pmean=(session_output(i).pmean_D.test_mean/session_output(i).pmean_D.bsl_mean-1)*100;
    group_info_D(i).d_CV2=(session_output(i).CV2_D.test_mean/session_output(i).CV2_D.bsl_mean-1)*100;
    if group_info_D(i).p_pmean<0.05
       if group_info_D(i).p_CV2<0.05
          if group_info_D(i).d_pmean<=0
             fac_irg=fac_irg+1;
             plot(group_info_D(i).d_pmean,group_info_D(i).d_CV2,'r.','MarkerSize',15)
             hold on
             if group_info_D(i).d_CV2>=0
                group_info_D(i).type=1;
             elseif group_info_D(i).d_CV2<0
                group_info_D(i).type=2; 
             end                 
          elseif group_info_D(i).d_pmean>0
             sup_irg=sup_irg+1;
             plot(group_info_D(i).d_pmean,group_info_D(i).d_CV2,'.','Color',[0 0.4 1],'MarkerSize',15)
             hold on
             if group_info_D(i).d_CV2>=0
                group_info_D(i).type=3;
             elseif group_info_D(i).d_CV2<0
                group_info_D(i).type=4; 
             end              
          end
       elseif group_info_D(i).p_CV2>=0.05
          if group_info_D(i).d_pmean<=0
             fac_reg=fac_reg+1;
             plot(group_info_D(i).d_pmean,group_info_D(i).d_CV2,'.','Color',[1 0.7 0.7],'MarkerSize',15)
             hold on
             if group_info_D(i).d_CV2>=0
                group_info_D(i).type=1;
             elseif group_info_D(i).d_CV2<0
                group_info_D(i).type=2; 
             end               
          elseif group_info_D(i).d_pmean>0
             sup_reg=sup_reg+1; 
             plot(group_info_D(i).d_pmean,group_info_D(i).d_CV2,'.','Color',[0.7 0.8 1],'MarkerSize',15)
             hold on
             if group_info_D(i).d_CV2>=0
                group_info_D(i).type=3;
             elseif group_info_D(i).d_CV2<0
                group_info_D(i).type=4; 
             end               
          end                  
       end
    elseif group_info_D(i).p_pmean>=0.05
       if group_info_D(i).p_CV2<0.05
          non_irg=non_irg+1; 
          plot(group_info_D(i).d_pmean,group_info_D(i).d_CV2,'k.','MarkerSize',15)
          hold on
       elseif group_info_D(i).p_CV2>=0.05
          non_reg=non_reg+1; 
          plot(group_info_D(i).d_pmean,group_info_D(i).d_CV2,'.','Color',[0.7 0.7 0.7],'MarkerSize',15)
          hold on
       end
       group_info_D(i).type=5;
    end    
end
A=isoutlier([group_info_D.d_CV2],'grubbs');
B=isoutlier([group_info_D.d_pmean],'grubbs');
for i=1:size(session_output,2)
    if A(1,i) || B(1,i)
       group_info_D(i).d_pmean=[];        
    end   
end
group_info_D=group_info_D(~cellfun(@isempty,{group_info_D.d_pmean}));


[~,index] = sortrows([group_info_D.type].');
group_info_D = group_info_D(index);
clear index;
range=ones(1,5);
for i=1:3
    range(1,i+1)=find([group_info_D.type]>i,1,'first');
    corr=zeros(range(1,i+1)-range(1,i),3);
    for j=range(1,i):range(1,i+1)-1
        corr(j-range(1,i)+1,1)=group_info_D(j).d_pmean;
        corr(j-range(1,i)+1,2)=group_info_D(j).d_CV2;
    end
    [R,P]=corrcoef(corr(:,1),corr(:,2));
    p=polyfit(corr(:,1),corr(:,2),1);
    regression=p(1)*corr(:,1)+p(2);
    corr(:,3)=regression;
    plot(corr(:,1),corr(:,3),'k-')
    hold on
    if i==1
       text(-70,40,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12);
    elseif i==2
       text(-70,-40,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12);
    elseif i==3
       text(50,5,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12);
    end
end

range(1,5)=find([group_info_D.type]>4,1,'first');
corr=zeros(range(1,3)-range(1,1),3);
for j=range(1,1):range(1,3)-1
    corr(j-range(1,1)+1,1)=group_info_D(j).d_pmean;
    corr(j-range(1,1)+1,2)=group_info_D(j).d_CV2;
end
[R,P]=corrcoef(corr(:,1),corr(:,2));
p=polyfit(corr(:,1),corr(:,2),1);
regression=p(1)*corr(:,1)+p(2);
corr(:,3)=regression;
plot(corr(:,1),corr(:,3),'r-','MarkerSize',3)
hold on
text(-70,5,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[1 0 0]);

corr=zeros(range(1,5)-range(1,3),3);
for j=range(1,3):range(1,5)-1
    corr(j-range(1,3)+1,1)=group_info_D(j).d_pmean;
    corr(j-range(1,3)+1,2)=group_info_D(j).d_CV2;
end
[R,P]=corrcoef(corr(:,1),corr(:,2));
p=polyfit(corr(:,1),corr(:,2),1);
regression=p(1)*corr(:,1)+p(2);
corr(:,3)=regression;
plot(corr(:,1),corr(:,3),'b-','MarkerSize',3)
hold on
text(50,-5,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[0 0 1]);
    
xlim([-80 80]);
ylim([-50 50]);
line([-80,80],[0 0],'Color',[0.5 0.5 0.5],'LineStyle','-');
line([0 0],[-50 50],'Color',[0.5 0.5 0.5],'LineStyle','-');
xlabel('Relative mean of ISI pair change (%)');
ylabel('Relative CV2 change (%)');
title('Delay session - Baseline vs. CR period');

group_info_T=struct('d_pmean',[],'d_CV2',[],'p_pmean',[],'p_CV2',[],'type',[]);
fac_irg=0;
fac_reg=0;
sup_irg=0;
sup_reg=0;
non_irg=0;
non_reg=0;
subplot(1,2,2)
for i=1:size(session_output,2)
    group_info_T(i).p_pmean=session_output(i).pmean_T.p_value;
    group_info_T(i).p_CV2=session_output(i).CV2_T.p_value;
    group_info_T(i).d_pmean=(session_output(i).pmean_T.test_mean/session_output(i).pmean_D.bsl_mean-1)*100;
    group_info_T(i).d_CV2=(session_output(i).CV2_T.test_mean/session_output(i).CV2_D.bsl_mean-1)*100;
    if group_info_T(i).p_pmean<0.05
       if group_info_T(i).p_CV2<0.05
          if group_info_T(i).d_pmean<=0
             fac_irg=fac_irg+1;
             plot(group_info_T(i).d_pmean,group_info_T(i).d_CV2,'r.','MarkerSize',15)
             hold on
             if group_info_T(i).d_CV2>=0
                group_info_T(i).type=1;
             elseif group_info_T(i).d_CV2<0
                group_info_T(i).type=2;   
             end
          elseif group_info_T(i).d_pmean>0
             sup_irg=sup_irg+1;
             plot(group_info_T(i).d_pmean,group_info_T(i).d_CV2,'.','Color',[0 0.4 1],'MarkerSize',15)
             hold on
             if group_info_T(i).d_CV2>=0
                group_info_T(i).type=3;
             elseif group_info_T(i).d_CV2<0
                group_info_T(i).type=4;   
             end             
          end
       elseif group_info_T(i).p_CV2>=0.05
          if group_info_T(i).d_pmean<=0
             fac_reg=fac_reg+1;
             plot(group_info_T(i).d_pmean,group_info_T(i).d_CV2,'.','Color',[1 0.7 0.7],'MarkerSize',15)
             hold on
             if group_info_T(i).d_CV2>=0
                group_info_T(i).type=1;
             elseif group_info_T(i).d_CV2<0
                group_info_T(i).type=2;   
             end             
          elseif group_info_T(i).d_pmean>0
             sup_reg=sup_reg+1; 
             plot(group_info_T(i).d_pmean,group_info_T(i).d_CV2,'.','Color',[0.7 0.8 1],'MarkerSize',15)
             hold on
             if group_info_T(i).d_CV2>=0
                group_info_T(i).type=3;
             elseif group_info_T(i).d_CV2<0
                group_info_T(i).type=4;   
             end                 
          end                  
       end
    elseif group_info_T(i).p_pmean>=0.05
       if group_info_T(i).p_CV2<0.05
          non_irg=non_irg+1; 
          plot(group_info_T(i).d_pmean,group_info_T(i).d_CV2,'k.','MarkerSize',15)
          hold on
          group_info_T(i).type=5; 
       elseif group_info_T(i).p_CV2>=0.05
          non_reg=non_reg+1; 
          plot(group_info_T(i).d_pmean,group_info_T(i).d_CV2,'.','Color',[0.7 0.7 0.7],'MarkerSize',15)
          hold on
          group_info_T(i).type=6;   
       end
    end    
end
A=isoutlier([group_info_T.d_CV2],'grubbs');
B=isoutlier([group_info_T.d_pmean],'grubbs');
% for i=1:size(session_output,2)
%     if A(1,i) || B(1,i)
%        group_info_T(i).d_pmean=[];        
%     end   
% end
% group_info_T=group_info_T(~cellfun(@isempty,{group_info_T.d_pmean}));
% [~,index] = sortrows([group_info_T.type].');
% group_info_T = group_info_T(index);
% clear index;
% range=ones(1,5);
% for i=1:3
%     range(1,i+1)=find([group_info_T.type]>i,1,'first');
%     corr=zeros(range(1,i+1)-range(1,i),3);
%     for j=range(1,i):range(1,i+1)-1
%         corr(j-range(1,i)+1,1)=group_info_T(j).d_pmean;
%         corr(j-range(1,i)+1,2)=group_info_T(j).d_CV2;
%     end
%     [R,P]=corrcoef(corr(:,1),corr(:,2));
%     p=polyfit(corr(:,1),corr(:,2),1);
%     regression=p(1)*corr(:,1)+p(2);
%     corr(:,3)=regression;
%     plot(corr(:,1),corr(:,3),'k-')
%     hold on
%     if i==1
%        text(-90,40,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12);
%     elseif i==2
%        text(-90,-40,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12);
%     elseif i==3
%        text(100,5,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12);
%     end
% end
% 
% range(1,5)=find([group_info_T.type]>4,1,'first');
% corr=zeros(range(1,3)-range(1,1),3);
% for j=range(1,1):range(1,3)-1
%     corr(j-range(1,1)+1,1)=group_info_T(j).d_pmean;
%     corr(j-range(1,1)+1,2)=group_info_T(j).d_CV2;
% end
% [R,P]=corrcoef(corr(:,1),corr(:,2));
% p=polyfit(corr(:,1),corr(:,2),1);
% regression=p(1)*corr(:,1)+p(2);
% corr(:,3)=regression;
% plot(corr(:,1),corr(:,3),'r-','MarkerSize',3)
% hold on
% text(-90,5,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[1 0 0]);
% 
% corr=zeros(range(1,5)-range(1,3),3);
% for j=range(1,3):range(1,5)-1
%     corr(j-range(1,3)+1,1)=group_info_T(j).d_pmean;
%     corr(j-range(1,3)+1,2)=group_info_T(j).d_CV2;
% end
% [R,P]=corrcoef(corr(:,1),corr(:,2));
% p=polyfit(corr(:,1),corr(:,2),1);
% regression=p(1)*corr(:,1)+p(2);
% corr(:,3)=regression;
% plot(corr(:,1),corr(:,3),'b-','MarkerSize',3)
% hold on
% text(100,-5,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[0 0 1]);
% 
% xlim([-100 150]);
% ylim([-50 50]);
% line([-100,150],[0 0],'Color',[0.5 0.5 0.5],'LineStyle','-');
% line([0 0],[-50 50],'Color',[0.5 0.5 0.5],'LineStyle','-');
% xlabel('Relative mean of ISI pair change (%)');
% ylabel('Relative CV2 change (%)');
% title('Trace session - Baseline vs. CR period');

% figure('units','normalized','outerposition',[0 0.1 1 0.8]);  
% 
% bsl_comp_info=zeros(size(session_output,2),3);
% subplot(1,2,1)
% for i=1:size(session_output,2)
%     if group_info_D(i).type==1 || group_info_D(i).type==2
%        plot(session_output(i).pmean_D.bsl_mean,session_output(i).CV2_D.bsl_mean,'r.','MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_D.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_D.bsl_mean;
%     elseif group_info_D(i).type==3 || group_info_D(i).type==4
%        plot(session_output(i).pmean_D.bsl_mean,session_output(i).CV2_D.bsl_mean,'.','Color',[0 0.4 1],'MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_D.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_D.bsl_mean;
%     elseif group_info_D(i).type==5 || group_info_D(i).type==6
%        plot(session_output(i).pmean_D.bsl_mean,session_output(i).CV2_D.bsl_mean,'k.','MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_D.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_D.bsl_mean;
%     end
% end
% A=isoutlier(bsl_comp_info,'grubbs',1);
% for i=1:size(bsl_comp_info,1)
%     if A(i,1) || A(i,2)
%        bsl_comp_info(i,1)=NaN;        
%     end   
% end
% bsl_comp_info(any(isnan(bsl_comp_info), 2), :) = [];
% [R,P]=corrcoef(bsl_comp_info(:,1),bsl_comp_info(:,2));
% p=polyfit(bsl_comp_info(:,1),bsl_comp_info(:,2),1);
% regression=p(1)*bsl_comp_info(:,1)+p(2);
% bsl_comp_info(:,3)=regression;
% plot(bsl_comp_info(:,1),bsl_comp_info(:,3),'k-','MarkerSize',3)
% hold on
% text(70,0.1,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[0 0 0]);
% 
% xlim([0 100]);
% ylim([0 1]);
% xlabel('Average baseline ISI pair mean (ms)');
% ylabel('Average baseline |CV2|');
% title('Dealy session');
% 
% bsl_comp_info=zeros(size(session_output,2),3);
% subplot(1,2,2)
% for i=1:size(session_output,2)
%     if group_info_T(i).type==1 || group_info_T(i).type==2
%        plot(session_output(i).pmean_T.bsl_mean,session_output(i).CV2_T.bsl_mean,'r.','MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_T.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_T.bsl_mean;
%     elseif group_info_T(i).type==3 || group_info_T(i).type==4
%        plot(session_output(i).pmean_T.bsl_mean,session_output(i).CV2_T.bsl_mean,'.','Color',[0 0.4 1],'MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_T.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_T.bsl_mean;
%     elseif group_info_T(i).type==5 || group_info_T(i).type==6
%        plot(session_output(i).pmean_T.bsl_mean,session_output(i).CV2_T.bsl_mean,'k.','MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_T.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_T.bsl_mean;
%     end
% end
% A=isoutlier(bsl_comp_info,'grubbs',1);
% for i=1:size(bsl_comp_info,1)
%     if A(i,1) || A(i,2)
%        bsl_comp_info(i,1)=NaN;        
%     end   
% end
% bsl_comp_info(any(isnan(bsl_comp_info), 2), :) = [];
% [R,P]=corrcoef(bsl_comp_info(:,1),bsl_comp_info(:,2));
% p=polyfit(bsl_comp_info(:,1),bsl_comp_info(:,2),1);
% regression=p(1)*bsl_comp_info(:,1)+p(2);
% bsl_comp_info(:,3)=regression;
% plot(bsl_comp_info(:,1),bsl_comp_info(:,3),'k-','MarkerSize',3)
% hold on
% text(70,0.1,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[0 0 0]);
% 
% xlim([0 100]);
% ylim([0 1]);
% xlabel('Average baseline ISI pair mean (ms)');
% ylabel('Average baseline |CV2|');
% title('Trace session');
% 
% figure('units','normalized','outerposition',[0 0.1 1 0.8]);  
% 
% bsl_comp_info=zeros(size(session_output,2),3);
% subplot(1,2,1)
% for i=1:size(session_output,2)
%     if group_info_D(i).p_CV2<0.05
%        if group_info_D(i).d_CV2>=0
%           plot(session_output(i).pmean_D.bsl_mean,session_output(i).CV2_D.bsl_mean,'m.','MarkerSize',15)
%           hold on
%        elseif group_info_D(i).d_CV2<0
%           plot(session_output(i).pmean_D.bsl_mean,session_output(i).CV2_D.bsl_mean,'c.','MarkerSize',15)
%           hold on 
%        end
%        bsl_comp_info(i,1)=session_output(i).pmean_D.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_D.bsl_mean;
%     elseif group_info_D(i).p_CV2>=0.05
%        plot(session_output(i).pmean_D.bsl_mean,session_output(i).CV2_D.bsl_mean,'k.','MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_D.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_D.bsl_mean;
%     end
% end
% A=isoutlier(bsl_comp_info,'grubbs',1);
% for i=1:size(bsl_comp_info,1)
%     if A(i,1) || A(i,2)
%        bsl_comp_info(i,1)=NaN;        
%     end   
% end
% bsl_comp_info(any(isnan(bsl_comp_info), 2), :) = [];
% [R,P]=corrcoef(bsl_comp_info(:,1),bsl_comp_info(:,2));
% p=polyfit(bsl_comp_info(:,1),bsl_comp_info(:,2),1);
% regression=p(1)*bsl_comp_info(:,1)+p(2);
% bsl_comp_info(:,3)=regression;
% plot(bsl_comp_info(:,1),bsl_comp_info(:,3),'k-','MarkerSize',3)
% hold on
% text(70,0.1,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[0 0 0]);
% 
% xlim([0 100]);
% ylim([0 1]);
% xlabel('Average baseline ISI pair mean (ms)');
% ylabel('Average baseline |CV2|');
% title('Dealy session');
% 
% bsl_comp_info=zeros(size(session_output,2),3);
% subplot(1,2,2)
% for i=1:size(session_output,2)
%     if group_info_T(i).p_CV2<0.05
%        if group_info_T(i).d_CV2>=0
%           plot(session_output(i).pmean_T.bsl_mean,session_output(i).CV2_T.bsl_mean,'m.','MarkerSize',15)
%           hold on
%        elseif group_info_D(i).d_CV2<0
%           plot(session_output(i).pmean_T.bsl_mean,session_output(i).CV2_T.bsl_mean,'c.','MarkerSize',15)
%           hold on 
%        end
%        bsl_comp_info(i,1)=session_output(i).pmean_T.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_T.bsl_mean;
%     elseif group_info_T(i).p_CV2>=0.05
%        plot(session_output(i).pmean_T.bsl_mean,session_output(i).CV2_T.bsl_mean,'k.','MarkerSize',15)
%        hold on
%        bsl_comp_info(i,1)=session_output(i).pmean_T.bsl_mean;
%        bsl_comp_info(i,2)=session_output(i).CV2_T.bsl_mean;
%     end
% end
% A=isoutlier(bsl_comp_info,'grubbs',1);
% for i=1:size(bsl_comp_info,1)
%     if A(i,1) || A(i,2)
%        bsl_comp_info(i,1)=NaN;        
%     end   
% end
% bsl_comp_info(any(isnan(bsl_comp_info), 2), :) = [];
% [R,P]=corrcoef(bsl_comp_info(:,1),bsl_comp_info(:,2));
% p=polyfit(bsl_comp_info(:,1),bsl_comp_info(:,2),1);
% regression=p(1)*bsl_comp_info(:,1)+p(2);
% bsl_comp_info(:,3)=regression;
% plot(bsl_comp_info(:,1),bsl_comp_info(:,3),'k-','MarkerSize',3)
% hold on
% text(70,0.1,{['r=' num2str(R(2,1))];['p=' num2str(P(2,1))]},'FontSize',12,'Color',[0 0 0]);
% 
% xlim([0 100]);
% ylim([0 1]);
% xlabel('Average baseline ISI pair mean (ms)');
% ylabel('Average baseline |CV2|');
% title('Trace session');

% pmean_bsl_up=0;
% pmean_bsl_down=0;
% pmean_bsl_non=0;
% CV2_bsl_up=0;
% CV2_bsl_down=0;
% CV2_bsl_non=0;
% for i=1:size(session_output,2)
%     if session_output(i).pmean_T.p_bsl<0.05
%        if session_output(i).pmean_T.bsl_mean>=session_output(i).pmean_D.bsl_mean
%           pmean_bsl_up=pmean_bsl_up+1;
%        elseif session_output(i).pmean_T.bsl_mean<=session_output(i).pmean_D.bsl_mean
%           pmean_bsl_down=pmean_bsl_down+1;
%        end
%     elseif session_output(i).pmean_T.p_bsl>=0.05
%        pmean_bsl_non=pmean_bsl_non+1;
%     end
%     if session_output(i).CV2_T.p_bsl<0.05
%        if session_output(i).CV2_T.bsl_mean>=session_output(i).CV2_D.bsl_mean
%           CV2_bsl_up=CV2_bsl_up+1;
%        elseif session_output(i).CV2_T.bsl_mean<=session_output(i).CV2_D.bsl_mean
%           CV2_bsl_down=CV2_bsl_down+1;
%        end
%     elseif session_output(i).CV2_T.p_bsl>=0.05
%        CV2_bsl_non=CV2_bsl_non+1;
%     end      
%     
%     
% end