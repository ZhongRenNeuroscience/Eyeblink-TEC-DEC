% % TD
% figure;
% 
% for i=1:size(ttt_fac_T,2)
%     if ttt_fac_T(i).P < 0.05
%        plot (ttt_fac_T(i).ttt(:,3),ttt_fac_T(i).ttt(:,4),'r-')
%        hold on
%     else
%        plot (ttt_fac_T(i).ttt(:,3),ttt_fac_T(i).ttt(:,4),'Color',[1 0.75 0.75],'LineStyle','-')
%        hold on
%     end
% end
% 
% xlim([0 2000]);
% ylim([20 80]);
% xticks(0:250:2000);
% yticks(0:10:80);
% xlabel('Mod change (%)');
% ylabel('CR amplitude (%)');
% title('trace');
% 
% figure;
% 
% for i=1:size(ttt_sup_T,2)
%     if ttt_sup_T(i).P < 0.05
%        plot (-ttt_sup_T(i).ttt(:,3),ttt_sup_T(i).ttt(:,4),'b-')
%        hold on
%     else
%        plot (-ttt_sup_T(i).ttt(:,3),ttt_sup_T(i).ttt(:,4),'Color',[0.75 0.75 1],'LineStyle','-')
%        hold on
%     end
% end
% 
% xlim([30 100]);
% ylim([0 80]);
% xticks(20:10:100);
% yticks(0:10:80);
% xlabel('Mod change (%)');
% ylabel('CR amplitude (%)');
% title('trace');
% 
% figure;
% 
% for i=1:size(ttt_fac_D,2)
%     if ttt_fac_D(i).P < 0.05
%        plot (ttt_fac_D(i).ttt(:,3),ttt_fac_D(i).ttt(:,4),'r-')
%        hold on
%     else
%        plot (ttt_fac_D(i).ttt(:,3),ttt_fac_D(i).ttt(:,4),'Color',[1 0.75 0.75],'LineStyle','-')
%        hold on
%     end
% end
% 
% xlim([0 2000]);
% ylim([0 50]);
% xticks(0:250:2000);
% yticks(0:10:70);
% xlabel('Mod change (%)');
% ylabel('CR amplitude (%)');
% title('delay');
% 
% figure;
% 
% for i=1:size(ttt_sup_D,2)
%     if ttt_sup_D(i).P < 0.05
%        plot (-ttt_sup_D(i).ttt(:,3),ttt_sup_D(i).ttt(:,4),'b-')
%        hold on
%     else
%        plot (-ttt_sup_D(i).ttt(:,3),ttt_sup_D(i).ttt(:,4),'Color',[0.75 0.75 1],'LineStyle','-')
%        hold on
%     end
% end
% 
% xlim([0 100]);
% ylim([0 70]);
% xticks(0:10:100);
% yticks(0:10:70);
% xlabel('Mod change (%)');
% ylabel('CR amplitude (%)');
% title('delay');

% DT
figure;

for i=1:size(ttt_fac_T,2)
    if ttt_fac_T(i).P < 0.05
       plot (ttt_fac_T(i).ttt(:,3),ttt_fac_T(i).ttt(:,4),'r-')
       hold on
    else
       plot (ttt_fac_T(i).ttt(:,3),ttt_fac_T(i).ttt(:,4),'Color',[1 0.75 0.75],'LineStyle','-')
       hold on
    end
end

xlim([0 1500]);
ylim([0 60]);
xticks(0:250:2000);
yticks(0:10:80);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');
title('trace');

figure;

for i=1:size(ttt_sup_T,2)
    if ttt_sup_T(i).P < 0.05
       plot (-ttt_sup_T(i).ttt(:,3),ttt_sup_T(i).ttt(:,4),'b-')
       hold on
    else
       plot (-ttt_sup_T(i).ttt(:,3),ttt_sup_T(i).ttt(:,4),'Color',[0.75 0.75 1],'LineStyle','-')
       hold on
    end
end

xlim([40 100]);
ylim([0 60]);
xticks(20:10:100);
yticks(0:10:80);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');
title('trace');

figure;

for i=1:size(ttt_fac_D,2)
    if ttt_fac_D(i).P < 0.05
       plot (ttt_fac_D(i).ttt(:,3),ttt_fac_D(i).ttt(:,4),'r-')
       hold on
    else
       plot (ttt_fac_D(i).ttt(:,3),ttt_fac_D(i).ttt(:,4),'Color',[1 0.75 0.75],'LineStyle','-')
       hold on
    end
end

xlim([0 1500]);
ylim([0 50]);
xticks(0:250:2000);
yticks(0:10:70);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');
title('delay');

figure;

for i=1:size(ttt_sup_D,2)
    if ttt_sup_D(i).P < 0.05
       plot (-ttt_sup_D(i).ttt(:,3),ttt_sup_D(i).ttt(:,4),'b-')
       hold on
    else
       plot (-ttt_sup_D(i).ttt(:,3),ttt_sup_D(i).ttt(:,4),'Color',[0.75 0.75 1],'LineStyle','-')
       hold on
    end
end

xlim([30 100]);
ylim([0 60]);
xticks(0:10:100);
yticks(0:10:70);
xlabel('Mod change (%)');
ylabel('CR amplitude (%)');
title('delay');