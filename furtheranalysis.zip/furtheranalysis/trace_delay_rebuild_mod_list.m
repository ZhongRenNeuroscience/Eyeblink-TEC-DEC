list=trace_list_sim;

align_info_1='align_info';
all_info_1='all_info';
t_pre=550;
% t_pre_extra=50;
t_post=500;
std_idx=3;
pct_idx=40;
mod_find_start=30;

mod_list_trace=struct('cell_ID',[],'file_name',[],'CR_fac',[],'CR_sup',[],'align_info',[]);

for i=1:size(list,2)
    mod_list_trace(i).cell_ID=list(i).cell_ID;
    mod_list_trace(i).file_name=list(i).file_name;
    mod_list_trace(i).CR_fac=list(i).CR_fac;
    mod_list_trace(i).CR_sup=list(i).CR_sup;
    align_info=struct('bsl_frq_ex',[],'bsl_frq_align',[],'SD_ex',[],'SD_align',[],'psth_ex',[],'psth_align',[],'CR_fac',[],'CR_sup',[],'CR_fac_align',[],'CR_sup_align',[],'t_start',[],'t_end',[]);
%     norm_info=struct('bsl_psth',[],'bsl_frq',[],'bsl_SD',[],'thrd',[]);
    
    bsl_psth=zeros(500,3);
    bsl_psth(:,1)=-500:1:-1;
    t_start_idx=find(list(i).(align_info_1).psth_ex(:,1)==-500);
    bsl_psth(:,2)=list(i).(align_info_1).psth_ex(t_start_idx:t_start_idx+499,2)/list(i).(align_info_1).bsl_frq_ex*100;
    bsl_psth(:,3)=list(i).(align_info_1).psth_ex(t_start_idx:t_start_idx+499,2);
    bsl_SD=list(i).(align_info_1).SD_ex/list(i).(align_info_1).bsl_frq_ex*100;

%     bsl_wv=max(abs(bsl_psth(:,2)-100));
%     mod_thrd=max([std_idx*bsl_SD pct_idx bsl_wv+10]);
%     mod_thrd=min([6*bsl_SD mod_thrd]);
%     mod_thrd=bsl_SD*std_idx/list(i).(align_info_1).bsl_frq_ex*100;
    
%     norm_info.bsl_psth=bsl_psth;
%     norm_info.bsl_frq=list(i).(align_info_1).bsl_frq_ex;
%     norm_info.bsl_SD=list(i).(align_info_1).SD_ex;
%     norm_info.thrd=mod_thrd;
%     mod_list(i).norm_info=norm_info;
    
    align_info.bsl_frq_ex=list(i).(align_info_1).bsl_frq_ex;
    align_info.SD_ex=list(i).(align_info_1).SD_ex;
    
    psth_ex=zeros(size(list(i).(align_info_1).psth_ex,1),3);
    psth_ex(:,1)=list(i).(align_info_1).psth_ex(:,1);
    psth_ex(:,2)=list(i).(align_info_1).psth_ex(:,2);
    psth_ex(:,3)=list(i).(align_info_1).psth_ex(:,2)/list(i).(align_info_1).bsl_frq_ex*100;
    CR_fac=struct('t_onset_1',[],'t_onset_p',[],'t_peak',[],'peak',[]);
    CR_sup=struct('t_onset_1',[],'t_onset_p',[],'t_peak',[],'peak',[]);   
    
    [CR_fac.peak,CR_fac.t_peak]=max(psth_ex(t_start_idx+500:t_start_idx+499+t_post,3));
    [fac_pk,fac_pk_idx]=findpeaks(psth_ex(t_start_idx+500:t_start_idx+499+t_post,3),'MinPeakHeight',std_idx*bsl_SD+100);
    if ~isempty(fac_pk)
        for j=1:length(fac_pk)
           fac_onset_p=find(psth_ex(t_start_idx+500:t_start_idx+499+fac_pk_idx(j,1),3)<=100+std_idx*bsl_SD,1,'last');           
           if ~isempty(fac_onset_p) && fac_pk_idx(j,1)-fac_onset_p>=4 && fac_onset_p>mod_find_start
              CR_fac.t_onset_p=fac_onset_p;
              CR_fac.t_onset_1=find(psth_ex(t_start_idx+500:t_start_idx+499+fac_pk_idx(j,1),3)<=100+std_idx*bsl_SD,1,'first');
              [CR_fac.peak,I]=max(fac_pk);
              CR_fac.t_peak=fac_pk_idx(I);
              mod_list_trace(i).CR_fac=1;
              break              
           end
        end 
    end
    [CR_sup.peak,CR_sup.t_peak]=min(psth_ex(t_start_idx+500:t_start_idx+499+t_post,3));
    [sup_pk,sup_pk_idx]=findpeaks((psth_ex(t_start_idx+500:t_start_idx+499+t_post,3)*-1),'MinPeakHeight',-100+std_idx*bsl_SD);
    if ~isempty(sup_pk)
        for j=1:length(sup_pk)
           sup_onset_p=find((psth_ex(t_start_idx+500:t_start_idx+499+sup_pk_idx(j,1),3)*-1)<=-100+std_idx*bsl_SD,1,'last');
           if ~isempty(sup_onset_p) && sup_pk_idx(j,1)-sup_onset_p>=4 && sup_onset_p>mod_find_start
              CR_sup.t_onset=sup_onset_p;
              CR_sup.t_onset_1=find(psth_ex(t_start_idx+500:t_start_idx+499+sup_pk_idx(j,1),3)<=-100+std_idx*bsl_SD,1,'first');
              [CR_sup.peak,I]=max(sup_pk);
              CR_sup.peak=CR_sup.peak*-1;
              CR_sup.t_peak=sup_pk_idx(I);
              mod_list_trace(i).CR_sup=1;
              break
           end
        end          
    end
    
    psth_align=zeros(size(list(i).(align_info_1).psth_align,1),3);
    psth_align(:,1)=list(i).(align_info_1).psth_align(:,1);
    psth_align(:,2)=list(i).(align_info_1).psth_align(:,2);
    bsl_frq_align=mean(psth_align(51:t_pre-list(i).(align_info_1).t_end,2));
    psth_align(:,3)=list(i).(align_info_1).psth_align(:,2)/bsl_frq_align*100;
    SD_align=std(psth_align(51:t_pre-list(i).(align_info_1).t_end,2));
    mod_thrd=std_idx*SD_align/bsl_frq_align*100;
    CR_fac_align=struct('t_onset_1',[],'t_onset_p',[],'t_peak',[],'peak',[]);
    CR_sup_align=struct('t_onset_1',[],'t_onset_p',[],'t_peak',[],'peak',[]);
    [fac_pk,fac_pk_idx]=max(psth_align(t_pre+1-list(i).(align_info_1).t_start:t_pre+t_post-list(i).(align_info_1).t_end,3));
    CR_fac_align.peak=fac_pk; 
    CR_fac_align.t_peak=-list(i).(align_info_1).t_start+fac_pk_idx-1;
    if fac_pk>=100+mod_thrd
       if psth_align(t_pre+fac_pk_idx-list(i).(align_info_1).t_start-5,3)>=100+mod_thrd && psth_align(t_pre+fac_pk_idx-list(i).(align_info_1).t_start+5,3)>=100+mod_thrd
          CR_fac_align.t_onset_1=find(psth_align(t_pre+1-list(i).(align_info_1).t_end:t_pre+CR_fac_align.t_peak,3)>=100+mod_thrd,1,'first')-list(i).(align_info_1).t_end-1;
          CR_fac_align.t_onset_p=find(psth_align(t_pre+1-list(i).(align_info_1).t_end:t_pre+CR_fac_align.t_peak,3)<=100+mod_thrd,1,'last')-list(i).(align_info_1).t_end;
       end
    end    
    [sup_pk,sup_pk_idx]=min(psth_align(t_pre+1-list(i).(align_info_1).t_start:t_pre+t_post-list(i).(align_info_1).t_end,3));
    CR_sup_align.peak=sup_pk;
    CR_sup_align.t_peak=-list(i).(align_info_1).t_start+sup_pk_idx-1; 
    if sup_pk<=100-mod_thrd
       if psth_align(t_pre+sup_pk_idx-list(i).(align_info_1).t_start-5,3)<=100-mod_thrd && psth_align(t_pre+sup_pk_idx-list(i).(align_info_1).t_start+5,3)<=100-mod_thrd             
          CR_sup_align.t_onset_1=find(psth_align(t_pre+1-list(i).(align_info_1).t_end:t_pre+CR_sup_align.t_peak,3)<=100-mod_thrd,1,'first')-list(i).(align_info_1).t_end-1;
          CR_sup_align.t_onset_p=find(psth_align(t_pre+1-list(i).(align_info_1).t_end:t_pre+CR_sup_align.t_peak,3)>=100-mod_thrd,1,'last')-list(i).(align_info_1).t_end;
       end 
    end     
    
    align_info.psth_ex=psth_ex;
    align_info.psth_align=psth_align;
    align_info.SD_align=SD_align;
    align_info.bsl_frq_align=bsl_frq_align;
    align_info.CR_fac=list(i).(align_info_1).CR_fac;
    align_info.CR_sup=list(i).(align_info_1).CR_sup;
    align_info.CR_fac_align=CR_fac_align;
    align_info.CR_sup_align=CR_sup_align;    
    align_info.t_start=list(i).(align_info_1).t_start;
    align_info.t_end=list(i).(align_info_1).t_end;
    mod_list_trace(i).align_info=align_info;
    
end