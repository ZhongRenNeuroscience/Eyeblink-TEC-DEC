%  fix the US timing for several sessions

file=file;
t_post=500;
US_delay=15;
all_info='all_info_T';
align_info='align_info_T';
non_info='non_info_T';
mod_info='mod_info_T';

for i=1:size(file,2)
    if file(i).US_fix==1
       if ~isempty(file(i).(mod_info).URf)
          file(i).(mod_info).URf.t_peak=file(i).(mod_info).URf.t_peak-US_delay;                
       end
       if ~isempty(file(i).(mod_info).URs)
          file(i).(mod_info).URs.t_peak=file(i).(mod_info).URs.t_peak-US_delay;                
       end        
       file(i).(all_info).sss_all.blk.CR_trial=US_fix(file(i).(all_info).sss_all.blk.CR_trial(:,1),file(i).(all_info).sss_all.blk.CR_trial(:,2),t_post,US_delay);
       if ~isempty(file(i).(all_info).sss_all.blk.nonCR_trial)
          file(i).(all_info).sss_all.blk.nonCR_trial=US_fix(file(i).(all_info).sss_all.blk.nonCR_trial(:,1),file(i).(all_info).sss_all.blk.nonCR_trial(:,2),t_post,US_delay);    
       end
       file(i).(all_info).sss_all.blk.CR_trial_new=US_fix(file(i).(all_info).sss_all.blk.CR_trial_new(:,1),file(i).(all_info).sss_all.blk.CR_trial_new(:,2),t_post,US_delay);  
       file(i).(all_info).sss_all.psth.CR_trial.psth_raw=US_fix(file(i).(all_info).sss_all.psth.CR_trial.psth_raw(:,1),file(i).(all_info).sss_all.psth.CR_trial.psth_raw(:,2),t_post,US_delay);
       file(i).(all_info).sss_all.psth.CR_trial.psth_smooth=US_fix(file(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1),file(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2),t_post,US_delay);
       if ~isempty(file(i).(all_info).sss_all.blk.nonCR_trial)
          file(i).(all_info).sss_all.psth.nonCR_trial.psth_raw=US_fix(file(i).(all_info).sss_all.psth.nonCR_trial.psth_raw(:,1),file(i).(all_info).sss_all.psth.nonCR_trial.psth_raw(:,2),t_post,US_delay);
          file(i).(all_info).sss_all.psth.nonCR_trial.psth_smooth=US_fix(file(i).(all_info).sss_all.psth.nonCR_trial.psth_smooth(:,1),file(i).(all_info).sss_all.psth.nonCR_trial.psth_smooth(:,2),t_post,US_delay);    
       end
       for j=1:size(file(i).(all_info).ttt.CR_trial,2)
           for k=1:length(file(i).(all_info).ttt.CR_trial(j).spk_time)
               if file(i).(all_info).ttt.CR_trial(j).spk_time(k)>=t_post/1000 && file(i).(all_info).ttt.CR_trial(j).spk_time(k)<(t_post+US_delay)/1000
                  file(i).(all_info).ttt.CR_trial(j).spk_time(k)=NaN;                   
               elseif file(i).(all_info).ttt.CR_trial(j).spk_time(k)>=(t_post+US_delay)/1000
                  file(i).(all_info).ttt.CR_trial(j).spk_time(k)=file(i).(all_info).ttt.CR_trial(j).spk_time(k)-US_delay/1000;                   
               end               
           end
           file(i).(all_info).ttt.CR_trial(j).spk_time(any(isnan(file(i).(all_info).ttt.CR_trial(j).spk_time),2),:) = [];
           ifr_smooth=zeros(size(file(i).(all_info).ttt.CR_trial(j).ifr_smooth,1),size(file(i).(all_info).ttt.CR_trial(j).ifr_smooth,2));
           ifr_smooth(:,1)=file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,1);
           ifr_smooth_2=US_fix(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,1),file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,2),t_post,US_delay);
           ifr_smooth_3=US_fix(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,1),file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,3),t_post,US_delay);
           ifr_smooth_4=US_fix(file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,1),file(i).(all_info).ttt.CR_trial(j).ifr_smooth(:,4),t_post,US_delay);
           ifr_smooth(:,2)=ifr_smooth_2(:,2);
           ifr_smooth(:,3)=ifr_smooth_3(:,2);
           ifr_smooth(:,4)=ifr_smooth_4(:,2);
           file(i).(all_info).ttt.CR_trial(j).ifr_smooth=ifr_smooth;
           file(i).(all_info).ttt.CR_trial(j).blk_smth=US_fix(file(i).(all_info).ttt.CR_trial(j).blk_smth(:,1),file(i).(all_info).ttt.CR_trial(j).blk_smth(:,2),t_post,US_delay);
           file(i).(all_info).ttt.CR_trial(j).blk_info_new.UR_peaktime=file(i).(all_info).ttt.CR_trial(j).blk_info_new.UR_peaktime-US_delay;           
       end
       
       for j=1:size(file(i).(all_info).ttt.nonCR_trial,2)
           for k=1:length(file(i).(all_info).ttt.nonCR_trial(j).spk_time)
               if file(i).(all_info).ttt.nonCR_trial(j).spk_time(k)>=t_post/1000 && file(i).(all_info).ttt.nonCR_trial(j).spk_time(k)<(t_post+US_delay)/1000
                  file(i).(all_info).ttt.nonCR_trial(j).spk_time(k)=NaN;                   
               elseif file(i).(all_info).ttt.nonCR_trial(j).spk_time(k)>=(t_post+US_delay)/1000
                  file(i).(all_info).ttt.nonCR_trial(j).spk_time(k)=file(i).(all_info).ttt.nonCR_trial(j).spk_time(k)-US_delay/1000;                   
               end               
           end
           file(i).(all_info).ttt.nonCR_trial(j).spk_time(any(isnan(file(i).(all_info).ttt.nonCR_trial(j).spk_time),2),:) = [];
           ifr_smooth=zeros(size(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth,1),size(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth,2));
           ifr_smooth(:,1)=file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1);
           ifr_smooth_2=US_fix(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1),file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,2),t_post,US_delay);
           ifr_smooth_3=US_fix(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1),file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,3),t_post,US_delay);
           ifr_smooth_4=US_fix(file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,1),file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth(:,4),t_post,US_delay);
           ifr_smooth(:,2)=ifr_smooth_2(:,2);
           ifr_smooth(:,3)=ifr_smooth_3(:,2);
           ifr_smooth(:,4)=ifr_smooth_4(:,2);
           file(i).(all_info).ttt.nonCR_trial(j).ifr_smooth=ifr_smooth;
           file(i).(all_info).ttt.nonCR_trial(j).blk_smth=US_fix(file(i).(all_info).ttt.nonCR_trial(j).blk_smth(:,1),file(i).(all_info).ttt.nonCR_trial(j).blk_smth(:,2),t_post,US_delay);
           file(i).(all_info).ttt.nonCR_trial(j).blk_info_new.UR_peaktime=file(i).(all_info).ttt.nonCR_trial(j).blk_info_new.UR_peaktime-US_delay;  
           file(i).(all_info).ttt.nonCR_trial(j).blk_info.UR_peaktime=file(i).(all_info).ttt.nonCR_trial(j).blk_info.UR_peaktime-US_delay/1000; 
       end
       file(i).(align_info).psth_ex=US_fix(file(i).(align_info).psth_ex(:,1),file(i).(align_info).psth_ex(:,2),t_post,US_delay);
       file(i).(non_info).psth=US_fix(file(i).(non_info).psth(:,1),file(i).(non_info).psth(:,2),t_post,US_delay);
       
       
       
       
       
    end
    
    
        
   
end

function fix_curve=US_fix(raw_curve_t,raw_curve_v,t_post,US_delay)

fix_curve=zeros(size(raw_curve_t,1),2);
fix_curve(:,1)=raw_curve_t;
fix_curve(:,2)=raw_curve_v;

[~,t_idx_1]=min(abs(fix_curve(:,1)-t_post));
[~,t_idx_2]=min(abs(fix_curve(:,1)-(t_post+US_delay)));

for i=t_idx_1:size(raw_curve_t,1)-t_idx_2+t_idx_1
    fix_curve(i,2)=fix_curve(i+t_idx_2-t_idx_1,2);  
end
for i=size(raw_curve_t,1)-t_idx_2+t_idx_1+1:size(raw_curve_t,1)
%     rand_idx=floor(rand(1)*(t_idx_2-t_idx_1));   
    fix_curve(i,2)=fix_curve(size(raw_curve_t,1)-t_idx_2+t_idx_1,2);  
end

end




