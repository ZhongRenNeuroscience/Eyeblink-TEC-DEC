% include Day 1 trace part of trace-delay recording to IN trace-only
% recording database

k=215;
for i=1:size(TD_list_new,2)
    if TD_list_new(i).Day==1
       info=struct('cell_ID',[],'file_name',[],'cell_num',[],'CR_fac',[],'CR_sup',[],'UR_fac',[],'UR_sup',[],'mod_info',[],'all_info',[]);
       info.cell_ID=k;
       info.file_name=TD_list_new(i).file_name;
       info.cell_num=TD_list_new(i).cell_num;
       info.CR_fac=TD_list_new(i).CR_fac_T;
       info.CR_sup=TD_list_new(i).CR_sup_T;
       info.UR_fac=TD_list_new(i).UR_fac_T;
       info.UR_sup=TD_list_new(i).UR_sup_T;
       info.mod_info=TD_list_new(i).mod_info_T;
       info.all_info=TD_list_new(i).all_info_T;
       if info.CR_fac>0
          list_mod.fac=[list_mod.fac,info];
       elseif info.CR_sup>0
          list_mod.sup=[list_mod.sup,info];
       elseif info.CR_fac+info.CR_sup==0
          list_mod.non=[list_mod.non,info]; 
       end
       k=k+1;
    end
end