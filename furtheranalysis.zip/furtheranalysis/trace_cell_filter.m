%Trace behavior session filter

file=Trace_T;
% t_interval=500;
all_info='all_info';
cell_filter=struct('cell_ID',[],'avg_amp',[],'trial_left',[],'info',[],'exclude',[]);

for i=1:size(file,2)
    info=struct('trial_num',[],'amp',[]);
    k=1;
    for j=1:size(file(i).(all_info).ttt.CR_trial,2)
        if file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp>0.1
           info(k).trial_num=file(i).(all_info).ttt.CR_trial(j).trial_num;
           info(k).amp=file(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_amp;
           k=k+1; 
        end        
    end
    cell_filter(i).cell_ID=file(i).cell_ID;
    cell_filter(i).avg_amp=mean([info.amp]);
    cell_filter(i).trial_left=size(info,2);
    cell_filter(i).info=info;
    if cell_filter(i).avg_amp>0.1 && cell_filter(i).trial_left>=20
       cell_filter(i).exclude=0;
    else
       cell_filter(i).exclude=1;
       file(i).cell_ID=[];
    end
end

file=file(~cellfun(@isempty,{file.cell_ID}));
for i=1:size(file,2)
    file(i).cell_ID=i;  
end