listing = dir('pack_*');

mus_DT_list=struct('mouse_ID',[],'date',[],'injection',[],'onset_norm_1_mean',[],'onset_prb_1_mean',[],'onset_norm_2_mean',[],'onset_prb_2_mean',[],...
    'onset_norm_3_mean',[],'onset_prb_3_mean',[],'amp_norm_1_mean',[],'amp_prb_1_mean',[],'amp_norm_2_mean',[],'amp_prb_2_mean',[],...
    'amp_norm_3_mean',[],'amp_prb_3_mean',[],'per_norm_1_mean',[],'per_prb_1_mean',[],'per_norm_2_mean',[],'per_prb_2_mean',[],...
    'per_norm_3_mean',[],'per_prb_3_mean',[],'curve_norm_1_mean',[],'curve_prb_1_mean',[],'curve_norm_2_mean',[],'curve_prb_2_mean',[],...
    'curve_norm_3_mean',[],'curve_prb_3_mean',[],'trial_info',[],'p_value',[]);
color_11=[1 0.5 0];
color_12=[1 0.8 0.6];
color_21=[0.5 0 1];
color_22=[0.8 0.6 1];

for i=9:9
    load(listing(i).name);
    
    mus_DT_list(i).mouse_ID=package_session.mouse_ID;
    mus_DT_list(i).date=package_session.date;
    idcs = strfind(listing(i).name,'_');
    mus_DT_list(i).injection=extractAfter(listing(i).name,idcs(3));
    mus_DT_list(i).injection=extractBefore(mus_DT_list(i).injection,'.mat');
    
    mus_DT_list(i).onset_norm_1_mean=package_session.CR_onset.norm_1_mean;
    mus_DT_list(i).onset_prb_1_mean=package_session.CR_onset.prb_1_mean;
    mus_DT_list(i).onset_norm_2_mean=package_session.CR_onset.norm_2_mean;
    mus_DT_list(i).onset_prb_2_mean=package_session.CR_onset.prb_2_mean;    
    mus_DT_list(i).onset_norm_3_mean=package_session.CR_onset.norm_3_mean;
    mus_DT_list(i).onset_prb_3_mean=package_session.CR_onset.prb_3_mean;      
    
    mus_DT_list(i).amp_norm_1_mean=package_session.CR_amp.norm_1_mean;
    mus_DT_list(i).amp_prb_1_mean=package_session.CR_amp.prb_1_mean;
    mus_DT_list(i).amp_norm_2_mean=package_session.CR_amp.norm_2_mean;
    mus_DT_list(i).amp_prb_2_mean=package_session.CR_amp.prb_2_mean;    
    mus_DT_list(i).amp_norm_3_mean=package_session.CR_amp.norm_3_mean;
    mus_DT_list(i).amp_prb_3_mean=package_session.CR_amp.prb_3_mean;      
    
    mus_DT_list(i).per_norm_1_mean=package_session.CR_per.norm_1_mean;
    mus_DT_list(i).per_prb_1_mean=package_session.CR_per.prb_1_mean;
    mus_DT_list(i).per_norm_2_mean=package_session.CR_per.norm_2_mean;
    mus_DT_list(i).per_prb_2_mean=package_session.CR_per.prb_2_mean;    
    mus_DT_list(i).per_norm_3_mean=package_session.CR_per.norm_3_mean;
    mus_DT_list(i).per_prb_3_mean=package_session.CR_per.prb_3_mean;   
    
    mus_DT_list(i).curve_norm_1_mean=package_session.eyelid_curve.norm_1_mean;
    mus_DT_list(i).curve_prb_1_mean=package_session.eyelid_curve.prb_1_mean;
    mus_DT_list(i).curve_norm_2_mean=package_session.eyelid_curve.norm_2_mean;
    mus_DT_list(i).curve_prb_2_mean=package_session.eyelid_curve.prb_2_mean;    
    mus_DT_list(i).curve_norm_3_mean=package_session.eyelid_curve.norm_3_mean;
    mus_DT_list(i).curve_prb_3_mean=package_session.eyelid_curve.prb_3_mean;     
    
    mus_DT_list(i).trial_info=struct('onset_norm_1_trial',[],'onset_prb_1_trial',[],'onset_norm_2_trial',[],'onset_prb_2_trial',[],...
    'onset_norm_3_trial',[],'onset_prb_3_trial',[],'amp_norm_1_trial',[],'amp_prb_1_trial',[],'amp_norm_2_trial',[],'amp_prb_2_trial',[],...
    'amp_norm_3_trial',[],'amp_prb_3_trial',[],'curve_norm_1_trial',[],'curve_prb_1_trial',[],'curve_norm_2_trial',[],'curve_prb_2_trial',[],...
    'curve_norm_3_trial',[],'curve_prb_3_trial',[]);

    mus_DT_list(i).trial_info.onset_norm_1_trial=package_session.CR_onset.norm_1_trial;
    mus_DT_list(i).trial_info.onset_prb_1_trial=package_session.CR_onset.prb_1_trial;
    mus_DT_list(i).trial_info.onset_norm_2_trial=package_session.CR_onset.norm_2_trial;
    mus_DT_list(i).trial_info.onset_prb_2_trial=package_session.CR_onset.prb_2_trial;
    mus_DT_list(i).trial_info.onset_norm_3_trial=package_session.CR_onset.norm_3_trial;
    mus_DT_list(i).trial_info.onset_prb_3_trial=package_session.CR_onset.prb_3_trial;

    mus_DT_list(i).trial_info.amp_norm_1_trial=package_session.CR_amp.norm_1_trial;
    mus_DT_list(i).trial_info.amp_prb_1_trial=package_session.CR_amp.prb_1_trial;
    mus_DT_list(i).trial_info.amp_norm_2_trial=package_session.CR_amp.norm_2_trial;
    mus_DT_list(i).trial_info.amp_prb_2_trial=package_session.CR_amp.prb_2_trial;
    mus_DT_list(i).trial_info.amp_norm_3_trial=package_session.CR_amp.norm_3_trial;
    mus_DT_list(i).trial_info.amp_prb_3_trial=package_session.CR_amp.prb_3_trial;          
  
    mus_DT_list(i).trial_info.curve_norm_1_trial=package_session.eyelid_curve.norm_1_trial;
    mus_DT_list(i).trial_info.curve_prb_1_trial=package_session.eyelid_curve.prb_1_trial;
    mus_DT_list(i).trial_info.curve_norm_2_trial=package_session.eyelid_curve.norm_2_trial;
    mus_DT_list(i).trial_info.curve_prb_2_trial=package_session.eyelid_curve.prb_2_trial;
    mus_DT_list(i).trial_info.curve_norm_3_trial=package_session.eyelid_curve.norm_3_trial;
    mus_DT_list(i).trial_info.curve_prb_3_trial=package_session.eyelid_curve.prb_3_trial;  
    
    
    mus_DT_list(i).p_value=struct('prb_12_onset',[],'prb_23_onset',[],'prb_12_amp',[],'prb_23_amp',[]);
    
    if ~isempty(package_session.CR_onset.prb_1_trial(1).value) && ~isempty(package_session.CR_onset.prb_2_trial(1).value)
        p_1=ranksum([package_session.CR_onset.prb_1_trial.value],[package_session.CR_onset.prb_2_trial.value]);    
        mus_DT_list(i).p_value.prb_12_onset=p_1;
    else
        mus_DT_list(i).p_value.prb_12_onset=[];       
    end
    if ~isempty(package_session.CR_onset.prb_2_trial(1).value) && ~isempty(package_session.CR_onset.prb_3_trial(1).value)
        p_2=ranksum([package_session.CR_onset.prb_2_trial.value],[package_session.CR_onset.prb_3_trial.value]);    
        mus_DT_list(i).p_value.prb_23_onset=p_2;    
    else
        mus_DT_list(i).p_value.prb_23_onset=[];       
    end        
    if ~isempty(package_session.CR_amp.prb_1_trial(1).value) && ~isempty(package_session.CR_amp.prb_2_trial(1).value)
        p_3=ranksum([package_session.CR_amp.prb_1_trial.value],[package_session.CR_amp.prb_2_trial.value]);    
        mus_DT_list(i).p_value.prb_12_amp=p_3;
    else
        mus_DT_list(i).p_value.prb_12_amp=[];       
    end  
    if ~isempty(package_session.CR_amp.prb_2_trial(1).value) && ~isempty(package_session.CR_amp.prb_3_trial(1).value)
        p_4=ranksum([package_session.CR_amp.prb_2_trial.value],[package_session.CR_amp.prb_3_trial.value]);    
        mus_DT_list(i).p_value.prb_23_amp=p_4;      
    else
        mus_DT_list(i).p_value.prb_23_amp=[];       
    end   
    
    
    figure;
    for k=1:size(package_session.eyelid_curve.prb_2_trial,2)
        curve_plot=smooth_curve(package_session.eyelid_curve.prb_2_trial(k).value(:,1),package_session.eyelid_curve.prb_2_trial(k).value(:,2),20,5);
        plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_12,'LineWidth',0.5)
        hold on               
    end
    curve_plot=smooth_curve(package_session.eyelid_curve.prb_2_mean(:,1),package_session.eyelid_curve.prb_2_mean(:,2),20,5);
    plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_11,'LineWidth',2)
    hold on
    
    for k=1:size(package_session.eyelid_curve.prb_3_trial,2)
        curve_plot=smooth_curve(package_session.eyelid_curve.prb_3_trial(k).value(:,1),package_session.eyelid_curve.prb_3_trial(k).value(:,2),20,5);
        plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_22,'LineWidth',0.5)
        hold on               
    end
    curve_plot=smooth_curve(package_session.eyelid_curve.prb_3_mean(:,1),package_session.eyelid_curve.prb_3_mean(:,2),20,5);
    plot(curve_plot(:,1),curve_plot(:,2)*100,'Color',color_21,'LineWidth',2)
    hold on    
    
    xlim([-250 1000]);
    ylim([-10 110]);
    xticks(-250:250:1000);
    yticks(0:50:100);
    xlabel('Time (ms)');
    ylabel('Eyelid (%)');
    title_name=[mus_DT_list(i).mouse_ID ' ' mus_DT_list(i).date ' ' mus_DT_list(i).injection];
    title(title_name);
    
    saveas(gcf,[mus_DT_list(i).mouse_ID '_' mus_DT_list(i).date '_' mus_DT_list(i).injection '.pdf']);  
    close all
    
    figure;
    trial_1=size(mus_DT_list(i).trial_info.onset_prb_1_trial,2);
    trial_2=size(mus_DT_list(i).trial_info.onset_prb_2_trial,2);
    trial_3=size(mus_DT_list(i).trial_info.onset_prb_3_trial,2);
    ymax_1=max([mus_DT_list(i).trial_info.onset_prb_1_trial.value]);
    ymax_2=max([mus_DT_list(i).trial_info.onset_prb_2_trial.value]);
    ymax_3=max([mus_DT_list(i).trial_info.onset_prb_3_trial.value]);
    ymax=max([ymax_1 ymax_2 ymax_3]);
    ymax=ceil(ymax/100)*100;
    
    for k=1:trial_1
        plot(k,mus_DT_list(i).trial_info.onset_prb_1_trial(k).value,'.','Color',color_12,'MarkerSize',15);
        hold on 
    end
    for k=1:trial_2
        plot(trial_1+k,mus_DT_list(i).trial_info.onset_prb_2_trial(k).value,'.','Color',color_12,'MarkerSize',15);
        hold on                            
    end    
    for k=1:trial_3
        plot(trial_1+trial_2+k,mus_DT_list(i).trial_info.onset_prb_3_trial(k).value,'.','Color',color_22,'MarkerSize',15);
        hold on                            
    end   
    
    line([trial_1+0.5 trial_1+0.5],[50 500],'LineStyle','--')
    line([trial_1+trial_2+0.5 trial_1+trial_2+0.5],[50 500],'LineStyle','--')
    line([1 trial_1],[mus_DT_list(i).onset_prb_1_mean mus_DT_list(i).onset_prb_1_mean],'LineStyle','-','Color',color_11,'LineWidth',2);
    line([trial_1+1 trial_1+trial_2],[mus_DT_list(i).onset_prb_2_mean mus_DT_list(i).onset_prb_2_mean],'LineStyle','-','Color',color_11,'LineWidth',2);
    line([trial_1+trial_2+1 trial_1+trial_2+trial_3],[mus_DT_list(i).onset_prb_3_mean mus_DT_list(i).onset_prb_3_mean],'LineStyle','-','Color',color_21,'LineWidth',2);
    xlim([0 trial_1+trial_2+trial_3+1]);
    ylim([100 500]);
    xticks([1 trial_1+1 trial_1+trial_2+1 trial_1+trial_2+trial_3]);
    yticks(100:50:500);
    xlabel('Trials (ms)');
    ylabel('CR onset (ms)');
    
    title_name=[mus_DT_list(i).mouse_ID ' ' mus_DT_list(i).date ' ' mus_DT_list(i).injection];
    title(title_name);
    
    saveas(gcf,['CR_onset' mus_DT_list(i).mouse_ID '_' mus_DT_list(i).date '_' mus_DT_list(i).injection '.pdf']);  
    close all
end


function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end