% Low/high locomotion trial comparison analysis
file=trace_T_loco_fix;
all_info='all_info';
blk_info='blk_info_new';
t_pre=500;
t_post=500;

loco_com=struct('cell_ID',[],'session_ID',[],'CR_fac',[],'CR_sup',[],'mod_fac_amp',[],'mod_sup_amp',[],'CR_onset',[],'CR_amp',[],'bsl_frq',[],'test_frq',[],...
    'CR_onset_H',[],'CR_onset_L',[],'p_CR_onset',[],'CR_amp_H',[],'CR_amp_L',[],'p_CR_amp',[],'bsl_frq_H',[],'bsl_frq_L',[],'p_bsl_frq',[],'test_frq_H',[],'test_frq_L',[],'p_test_frq',[]);
for i=1:size(file,2)
    loco_com(i).cell_ID=file(i).cell_ID;
    loco_com(i).session_ID=file(i).file_name;
    loco_com(i).CR_fac=file(i).CR_fac;
    loco_com(i).CR_sup=file(i).CR_sup;
    
    if file(i).CR_fac>0
       loco_com(i).mod_fac_amp=max([file(i).mod_info.CRf.peak]) / file(i).(all_info).sss_all.psth.CR_trial.avg_frq*100-100; 
       if loco_com(i).mod_fac_amp<20
          loco_com(i).CR_fac=0;
       end
    else
       loco_com(i).mod_fac_amp=0; 
    end
    if file(i).CR_sup>0
       loco_com(i).mod_sup_amp=min([file(i).mod_info.CRs.peak]) / file(i).(all_info).sss_all.psth.CR_trial.avg_frq*100-100;    
       if loco_com(i).mod_sup_amp>-20
          loco_com(i).CR_sup=0;
       end
    else
       loco_com(i).mod_sup_amp=0;  
    end   
    CR_onset=struct('CH_trial',[],'CL_trial',[]);
    CR_amp=struct('CH_trial',[],'CL_trial',[]);
    bsl_frq=struct('NO_avg',[],'CH_trial',[],'CL_trial',[],'NO_trial',[]);
    test_frq=struct('NO_avg',[],'CH_trial',[],'CL_trial',[],'NO_trial',[]);
    CR_onset_CH=zeros(size(file(i).(all_info).ttt.CH_trial,2),2);
    CR_amp_CH=zeros(size(file(i).(all_info).ttt.CH_trial,2),2);    
    bsl_frq_CH=zeros(size(file(i).(all_info).ttt.CH_trial,2),2);
    test_frq_CH=zeros(size(file(i).(all_info).ttt.CH_trial,2),2);
    CR_onset_CL=zeros(size(file(i).(all_info).ttt.CL_trial,2),2);
    CR_amp_CL=zeros(size(file(i).(all_info).ttt.CL_trial,2),2);
    bsl_frq_CL=zeros(size(file(i).(all_info).ttt.CL_trial,2),2);
    test_frq_CL=zeros(size(file(i).(all_info).ttt.CL_trial,2),2);
    CR_onset_NO=zeros(size(file(i).(all_info).ttt.nonCR_trial,2),2);
    bsl_frq_NO=zeros(size(file(i).(all_info).ttt.nonCR_trial,2),2);
    test_frq_NO=zeros(size(file(i).(all_info).ttt.nonCR_trial,2),2);

    for j=1:size(file(i).(all_info).ttt.CH_trial,2)
        CR_onset_CH(j,1)=file(i).(all_info).ttt.CH_trial(j).trial_num;
        CR_onset_CH(j,2)=file(i).(all_info).ttt.CH_trial(j).(blk_info).CR_onset*1000;
        CR_amp_CH(j,1)=file(i).(all_info).ttt.CH_trial(j).trial_num;
        CR_amp_CH(j,2)=file(i).(all_info).ttt.CH_trial(j).(blk_info).CR_amp*100;
        bsl_frq_CH(j,1)=file(i).(all_info).ttt.CH_trial(j).trial_num;
        spk_bsl_CH=file(i).(all_info).ttt.CH_trial(j).spk_time(file(i).(all_info).ttt.CH_trial(j).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.CH_trial(j).spk_time<0);
        bsl_frq_CH(j,2)=length(spk_bsl_CH)/t_pre*1000;
        test_frq_CH(j,1)=file(i).(all_info).ttt.CH_trial(j).trial_num;
        spk_test_CH=file(i).(all_info).ttt.CH_trial(j).spk_time(file(i).(all_info).ttt.CH_trial(j).spk_time>=0 & file(i).(all_info).ttt.CH_trial(j).spk_time<t_post/1000);
        test_frq_CH(j,2)=length(spk_test_CH)/t_post*1000-bsl_frq_CH(j,2);
    end
    
    for j=1:size(file(i).(all_info).ttt.CL_trial,2)
        CR_onset_CL(j,1)=file(i).(all_info).ttt.CL_trial(j).trial_num;
        CR_onset_CL(j,2)=file(i).(all_info).ttt.CL_trial(j).(blk_info).CR_onset*1000;
        CR_amp_CL(j,1)=file(i).(all_info).ttt.CL_trial(j).trial_num;
        CR_amp_CL(j,2)=file(i).(all_info).ttt.CL_trial(j).(blk_info).CR_amp*100;        
        bsl_frq_CL(j,1)=file(i).(all_info).ttt.CL_trial(j).trial_num;
        spk_bsl_CL=file(i).(all_info).ttt.CL_trial(j).spk_time(file(i).(all_info).ttt.CL_trial(j).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.CL_trial(j).spk_time<0);
        bsl_frq_CL(j,2)=length(spk_bsl_CL)/t_pre*1000;
        test_frq_CL(j,1)=file(i).(all_info).ttt.CL_trial(j).trial_num;
        spk_test_CL=file(i).(all_info).ttt.CL_trial(j).spk_time(file(i).(all_info).ttt.CL_trial(j).spk_time>=0 & file(i).(all_info).ttt.CL_trial(j).spk_time<t_post/1000);
        test_frq_CL(j,2)=length(spk_test_CL)/t_post*1000-bsl_frq_CL(j,2);
    end    
    
     for j=1:size(file(i).(all_info).ttt.nonCR_trial,2)
        bsl_frq_NO(j,1)=file(i).(all_info).ttt.nonCR_trial(j).trial_num;
        spk_bsl_NO=file(i).(all_info).ttt.nonCR_trial(j).spk_time(file(i).(all_info).ttt.nonCR_trial(j).spk_time>=-t_pre/1000 & file(i).(all_info).ttt.nonCR_trial(j).spk_time<0);
        bsl_frq_NO(j,2)=length(spk_bsl_CL)/t_pre*1000;
        test_frq_NO(j,1)=file(i).(all_info).ttt.nonCR_trial(j).trial_num;
        spk_test_NO=file(i).(all_info).ttt.nonCR_trial(j).spk_time(file(i).(all_info).ttt.nonCR_trial(j).spk_time>=0 & file(i).(all_info).ttt.nonCR_trial(j).spk_time<t_post/1000);
        test_frq_NO(j,2)=length(spk_test_NO)/t_post*1000-bsl_frq_NO(j,2);
     end       
    
    loco_com(i).CR_onset_H=mean(CR_onset_CH(:,2));
    loco_com(i).CR_amp_H=mean(CR_amp_CH(:,2));
    loco_com(i).bsl_frq_H=mean(bsl_frq_CH(:,2));
    loco_com(i).test_frq_H=mean(test_frq_CH(:,2));
    CR_onset.CH_trial=CR_onset_CH;
    bsl_frq.CH_trial=bsl_frq_CH;
    test_frq.CH_trial=test_frq_CH;    
    
    loco_com(i).CR_onset_L=mean(CR_onset_CL(:,2));
    loco_com(i).CR_amp_L=mean(CR_amp_CL(:,2));
    loco_com(i).bsl_frq_L=mean(bsl_frq_CL(:,2));
    loco_com(i).test_frq_L=mean(test_frq_CL(:,2));
    CR_onset.CL_trial=CR_onset_CL;
    bsl_frq.CL_trial=bsl_frq_CL;
    test_frq.CL_trial=test_frq_CL; 
    
    bsl_frq.NO_avg=mean(bsl_frq_NO(:,2));
    test_frq.NO_avg=mean(test_frq_NO(:,2));
    bsl_frq.NO_trial=bsl_frq_NO;
    test_frq.NO_trial=test_frq_NO; 
    
    loco_com(i).p_CR_onset=ranksum(CR_onset_CH(:,2),CR_onset_CL(:,2));
    loco_com(i).p_CR_amp=ranksum(CR_amp_CH(:,2),CR_amp_CL(:,2));
    loco_com(i).p_bsl_frq=ranksum(bsl_frq_CH(:,2),bsl_frq_CL(:,2));
    loco_com(i).p_test_frq=ranksum(test_frq_CH(:,2),test_frq_CL(:,2));
    
    loco_com(i).CR_onset=CR_onset;
    loco_com(i).CR_amp=CR_amp;
    loco_com(i).bsl_frq=bsl_frq;
    loco_com(i).test_frq=test_frq;
end