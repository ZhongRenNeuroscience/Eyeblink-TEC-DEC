% Trace or delay modulation onset/peak time vs. CR onset/peak time

file=mod_list_trace;
align_info_1='align_info';
bhv_file_D=blk_sss_trace;
% ttt_list_D=trial_mod_list_D;
t_pre=-250;
t_post=500;


fac_idx_D=0;
sup_idx_D=0;

mod_list=struct('fac_list_D',[],'sup_list_D',[],'fac_list_T',[],'sup_list_T',[]);
fac_list_D=struct('cell_ID',[],'mod_onset',[],'mod_pkt',[],'CR_onset',[],'CR_pkt',[],'mod_amp',[],'CR_amp',[],'mod_amp_align',[],'mod_pkt_align',[]);
sup_list_D=struct('cell_ID',[],'mod_onset',[],'mod_pkt',[],'CR_onset',[],'CR_pkt',[],'mod_amp',[],'CR_amp',[],'mod_amp_align',[],'mod_pkt_align',[]);
fac_list_T=struct('cell_ID',[],'mod_onset',[],'mod_pkt',[],'CR_onset',[],'CR_pkt',[],'mod_amp',[],'CR_amp',[],'mod_amp_align',[],'mod_pkt_align',[]);
sup_list_T=struct('cell_ID',[],'mod_onset',[],'mod_pkt',[],'CR_onset',[],'CR_pkt',[],'mod_amp',[],'CR_amp',[],'mod_amp_align',[],'mod_pkt_align',[]);

for i=1:size(file,2)
    if ~isempty(file(i).(align_info_1).CR_fac) % && ~isempty(ttt_list_D(i).fac_corr_info.P_amp)
%        if ttt_list_D(i).fac_corr_info.P_amp<0.05
           fac_idx_D=fac_idx_D+1;
           fac_list_D(fac_idx_D).cell_ID=file(i).cell_ID;
           fac_list_D(fac_idx_D).mod_onset=file(i).(align_info_1).CR_fac(1).t_onset;
           [mod_amp,peak_idx]=max([file(i).(align_info_1).CR_fac.peak]);
           fac_list_D(fac_idx_D).mod_pkt=file(i).(align_info_1).CR_fac(peak_idx).t_peak;
%            fac_list_D(fac_idx_D).mod_amp=mod_amp/file(i).(align_info_1).bsl_frq_ex*100-100;
           fac_list_D(fac_idx_D).mod_amp=mod_amp-file(i).(align_info_1).bsl_frq_ex;
           fac_list_D(fac_idx_D).mod_pkt_align=file(i).(align_info_1).CR_fac_align.t_peak;
           fac_list_D(fac_idx_D).mod_amp_align=file(i).(align_info_1).CR_fac_align.peak-100;   
           session_idx=find(strcmp({bhv_file_D.session_path},file(i).file_name));       
           fac_list_D(fac_idx_D).CR_onset=bhv_file_D(session_idx).CR_onset;
           fac_list_D(fac_idx_D).CR_pkt=bhv_file_D(session_idx).CR_pkt;
           fac_list_D(fac_idx_D).CR_amp=bhv_file_D(session_idx).CR_amp;
%        end
    end
    if ~isempty(file(i).(align_info_1).CR_sup) % && ~isempty(ttt_list_D(i).sup_corr_info.P_amp)
%        if ttt_list_D(i).sup_corr_info.P_amp<0.05 
           sup_idx_D=sup_idx_D+1;
           sup_list_D(sup_idx_D).cell_ID=file(i).cell_ID; 
           sup_list_D(sup_idx_D).mod_onset=file(i).(align_info_1).CR_sup(1).t_onset;
           [mod_amp,peak_idx]=min([file(i).(align_info_1).CR_sup.peak]);
           sup_list_D(sup_idx_D).mod_pkt=file(i).(align_info_1).CR_sup(peak_idx).t_peak;
%            sup_list_D(sup_idx_D).mod_amp=mod_amp/file(i).(align_info_1).bsl_frq_ex*100-100;
           sup_list_D(sup_idx_D).mod_amp=mod_amp-file(i).(align_info_1).bsl_frq_ex;
           sup_list_D(sup_idx_D).mod_pkt_align=file(i).(align_info_1).CR_sup_align.t_peak;
           sup_list_D(sup_idx_D).mod_amp_align=file(i).(align_info_1).CR_sup_align.peak-100;   
           session_idx=find(strcmp({bhv_file_D.session_path},file(i).file_name));       
           sup_list_D(sup_idx_D).CR_onset=bhv_file_D(session_idx).CR_onset;
           sup_list_D(sup_idx_D).CR_pkt=bhv_file_D(session_idx).CR_pkt;   
           sup_list_D(sup_idx_D).CR_amp=bhv_file_D(session_idx).CR_amp;
%        end
    end    
end
mod_list.fac_list_D=fac_list_D;
mod_list.sup_list_D=sup_list_D;

file=mod_list_trace;
align_info_1='align_info';
bhv_file_T=blk_sss_trace;
% ttt_list_T=trial_mod_list_T;
t_pre=-250;
t_post=500;

fac_idx_T=0;
sup_idx_T=0;

for i=1:size(file,2)
    if ~isempty(file(i).(align_info_1).CR_fac) % && ~isempty(ttt_list_T(i).fac_corr_info.P_amp)
%        if ttt_list_T(i).fac_corr_info.P_amp<0.05
           fac_idx_T=fac_idx_T+1;
           fac_list_T(fac_idx_T).cell_ID=file(i).cell_ID;
           fac_list_T(fac_idx_T).mod_onset=file(i).(align_info_1).CR_fac(1).t_onset;
           [mod_amp,peak_idx]=max([file(i).(align_info_1).CR_fac.peak]);
           fac_list_T(fac_idx_T).mod_pkt=file(i).(align_info_1).CR_fac(peak_idx).t_peak;
%            fac_list_T(fac_idx_T).mod_amp=mod_amp/file(i).(align_info_1).bsl_frq_ex*100-100;
           fac_list_T(fac_idx_T).mod_amp=mod_amp-file(i).(align_info_1).bsl_frq_ex;
           fac_list_T(fac_idx_T).mod_pkt_align=file(i).(align_info_1).CR_fac_align.t_peak;
           fac_list_T(fac_idx_T).mod_amp_align=file(i).(align_info_1).CR_fac_align.peak-100;       
           session_idx=find(strcmp({bhv_file_T.session_path},file(i).file_name));       
           fac_list_T(fac_idx_T).CR_onset=bhv_file_T(session_idx).CR_onset;
           fac_list_T(fac_idx_T).CR_pkt=bhv_file_T(session_idx).CR_pkt;
           fac_list_T(fac_idx_T).CR_amp=bhv_file_T(session_idx).CR_amp;
%        end
    end
    if ~isempty(file(i).(align_info_1).CR_sup) % && ~isempty(ttt_list_T(i).sup_corr_info.P_amp)
%        if ttt_list_T(i).sup_corr_info.P_amp<0.05  
           sup_idx_T=sup_idx_T+1;
           sup_list_T(sup_idx_T).cell_ID=file(i).cell_ID; 
           sup_list_T(sup_idx_T).mod_onset=file(i).(align_info_1).CR_sup(1).t_onset;
           [mod_amp,peak_idx]=min([file(i).(align_info_1).CR_sup.peak]);
           sup_list_T(sup_idx_T).mod_pkt=file(i).(align_info_1).CR_sup(peak_idx).t_peak;
           sup_list_T(sup_idx_T).mod_amp=mod_amp-file(i).(align_info_1).bsl_frq_ex;
%          sup_list_T(sup_idx_T).mod_amp=mod_amp/file(i).(align_info_1).bsl_frq_ex*100-100;
           sup_list_T(sup_idx_T).mod_pkt_align=file(i).(align_info_1).CR_sup_align.t_peak;
           sup_list_T(sup_idx_T).mod_amp_align=file(i).(align_info_1).CR_sup_align.peak-100;   
           session_idx=find(strcmp({bhv_file_T.session_path},file(i).file_name));       
           sup_list_T(sup_idx_T).CR_onset=bhv_file_T(session_idx).CR_onset;
           sup_list_T(sup_idx_T).CR_pkt=bhv_file_T(session_idx).CR_pkt;    
           sup_list_T(sup_idx_T).CR_amp=bhv_file_T(session_idx).CR_amp;
%        end
    end    
end
mod_list.fac_list_T=fac_list_T;
mod_list.sup_list_T=sup_list_T;
% 
% [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([fac_list_D.CR_onset],[fac_list_T.CR_onset]);
% [mod_mean_D,mod_mean_T,mod_std_D,mod_std_T]=mean_std_cal([fac_list_D.mod_onset],[fac_list_T.mod_onset]);
% 
% figure;
% subplot(3,2,1)
% for i=1:size(fac_list_D,2)
%     plot(fac_list_D(i).mod_onset,fac_list_D(i).CR_onset,'.','Color',[1 0.5 0])
%     hold on  
% end
% for i=1:size(fac_list_T,2)
%     plot(fac_list_T(i).mod_onset,fac_list_T(i).CR_onset,'.','Color',[0.5 0 1])
%     hold on  
% end
% plot(mod_mean_D,CR_mean_D,'s','Color',[1 0.5 0])
% hold on
% errorbar(mod_mean_D,CR_mean_D,CR_std_D/sqrt(fac_idx_D),CR_std_D/sqrt(fac_idx_D),...
%     mod_std_D/sqrt(fac_idx_D),mod_std_D/sqrt(fac_idx_D),'Color',[1 0.5 0]);
% hold on
% plot(mod_mean_T,CR_mean_T,'s','Color',[0.5 0 1])
% hold on
% errorbar(mod_mean_T,CR_mean_T,CR_std_T/sqrt(fac_idx_T),CR_std_T/sqrt(fac_idx_T),...
%     mod_std_T/sqrt(fac_idx_T),mod_std_T/sqrt(fac_idx_T),'Color',[0.5 0 1]);
% hold on
% xlim([0 500]);
% ylim([0 500]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% xlabel('Modulation onset (ms)');
% ylabel('CR onset (ms)');
% xticks(0:50:500);
% yticks(0:50:500);
% title('Facilitation cells');
% 
% [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([sup_list_D.CR_onset],[sup_list_T.CR_onset]);
% [mod_mean_D,mod_mean_T,mod_std_D,mod_std_T]=mean_std_cal([sup_list_D.mod_onset],[sup_list_T.mod_onset]);
% 
% subplot(3,2,2)
% for i=1:size(sup_list_D,2)
%     plot(sup_list_D(i).mod_onset,sup_list_D(i).CR_onset,'.','Color',[1 0.5 0])
%     hold on  
% end
% for i=1:size(sup_list_T,2)
%     plot(sup_list_T(i).mod_onset,sup_list_T(i).CR_onset,'.','Color',[0.5 0 1])
%     hold on  
% end
% plot(mod_mean_D,CR_mean_D,'s','Color',[1 0.5 0])
% hold on
% errorbar(mod_mean_D,CR_mean_D,CR_std_D/sqrt(sup_idx_D),CR_std_D/sqrt(sup_idx_D),...
%     mod_std_D/sqrt(sup_idx_D),mod_std_D/sqrt(sup_idx_D),'Color',[1 0.5 0]);
% hold on
% plot(mod_mean_T,CR_mean_T,'s','Color',[0.5 0 1])
% hold on
% errorbar(mod_mean_T,CR_mean_T,CR_std_T/sqrt(sup_idx_T),CR_std_T/sqrt(sup_idx_T),...
%     mod_std_T/sqrt(sup_idx_T),mod_std_T/sqrt(sup_idx_T),'Color',[0.5 0 1]);
% hold on
% xlim([0 500]);
% ylim([0 500]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% xlabel('Modulation onset (ms)');
% ylabel('CR onset (ms)');
% xticks(0:50:500);
% yticks(0:50:500);
% title('Suppression cells');
% 
% [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([fac_list_D.CR_pkt],[fac_list_T.CR_pkt]);
% [mod_mean_D,mod_mean_T,mod_std_D,mod_std_T]=mean_std_cal([fac_list_D.mod_pkt],[fac_list_T.mod_pkt]);
% 
% subplot(3,2,3)
% for i=1:size(fac_list_D,2)
%     plot(fac_list_D(i).mod_pkt,fac_list_D(i).CR_pkt,'.','Color',[1 0.5 0])
%     hold on  
% end
% for i=1:size(fac_list_T,2)
%     plot(fac_list_T(i).mod_pkt,fac_list_T(i).CR_pkt,'.','Color',[0.5 0 1])
%     hold on  
% end
% plot(mod_mean_D,CR_mean_D,'s','Color',[1 0.5 0])
% hold on
% errorbar(mod_mean_D,CR_mean_D,CR_std_D/sqrt(fac_idx_D),CR_std_D/sqrt(fac_idx_D),...
%     mod_std_D/sqrt(fac_idx_D),mod_std_D/sqrt(fac_idx_D),'Color',[1 0.5 0]);
% hold on
% plot(mod_mean_T,CR_mean_T,'s','Color',[0.5 0 1])
% hold on
% errorbar(mod_mean_T,CR_mean_T,CR_std_T/sqrt(fac_idx_T),CR_std_T/sqrt(fac_idx_T),...
%     mod_std_T/sqrt(fac_idx_T),mod_std_T/sqrt(fac_idx_T),'Color',[0.5 0 1]);
% hold on
% xlim([0 500]);
% ylim([0 500]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% xlabel('Modulation peak time (ms)');
% ylabel('CR peak time (ms)');
% xticks(0:50:500);
% yticks(0:50:500);
% 
% [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([sup_list_D.CR_pkt],[sup_list_T.CR_pkt]);
% [mod_mean_D,mod_mean_T,mod_std_D,mod_std_T]=mean_std_cal([sup_list_D.mod_pkt],[sup_list_T.mod_pkt]);
% 
% subplot(3,2,4)
% for i=1:size(sup_list_D,2)
%     plot(sup_list_D(i).mod_pkt,sup_list_D(i).CR_pkt,'.','Color',[1 0.5 0])
%     hold on  
% end
% for i=1:size(sup_list_T,2)
%     plot(sup_list_T(i).mod_pkt,sup_list_T(i).CR_pkt,'.','Color',[0.5 0 1])
%     hold on  
% end
% plot(mod_mean_D,CR_mean_D,'s','Color',[1 0.5 0])
% hold on
% errorbar(mod_mean_D,CR_mean_D,CR_std_D/sqrt(sup_idx_D),CR_std_D/sqrt(sup_idx_D),...
%     mod_std_D/sqrt(sup_idx_D),mod_std_D/sqrt(sup_idx_D),'Color',[1 0.5 0]);
% hold on
% plot(mod_mean_T,CR_mean_T,'s','Color',[0.5 0 1])
% hold on
% errorbar(mod_mean_T,CR_mean_T,CR_std_T/sqrt(sup_idx_T),CR_std_T/sqrt(sup_idx_T),...
%     mod_std_T/sqrt(sup_idx_T),mod_std_T/sqrt(sup_idx_T),'Color',[0.5 0 1]);
% hold on
% xlim([0 500]);
% ylim([0 500]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% xlabel('Modulation peak time (ms)');
% ylabel('CR peak time (ms)');
% xticks(0:50:500);
% yticks(0:50:500);
% 
% [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([fac_list_D.CR_amp],[fac_list_T.CR_amp]);
% [mod_mean_D,mod_mean_T,mod_std_D,mod_std_T]=mean_std_cal([fac_list_D.mod_amp],[fac_list_T.mod_amp]);
% 
% subplot(3,2,5)
% for i=1:size(fac_list_D,2)
%     plot(fac_list_D(i).mod_amp,fac_list_D(i).CR_amp,'.','Color',[1 0.5 0])
%     hold on  
% end
% for i=1:size(fac_list_T,2)
%     plot(fac_list_T(i).mod_amp,fac_list_T(i).CR_amp,'.','Color',[0.5 0 1])
%     hold on  
% end
% plot(mod_mean_D,CR_mean_D,'s','Color',[1 0.5 0])
% hold on
% errorbar(mod_mean_D,CR_mean_D,CR_std_D/sqrt(fac_idx_D),CR_std_D/sqrt(fac_idx_D),...
%     mod_std_D/sqrt(fac_idx_D),mod_std_D/sqrt(fac_idx_D),'Color',[1 0.5 0]);
% hold on
% plot(mod_mean_T,CR_mean_T,'s','Color',[0.5 0 1])
% hold on
% errorbar(mod_mean_T,CR_mean_T,CR_std_T/sqrt(fac_idx_T),CR_std_T/sqrt(fac_idx_T),...
%     mod_std_T/sqrt(fac_idx_T),mod_std_T/sqrt(fac_idx_T),'Color',[0.5 0 1]);
% hold on
% xlim([0 400]);
% ylim([0 100]);
% % line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% xlabel('Modulation amplitude (%)');
% ylabel('CR amplitude (%)');
% xticks(0:50:400);
% yticks(0:20:100);
% 
% % fac_amp_corr_D=zeros(size(fac_list_D,2),3);
% % fac_amp_corr_T=zeros(size(fac_list_T,2),3);
% % fac_amp_corr_D(:,1)=[fac_list_D.mod_amp];
% % fac_amp_corr_D(:,2)=[fac_list_D.CR_amp];
% % fac_amp_corr_T(:,1)=[fac_list_T.mod_amp];
% % fac_amp_corr_T(:,2)=[fac_list_T.CR_amp];
% % [R_fac_D,P_fac_D]=corrcoef(fac_amp_corr_D(:,1),fac_amp_corr_D(:,2));
% % p_fac_D=polyfit(fac_amp_corr_D(:,1),fac_amp_corr_D(:,2),1);
% % reg_fac_D=p_fac_D(1)*fac_amp_corr_D(:,1)+p_fac_D(2);
% % fac_amp_corr_D(:,3)=reg_fac_D; 
% % [R_fac_T,P_fac_T]=corrcoef(fac_amp_corr_T(:,1),fac_amp_corr_T(:,2));
% % p_fac_T=polyfit(fac_amp_corr_T(:,1),fac_amp_corr_T(:,2),1);
% % reg_fac_T=p_fac_T(1)*fac_amp_corr_T(:,1)+p_fac_T(2);
% % fac_amp_corr_T(:,3)=reg_fac_T; 
% % 
% % plot(fac_amp_corr_D(:,1),fac_amp_corr_D(:,3),'-','Color',[1 0.5 0])
% % hold on
% % text_1=['r=' num2str(R_fac_D(2,1)) 'p=' num2str(P_fac_D(2,1))];
% % text(25,90,text_1,'Color',[1 0.5 0]);
% % hold on
% % plot(fac_amp_corr_T(:,1),fac_amp_corr_T(:,3),'-','Color',[1 0 0.5])
% % hold on
% % text_2=['r=' num2str(R_fac_T(2,1)) 'p=' num2str(P_fac_T(2,1))];
% % text(225,90,text_2,'Color',[1 0 0.5]);
% % hold on
% 
% [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([sup_list_D.CR_amp],[sup_list_T.CR_amp]);
% [mod_mean_D,mod_mean_T,mod_std_D,mod_std_T]=mean_std_cal(-[sup_list_D.mod_amp],-[sup_list_T.mod_amp]);
% 
% subplot(3,2,6)
% for i=1:size(sup_list_D,2)
%     plot(-sup_list_D(i).mod_amp,sup_list_D(i).CR_amp,'.','Color',[1 0.5 0])
%     hold on  
% end
% for i=1:size(sup_list_T,2)
%     plot(-sup_list_T(i).mod_amp,sup_list_T(i).CR_amp,'.','Color',[0.5 0 1])
%     hold on  
% end
% plot(mod_mean_D,CR_mean_D,'s','Color',[1 0.5 0])
% hold on
% errorbar(mod_mean_D,CR_mean_D,CR_std_D/sqrt(sup_idx_D),CR_std_D/sqrt(sup_idx_D),...
%     mod_std_D/sqrt(sup_idx_D),mod_std_D/sqrt(sup_idx_D),'Color',[1 0.5 0]);
% hold on
% plot(mod_mean_T,CR_mean_T,'s','Color',[0.5 0 1])
% hold on
% errorbar(mod_mean_T,CR_mean_T,CR_std_T/sqrt(sup_idx_T),CR_std_T/sqrt(sup_idx_T),...
%     mod_std_T/sqrt(sup_idx_T),mod_std_T/sqrt(sup_idx_T),'Color',[0.5 0 1]);
% hold on
% xlim([0 100]);
% ylim([0 100]);
% % line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% xlabel('Modulation amplitude (%)');
% ylabel('CR amplitude (%)');
% xticks(0:20:100);
% yticks(0:20:100);
% 
% figure;
% stair_plot=struct('plot_idx',[],'item',[],'data_D',[],'data_T',[]);
% subplot(6,2,1)
% h1=histogram([fac_list_D.mod_onset]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([fac_list_T.mod_onset]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Fac mod onset');
% plot_idx=1;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Fac mod onset';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,3)
% h1=histogram([fac_list_D.CR_onset]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([fac_list_T.CR_onset]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Fac CR onset');
% plot_idx=3;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Fac CR onset';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,2)
% h1=histogram([sup_list_D.mod_onset]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([sup_list_T.mod_onset]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Sup mod onset');
% plot_idx=2;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Sup mod onset';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,4)
% h1=histogram([sup_list_D.CR_onset]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([sup_list_T.CR_onset]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Sup CR onset');
% plot_idx=4;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Sup CR onset';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,5)
% h1=histogram([fac_list_D.mod_pkt]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([fac_list_T.mod_pkt]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Fac mod pkt');
% plot_idx=5;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Fac mod pkt';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,7)
% h1=histogram([fac_list_D.CR_pkt]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([fac_list_T.CR_pkt]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Fac CR pkt');
% plot_idx=7;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Fac CR pkt';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,6)
% h1=histogram([sup_list_D.mod_pkt]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([sup_list_T.mod_pkt]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Sup mod pkt');
% plot_idx=6;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Sup mod pkt';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,8)
% h1=histogram([sup_list_D.CR_pkt]);
% h1.BinWidth=50;
% h1.BinLimits=[0 250];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([sup_list_T.CR_pkt]);
% h2.BinWidth=50;
% h2.BinLimits=[0 500];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 500]);
% ylim([0 1]);
% xticks(0:50:500);
% title('Sup CR pkt');
% plot_idx=8;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Sup CR pkt';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,9)
% h1=histogram([fac_list_D.mod_amp]);
% h1.BinWidth=50;
% h1.BinLimits=[0 400];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([fac_list_T.mod_amp]);
% h2.BinWidth=50;
% h2.BinLimits=[0 400];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 400]);
% ylim([0 1]);
% xticks(0:50:400);
% title('Fac mod amp');
% plot_idx=9;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Fac mod amp';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,11)
% h1=histogram([fac_list_D.CR_amp]);
% h1.BinWidth=20;
% h1.BinLimits=[0 100];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([fac_list_T.CR_amp]);
% h2.BinWidth=20;
% h2.BinLimits=[0 100];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 100]);
% ylim([0 1]);
% xticks(0:20:100);
% title('Fac CR amp');
% plot_idx=11;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Fac CR amp';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,10)
% h1=histogram(-[sup_list_D.mod_amp]);
% h1.BinWidth=20;
% h1.BinLimits=[0 100];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram(-[sup_list_T.mod_amp]);
% h2.BinWidth=20;
% h2.BinLimits=[0 100];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 100]);
% ylim([0 1]);
% xticks(0:20:100);
% title('Sup mod amp');
% plot_idx=10;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Sup mod amp';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% subplot(6,2,12)
% h1=histogram([sup_list_D.CR_amp]);
% h1.BinWidth=20;
% h1.BinLimits=[0 100];
% h1.FaceColor=[1 0.5 0];
% h1.Normalization='probability';
% hold on
% h2=histogram([sup_list_T.CR_amp]);
% h2.BinWidth=20;
% h2.BinLimits=[0 100];
% h2.FaceColor=[0.5 0 1];
% h2.Normalization='probability';
% hold on
% xlim([0 100]);
% ylim([0 1]);
% xticks(0:20:100);
% title('Sup CR amp');
% plot_idx=12;
% stair_plot(plot_idx).plot_idx=plot_idx;
% stair_plot(plot_idx).item='Sup CR amp';
% data_D=zeros(size(h1.BinEdges,2),2);
% data_T=zeros(size(h2.BinEdges,2),2);
% data_D(:,1)=h1.BinEdges';
% data_D(1:end-1,2)=h1.BinCounts'/size(h1.Data,2);
% % data_D(end,2)=data_D(end-1,2);
% data_T(:,1)=h2.BinEdges';
% data_T(1:end-1,2)=h2.BinCounts'/size(h2.Data,2);
% % data_T(end,2)=data_T(end-1,2);
% stair_plot(plot_idx).data_D=data_D;
% stair_plot(plot_idx).data_T=data_T;
% 
% figure;
% for i=1:12
%     subplot(6,2,stair_plot(i).plot_idx)
%     stairs(stair_plot(i).data_D(:,1),stair_plot(i).data_D(:,2),'Color',[1 0.5 0])
%     hold on
%     stairs(stair_plot(i).data_T(:,1),stair_plot(i).data_T(:,2),'Color',[0.5 0 1])
%     hold on
%     xlim([0 stair_plot(i).data_T(end,1)]);
%     ylim([0 1]);
%     xticks(stair_plot(i).data_T(:,1));
%     yticks(0:0.5:1);   
%     title([stair_plot(i).item]);
% end
% 
% % figure;
% % subplot(2,1,1)
% % [CS_mean_D,CS_mean_T,CS_std_D,CS_std_T]=mean_std_cal([fac_list_D.mod_amp],[fac_list_T.mod_amp]);
% % [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([fac_list_D.mod_amp_align],[fac_list_T.mod_amp_align]);
% % lim=300;
% % for i=1:size(fac_list_D,2)
% %     plot(fac_list_D(i).mod_amp_align,fac_list_D(i).mod_amp,'.','Color',[1 0.5 0])
% %     hold on  
% % end
% % for i=1:size(fac_list_T,2)
% %     plot(fac_list_T(i).mod_amp_align,fac_list_T(i).mod_amp,'.','Color',[0.5 0 1])
% %     hold on  
% % end
% % plot(CR_mean_D,CS_mean_D,'Color',[1 0.5 0])
% % hold on
% % errorbar(CR_mean_D,CS_mean_D,CS_std_D/sqrt(fac_idx_D),CS_std_D/sqrt(fac_idx_D),...
% %     CR_std_D/sqrt(fac_idx_D),CR_std_D/sqrt(fac_idx_D),'Color',[1 0.5 0]);
% % hold on
% % plot(CR_mean_T,CS_mean_T,'Color',[0.5 0 1])
% % hold on
% % errorbar(CR_mean_T,CS_mean_T,CS_std_T/sqrt(fac_idx_T),CS_std_T/sqrt(fac_idx_T),...
% %     CR_std_T/sqrt(fac_idx_T),CR_std_T/sqrt(fac_idx_T),'Color',[0.5 0 1]);
% % hold on
% % xlim([0 lim]);
% % ylim([0 lim]);
% % line([0 lim],[0 lim],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% % xlabel('CR aligned facilitation (%)');
% % ylabel('CS aligned facilitation (%)');
% % xticks(0:50:lim);
% % yticks(0:50:lim);
% % 
% % subplot(2,1,2)
% % [CS_mean_D,CS_mean_T,CS_std_D,CS_std_T]=mean_std_cal([sup_list_D.mod_amp],[sup_list_T.mod_amp]);
% % [CR_mean_D,CR_mean_T,CR_std_D,CR_std_T]=mean_std_cal([sup_list_D.mod_amp_align],[sup_list_T.mod_amp_align]);
% % lim=100;
% % for i=1:size(sup_list_D,2)
% %     plot(-sup_list_D(i).mod_amp_align,-sup_list_D(i).mod_amp,'.','Color',[1 0.5 0])
% %     hold on  
% % end
% % for i=1:size(sup_list_T,2)
% %     plot(-sup_list_T(i).mod_amp_align,-sup_list_T(i).mod_amp,'.','Color',[0.5 0 1])
% %     hold on  
% % end
% % plot(-CR_mean_D,-CS_mean_D,'Color',[1 0.5 0])
% % hold on
% % errorbar(-CR_mean_D,-CS_mean_D,CS_std_D/sqrt(sup_idx_D),CS_std_D/sqrt(sup_idx_D),...
% %     CR_std_D/sqrt(sup_idx_D),CR_std_D/sqrt(sup_idx_D),'Color',[1 0.5 0]);
% % hold on
% % plot(-CR_mean_T,-CS_mean_T,'Color',[0.5 0 1])
% % hold on
% % errorbar(-CR_mean_T,-CS_mean_T,CS_std_T/sqrt(sup_idx_T),CS_std_T/sqrt(sup_idx_T),...
% %     CR_std_T/sqrt(sup_idx_T),CR_std_T/sqrt(sup_idx_T),'Color',[0.5 0 1]);
% % hold on
% % xlim([0 lim]);
% % ylim([0 lim]);
% % line([0 lim],[0 lim],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% % xlabel('CR aligned suppression (%)');
% % ylabel('CS aligned suppression (%)');
% % xticks(0:20:lim);
% % yticks(0:20:lim);
% 
% % figure;
% % lim=100;
% % for i=1:size(sup_list_D,2)
% %     plot(-sup_list_D(i).mod_amp,-sup_list_D(i).mod_amp_align,'b.')
% %     hold on  
% % end
% % plot(sup_CS_align_mean,sup_CR_align_mean,'bs')
% % hold on
% % errorbar(sup_CS_align_mean,sup_CR_align_mean,sup_CR_align_std/sqrt(sup_idx_D),sup_CR_align_std/sqrt(sup_idx_D),...
% %     sup_CS_align_std/sqrt(sup_idx_D),sup_CS_align_std/sqrt(sup_idx_D),'Color','b');
% % hold on
% % xlim([0 lim]);
% % ylim([0 lim]);
% % line([0 lim],[0 lim],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
% % xlabel('CS aligned suppression (%)');
% % ylabel('CR aligned suppression (%)');
% % xticks(0:20:lim);
% % yticks(0:20:lim);

function [mean_1,mean_2,std_1,std_2]=mean_std_cal(data_1,data_2)
    mean_1=mean(data_1);
    mean_2=mean(data_2);
    std_1=std(data_1);
    std_2=std(data_2);
end