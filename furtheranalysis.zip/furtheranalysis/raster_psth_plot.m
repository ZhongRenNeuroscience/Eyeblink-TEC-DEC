function raster_psth_plot(package,figure_name,t_interval,~,~)

all_info='all_info';
align_info='align_info';

raster_info=struct('cell_ID',[],'trial_info',[]);

for i=424:424
    raster_info(i).cell_ID=package(i).cell_ID;
    trial_info=struct('field',[],'trial_num',[],'CR_onset',[],'spk',[]);
    for j=1:size(package(i).(all_info).ttt.CR_trial,2)
        trial_info(j).field=j;
        trial_info(j).trial_num=package(i).(all_info).ttt.CR_trial(j).trial_num;
        trial_info(j).CR_onset=package(i).(all_info).ttt.CR_trial(j).blk_info_new.CR_onset;
        trial_info(j).spk=package(i).(all_info).ttt.CR_trial(j).spk_time;
    end
    
    trial_info = trial_info(all(~cellfun(@isempty,struct2cell(trial_info))));
    
    raster_info(i).trial_info=trial_info;  
    
    figure('Name',[figure_name num2str(i)],'NumberTitle','off','units','normalized','outerposition',[0 0 1 1]);   
    
%     subplot(3,2,1)
%     hold on
%     
%     behavior_mean=zeros(1550,size(trial_info,2));
%     for m=1:size(trial_info,2)
%         behavior_mean(:,m)=package(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
%     end
%     ymax=max(max(behavior_mean))+0.1;
%     ymin=min(min(behavior_mean))-0.1;
%     line([0 0],[ymin, ymax],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
% %     rectangle('Position',[0,ymin*0.95,250,ymax-ymin],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')
%     line([t_interval t_interval],[ymin, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
%     for m=1:size(trial_info,2)
%         behavior_mean(:,m)=package(i).(all_info).ttt.CR_trial(m).blk_smth(:,2);
%         plot(package(i).(all_info).ttt.CR_trial(m).blk_smth(:,1),package(i).(all_info).ttt.CR_trial(m).blk_smth(:,2),'linewidth',0.5,'color',[0.9 0.9 0.9])
%         hold on
%     end
%     plot(package(i).(all_info).ttt.CR_trial(1).blk_smth(:,1),mean(behavior_mean,2),'Color',[0 0 0],'LineWidth',2)
%     hold on
%     xlim([-250 750]);
%     xticks(-250:250:750);
%     ylim([ymin ymax]);
%     xlabel('Time(ms)');
%     ylabel('Normalized eyelid trace')    
    
    
    subplot(3,2,2)
    rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
    hold on
    
    for m=1:size(trial_info,2)
        hold on
        Y=ones(length(trial_info(m).spk),1)*m;
        plot(trial_info(m).spk*1000,Y,'.','Color',[0.1 0.1 0.1],'MarkerSize',1)
        hold on
%         plot(0,m,'g.')
%         hold on
        plot(trial_info(m).CR_onset*1000,m,'b*')
        hold on
%         plot(t_interval,m,'r.')        
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    line([t_interval t_interval],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
    xlabel('Time(ms)');
    ylabel('Trial number');
    
    subplot(3,2,3)
    yh = max(package(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2)) * 1.01;
    rectangle('Position',[0,0.5,250,yh],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
    hold on
    h = histogram(package(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1));
        h.BinEdges = (min(package(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1))):(max(package(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1)) + 1);
        h.NumBins = size(package(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,1),1);
        h.BinCounts = package(i).(all_info).sss_all.psth.CR_trial.psth_smooth(:,2)';
        h.EdgeColor = [0 0 0];
        h.EdgeAlpha = 0.50;
        h.FaceColor = [0 0.4470 0.7410];
        h.FaceAlpha = 0.75;

    hold on
    line([0 0],[0, yh],'Color',[0 1 0],'LineStyle','--','LineWidth',1.0);
    line([t_interval t_interval],[0, yh],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
    xlabel('Bin No.');
    xlim([-250 750]);
    xticks(-250:250:750);
    ylabel('Est. Spike Freq. (Hz)');
    ylim([0 inf]);
    hold on    
    
    
    [~,index] = sortrows([trial_info.CR_onset].'); 
    trial_info = trial_info(index);
    for n=1:size(trial_info,2)
        if trial_info(n).CR_onset<0.05 || trial_info(n).CR_onset>t_interval/1000*0.9
           trial_info(n).trial_num=[]; 
        end
    end
    trial_info=trial_info(~cellfun(@isempty,{trial_info.trial_num}));

    subplot(3,2,4)
    rectangle('Position',[0,0.5,250,size(trial_info,2)],'FaceColor',[0.6 1 0.8],'EdgeColor',[0.6 1 0.8],'LineWidth',0.5,'LineStyle','none')    
    hold on
    for m=1:size(trial_info,2)
        hold on        
        Y=ones(length(trial_info(m).spk),1)*m;
        plot(trial_info(m).spk*1000,Y,'.','Color',[0.1 0.1 0.1],'MarkerSize',1)
        hold on
%         plot(0,m,'g.')
%         hold on
        plot(trial_info(m).CR_onset*1000,m,'b*')
        hold on
%         plot(t_interval,m,'r.')         
    end
    hold on
    xlim([-250 750]);
    xticks(-250:250:750);
    ylim([0 m]);
    line([t_interval t_interval],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',2.0);
    xlabel('Time(ms)');
    ylabel('Trial number');
    
    subplot(3,2,5)
    ymin=min(min(package(i).(align_info).psth_ex(51:1051,2)),min(package(i).(align_info).psth_align(51:1051,2)))*0.9;   
    ymax=max(max(package(i).(align_info).psth_ex(51:1051,2)),max(package(i).(align_info).psth_align(51:1051,2)))*1.1;   
%     rectangle('Position',[0,ymin_psth_plot+0.5,250,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 1 0.9],'EdgeColor',[0.8 1 0.9],'LineWidth',0.5,'LineStyle','none')       
%     hold on
%     rectangle('Position',[-package(i).(align_info).t_start,ymin_psth_plot+0.5,t_interval-package(i).(align_info).t_end+package(i).(align_info).t_start,ymax_psth_plot-ymin_psth_plot],'FaceColor',[0.8 0.9 1],'EdgeColor',[0.8 0.9 1],'LineWidth',1,'LineStyle','--')       
%     hold on    
    plot(package(i).(align_info).psth_ex(:,1),smooth(package(i).(align_info).psth_ex(:,2),20),'k-','LineWidth',2.0)
    hold on
    plot(package(i).(align_info).psth_align(:,1),smooth(package(i).(align_info).psth_align(:,2),20),'b-','LineWidth',2.0)
    hold on

    line([-package(i).(align_info).t_start -package(i).(align_info).t_start],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
    line([t_interval-package(i).(align_info).t_end t_interval-package(i).(align_info).t_end],[0,ymax],'LineStyle','--','Color',[0 0 1],'LineWidth',2.0);
    line([0 0],[0,ymax],'LineStyle','--','Color',[0 1 0],'LineWidth',1.0);
    hold on
    xlim([-500 750]);
    ylim([ymin ymax]); 
    xticks(-500:250:750);
    xlabel('Time(ms)');
    ylabel('Est. Spike Freq. (Hz)');
    hold on
    
    subplot(3,2,6)
    rectangle('Position',[-package(i).(align_info).t_start,0.5,t_interval-package(i).(align_info).t_end+package(i).(align_info).t_start,size(trial_info,2)],'FaceColor',[0.6 0.8 1],'EdgeColor',[0.6 0.8 1],'LineWidth',0.5,'LineStyle','none')       
    hold on   
    for m=1:size(trial_info,2)
        hold on
        Y=ones(length(trial_info(m).spk),1)*m;
        hold on
        plot((trial_info(m).spk-trial_info(m).CR_onset)*1000,Y,'.','Color',[0.1 0.1 0.1],'MarkerSize',1)
        hold on
        plot(-trial_info(m).CR_onset*1000,m,'g.')
        hold on
        plot(0,m,'b*')
        hold on
        plot(t_interval-trial_info(m).CR_onset*1000,m,'r.')        
    end
    hold on
    xlim([-500 500]);
    xticks(-500:250:500);
    ylim([0 m]);
    xlabel('CR onset aligned time(ms)');
    ylabel('Trial number');
    hold on
    
%     saveas(gcf,[figure_name num2str(i) '-' num2str(package(i).CR_fac) '-' num2str(package(i).CR_sup) '.tif']);
%     close all    
end

end