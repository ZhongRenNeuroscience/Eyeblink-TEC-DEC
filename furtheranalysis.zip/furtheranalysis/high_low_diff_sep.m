type='fac';
fac_form=zeros(size(list_mod.fac,2)-2,5);
fac_trial=struct('fac_num',[],'cell_ID',[],'spd_info',[],'hgh_info',[],'hgh_psth',[],'hgh_blk',[],'low_info',[],'low_psth',[],'low_blk',[]);
k=0;
% first loop for each cell
for i=1:size(list_mod.fac,2)
    if i==33 || i==39
        k=k+1;
        continue    
    end
    j=i-k;
    fac_trial(j).fac_num=i;
    fac_trial(j).cell_ID=list_mod.(type)(i).cell_ID;
% second loop for each trial 
    fac_trial(j).spd_info=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),1);
    for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
        fac_trial(j).spd_info(m,1)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info.CR_differential*1000;
    end
    [rank,idx]=sort(fac_trial(j).spd_info);
%     if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 30
%        early=0;
%        late=0;
    if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 40
       hgh=idx(find(idx,20,'last'),1);
       low=idx(find(idx,20,'first'),1);
    else
        sz_mod=mod(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
        sz_group=(size(list_mod.(type)(i).all_info.ttt.CR_trial,2)-sz_mod)/2;
        hgh=idx(find(idx,sz_group+sz_mod,'last'),1);
        low=idx(find(idx,sz_group,'first'),1);
    end
    fac_trial(j).hgh_info=struct('trial_num',[],'spd',[],'ifr',[],'blk',[]);
    hgh_ifr_form=zeros(32001,size(hgh,1));
    hgh_blk_form=zeros(31000,size(hgh,1));
    fac_trial(j).low_info=struct('trial_num',[],'spd',[],'ifr',[],'blk',[]);
    low_ifr_form=zeros(32001,size(low,1));
    low_blk_form=zeros(31000,size(low,1));
    for n=1:size(hgh,1)
        fac_trial(j).hgh_info(n).trial_num=hgh(n,1);
        fac_trial(j).hgh_info(n).spd=list_mod.(type)(i).all_info.ttt.CR_trial(hgh(n,1)).blk_info.CR_differential*1000;
        fac_trial(j).hgh_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(hgh(n,1)).ifr_org_Gau(:,2);
        fac_trial(j).hgh_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(hgh(n,1)).blk_trace(:,4);
        hgh_ifr_form(:,n)=fac_trial(j).hgh_info(n).ifr;
        hgh_blk_form(:,n)=fac_trial(j).hgh_info(n).blk;
    end
    for n=1:size(low,1)
        fac_trial(j).low_info(n).trial_num=low(n,1);
        fac_trial(j).low_info(n).spd=list_mod.(type)(i).all_info.ttt.CR_trial(low(n,1)).blk_info.CR_differential*1000;
        fac_trial(j).low_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(low(n,1)).ifr_org_Gau(:,2);
        fac_trial(j).low_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(low(n,1)).blk_trace(:,4);
        low_ifr_form(:,n)=fac_trial(j).low_info(n).ifr;
        low_blk_form(:,n)=fac_trial(j).low_info(n).blk;
    end
    fac_form(j,1)=i;
    fac_form(j,2)=mean([fac_trial(j).hgh_info.spd]);
    fac_form(j,3)=mean([fac_trial(j).low_info.spd]);
    hgh_psth=zeros(32001,3);
    low_psth=zeros(32001,3);
    hgh_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    hgh_psth(:,2)=mean(hgh_ifr_form,2)*1000;
    hgh_bsl=mean(hgh_psth(hgh_psth(:,1) < 0 & hgh_psth(:,1) >= -500,2));
    hgh_sd=std(hgh_psth(hgh_psth(:,1) < 0 & hgh_psth(:,1) >= -500,2));
    hgh_shrld=hgh_bsl+3*hgh_sd;
    hgh_psth(:,3)=hgh_psth(:,2)/hgh_bsl*100;
    fac_form(j,4)=max(hgh_psth(11001:21001,3));
    
    low_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    low_psth(:,2)=mean(low_ifr_form,2)*1000;
    low_bsl=mean(low_psth(low_psth(:,1)<0 & low_psth(:,1) >= -500,2));
    low_sd=std(low_psth(low_psth(:,1)<0 & low_psth(:,1) >= -500,2));
    low_shrld=low_bsl+3*low_sd;
    low_psth(:,3)=low_psth(:,2)/low_bsl*100;
    fac_form(j,5)=max(low_psth(11001:21001,3));

    
    hgh_blk=zeros(31000,2);
    low_blk=zeros(31000,2);
    hgh_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    hgh_blk(:,2)=mean(hgh_blk_form,2);
    fac_trial(j).hgh_blk=hgh_blk;
    low_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    low_blk(:,2)=mean(low_blk_form,2);
    fac_trial(j).low_blk=low_blk;
    
    fac_trial(j).hgh_psth=hgh_psth;
    fac_trial(j).low_psth=low_psth;
    
    clear idx rank sz_group sz_mod hgh_ifr_form hgh_psth low_ifr_form low_psth 
end
clear i j k m n type

type='sup';
sup_form=zeros(size(list_mod.sup,2),5);
sup_trial=struct('sup_num',[],'cell_ID',[],'spd_info',[],'hgh_info',[],'hgh_psth',[],'hgh_blk',[],'low_info',[],'low_psth',[],'low_blk',[]);
k=0;
% first loop for each cell
for i=1:size(list_mod.sup,2)
    j=i-k;
    sup_trial(j).sup_num=i;
    sup_trial(j).cell_ID=list_mod.(type)(i).cell_ID;
% second loop for each trial 
    sup_trial(j).spd_info=zeros(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),1);
    for m=1:size(list_mod.(type)(i).all_info.ttt.CR_trial,2)
        sup_trial(j).spd_info(m,1)=list_mod.(type)(i).all_info.ttt.CR_trial(m).blk_info.CR_differential*1000;
    end
    [rank,idx]=sort(sup_trial(j).spd_info);
%     if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 30
%        early=0;
%        late=0;
    if size(list_mod.(type)(i).all_info.ttt.CR_trial,2) < 40
       hgh=idx(find(idx,20,'last'),1);
       low=idx(find(idx,20,'first'),1);
    else
        sz_mod=mod(size(list_mod.(type)(i).all_info.ttt.CR_trial,2),2);
        sz_group=(size(list_mod.(type)(i).all_info.ttt.CR_trial,2)-sz_mod)/2;
        hgh=idx(find(idx,sz_group+sz_mod,'last'),1);
        low=idx(find(idx,sz_group,'first'),1);
    end
    sup_trial(j).hgh_info=struct('trial_num',[],'spd',[],'ifr',[],'blk',[]);
    hgh_ifr_form=zeros(32001,size(hgh,1));
    hgh_blk_form=zeros(31000,size(hgh,1));
    sup_trial(j).low_info=struct('trial_num',[],'spd',[],'ifr',[],'blk',[]);
    low_ifr_form=zeros(32001,size(low,1));
    low_blk_form=zeros(31000,size(low,1));
    for n=1:size(hgh,1)
        sup_trial(j).hgh_info(n).trial_num=hgh(n,1);
        sup_trial(j).hgh_info(n).spd=list_mod.(type)(i).all_info.ttt.CR_trial(hgh(n,1)).blk_info.CR_differential*1000;
        sup_trial(j).hgh_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(hgh(n,1)).ifr_org_Gau(:,2);
        sup_trial(j).hgh_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(hgh(n,1)).blk_trace(:,4);
        hgh_ifr_form(:,n)=sup_trial(j).hgh_info(n).ifr;
        hgh_blk_form(:,n)=sup_trial(j).hgh_info(n).blk;
    end
    for n=1:size(low,1)
        sup_trial(j).low_info(n).trial_num=low(n,1);
        sup_trial(j).low_info(n).spd=list_mod.(type)(i).all_info.ttt.CR_trial(low(n,1)).blk_info.CR_differential*1000;
        sup_trial(j).low_info(n).ifr=list_mod.(type)(i).all_info.ttt.CR_trial(low(n,1)).ifr_org_Gau(:,2);
        sup_trial(j).low_info(n).blk=list_mod.(type)(i).all_info.ttt.CR_trial(low(n,1)).blk_trace(:,4);
        low_ifr_form(:,n)=sup_trial(j).low_info(n).ifr;
        low_blk_form(:,n)=sup_trial(j).low_info(n).blk;
    end
    sup_form(j,1)=i;
    sup_form(j,2)=mean([sup_trial(j).hgh_info.spd]);
    sup_form(j,3)=mean([sup_trial(j).low_info.spd]);
    hgh_psth=zeros(32001,3);
    low_psth=zeros(32001,3);
    hgh_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    hgh_psth(:,2)=mean(hgh_ifr_form,2)*1000;
    hgh_bsl=mean(hgh_psth(hgh_psth(:,1) < 0 & hgh_psth(:,1) >= -500,2));
    hgh_sd=std(hgh_psth(hgh_psth(:,1) < 0 & hgh_psth(:,1) >= -500,2));
    hgh_shrld=hgh_bsl-3*hgh_sd;
    hgh_psth(:,3)=hgh_psth(:,2)/hgh_bsl*100;
    sup_form(j,4)=min(hgh_psth(11001:21001,3));
    
    low_psth(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).ifr_org_Gau(:,1);
    low_psth(:,2)=mean(low_ifr_form,2)*1000;
    low_bsl=mean(low_psth(low_psth(:,1)<0 & low_psth(:,1) >= -500,2));
    low_sd=std(low_psth(low_psth(:,1)<0 & low_psth(:,1) >= -500,2));
    low_shrld=low_bsl-3*low_sd;
    low_psth(:,3)=low_psth(:,2)/low_bsl*100;
    sup_form(j,5)=min(low_psth(11001:21001,3));

    
    hgh_blk=zeros(31000,2);
    low_blk=zeros(31000,2);
    hgh_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    hgh_blk(:,2)=mean(hgh_blk_form,2);
    sup_trial(j).hgh_blk=hgh_blk;
    low_blk(:,1)=list_mod.fac(1).all_info.ttt.CR_trial(1).blk_trace(:,2)*1000;
    low_blk(:,2)=mean(low_blk_form,2);
    sup_trial(j).low_blk=low_blk;
    
    sup_trial(j).hgh_psth=hgh_psth;
    sup_trial(j).low_psth=low_psth;
    
    clear hgh low idx rank sz_group sz_mod hgh_ifr_form hgh_psth low_ifr_form low_psth 
end
clear i j k m n type hgh_bsl hgh_sd hgh_shrld low_bsl low_sd low_shrld

figure;
plot(fac_form(:,4)-fac_form(:,5),fac_form(:,2)-fac_form(:,3),'r.')
hold on
plot(sup_form(:,4)-sup_form(:,5),sup_form(:,2)-sup_form(:,3),'b.')
hold on
xlabel('Mod relative peak high-low (%)');
ylabel('CR speed high-low (A.U.)');
xlim([-100 200]);
ylim([0 5]);
% line([0 500],[0 500],'Color',[0 0 0],'LineStyle','--');
line([0 0],[0,5],'Color',[0 0 0],'LineStyle','--');
% legend({'Facilitation','Suppression'},'Location','northwest');
% line([-300,500],[0 0],'Color',[0 0 0],'LineStyle','--');
