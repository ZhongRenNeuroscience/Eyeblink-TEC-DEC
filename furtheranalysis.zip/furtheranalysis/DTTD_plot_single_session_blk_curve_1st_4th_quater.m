sss_list_1=TD_blk_sss;
session_1='T';
session_2='D';


blk_session_1=['behavior_curve_trial_' session_1];
blk_session_2=['behavior_curve_trial_' session_2];
trial_type='norm_trial';

color_21=[1 0.5 0];
color_24=[1 0.8 0.5];
color_11=[0.5 0 1];
color_14=[0.9 0.8 1];

trial_num_split=4;

figure;

for i=17:17%size(sss_list_1,2)
    for j=1:size(sss_list_1(i).(blk_session_1).(trial_type),2)
        smth_curve=smooth_curve(sss_list_1(i).(blk_session_1).(trial_type)(j).blk_curve(:,1),sss_list_1(i).(blk_session_1).(trial_type)(j).blk_curve(:,2)*100,20,5);
        plot(smth_curve(:,1),smth_curve(:,2),'Color',color_11,'LineWidth',1)
        hold on
    end

    sz_2=size(sss_list_1(i).(blk_session_2).(trial_type),2);
    trial_group=quantile(1:sz_2-1,trial_num_split-1);
    trial_group=[0 floor(trial_group(1:trial_num_split-1)) sz_2-1];
    
    for j=trial_group(1)+1:trial_group(2)
        smth_curve=smooth_curve(sss_list_1(i).(blk_session_2).(trial_type)(j).blk_curve(:,1),sss_list_1(i).(blk_session_2).(trial_type)(j).blk_curve(:,2)*100,20,5);
        plot(smth_curve(:,1),smth_curve(:,2),'Color',color_21,'LineWidth',1)
        hold on   
    end
    for j=trial_group(trial_num_split)+1:trial_group(trial_num_split+1)
        smth_curve=smooth_curve(sss_list_1(i).(blk_session_2).(trial_type)(j).blk_curve(:,1),sss_list_1(i).(blk_session_2).(trial_type)(j).blk_curve(:,2)*100,20,5);
        plot(smth_curve(:,1),smth_curve(:,2),'Color',color_24,'LineWidth',1)
        hold on   
    end    
end


xlim([-250 1000]);
ylim([-10 110]);
xticks(-250:250:1000);

function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step+1,2);
    for i=1:(length(x)-bin)/step+1
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end