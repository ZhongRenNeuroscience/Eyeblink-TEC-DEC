% Data arrangement
mod_list=mod_list_TD;
cell_list=TD_list_sim_prb;
blk_sss_list=TD_blk_sss;
align_info_1='align_info_T';
align_info_2='align_info_D';
t_pre=-250;
% t_post=750;
% bin=20;
% step=10;

mod_cell_number=struct('fac_cell',[],'sup_cell',[],'non_cell',[]);
fac_cell=struct('cell_ID',[],'CR_onset_D',[],'CR_onset_T',[],'mod_onset_1',[],'mod_onset_2',[],'mod_change_1',[],'mod_change_2',[],'mod_change_t250',[],'mod_pkt_t250',[],'mod_pkt_1',[],'mod_pkt_2',[],...
    'mod_change_prb_1',[],'mod_change_prb_2',[],'mod_pkt_prb_1',[],'mod_pkt_prb_2',[],...
    'mod_change_align_1',[],'mod_change_align_2',[],'mod_pkt_align_1',[],'mod_pkt_align_2',[]);
% fac_cell_single=struct('cell_ID',[],'mod_onset_1',[],'mod_onset_2',[],'mod_change_1',[],'mod_change_2',[],'mod_pkt_1',[],'mod_pkt_2',[]);
sup_cell=struct('cell_ID',[],'CR_onset_D',[],'CR_onset_T',[],'mod_onset_1',[],'mod_onset_2',[],'mod_change_1',[],'mod_change_2',[],'mod_change_t250',[],'mod_pkt_t250',[],'mod_pkt_1',[],'mod_pkt_2',[],...
    'mod_change_prb_1',[],'mod_change_prb_2',[],'mod_pkt_prb_1',[],'mod_pkt_prb_2',[],...
    'mod_change_align_1',[],'mod_change_align_2',[],'mod_pkt_align_1',[],'mod_pkt_align_2',[]);
% sup_cell_single=struct('cell_ID',[],'mod_onset_1',[],'mod_onset_2',[],'mod_change_1',[],'mod_change_2',[],'mod_pkt_1',[],'mod_pkt_2',[]);
non_cell=struct('cell_ID',[]);

fac_idx=0;
sup_idx=0;
non_idx=0;

for i=1:size(mod_list,2)
    if (~isempty(mod_list(i).(align_info_1).CR_fac.t_onset) && ~isempty(mod_list(i).(align_info_2).CR_fac.t_onset))
        fac_idx=fac_idx+1;
        fac_cell(fac_idx).cell_ID=i;
        sss_idx=find(strcmp({blk_sss_list.session_path}, cell_list(i).file_name)==1);
        fac_cell(fac_idx).CR_onset_D=blk_sss_list(sss_idx).CR_onset_D;
        fac_cell(fac_idx).CR_onset_T=blk_sss_list(sss_idx).CR_onset_T;
        fac_cell(fac_idx).mod_change_t250=mod_list(i).align_info_T.CR_fac(1).peak_250-100;
        fac_cell(fac_idx).mod_pkt_t250=mod_list(i).align_info_T.CR_fac(1).t_peak_250;
        if ~isempty(mod_list(i).(align_info_1).CR_fac.t_onset)
          fac_cell(fac_idx).mod_onset_1=mod_list(i).(align_info_1).CR_fac(1).t_onset;
          fac_cell(fac_idx).mod_change_1=mod_list(i).(align_info_1).CR_fac(1).peak-100;
          fac_cell(fac_idx).mod_pkt_1=mod_list(i).(align_info_1).CR_fac(1).t_peak;
          fac_prb_psth_smth_1=smooth_curve(cell_list(i).(align_info_1).psth_prb.Gau_psth_shft(:,1),cell_list(i).(align_info_1).psth_prb.Gau_psth_shft(:,2),20,1);
          t_start_1=find(fac_prb_psth_smth_1==t_pre,1,'first');
          prb_bsl_mean_1=mean(fac_prb_psth_smth_1(t_start_1:t_start_1-t_pre-1,2));
          [fac_mod_change_prb_1,fac_mod_pkt_prb_1]=max(fac_prb_psth_smth_1(t_start_1-t_pre:t_start_1-t_pre+499,2));
          fac_cell(fac_idx).mod_change_prb_1=fac_mod_change_prb_1/prb_bsl_mean_1*100-100;
          fac_cell(fac_idx).mod_pkt_prb_1=fac_mod_pkt_prb_1;     
       elseif isempty(mod_list(i).(align_info_1).CR_fac.t_onset)
          fac_cell(fac_idx).mod_onset_1=0;
          fac_cell(fac_idx).mod_change_1=0;
          fac_cell(fac_idx).mod_pkt_1=0;          
          fac_cell(fac_idx).mod_change_prb_1=0;
          fac_cell(fac_idx).mod_pkt_prb_1=0;          
       end
       if ~isempty(mod_list(i).(align_info_2).CR_fac.t_onset)
          fac_cell(fac_idx).mod_onset_2=mod_list(i).(align_info_2).CR_fac(1).t_onset;
          fac_cell(fac_idx).mod_change_2=mod_list(i).(align_info_2).CR_fac(1).peak-100;
          fac_cell(fac_idx).mod_pkt_2=mod_list(i).(align_info_2).CR_fac(1).t_peak;
          fac_prb_psth_smth_2=smooth_curve(cell_list(i).(align_info_2).psth_prb.Gau_psth_shft(:,1),cell_list(i).(align_info_2).psth_prb.Gau_psth_shft(:,2),20,1);
          t_start_2=find(fac_prb_psth_smth_2==t_pre,1,'first');
          prb_bsl_mean_2=mean(fac_prb_psth_smth_2(t_start_2:t_start_2-t_pre-1,2));
          [fac_mod_change_prb_2,fac_mod_pkt_prb_2]=max(fac_prb_psth_smth_2(t_start_2-t_pre:t_start_2-t_pre+499,2));
          fac_cell(fac_idx).mod_change_prb_2=fac_mod_change_prb_2/prb_bsl_mean_2*100-100;
          fac_cell(fac_idx).mod_pkt_prb_2=fac_mod_pkt_prb_2;      
       elseif isempty(mod_list(i).(align_info_2).CR_fac.t_onset)
          fac_cell(fac_idx).mod_onset_2=0;
          fac_cell(fac_idx).mod_change_2=0;
          fac_cell(fac_idx).mod_pkt_2=0;  
          fac_cell(fac_idx).mod_change_prb_2=0;
          fac_cell(fac_idx).mod_pkt_prb_2=0;   
       end 
    end
    if (~isempty(mod_list(i).(align_info_1).CR_sup.t_onset) && ~isempty(mod_list(i).(align_info_2).CR_sup.t_onset))
       sup_idx=sup_idx+1;
       sup_cell(sup_idx).cell_ID=i;    
       sss_idx=find(strcmp({blk_sss_list.session_path}, cell_list(i).file_name)==1);
       sup_cell(sup_idx).CR_onset_D=blk_sss_list(sss_idx).CR_onset_D;
       sup_cell(sup_idx).CR_onset_T=blk_sss_list(sss_idx).CR_onset_T;
       sup_cell(sup_idx).mod_change_t250=mod_list(i).align_info_T.CR_sup(1).peak_250-100;
       sup_cell(sup_idx).mod_pkt_t250=mod_list(i).align_info_T.CR_sup(1).t_peak_250;
       if ~isempty(mod_list(i).(align_info_1).CR_sup.t_onset)
          sup_cell(sup_idx).mod_onset_1=mod_list(i).(align_info_1).CR_sup(1).t_onset;
          sup_cell(sup_idx).mod_change_1=mod_list(i).(align_info_1).CR_sup(1).peak-100;
          sup_cell(sup_idx).mod_pkt_1=mod_list(i).(align_info_1).CR_sup(1).t_peak;
          sup_prb_psth_smth_1=smooth_curve(cell_list(i).(align_info_1).psth_prb.Gau_psth_shft(:,1),cell_list(i).(align_info_1).psth_prb.Gau_psth_shft(:,2),20,1);
          t_start_1=find(sup_prb_psth_smth_1==t_pre,1,'first');
          prb_bsl_mean_1=mean(sup_prb_psth_smth_1(t_start_1:t_start_1-t_pre-1,2));
          [sup_mod_change_prb_1,sup_mod_pkt_prb_1]=min(sup_prb_psth_smth_1(t_start_1-t_pre:t_start_1-t_pre+499,2));
          sup_cell(sup_idx).mod_change_prb_1=sup_mod_change_prb_1/prb_bsl_mean_1*100-100;
          sup_cell(sup_idx).mod_pkt_prb_1=sup_mod_pkt_prb_1;
       elseif isempty(mod_list(i).(align_info_1).CR_sup.t_onset)
          sup_cell(sup_idx).mod_onset_1=0;
          sup_cell(sup_idx).mod_change_1=0;
          sup_cell(sup_idx).mod_pkt_1=0;       
          sup_cell(sup_idx).mod_change_prb_1=0;
          sup_cell(sup_idx).mod_pkt_prb_1=0;  
       end
       if ~isempty(mod_list(i).(align_info_2).CR_sup.t_onset)
          sup_cell(sup_idx).mod_onset_2=mod_list(i).(align_info_2).CR_sup(1).t_onset;
          sup_cell(sup_idx).mod_change_2=mod_list(i).(align_info_2).CR_sup(1).peak-100;
          sup_cell(sup_idx).mod_pkt_2=mod_list(i).(align_info_2).CR_sup(1).t_peak;
          sup_prb_psth_smth_2=smooth_curve(cell_list(i).(align_info_2).psth_prb.Gau_psth_shft(:,1),cell_list(i).(align_info_2).psth_prb.Gau_psth_shft(:,2),20,1);
          t_start_2=find(sup_prb_psth_smth_2==t_pre,1,'first');
          prb_bsl_mean_2=mean(sup_prb_psth_smth_2(t_start_2:t_start_2-t_pre-1,2));
          [sup_mod_change_prb_2,sup_mod_pkt_prb_2]=min(sup_prb_psth_smth_2(t_start_2-t_pre:t_start_2-t_pre+499,2));
          sup_cell(sup_idx).mod_change_prb_2=sup_mod_change_prb_2/prb_bsl_mean_2*100-100;
          sup_cell(sup_idx).mod_pkt_prb_2=sup_mod_pkt_prb_2;
       elseif isempty(mod_list(i).(align_info_2).CR_sup.t_onset)
          sup_cell(sup_idx).mod_onset_2=0;
          sup_cell(sup_idx).mod_change_2=0;
          sup_cell(sup_idx).mod_pkt_2=0;       
          sup_cell(sup_idx).mod_change_prb_2=0;
          sup_cell(sup_idx).mod_pkt_prb_2=0;  
       end   
    end
%     elseif (~isempty(list(i).(align_info_1).CR_sup.t_onset) && ~isempty(list(i).(align_info_2).CR_sup.t_onset)) && (~isempty(list(i).(align_info_1).CR_fac.t_onset) && ~isempty(list(i).(align_info_2).CR_fac.t_onset))
%        if ~isempty(list(i).(align_info_1).CR_fac)
%           fac_judge_1=list(i).(align_info_1).CR_fac(1).peak-list(i).(align_info_1).bsl_frq_ex;
%        else
%           fac_judge_1=0; 
%        end
%        if ~isempty(list(i).(align_info_2).CR_fac)
%           fac_judge_2=list(i).(align_info_2).CR_fac(1).peak-list(i).(align_info_2).bsl_frq_ex;
%        else
%           fac_judge_2=0; 
%        end 
%        if ~isempty(list(i).(align_info_1).CR_sup)
%           sup_judge_1=list(i).(align_info_1).CR_sup(1).peak-list(i).(align_info_1).bsl_frq_ex;
%        else
%           sup_judge_1=0; 
%        end
%        if ~isempty(list(i).(align_info_2).CR_sup)
%           sup_judge_2=list(i).(align_info_2).CR_sup(1).peak-list(i).(align_info_2).bsl_frq_ex;
%        else
%           sup_judge_2=0; 
%        end 
%        if fac_judge_1+fac_judge_2+sup_judge_1+sup_judge_2>=0
%           fac_idx=fac_idx+1;
%           fac_cell(fac_idx).cell_ID=i;   
%            if ~isempty(list(i).(align_info_1).CR_fac)
%               fac_cell(fac_idx).mod_onset_1=list(i).(align_info_1).CR_fac(1).t_onset;
%               fac_cell(fac_idx).mod_change_1=list(i).(align_info_1).CR_fac(1).peak/list(i).(align_info_1).bsl_frq_ex*100-100;
%               fac_cell(fac_idx).mod_pkt_1=list(i).(align_info_1).CR_fac(1).t_peak;
%            elseif isempty(list(i).(align_info_1).CR_fac)
%               fac_cell(fac_idx).mod_onset_1=0;
%               fac_cell(fac_idx).mod_change_1=0;
%               fac_cell(fac_idx).mod_pkt_1=0;          
%            end
%            if ~isempty(list(i).(align_info_2).CR_fac)
%               fac_cell(fac_idx).mod_onset_2=list(i).(align_info_2).CR_fac(1).t_onset;
%               fac_cell(fac_idx).mod_change_2=list(i).(align_info_2).CR_fac(1).peak/list(i).(align_info_2).bsl_frq_ex*100-100;
%               fac_cell(fac_idx).mod_pkt_2=list(i).(align_info_2).CR_fac(1).t_peak;
%            elseif isempty(list(i).(align_info_2).CR_fac)
%               fac_cell(fac_idx).mod_onset_2=0;
%               fac_cell(fac_idx).mod_change_2=0;
%               fac_cell(fac_idx).mod_pkt_2=0;          
%            end          
%        elseif fac_judge_1+fac_judge_2+sup_judge_1+sup_judge_2<0 
%           sup_idx=sup_idx+1;
%           sup_cell(sup_idx).cell_ID=i; 
%             if ~isempty(list(i).(align_info_1).CR_sup)
%               sup_cell(sup_idx).mod_onset_1=list(i).(align_info_1).CR_sup(1).t_onset;
%               sup_cell(sup_idx).mod_change_1=list(i).(align_info_1).CR_sup(1).peak/list(i).(align_info_1).bsl_frq_ex*100-100;
%               sup_cell(sup_idx).mod_pkt_1=list(i).(align_info_1).CR_sup(1).t_peak;
%            elseif isempty(list(i).(align_info_1).CR_sup)
%               sup_cell(sup_idx).mod_onset_1=0;
%               sup_cell(sup_idx).mod_change_1=0;
%               sup_cell(sup_idx).mod_pkt_1=0;          
%            end
%            if ~isempty(list(i).(align_info_2).CR_sup)
%               sup_cell(sup_idx).mod_onset_2=list(i).(align_info_2).CR_sup(1).t_onset;
%               sup_cell(sup_idx).mod_change_2=list(i).(align_info_2).CR_sup(1).peak/list(i).(align_info_2).bsl_frq_ex*100-100;
%               sup_cell(sup_idx).mod_pkt_2=list(i).(align_info_2).CR_sup(1).t_peak;
%            elseif isempty(list(i).(align_info_2).CR_sup)
%               sup_cell(sup_idx).mod_onset_2=0;
%               sup_cell(sup_idx).mod_change_2=0;
%               sup_cell(sup_idx).mod_pkt_2=0;          
%            end           
%        end
    if (isempty(mod_list(i).(align_info_1).CR_fac.t_onset) || isempty(mod_list(i).(align_info_2).CR_fac.t_onset)) && (isempty(mod_list(i).(align_info_1).CR_sup.t_onset) || isempty(mod_list(i).(align_info_2).CR_sup.t_onset))
       non_idx=non_idx+1;
       non_cell(non_idx).cell_ID=i;          
    end  
end

figure;
for i=1:size(fac_cell,2)
    plot(fac_cell(i).mod_onset_1,fac_cell(i).mod_onset_2,'r.')
    hold on    
end
for i=1:size(sup_cell,2)
    plot(sup_cell(i).mod_onset_1,sup_cell(i).mod_onset_2,'b.')
    hold on    
end
fac_modonset_mean_1=mean([fac_cell.mod_onset_1]);
fac_modonset_mean_2=mean([fac_cell.mod_onset_2]);
fac_modonset_std_1=std([fac_cell.mod_onset_1]);
fac_modonset_std_2=std([fac_cell.mod_onset_2]);
sup_modonset_mean_1=mean([sup_cell.mod_onset_1]);
sup_modonset_mean_2=mean([sup_cell.mod_onset_2]);
sup_modonset_std_1=std([sup_cell.mod_onset_1]);
sup_modonset_std_2=std([sup_cell.mod_onset_2]);
all_modonset_mean_1=mean([[fac_cell.mod_onset_1] [sup_cell.mod_onset_1]]);
all_modonset_mean_2=mean([[fac_cell.mod_onset_2] [sup_cell.mod_onset_2]]);
all_modonset_std_1=std([[fac_cell.mod_onset_1] [sup_cell.mod_onset_1]]);
all_modonset_std_2=std([[fac_cell.mod_onset_2] [sup_cell.mod_onset_2]]);
plot(fac_modonset_mean_1,fac_modonset_mean_2,'rs')
hold on
errorbar(fac_modonset_mean_1,fac_modonset_mean_2,fac_modonset_std_2/sqrt(fac_idx),fac_modonset_std_2/sqrt(fac_idx),...
    fac_modonset_std_1/sqrt(fac_idx),fac_modonset_std_1/sqrt(fac_idx),'Color','r');
hold on
plot(sup_modonset_mean_1,sup_modonset_mean_2,'bs')
hold on
errorbar(sup_modonset_mean_1,sup_modonset_mean_2,sup_modonset_std_2/sqrt(sup_idx),sup_modonset_std_2/sqrt(sup_idx),...
    sup_modonset_std_1/sqrt(sup_idx),sup_modonset_std_1/sqrt(sup_idx),'Color','b');
hold on
plot(all_modonset_mean_1,all_modonset_mean_2,'ms')
hold on
errorbar(all_modonset_mean_1,all_modonset_mean_2,all_modonset_std_2/sqrt(fac_idx+sup_idx),all_modonset_std_2/sqrt(fac_idx+sup_idx),...
    all_modonset_std_1/sqrt(fac_idx+sup_idx),all_modonset_std_1/sqrt(fac_idx+sup_idx),'Color','m');
hold on
% xlim([0 250]);
% ylim([0 500]);
% line([0 250],[0 250],'LineStyle','--','Color','k');
% line([0 250],[250 250],'LineStyle','--','Color','g');
% xlabel('DEC modulation onset (ms)');
% ylabel('TEC modulation onset (ms)');
xlim([0 500]);
ylim([0 250]);
line([0 250],[0 250],'LineStyle','--','Color','k');
line([250 250],[0 250],'LineStyle','--','Color','g');
xlabel('TEC modulation onset (ms)');
ylabel('DEC modulation onset (ms)');

figure;
for i=1:size(fac_cell,2)
    plot(fac_cell(i).mod_change_1,fac_cell(i).mod_change_2,'r.')
    hold on    
end

line([0 400],[0 400],'LineStyle','--','Color','k');
xlim([0 300]);
ylim([0 300]);
fac_modchange_mean_1=mean([fac_cell.mod_change_1]);
fac_modchange_mean_2=mean([fac_cell.mod_change_2]);
fac_modchange_std_1=std([fac_cell.mod_change_1]);
fac_modchange_std_2=std([fac_cell.mod_change_2]);
plot(fac_modchange_mean_1,fac_modchange_mean_2,'rs')
hold on
errorbar(fac_modchange_mean_1,fac_modchange_mean_2,fac_modchange_std_2/sqrt(fac_idx),fac_modchange_std_2/sqrt(fac_idx),...
    fac_modchange_std_1/sqrt(fac_idx),fac_modchange_std_1/sqrt(fac_idx),'Color','r');
hold on
% xlabel('DEC modulation amplitude change (%)');
% ylabel('TEC modulation amplitude change (%)');
xlabel('TEC modulation amplitude change (%)');
ylabel('DEC modulation amplitude change (%)');

figure;
for i=1:size(sup_cell,2)
    plot(-sup_cell(i).mod_change_1,-sup_cell(i).mod_change_2,'b.')
    hold on    
end
line([0 100],[0 100],'LineStyle','--','Color','k');
% xlim([-100 0]);
% ylim([-100 0]);
sup_modchange_mean_1=-mean([sup_cell.mod_change_1]);
sup_modchange_mean_2=-mean([sup_cell.mod_change_2]);
sup_modchange_std_1=-std([sup_cell.mod_change_1]);
sup_modchange_std_2=-std([sup_cell.mod_change_2]);
plot(sup_modchange_mean_1,sup_modchange_mean_2,'bs')
hold on
errorbar(sup_modchange_mean_1,sup_modchange_mean_2,sup_modchange_std_2/sqrt(sup_idx),sup_modchange_std_2/sqrt(sup_idx),...
    sup_modchange_std_1/sqrt(sup_idx),sup_modchange_std_1/sqrt(sup_idx),'Color','b');
% xlabel('DEC modulation amplitude change (%)');
% ylabel('TEC modulation amplitude change (%)');
xlabel('TEC modulation amplitude change (%)');
ylabel('DEC modulation amplitude change (%)');

figure;
for i=1:size(fac_cell,2)
%     plot(fac_cell(i).mod_change_1,fac_cell(i).mod_change_t250,'r.')
    plot(fac_cell(i).mod_change_t250,fac_cell(i).mod_change_2,'r.')
    hold on    
end

line([0 400],[0 400],'LineStyle','--','Color','k');
xlim([0 300]);
ylim([0 300]);
% fac_modchange_mean_1=mean([fac_cell.mod_change_1]);
% fac_modchange_mean_2=mean([fac_cell.mod_change_t250]);
% fac_modchange_std_1=std([fac_cell.mod_change_1]);
% fac_modchange_std_2=std([fac_cell.mod_change_t250]);
fac_modchange_mean_1=mean([fac_cell.mod_change_t250]);
fac_modchange_mean_2=mean([fac_cell.mod_change_2]);
fac_modchange_std_1=std([fac_cell.mod_change_t250]);
fac_modchange_std_2=std([fac_cell.mod_change_2]);
plot(fac_modchange_mean_1,fac_modchange_mean_2,'rs')
hold on
errorbar(fac_modchange_mean_1,fac_modchange_mean_2,fac_modchange_std_2/sqrt(fac_idx),fac_modchange_std_2/sqrt(fac_idx),...
    fac_modchange_std_1/sqrt(fac_idx),fac_modchange_std_1/sqrt(fac_idx),'Color','r');
hold on
% xlabel('DEC modulation amplitude change (%)');
% ylabel('TEC modulation amplitude change (%)');
xlabel('TEC modulation amplitude change (%)');
ylabel('DEC modulation amplitude change (%)');

figure;
for i=1:size(sup_cell,2)
%     plot(-sup_cell(i).mod_change_1,-sup_cell(i).mod_change_2,'b.')
    plot(-sup_cell(i).mod_change_t250,-sup_cell(i).mod_change_2,'b.')
    hold on    
end
line([0 100],[0 100],'LineStyle','--','Color','k');
% xlim([-100 0]);
% ylim([-100 0]);
% sup_modchange_mean_1=-mean([sup_cell.mod_change_1]);
% sup_modchange_mean_2=-mean([sup_cell.mod_change_t250]);
% sup_modchange_std_1=-std([sup_cell.mod_change_1]);
% sup_modchange_std_2=-std([sup_cell.mod_change_t250]);
sup_modchange_mean_1=-mean([sup_cell.mod_change_t250]);
sup_modchange_mean_2=-mean([sup_cell.mod_change_2]);
sup_modchange_std_1=-std([sup_cell.mod_change_t250]);
sup_modchange_std_2=-std([sup_cell.mod_change_2]);
plot(sup_modchange_mean_1,sup_modchange_mean_2,'bs')
hold on
errorbar(sup_modchange_mean_1,sup_modchange_mean_2,sup_modchange_std_2/sqrt(sup_idx),sup_modchange_std_2/sqrt(sup_idx),...
    sup_modchange_std_1/sqrt(sup_idx),sup_modchange_std_1/sqrt(sup_idx),'Color','b');
% xlabel('DEC modulation amplitude change (%)');
% ylabel('TEC modulation amplitude change (%)');
xlabel('TEC modulation amplitude change (%)');
ylabel('DEC modulation amplitude change (%)');

figure;
for i=1:size(fac_cell,2)
    plot(fac_cell(i).mod_pkt_1,fac_cell(i).mod_pkt_2,'r.')
    hold on    
end
for i=1:size(sup_cell,2)
    plot(sup_cell(i).mod_pkt_1,sup_cell(i).mod_pkt_2,'b.')
    hold on    
end
fac_pkt_mean_1=mean([fac_cell.mod_pkt_1]);
fac_pkt_mean_2=mean([fac_cell.mod_pkt_2]);
fac_pkt_std_1=std([fac_cell.mod_pkt_1]);
fac_pkt_std_2=std([fac_cell.mod_pkt_2]);
sup_pkt_mean_1=mean([sup_cell.mod_pkt_1]);
sup_pkt_mean_2=mean([sup_cell.mod_pkt_2]);
sup_pkt_std_1=std([sup_cell.mod_pkt_1]);
sup_pkt_std_2=std([sup_cell.mod_pkt_2]);
all_pkt_mean_1=mean([[fac_cell.mod_pkt_1] [sup_cell.mod_pkt_1]]);
all_pkt_mean_2=mean([[fac_cell.mod_pkt_2] [sup_cell.mod_pkt_2]]);
all_pkt_std_1=std([[fac_cell.mod_pkt_1] [sup_cell.mod_pkt_1]]);
all_pkt_std_2=std([[fac_cell.mod_pkt_2] [sup_cell.mod_pkt_2]]);
plot(fac_pkt_mean_1,fac_pkt_mean_2,'rs')
hold on
errorbar(fac_pkt_mean_1,fac_pkt_mean_2,fac_pkt_std_2/sqrt(fac_idx),fac_pkt_std_2/sqrt(fac_idx),...
    fac_pkt_std_1/sqrt(fac_idx),fac_pkt_std_1/sqrt(fac_idx),'Color','r');
hold on
plot(sup_pkt_mean_1,sup_pkt_mean_2,'bs')
hold on
errorbar(sup_pkt_mean_1,sup_pkt_mean_2,sup_pkt_std_2/sqrt(sup_idx),sup_pkt_std_2/sqrt(sup_idx),...
    sup_pkt_std_1/sqrt(sup_idx),sup_pkt_std_1/sqrt(sup_idx),'Color','b');
hold on
plot(all_pkt_mean_1,all_pkt_mean_2,'ms')
hold on
errorbar(all_pkt_mean_1,all_pkt_mean_2,all_pkt_std_2/sqrt(fac_idx+sup_idx),all_pkt_std_2/sqrt(fac_idx+sup_idx),...
    all_pkt_std_1/sqrt(fac_idx+sup_idx),all_pkt_std_1/sqrt(fac_idx+sup_idx),'Color','m');
hold on
% xlim([0 250]);
% ylim([0 500]);
% line([0 250],[0 250],'LineStyle','--','Color','k');
% line([0 250],[250 250],'LineStyle','--','Color','g');
% xlabel('DEC modulation peaktime (ms)');
% ylabel('TEC modulation peaktime (ms)');
xlim([0 500]);
ylim([0 250]);
line([0 250],[0 250],'LineStyle','--','Color','k');
line([250 250],[0 250],'LineStyle','--','Color','g');
xlabel('TEC modulation peaktime (ms)');
ylabel('DEC modulation peaktime (ms)');

figure;
for i=1:size(fac_cell,2)
%     plot(fac_cell(i).mod_pkt_1,fac_cell(i).mod_pkt_t250,'r.')
    plot(fac_cell(i).mod_pkt_t250,fac_cell(i).mod_pkt_2,'r.')
    hold on    
end
for i=1:size(sup_cell,2)
%     plot(sup_cell(i).mod_pkt_1,sup_cell(i).mod_pkt_t250,'b.')
    plot(sup_cell(i).mod_pkt_t250,sup_cell(i).mod_pkt_2,'b.')
    hold on    
end
% fac_pkt_mean_1=mean([fac_cell.mod_pkt_1]);
% fac_pkt_mean_2=mean([fac_cell.mod_pkt_t250]);
% fac_pkt_std_1=std([fac_cell.mod_pkt_1]);
% fac_pkt_std_2=std([fac_cell.mod_pkt_t250]);
% sup_pkt_mean_1=mean([sup_cell.mod_pkt_1]);
% sup_pkt_mean_2=mean([sup_cell.mod_pkt_t250]);
% sup_pkt_std_1=std([sup_cell.mod_pkt_1]);
% sup_pkt_std_2=std([sup_cell.mod_pkt_t250]);
% all_pkt_mean_1=mean([[fac_cell.mod_pkt_1] [sup_cell.mod_pkt_1]]);
% all_pkt_mean_2=mean([[fac_cell.mod_pkt_t250] [sup_cell.mod_pkt_t250]]);
% all_pkt_std_1=std([[fac_cell.mod_pkt_1] [sup_cell.mod_pkt_1]]);
% all_pkt_std_2=std([[fac_cell.mod_pkt_t250] [sup_cell.mod_pkt_t250]]);
fac_pkt_mean_1=mean([fac_cell.mod_pkt_t250]);
fac_pkt_mean_2=mean([fac_cell.mod_pkt_2]);
fac_pkt_std_1=std([fac_cell.mod_pkt_t250]);
fac_pkt_std_2=std([fac_cell.mod_pkt_2]);
sup_pkt_mean_1=mean([sup_cell.mod_pkt_t250]);
sup_pkt_mean_2=mean([sup_cell.mod_pkt_2]);
sup_pkt_std_1=std([sup_cell.mod_pkt_t250]);
sup_pkt_std_2=std([sup_cell.mod_pkt_2]);
all_pkt_mean_1=mean([[fac_cell.mod_pkt_t250] [sup_cell.mod_pkt_t250]]);
all_pkt_mean_2=mean([[fac_cell.mod_pkt_2] [sup_cell.mod_pkt_2]]);
all_pkt_std_1=std([[fac_cell.mod_pkt_t250] [sup_cell.mod_pkt_t250]]);
all_pkt_std_2=std([[fac_cell.mod_pkt_2] [sup_cell.mod_pkt_2]]);
plot(fac_pkt_mean_1,fac_pkt_mean_2,'rs')
hold on
errorbar(fac_pkt_mean_1,fac_pkt_mean_2,fac_pkt_std_2/sqrt(fac_idx),fac_pkt_std_2/sqrt(fac_idx),...
    fac_pkt_std_1/sqrt(fac_idx),fac_pkt_std_1/sqrt(fac_idx),'Color','r');
hold on
plot(sup_pkt_mean_1,sup_pkt_mean_2,'bs')
hold on
errorbar(sup_pkt_mean_1,sup_pkt_mean_2,sup_pkt_std_2/sqrt(sup_idx),sup_pkt_std_2/sqrt(sup_idx),...
    sup_pkt_std_1/sqrt(sup_idx),sup_pkt_std_1/sqrt(sup_idx),'Color','b');
hold on
plot(all_pkt_mean_1,all_pkt_mean_2,'ms')
hold on
errorbar(all_pkt_mean_1,all_pkt_mean_2,all_pkt_std_2/sqrt(fac_idx+sup_idx),all_pkt_std_2/sqrt(fac_idx+sup_idx),...
    all_pkt_std_1/sqrt(fac_idx+sup_idx),all_pkt_std_1/sqrt(fac_idx+sup_idx),'Color','m');
hold on
xlim([0 250]);
ylim([0 250]);
line([0 250],[0 250],'LineStyle','--','Color','k');
% xlabel('DEC modulation peaktime (ms)');
% ylabel('TEC modulation peaktime (ms)');
xlabel('TEC modulation peaktime (ms)');
ylabel('DEC modulation peaktime (ms)');

figure;
for i=1:size(fac_cell,2)
    plot(fac_cell(i).mod_change_prb_1,fac_cell(i).mod_change_prb_2,'r.')
    hold on    
end

line([0 400],[0 400],'LineStyle','--','Color','k');
xlim([0 300]);
ylim([0 300]);
fac_modchange_mean_1=mean([fac_cell.mod_change_prb_1]);
fac_modchange_mean_2=mean([fac_cell.mod_change_prb_2]);
fac_modchange_std_1=std([fac_cell.mod_change_prb_1]);
fac_modchange_std_2=std([fac_cell.mod_change_prb_2]);
plot(fac_modchange_mean_1,fac_modchange_mean_2,'rs')
hold on
errorbar(fac_modchange_mean_1,fac_modchange_mean_2,fac_modchange_std_2/sqrt(fac_idx),fac_modchange_std_2/sqrt(fac_idx),...
    fac_modchange_std_1/sqrt(fac_idx),fac_modchange_std_1/sqrt(fac_idx),'Color','r');
hold on
% xlabel('DEC modulation amplitude change (%)');
% ylabel('TEC modulation amplitude change (%)');
xlabel('TEC modulation amplitude change (%)');
ylabel('DEC modulation amplitude change (%)');

figure;
for i=1:size(sup_cell,2)
    plot(-sup_cell(i).mod_change_prb_1,-sup_cell(i).mod_change_prb_2,'b.')
    hold on    
end
line([0 100],[0 100],'LineStyle','--','Color','k');
% xlim([-100 0]);
% ylim([-100 0]);
sup_modchange_mean_1=-mean([sup_cell.mod_change_prb_1]);
sup_modchange_mean_2=-mean([sup_cell.mod_change_prb_2]);
sup_modchange_std_1=-std([sup_cell.mod_change_prb_1]);
sup_modchange_std_2=-std([sup_cell.mod_change_prb_2]);
plot(sup_modchange_mean_1,sup_modchange_mean_2,'bs')
hold on
errorbar(sup_modchange_mean_1,sup_modchange_mean_2,sup_modchange_std_2/sqrt(sup_idx),sup_modchange_std_2/sqrt(sup_idx),...
    sup_modchange_std_1/sqrt(sup_idx),sup_modchange_std_1/sqrt(sup_idx),'Color','b');
% xlabel('DEC modulation amplitude change (%)');
% ylabel('TEC modulation amplitude change (%)');
xlabel('TEC modulation amplitude change (%)');
ylabel('DEC modulation amplitude change (%)');

figure;
for i=1:size(fac_cell,2)
    plot(fac_cell(i).mod_pkt_prb_1,fac_cell(i).mod_pkt_prb_2,'r.')
    hold on    
end
for i=1:size(sup_cell,2)
    plot(sup_cell(i).mod_pkt_prb_1,sup_cell(i).mod_pkt_prb_2,'b.')
    hold on    
end
fac_pkt_mean_1=mean([fac_cell.mod_pkt_prb_1]);
fac_pkt_mean_2=mean([fac_cell.mod_pkt_prb_2]);
fac_pkt_std_1=std([fac_cell.mod_pkt_prb_1]);
fac_pkt_std_2=std([fac_cell.mod_pkt_prb_2]);
sup_pkt_mean_1=mean([sup_cell.mod_pkt_prb_1]);
sup_pkt_mean_2=mean([sup_cell.mod_pkt_prb_2]);
sup_pkt_std_1=std([sup_cell.mod_pkt_prb_1]);
sup_pkt_std_2=std([sup_cell.mod_pkt_prb_2]);
all_pkt_mean_1=mean([[fac_cell.mod_pkt_prb_1] [sup_cell.mod_pkt_prb_1]]);
all_pkt_mean_2=mean([[fac_cell.mod_pkt_prb_2] [sup_cell.mod_pkt_prb_2]]);
all_pkt_std_1=std([[fac_cell.mod_pkt_prb_1] [sup_cell.mod_pkt_prb_1]]);
all_pkt_std_2=std([[fac_cell.mod_pkt_prb_2] [sup_cell.mod_pkt_prb_2]]);
plot(fac_pkt_mean_1,fac_pkt_mean_2,'rs')
hold on
errorbar(fac_pkt_mean_1,fac_pkt_mean_2,fac_pkt_std_2/sqrt(fac_idx),fac_pkt_std_2/sqrt(fac_idx),...
    fac_pkt_std_1/sqrt(fac_idx),fac_pkt_std_1/sqrt(fac_idx),'Color','r');
hold on
plot(sup_pkt_mean_1,sup_pkt_mean_2,'bs')
hold on
errorbar(sup_pkt_mean_1,sup_pkt_mean_2,sup_pkt_std_2/sqrt(sup_idx),sup_pkt_std_2/sqrt(sup_idx),...
    sup_pkt_std_1/sqrt(sup_idx),sup_pkt_std_1/sqrt(sup_idx),'Color','b');
hold on
plot(all_pkt_mean_1,all_pkt_mean_2,'ms')
hold on
errorbar(all_pkt_mean_1,all_pkt_mean_2,all_pkt_std_2/sqrt(fac_idx+sup_idx),all_pkt_std_2/sqrt(fac_idx+sup_idx),...
    all_pkt_std_1/sqrt(fac_idx+sup_idx),all_pkt_std_1/sqrt(fac_idx+sup_idx),'Color','m');
hold on
xlim([0 500]);
ylim([0 500]);
line([0 500],[0 500],'LineStyle','--','Color','k');
line([0 500],[250 250],'LineStyle','--','Color','g');
line([250 250],[0 500],'LineStyle','--','Color','g');
xticks(0:50:500);
yticks(0:50:500);
% xlabel('DEC modulation peaktime (ms)');
% ylabel('TEC modulation peaktime (ms)');
xlabel('TEC modulation peaktime (ms)');
ylabel('DEC modulation peaktime (ms)');


function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end
