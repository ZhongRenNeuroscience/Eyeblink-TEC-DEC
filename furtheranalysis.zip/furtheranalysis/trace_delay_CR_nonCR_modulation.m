file=trace_list_sim;
fac_list=fac_list_T;

t_post=500;

CR_nonCR=struct('cell_ID',[],'CR_mod_frq',[],'nonCR_mod_frq',[]);

for i=1:size(fac_list,2)
    cell_ID=fac_list(i).cell_ID;
    t_pre_CR=file(cell_ID).all_info.sss_all.psth.CR_trial.psth_smooth(1,1);
    CR_mod_frq=mean(file(cell_ID).all_info.sss_all.psth.CR_trial.psth_smooth(-t_pre_CR+251:-t_pre_CR+t_post,2));
    if ~isempty(file(cell_ID).all_info.sss_all.psth.nonCR_trial)
        t_pre_nonCR=file(cell_ID).all_info.sss_all.psth.nonCR_trial.psth_smooth(1,1);
        nonCR_mod_frq=mean(file(cell_ID).all_info.sss_all.psth.nonCR_trial.psth_smooth(-t_pre_nonCR+251:-t_pre_nonCR+t_post,2));
    else
        nonCR_mod_frq=0;
    end
    CR_nonCR(i).cell_ID=cell_ID;
    CR_nonCR(i).CR_mod_frq=CR_mod_frq;
    CR_nonCR(i).nonCR_mod_frq=nonCR_mod_frq;
end