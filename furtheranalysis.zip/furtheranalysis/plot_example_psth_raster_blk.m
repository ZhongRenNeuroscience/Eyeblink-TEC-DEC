% Plot example neurons with three modulation types in TEC-only recordings.
% --Zhong

file=trace_all_sim;

cell_num=202;
trial_num=81;
% all_info='all_info';

blk_data1=zeros(31000,size(list_mod.fac(cell_num).all_info.ttt.CR_trial,2));

for n=1:size(list_mod.fac(cell_num).all_info.ttt.CR_trial,2)
    blk_data1(:,n)=list_mod.fac(cell_num).all_info.ttt.CR_trial(n).blk_trace(:,4)*100;
end

blk_data2=zeros(1250,size(blk_data1,2));
blk_form2=zeros(1250,5);
blk_form2(:,1)=-250:1:999;

for k=1:1250
t_idx=6001+20*(k-1);
blk_data2(k,:)=mean(blk_data1(t_idx-19:t_idx,:),1);  
end

blk_form2(:,2)=mean(blk_data2,2);
blk_form2(:,3)=std(blk_data2,0,2);

for k=1:1250
blk_form2(k,4)=blk_form2(k,2)+blk_form2(k,3);
blk_form2(k,5)=blk_form2(k,2)-blk_form2(k,3);
end

figure;
subplot(3,1,1)
hold on
for i=1:size(blk_data2,2)
    plot(blk_form2(:,1),smooth(blk_data2(:,i),5),'linewidth',0.5,'Color',[0.9 0.9 0.9],'LineWidth',0.5)
    hold on
end
plot(blk_form2(:,1),smooth(blk_form2(:,2),5),'Color',[1 0 0],'LineWidth',2)
hold on
plot(blk_form2(:,1),smooth(blk_form2(:,4),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
hold on
plot(blk_form2(:,1),smooth(blk_form2(:,5),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
hold on
line([0 0],[-10, 120],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[-10, 120],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[-10, 120],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([-10 120]);
xlabel('Time (ms)');
ylabel('Eyelid closure (%)');
xticks([-250 0 250 500 1000]);
yticks([0 100]);

subplot(3,1,2)
hold on

for m=1:size(blk_data2,2)
    hold on
    Y=ones(length(list_mod.fac(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
    plot(list_mod.fac(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'r.')
end
line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([0 m]);
xlabel('Time (ms)');
ylabel('CR trial number');
xticks([-250 0 250 500 1000]);
yticks([0 10 20 30 40 50]);

subplot(3,1,3)
plot(smth2(:,1),smth2(:,2),'r-','LineWidth',2)
hold on
plot(smth2(:,1),smth2(:,3),'Color',[0.5,0.5,0.5],'LineWidth',1.5)
hold on
plot(smth2(:,1),smth2(:,4),'Color',[0.5,0.5,0.5],'LineWidth',1.5)
xlabel('Time (ms)');
ylabel('Relative firing rate (%)');
xlim([-250 1000])
ylim([50 250]);
line([0 0],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([250 250],[50,250],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
line([500 500],[50,250],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
text(-150,225,'n = 46','Color','red','FontSize',10);
xticks([-250 0 250 500 1000]);

% type='sup';
% cell_num=1;
% 
% blk_data1=zeros(31000,size(list_mod.sup(cell_num).all_info.ttt.CR_trial,2));
% 
% for n=1:size(list_mod.sup(cell_num).all_info.ttt.CR_trial,2)
%     blk_data1(:,n)=list_mod.sup(cell_num).all_info.ttt.CR_trial(n).blk_trace(:,4)*100;
% end
% 
% blk_data2=zeros(1250,size(blk_data1,2));
% blk_form2=zeros(1250,5);
% blk_form2(:,1)=-250:1:999;
% 
% for k=1:1250
% t_idx=6001+20*(k-1);
% blk_data2(k,:)=mean(blk_data1(t_idx-19:t_idx,:),1);  
% end
% 
% exclude=find(blk_data2(251,:)>=10 | blk_data2(301,:)>=5);
% blk_data2(:,exclude)=[];
% 
% blk_form2(:,2)=mean(blk_data2,2);
% blk_form2(:,3)=std(blk_data2,0,2);
% 
% for k=1:1250
% blk_form2(k,4)=blk_form2(k,2)+blk_form2(k,3);
% blk_form2(k,5)=blk_form2(k,2)-blk_form2(k,3);
% end
% 
% figure;
% subplot(3,1,1)
% hold on
% for i=1:size(blk_data2,2)-length(exclude)
%     plot(blk_form2(:,1),smooth(blk_data2(:,i),5),'linewidth',0.5,'Color',[0.9 0.9 0.9],'LineWidth',0.5)
%     hold on
% end
% plot(blk_form2(:,1),smooth(blk_form2(:,2),5),'Color',[0 0 1],'LineWidth',2)
% hold on
% plot(blk_form2(:,1),smooth(blk_form2(:,4),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
% hold on
% plot(blk_form2(:,1),smooth(blk_form2(:,5),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
% hold on
% line([0 0],[-10, 140],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[-10, 140],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[-10, 140],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([-10 140]);
% xlabel('Time (ms)');
% ylabel('Eyelid closure (%)');
% xticks([-250 0 250 500 1000]);
% yticks([0 100]);
% 
% subplot(3,1,2)
% hold on
% 
% for m=1:size(blk_data2,2)-length(exclude)
%     hold on
%     Y=ones(length(list_mod.sup(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
%     plot(list_mod.sup(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'b.')
% end
% line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([0 m]);
% xlabel('Time (ms)');
% ylabel('CR trial number');
% xticks([-250 0 250 500 1000]);
% yticks([0 10 20 30 40]);
% 
% subplot(3,1,3)
% plot(smth2(:,1),smth2(:,5),'b-','LineWidth',2)
% hold on
% plot(smth2(:,1),smth2(:,6),'Color',[0.5,0.5,0.5],'LineWidth',1.5)
% hold on
% plot(smth2(:,1),smth2(:,7),'Color',[0.5,0.5,0.5],'LineWidth',1.5)
% xlabel('Time (ms)');
% ylabel('Relative firing rate (%)');
% xlim([-250 1000]);
% ylim([-25 175]);
% line([0 0],[-25,175],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[-25,175],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[-25,175],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% text(-150,150,'n = 20','Color','blue','FontSize',10);
% xticks([-500 0 250 500 1000]);
% 
% 
% type='non';
% cell_num=55;
% 
% blk_data1=zeros(31000,size(list_mod.non(cell_num).all_info.ttt.CR_trial,2));
% 
% for n=1:size(list_mod.non(cell_num).all_info.ttt.CR_trial,2)
%     blk_data1(:,n)=list_mod.non(cell_num).all_info.ttt.CR_trial(n).blk_trace(:,4)*100;
% end
% 
% blk_data2=zeros(1250,size(blk_data1,2));
% blk_form2=zeros(1250,5);
% blk_form2(:,1)=-250:1:999;
% 
% for k=1:1250
% t_idx=6001+20*(k-1);
% blk_data2(k,:)=mean(blk_data1(t_idx-19:t_idx,:),1);  
% end
% 
% blk_form2(:,2)=mean(blk_data2,2);
% blk_form2(:,3)=std(blk_data2,0,2);
% 
% for k=1:1250
% blk_form2(k,4)=blk_form2(k,2)+blk_form2(k,3);
% blk_form2(k,5)=blk_form2(k,2)-blk_form2(k,3);
% end
% 
% figure;
% subplot(3,1,1)
% hold on
% for i=1:size(blk_data2,2)
%     plot(blk_form2(:,1),smooth(blk_data2(:,i),5),'linewidth',0.5,'Color',[0.9 0.9 0.9],'LineWidth',0.5)
%     hold on
% end
% plot(blk_form2(:,1),smooth(blk_form2(:,2),5),'Color',[0 0 0],'LineWidth',2)
% hold on
% plot(blk_form2(:,1),smooth(blk_form2(:,4),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
% hold on
% plot(blk_form2(:,1),smooth(blk_form2(:,5),5),'Color',[0.5 0.5 0.5],'LineWidth',1.5)
% hold on
% line([0 0],[-20, 130],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[-20, 130],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[-20, 130],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([-20 130]);
% xlabel('Time (ms)');
% ylabel('Eyelid closure (%)');
% xticks([-250 0 250 500 1000]);
% yticks([0 100]);
% 
% subplot(3,1,2)
% hold on
% 
% for m=1:size(blk_data2,2)
%     hold on
%     Y=ones(length(list_mod.non(cell_num).all_info.ttt.CR_trial(m).spk_time),1)*m;
%     plot(list_mod.non(cell_num).all_info.ttt.CR_trial(m).spk_time*1000,Y,'k.')
% end
% line([0 0],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0, m],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0, m],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% xlim([-250 1000]);
% ylim([0 m]);
% xlabel('Time (ms)');
% ylabel('CR trial number');
% xticks([-250 0 250 500 1000]);
% yticks([0 10 20 30 40 50]);
% 
% subplot(3,1,3)
% plot(smth2(:,1),smth2(:,8),'k-','LineWidth',2)
% hold on
% plot(smth2(:,1),smth2(:,9),'Color',[0.5,0.5,0.5],'LineWidth',1.5)
% hold on
% plot(smth2(:,1),smth2(:,10),'Color',[0.5,0.5,0.5],'LineWidth',1.5)
% xlabel('Time (ms)');
% ylabel('Relative firing rate (%)');
% xlim([-250 1000])
% ylim([0 200]);
% line([0 0],[0,200],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([250 250],[0,200],'Color',[0.2941 0.4353 0.2667],'LineStyle','--','LineWidth',1.0);
% line([500 500],[0,200],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
% text(-150,175,'n = 147','Color','black','FontSize',10);
% xticks([-250 0 250 500 1000]);