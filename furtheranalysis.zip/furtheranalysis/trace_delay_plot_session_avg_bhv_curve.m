% plot session average behavior curve

file_bhv=blk_sss_D;
t_post=250;
t_pre=-550;
dur=1550;
bin=25;
step=5;

behavior_all=zeros((dur-bin)/step,size(file_bhv,2));
figure;
for i=1:size(file_bhv,2)
    blk_curve=smooth_curve(file_bhv(i).behavior_curve(:,1),file_bhv(i).behavior_curve(:,2)*100,bin,step);
    plot(blk_curve(:,1),blk_curve(:,2),'Color',[0.9 0.9 0.9],'LineWidth',1)
    hold on
    behavior_all(:,i)=blk_curve(:,2);   
end

behavior_pop=zeros((dur-bin)/step,5);
behavior_pop(:,1)=blk_curve(:,1);
behavior_pop(:,2)=mean(behavior_all,2);
behavior_pop(:,3)=std(behavior_all,1,2);
behavior_pop(:,4)=behavior_pop(:,2)+behavior_pop(:,3);
behavior_pop(:,5)=behavior_pop(:,2)-behavior_pop(:,3);
plot(behavior_pop(:,1),behavior_pop(:,2),'Color',[0 0 0],'LineWidth',2)
hold on
plot(behavior_pop(:,1),behavior_pop(:,4),'Color',[0.5 0.5 0.5],'LineWidth',2)
hold on
plot(behavior_pop(:,1),behavior_pop(:,5),'Color',[0.5 0.5 0.5],'LineWidth',2)
hold on
line([0 0],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([250 250],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[-10, 120],'Color',[0 0 0],'LineStyle','--','LineWidth',1.0);
xlim([-250 1000]);
ylim([-10 120]);
xlabel('Time (ms)');
ylabel('Eyelid closure (%)');
xticks([-250 0 250 500 1000]);
yticks([0 100]);




function smth_curve=smooth_curve(x,y,bin,step)
    smth_curve=zeros((length(x)-bin)/step,2);
    for i=1:(length(x)-bin)/step
        smth_curve(i,1)=x((i-1)*step+1);
        smth_curve(i,2)=mean(y((i-1)*step+1:(i-1)*step+bin));
    end
end