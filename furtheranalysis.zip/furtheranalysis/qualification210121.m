list_origion=trace_all_sim;

for i=1:size(mod_list_align,2)
    figure;
    plot(mod_list_align(i).align_info.psth_align(:,1),mod_list_align(i).align_info.psth_align(:,2))
    hold on
    if ~isempty(mod_list_align(i).align_info.CR_fac_align.t_onset_p)
       plot(mod_list_align(i).align_info.CR_fac_align.t_onset_p,mod_list_align(i).align_info.bsl_frq_align+3*mod_list_align(i).align_info.SD_align,'r*')
       hold on
    end
    if ~isempty(mod_list_align(i).align_info.CR_sup_align.t_onset_p)
       plot(mod_list_align(i).align_info.CR_sup_align.t_onset_p,mod_list_align(i).align_info.bsl_frq_align-3*mod_list_align(i).align_info.SD_align,'b*')
       hold on
    end
    xlim([-500 500]);
    xticks(-500:250:500);
    line([-500 500],[mod_list_align(i).align_info.bsl_frq_align+3*mod_list_align(i).align_info.SD_align mod_list_align(i).align_info.bsl_frq_align+3*mod_list_align(i).align_info.SD_align]);
    line([-500 500],[mod_list_align(i).align_info.bsl_frq_align-3*mod_list_align(i).align_info.SD_align mod_list_align(i).align_info.bsl_frq_align-3*mod_list_align(i).align_info.SD_align]);
    
    saveas(gcf,[['Cell-' num2str(mod_list_align(i).cell_ID) '-' num2str(mod_list_align(i).CR_fac) '-' num2str(mod_list_align(i).CR_sup)] '.jpg']);  
    close all

end