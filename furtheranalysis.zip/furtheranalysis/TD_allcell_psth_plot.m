% plot the PSTH curves from TD_list of all the neurons with TEC and DEC in one subplot figure. 
% red, facilitation; blue, suppression; black/grey, non-modulation. Shadow: TEC part; line: DEC part.--Zhong 
figure;

for k=1:35
subplot(7,5,k)
if TD_list(k).CR_fac_T > 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[1 0 0];
    h.FaceAlpha=0.3;
    hold on
elseif TD_list(k).CR_sup_T > 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 1];
    h.FaceAlpha=0.3;
    hold on
elseif TD_list(k).CR_fac_T == 0 && TD_list(k).CR_sup_T == 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 0];
    h.FaceAlpha=0.3;
    hold on   
end

if TD_list(k).CR_fac_D > 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'r-');
    hold on
elseif TD_list(k).CR_sup_D > 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'b-');
    hold on
elseif TD_list(k).CR_fac_D == 0 && TD_list(k).CR_sup_D == 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'k-');
    hold on   
end

plot(TD_list(k).all_info_T.sss_all.blk.CR_trial(:,1),TD_list(k).all_info_T.sss_all.blk.CR_trial(:,2)*100,'k--')
plot(TD_list(k).all_info_D.sss_all.blk.CR_trial(:,1),TD_list(k).all_info_D.sss_all.blk.CR_trial(:,2)*100,'k-.')

ymax1=max(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax2=max(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax=max(ymax1,ymax2)*1.05;
ymin1=min(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin2=min(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin=min(ymin1,ymin2)*0.95;
xlim([-250 750]);
ylim([0 ymax]);
xticks([-250 0 250 500 750]);
line([0 0],[0, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
line([250 250],[0, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
title(['Cell',num2str(TD_list(k).cell_ID),' ','T:',num2str(TD_list(k).CR_fac_T),'-',num2str(TD_list(k).CR_sup_T),'-',num2str(TD_list(k).UR_fac_T),'-',...
      num2str(TD_list(k).UR_sup_T),' ','D:',num2str(TD_list(k).CR_fac_D),'-',num2str(TD_list(k).CR_sup_D),'-',num2str(TD_list(k).UR_fac_D),'-',...
      num2str(TD_list(k).UR_sup_D),' Day',num2str(TD_list(k).Day)]);
end

figure;

for k=36:70
subplot(7,5,k-35)
if TD_list(k).CR_fac_T > 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[1 0 0];
    h.FaceAlpha=0.3;
    hold on
elseif TD_list(k).CR_sup_T > 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 1];
    h.FaceAlpha=0.3;
    hold on
elseif TD_list(k).CR_fac_T == 0 && TD_list(k).CR_sup_T == 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 0];
    h.FaceAlpha=0.3;
    hold on   
end

if TD_list(k).CR_fac_D > 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'r-');
    hold on
elseif TD_list(k).CR_sup_D > 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'b-');
    hold on
elseif TD_list(k).CR_fac_D == 0 && TD_list(k).CR_sup_D == 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'k-');
    hold on   
end

plot(TD_list(k).all_info_T.sss_all.blk.CR_trial(:,1),TD_list(k).all_info_T.sss_all.blk.CR_trial(:,2)*100,'k--')
plot(TD_list(k).all_info_D.sss_all.blk.CR_trial(:,1),TD_list(k).all_info_D.sss_all.blk.CR_trial(:,2)*100,'k-.')

ymax1=max(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax2=max(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax=max(ymax1,ymax2)*1.05;
ymin1=min(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin2=min(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin=min(ymin1,ymin2)*0.95;
xlim([-250 750]);
ylim([0 ymax]);
xticks([-250 0 250 500 750]);
line([0 0],[0, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
line([250 250],[0, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
title(['Cell',num2str(TD_list(k).cell_ID),' ','T:',num2str(TD_list(k).CR_fac_T),'-',num2str(TD_list(k).CR_sup_T),'-',num2str(TD_list(k).UR_fac_T),'-',...
      num2str(TD_list(k).UR_sup_T),' ','D:',num2str(TD_list(k).CR_fac_D),'-',num2str(TD_list(k).CR_sup_D),'-',num2str(TD_list(k).UR_fac_D),'-',...
      num2str(TD_list(k).UR_sup_D),' Day',num2str(TD_list(k).Day)]);
end

figure;

for k=71:101
subplot(7,5,k-70)
if TD_list(k).CR_fac_T > 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[1 0 0];
    h.FaceAlpha=0.3;
    hold on
elseif TD_list(k).CR_sup_T > 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 1];
    h.FaceAlpha=0.3;
    hold on
elseif TD_list(k).CR_fac_T == 0 && TD_list(k).CR_sup_T == 0
    h=area(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2),'LineStyle','none');
    h.FaceColor=[0 0 0];
    h.FaceAlpha=0.3;
    hold on   
end

if TD_list(k).CR_fac_D > 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'r-');
    hold on
elseif TD_list(k).CR_sup_D > 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'b-');
    hold on
elseif TD_list(k).CR_fac_D == 0 && TD_list(k).CR_sup_D == 0
    plot(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,1),TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2),'k-');
    hold on   
end

plot(TD_list(k).all_info_T.sss_all.blk.CR_trial(:,1),TD_list(k).all_info_T.sss_all.blk.CR_trial(:,2)*100,'k--')
plot(TD_list(k).all_info_D.sss_all.blk.CR_trial(:,1),TD_list(k).all_info_D.sss_all.blk.CR_trial(:,2)*100,'k-.')

ymax1=max(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax2=max(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymax=max(ymax1,ymax2)*1.05;
ymin1=min(TD_list(k).all_info_T.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin2=min(TD_list(k).all_info_D.sss_all.psth.CR_trial.psth_smooth(:,2));
ymin=min(ymin1,ymin2)*0.95;
xlim([-250 750]);
ylim([0 ymax]);
xticks([-250 0 250 500 750]);
line([0 0],[0, ymax],'Color',[0.2941 0.4353 0.2667],'LineStyle','-','LineWidth',1.0);
line([250 250],[0, ymax],'Color',[1 0 0],'LineStyle','--','LineWidth',1.0);
line([500 500],[0, ymax],'Color',[1 0 0],'LineStyle','-','LineWidth',1.0);
title(['Cell',num2str(TD_list(k).cell_ID),' ','T:',num2str(TD_list(k).CR_fac_T),'-',num2str(TD_list(k).CR_sup_T),'-',num2str(TD_list(k).UR_fac_T),'-',...
      num2str(TD_list(k).UR_sup_T),' ','D:',num2str(TD_list(k).CR_fac_D),'-',num2str(TD_list(k).CR_sup_D),'-',num2str(TD_list(k).UR_fac_D),'-',...
      num2str(TD_list(k).UR_sup_D),' Day',num2str(TD_list(k).Day)]);
end


