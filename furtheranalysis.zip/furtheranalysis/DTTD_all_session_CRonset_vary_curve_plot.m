sss_list_1=TD_blk_sss;
sss_list_2=TD_blk_sss_PFC;
session_1='T';
session_2='D';
ymax=120;
ymin=60;
idx_sss_list=2;   % 2=norm CR onset/prb CR pkt; 7=norm CR pkt;

bsl_epoch=['normCR_info_' session_1];
CR_data_D='normCR_info_D';
CR_data_T='normCR_info_T';
sz_1=['sz_' session_1];
sz_2=['sz_' session_2];
trial_info_1=['trial_info_' session_1];
trial_info_2=['trial_info_' session_2];

single_session_list=struct('session_ID',[],'file_name',[],'bsl_onset',[],'trial_info_D',[],'trial_info_T',[],'sz_D',[],'sz_T',[],'s1_all',[],'s2_1',[],'s2_2',[],'s2_3',[],'s2_4',[]);
session_idx=0;
for i=1:size(sss_list_1,2)
    session_idx=session_idx+1;
    single_session_list(session_idx).session_ID=session_idx;
    single_session_list(session_idx).file_name=sss_list_1(i).session_path;    
    
    sss_list_1(i).(CR_data_D)(any(isnan(sss_list_1(i).(CR_data_D)), 2), :) = [];
    sss_list_1(i).(CR_data_T)(any(isnan(sss_list_1(i).(CR_data_T)), 2), :) = [];
    
    single_session_list(session_idx).bsl_onset=nanmean(sss_list_1(i).(bsl_epoch)(:,idx_sss_list));
    trial_info_D=zeros(size(sss_list_1(i).(CR_data_D),1),5);
    trial_info_T=zeros(size(sss_list_1(i).(CR_data_T),1),5);
    
    for j=1:size(sss_list_1(i).(CR_data_D),1)
        trial_info_D(j,1)=j;
        trial_info_D(j,2)=j-size(sss_list_1(i).(CR_data_D),1);
        trial_info_D(j,3)=sss_list_1(i).(CR_data_D)(j,idx_sss_list);
        trial_info_D(j,4)=sss_list_1(i).(CR_data_D)(j,idx_sss_list)/single_session_list(session_idx).bsl_onset*100;
    end
    p_D=polyfit(trial_info_D(:,2),trial_info_D(:,4),1);
    regression_D=p_D(1)*trial_info_D(:,2)+p_D(2);
    trial_info_D(:,5)=regression_D;  
    single_session_list(session_idx).trial_info_D=trial_info_D;
    single_session_list(session_idx).sz_D=size(trial_info_D,1);
    
    for j=1:size(sss_list_1(i).(CR_data_T),1)
        trial_info_T(j,1)=j;
        trial_info_T(j,2)=j-size(sss_list_1(i).(CR_data_T),1);
        trial_info_T(j,3)=sss_list_1(i).(CR_data_T)(j,idx_sss_list);
        trial_info_T(j,4)=sss_list_1(i).(CR_data_T)(j,idx_sss_list)/single_session_list(session_idx).bsl_onset*100; 
    end
    p_T=polyfit(trial_info_T(:,2),trial_info_T(:,4),1);
    regression_T=p_T(1)*trial_info_T(:,2)+p_T(2);
    trial_info_T(:,5)=regression_T;          
    single_session_list(session_idx).trial_info_T=trial_info_T;
    single_session_list(session_idx).sz_T=size(trial_info_T,1);   
    single_session_list(session_idx).s1_all=nanmean(single_session_list(session_idx).(trial_info_1)(:,4));
    split_idx=quantile(1:1:single_session_list(session_idx).(sz_2),[0.25 0.5 0.75]);
    single_session_list(session_idx).s2_1=nanmean(single_session_list(session_idx).(trial_info_2)(1:floor(split_idx(1)),4));
    single_session_list(session_idx).s2_2=nanmean(single_session_list(session_idx).(trial_info_2)(floor(split_idx(1))+1:floor(split_idx(2)),4));
    single_session_list(session_idx).s2_3=nanmean(single_session_list(session_idx).(trial_info_2)(floor(split_idx(2))+1:floor(split_idx(3)),4));
    single_session_list(session_idx).s2_4=nanmean(single_session_list(session_idx).(trial_info_2)(floor(split_idx(3))+1:end,4));
end

if ~isempty(sss_list_2)
    for i=1:size(sss_list_2,2)
        session_idx=session_idx+1;
        single_session_list(session_idx).session_ID=session_idx;
        single_session_list(session_idx).file_name=sss_list_2(i).session_path;    
        
        sss_list_2(i).(CR_data_D)(any(isnan(sss_list_2(i).(CR_data_D)), 2), :) = [];
        sss_list_2(i).(CR_data_T)(any(isnan(sss_list_2(i).(CR_data_T)), 2), :) = [];
        
        single_session_list(session_idx).bsl_onset=nanmean(sss_list_2(i).(bsl_epoch)(:,idx_sss_list));
        trial_info_D=zeros(size(sss_list_2(i).(CR_data_D),1),5);
        trial_info_T=zeros(size(sss_list_2(i).(CR_data_T),1),5);

        for j=1:size(sss_list_2(i).(CR_data_D),1)
            trial_info_D(j,1)=j;
            trial_info_D(j,2)=j-size(sss_list_2(i).(CR_data_D),1);
            trial_info_D(j,3)=sss_list_2(i).(CR_data_D)(j,idx_sss_list);
            trial_info_D(j,4)=sss_list_2(i).(CR_data_D)(j,idx_sss_list)/single_session_list(session_idx).bsl_onset*100; 
        end
        p_D=polyfit(trial_info_D(:,2),trial_info_D(:,4),1);
        regression_D=p_D(1)*trial_info_D(:,2)+p_D(2);
        trial_info_D(:,5)=regression_D;  
        single_session_list(session_idx).trial_info_D=trial_info_D;
        single_session_list(session_idx).sz_D=size(trial_info_D,1);
        
        for j=1:size(sss_list_2(i).(CR_data_T),1)
            trial_info_T(j,1)=j;
            trial_info_T(j,2)=j-size(sss_list_2(i).(CR_data_T),1);
            trial_info_T(j,3)=sss_list_2(i).(CR_data_T)(j,idx_sss_list);
            trial_info_T(j,4)=sss_list_2(i).(CR_data_T)(j,idx_sss_list)/single_session_list(session_idx).bsl_onset*100;    
        end
        p_T=polyfit(trial_info_T(:,2),trial_info_T(:,4),1);
        regression_T=p_T(1)*trial_info_T(:,2)+p_T(2);
        trial_info_T(:,5)=regression_T;   
        single_session_list(session_idx).trial_info_T=trial_info_T;
        single_session_list(session_idx).sz_T=size(trial_info_T,1);
        single_session_list(session_idx).s1_all=nanmean(single_session_list(session_idx).(trial_info_1)(:,4));
        split_idx=quantile(1:1:single_session_list(session_idx).(sz_2),[0.25 0.5 0.75]);
        single_session_list(session_idx).s2_1=nanmean(single_session_list(session_idx).(trial_info_2)(1:floor(split_idx(1)),4));
        single_session_list(session_idx).s2_2=nanmean(single_session_list(session_idx).(trial_info_2)(floor(split_idx(1))+1:floor(split_idx(2)),4));
        single_session_list(session_idx).s2_3=nanmean(single_session_list(session_idx).(trial_info_2)(floor(split_idx(2))+1:floor(split_idx(3)),4));
        single_session_list(session_idx).s2_4=nanmean(single_session_list(session_idx).(trial_info_2)(floor(split_idx(3))+1:end,4));
    end                
end

sz_mean_1=ceil(nanmean([single_session_list.(sz_1)]));
sz_mean_2=ceil(nanmean([single_session_list.(sz_2)]));

all_trial_list=nan(size(single_session_list,2),sz_mean_1+sz_mean_2);
for i=1:size(single_session_list,2)
    for j=1:single_session_list(i).(sz_1)
        slot_idx=sz_mean_1-j+1;
        all_trial_list(i,slot_idx)=single_session_list(i).(trial_info_1)(end-j+1,4); 
        if j==sz_mean_1
            break
        end
    end
    for j=1:single_session_list(i).(sz_2)
        slot_idx=sz_mean_1+j;
        all_trial_list(i,slot_idx)=single_session_list(i).(trial_info_2)(j,4);         
        if j==sz_mean_2
            break
        end 
    end
end

all_trial_curve=zeros(6,sz_mean_1+sz_mean_2);
all_trial_curve(1,:)=1:1:sz_mean_1+sz_mean_2;
all_trial_curve(2,:)=nanmean(all_trial_list,1);
all_trial_curve(3,:)=nanstd(all_trial_list,0,1);
all_trial_curve(4,:)=sum(~isnan(all_trial_list),1);
all_trial_curve(5,:)=all_trial_curve(2,:)+all_trial_curve(3,:)/sqrt(all_trial_curve(4,:));
all_trial_curve(6,:)=all_trial_curve(2,:)-all_trial_curve(3,:)/sqrt(all_trial_curve(4,:));

figure;
plot(all_trial_curve(1,:),smooth(all_trial_curve(2,:)),'k-')
hold on
plot(all_trial_curve(1,:),smooth(all_trial_curve(5,:)),'-','Color',[0.5 0.5 0.5])
hold on
plot(all_trial_curve(1,:),smooth(all_trial_curve(6,:)),'-','Color',[0.5 0.5 0.5])
hold on
line([sz_mean_1+0.5 sz_mean_1+0.5],[ymin ymax],'LineStyle','--','Color',[0 0 0])
xlim([0 sz_mean_1+sz_mean_2]);
ylim([ymin ymax]);
xticks([sz_mean_1 sz_mean_1+sz_mean_2]);
xlabel('Corr. trial number');
ylabel('Norm. CR onset');

