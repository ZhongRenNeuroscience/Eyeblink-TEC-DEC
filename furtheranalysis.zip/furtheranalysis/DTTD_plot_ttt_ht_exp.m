path=DT_list;
tp='fac';
cell_ID=2;

if contains('fac',tp)
tpD=ttt_fac_D;
tpT=ttt_fac_T;
elseif contains('sup',tp)
tpD=ttt_sup_D;
tpT=ttt_sup_T;
end
idD=find([tpD.cell_ID]==cell_ID);
idT=find([tpT.cell_ID]==cell_ID);

if contains('fac',tp)
    figure;
    subplot(2,3,1)
    plot(tpD(idD).ttt(:,3),tpD(idD).ttt(:,4),'g-')
    hold on
    plot(tpT(idT).ttt(:,3),tpT(idT).ttt(:,4),'k-')
    hold on
    xlabel('Mod amp');
    ylabel('CR amp');

    all_info='all_info_D';
    t_find=250;
    tp=tpD;
    id=idD;
    subplot(2,3,2)
    cell=find([path.cell_ID]==cell_ID);
    amp=tp(id).ttt(:,3);
    [~,idx]=sort(amp);

    ifr=zeros(length(amp),t_find+1);
    blk=zeros(length(amp),t_find+1);
    for j=1:length(amp)
        kk=tp(id).ttt(idx(j),1);
        k=find([path(cell).(all_info).ttt.CR_trial.trial_num]==kk);
        ifr(j,:)=path(cell).(all_info).ttt.CR_trial(k).ifr_smooth(541:541+t_find,3)';
        blk(j,:)=path(cell).(all_info).ttt.CR_trial(k).blk_smth(551:551+t_find,2)';   
    end
    h=heatmap(ifr,'GridVisible','off','Colormap',hot);
    h.ColorLimits = [1 5];

    subplot(2,3,3)
    h=heatmap(blk,'GridVisible','off','Colormap',hot);
    h.ColorLimits = [0.02 0.3];

    all_info='all_info_T';
    t_find=500;
    tp=tpT;
    id=idT;
    subplot(2,3,4)
    amp=tp(id).ttt(:,3);
    [~,idx]=sort(amp);

    ifr=zeros(length(amp),t_find+1);
    blk=zeros(length(amp),t_find+1);
    for j=1:length(amp)
        kk=tp(id).ttt(idx(j),1);
        k=find([path(cell).(all_info).ttt.CR_trial.trial_num]==kk);
        ifr(j,:)=path(cell).(all_info).ttt.CR_trial(k).ifr_smooth(541:541+t_find,3)';
        blk(j,:)=path(cell).(all_info).ttt.CR_trial(k).blk_smth(551:551+t_find,2)';   
    end
    h=heatmap(ifr,'GridVisible','off','Colormap',hot);
    h.ColorLimits = [1 5];

    subplot(2,3,5)
    h=heatmap(blk,'GridVisible','off','Colormap',hot);
    h.ColorLimits = [0.02 0.3];

elseif contains('sup',tp)
    figure;
    subplot(2,3,1)
    plot(-tpD(idD).ttt(:,3),tpD(idD).ttt(:,4),'g-')
    hold on
    plot(-tpT(idT).ttt(:,3),tpT(idT).ttt(:,4),'k-')
    hold on
    xlabel('Mod amp');
    ylabel('CR amp')

    all_info='all_info_D';
    t_find=250;
    tp=tpD;
    id=idD;
    
    map=[0,0,0
0,0,0.025
0,0,0.05
0,0,0.075
0,0,0.1
0,0,0.125
0,0,0.15
0,0,0.175
0,0,0.2
0,0,0.225
0,0,0.25
0,0,0.275
0,0,0.3
0,0,0.325
0,0,0.35
0,0,0.375
0,0,0.4
0,0,0.425
0,0,0.45
0,0,0.475
0,0,0.5
0,0,0.525
0,0,0.55
0,0,0.575
0,0,0.6
0,0,0.625
0,0,0.65
0,0,0.675
0,0,0.7
0,0,0.725
0,0,0.75
0,0,0.775
0,0,0.8
0,0,0.825
0,0,0.85
0,0,0.875
0,0,0.9
0,0,0.925
0,0,0.95
0,0,0.975
0,0,1
0.025,0.025,1
0.05,0.05,1
0.075,0.075,1
0.1,0.1,1
0.125,0.125,1
0.15,0.15,1
0.175,0.175,1
0.2,0.2,1
0.225,0.225,1
0.25,0.25,1
0.275,0.275,1
0.3,0.3,1
0.325,0.325,1
0.35,0.35,1
0.375,0.375,1
0.4,0.4,1
0.425,0.425,1
0.45,0.45,1
0.475,0.475,1
0.5,0.5,1
0.525,0.525,1
0.55,0.55,1
0.575,0.575,1
0.6,0.6,1
0.625,0.625,1
0.65,0.65,1
0.675,0.675,1
0.7,0.7,1
0.725,0.725,1
0.75,0.75,1
0.775,0.775,1
0.8,0.8,1
0.825,0.825,1
0.85,0.85,1
0.875,0.875,1
0.9,0.9,1 
0.925,0.925,1
0.95,0.95,1
0.975,0.975,1
1,1,1];
    
    subplot(2,3,2)
    cell=find([path.cell_ID]==cell_ID);
    amp=tp(id).ttt(:,3);
    [~,idx]=sort(amp);

    ifr=zeros(length(amp),t_find+1);
    blk=zeros(length(amp),t_find+1);
    for j=1:length(amp)
        kk=tp(id).ttt(idx(j),1);
        k=find([path(cell).(all_info).ttt.CR_trial.trial_num]==kk);
        ifr(length(amp)-j+1,:)=path(cell).(all_info).ttt.CR_trial(k).ifr_smooth(541:541+t_find,3)';
        blk(length(amp)-j+1,:)=path(cell).(all_info).ttt.CR_trial(k).blk_smth(551:551+t_find,2)';   
    end
    h=heatmap(1-ifr,'GridVisible','off','Colormap',map);
    h.ColorLimits = [0.25 1];

    subplot(2,3,3)
    h=heatmap(blk,'GridVisible','off','Colormap',map);
    h.ColorLimits = [0.02 0.3];

    all_info='all_info_T';
    t_find=500;
    tp=tpT;
    id=idT;
    subplot(2,3,4)
    amp=tp(id).ttt(:,3);
    [~,idx]=sort(amp);

    ifr=zeros(length(amp),t_find+1);
    blk=zeros(length(amp),t_find+1);
    for j=1:length(amp)
        kk=tp(id).ttt(idx(j),1);
        k=find([path(cell).(all_info).ttt.CR_trial.trial_num]==kk);
        ifr(length(amp)-j+1,:)=path(cell).(all_info).ttt.CR_trial(k).ifr_smooth(541:541+t_find,3)';
        blk(length(amp)-j+1,:)=path(cell).(all_info).ttt.CR_trial(k).blk_smth(551:551+t_find,2)';   
    end
    h=heatmap(1-ifr,'GridVisible','off','Colormap',map);
    h.ColorLimits = [0.25 1];

    subplot(2,3,5)
    h=heatmap(blk,'GridVisible','off','Colormap',map);
    h.ColorLimits = [0.02 0.3];
end