blk_sss_file=blk_sss_trace;
t_post=500;
sample_num=5;

%% velocity detection
% curve_type='velocity_curve';
% bsl_peak_v=nan(300*sample_num,size(blk_sss_file,2));
% CR_peak_v=nan(300*sample_num,size(blk_sss_file,2));
% CR_max_v=nan(300,size(blk_sss_file,2));
% 
% % figure;
% 
% for i=1:size(blk_sss_file,2)
%     t_0=find(blk_sss_file(i).behavior_curve_trial(1).(curve_type)(:,1)<=0,1,'last');
%     t_end=find(blk_sss_file(i).behavior_curve_trial(1).(curve_type)(:,1)<=t_post,1,'last');
%     
%     for j=1:size(blk_sss_file(i).behavior_curve_trial,2)
%         jdx=(j-1)*sample_num+1;
%         bsl_peak_v(jdx:jdx+sample_num-1,i)=maxk(blk_sss_file(i).behavior_curve_trial(j).(curve_type)(1:t_0,2),sample_num);
% %         scatter(ones(1,sample_num),bsl_peak_v(jdx:jdx+sample_num-1,i))
% %         hold on
%         
%         [~,CRonset_t]=min(abs(blk_sss_file(i).behavior_curve_trial(j).(curve_type)(:,1)-blk_sss_file(i).behavior_info(j,2)));
%         CR_peak_v(jdx:jdx+sample_num-1,i)=blk_sss_file(i).behavior_curve_trial(j).(curve_type)(CRonset_t-floor(sample_num/2):CRonset_t+floor(sample_num/2),2);
% 
%         for k=1:floor(sample_num/2)+1
%             if blk_sss_file(i).behavior_curve_trial(j).(curve_type)(CRonset_t+k-1,1)>t_post
%                 CR_peak_v(jdx+1+k,i)=nan;
%             end
%         end 
% %         scatter(ones(1,sample_num)*2,CR_peak_v(jdx:jdx+sample_num-1,i))
% %         hold on
%         
%         CR_max_v(j,i)=max(blk_sss_file(i).behavior_curve_trial(j).(curve_type)(t_0+1:t_end,2));
% %         scatter(3,CR_max_v(j,i))
% %         hold on
%     end
% end
% 
% % xlim([0 4]);
% % xticks(1:1:3);
% 
% bsl_v_per=prctile(bsl_peak_v,70:5:95,'all');
% CRpeak_v_per=prctile(CR_max_v,5:5:30,'all');

%% CR amp detection
curve_type='blk_curve';
bsl_peak_amp=nan(300*sample_num,size(blk_sss_file,2));
CR_onset_amp=nan(300*sample_num,size(blk_sss_file,2));
CR_max_amp=nan(300,size(blk_sss_file,2));

% figure;

for i=1:size(blk_sss_file,2)
    t_0=find(blk_sss_file(i).behavior_curve_trial(1).(curve_type)(:,1)<=0,1,'last');
    t_end=find(blk_sss_file(i).behavior_curve_trial(1).(curve_type)(:,1)<=t_post,1,'last');
    
    for j=1:size(blk_sss_file(i).behavior_curve_trial,2)
        jdx=(j-1)*sample_num+1;
        bsl_peak_amp(jdx:jdx+sample_num-1,i)=maxk(blk_sss_file(i).behavior_curve_trial(j).(curve_type)(1:t_0,2),sample_num);
%         scatter(ones(1,sample_num),bsl_peak_v(jdx:jdx+sample_num-1,i))
%         hold on
        
        [~,CRonset_t]=min(abs(blk_sss_file(i).behavior_curve_trial(j).(curve_type)(:,1)-blk_sss_file(i).behavior_info(j,2)));
        CR_onset_amp(jdx:jdx+sample_num-1,i)=blk_sss_file(i).behavior_curve_trial(j).(curve_type)(CRonset_t-floor(sample_num/2):CRonset_t+floor(sample_num/2),2);

        for k=1:floor(sample_num/2)+1
            if blk_sss_file(i).behavior_curve_trial(j).(curve_type)(CRonset_t+k-1,1)>t_post
                CR_onset_amp(jdx+1+k,i)=nan;
            end
        end 
%         scatter(ones(1,sample_num)*2,CR_peak_v(jdx:jdx+sample_num-1,i))
%         hold on
        
        CR_max_amp(j,i)=max(blk_sss_file(i).behavior_curve_trial(j).(curve_type)(t_0+1:t_end,2));
%         scatter(3,CR_max_v(j,i))
%         hold on
    end
end

% xlim([0 4]);
% xticks(1:1:3);

bsl_amp_per=prctile(bsl_peak_amp,70:5:95,'all');
CRpeak_amp_per=prctile(CR_max_amp,5:5:30,'all');
