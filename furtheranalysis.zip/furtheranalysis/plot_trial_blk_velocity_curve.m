blk_sss_file=blk_sss_delay;
session_id=41;
curve_type_1='blk_curve';    % 'blk_curve'   'velocity_curve'
curve_type_2='velocity_curve';
figure_switch=1:24:999;

figure_num=0;
row_num=ceil(size(blk_sss_file(session_id).behavior_curve_trial,2)/6);
for i=1:size(blk_sss_file(session_id).behavior_curve_trial,2)
    if ismember(i,figure_switch)
        figure;
        figure_num=figure_num+1;
    end   
        subplot(4,6,i-(figure_num-1)*24)

        plot(blk_sss_file(session_id).behavior_curve_trial(i).(curve_type_1)(:,1),blk_sss_file(session_id).behavior_curve_trial(i).(curve_type_1)(:,2))
        hold on
        plot(blk_sss_file(session_id).behavior_info(i,2),0,'b*')
        hold on

        plot(blk_sss_file(session_id).behavior_curve_trial(i).(curve_type_2)(:,1),blk_sss_file(session_id).behavior_curve_trial(i).(curve_type_2)(:,2)*100)
        hold on
        if ~isnan(blk_sss_file(session_id).behavior_info(i,10))
            plot(blk_sss_file(session_id).behavior_info(i,10),0,'r*')
            hold on        
        end
        if ~isnan(blk_sss_file(session_id).behavior_info(i,11))
            plot(blk_sss_file(session_id).behavior_info(i,11),0,'g*')
            hold on        
        end
        xlim([-500 1000]);
    
end

%% for adaptation

% % blk_sss_file=DT_blk_sss;
% % session_id=25;
% % trial_type='behavior_curve_trial_D';
% % behavior_info='normCR_info_D';
% % curve_type_1='blk_curve';    % 'blk_curve'   'velocity_curve'
% % curve_type_2='velocity_curve';
% % figure_switch=1:24:999;
% % 
% % figure_num=0;
% % row_num=ceil(size(blk_sss_file(session_id).(trial_type).norm_trial,2)/6);
% % for i=1:size(blk_sss_file(session_id).(trial_type).norm_trial,2)
% %     if ismember(i,figure_switch)
% %         figure;
% %         figure_num=figure_num+1;
% %     end   
% %         subplot(4,6,i-(figure_num-1)*24)
% % 
% %         plot(blk_sss_file(session_id).(trial_type).norm_trial(i).(curve_type_1)(:,1),blk_sss_file(session_id).(trial_type).norm_trial(i).(curve_type_1)(:,2))
% %         hold on
% %         plot(blk_sss_file(session_id).(behavior_info)(i,2),0,'b*')
% %         hold on
% % 
% %         plot(blk_sss_file(session_id).(trial_type).norm_trial(i).(curve_type_2)(:,1),blk_sss_file(session_id).(trial_type).norm_trial(i).(curve_type_2)(:,2)*100)
% %         hold on
% %         xlim([-500 1000]);
% %     
% % end